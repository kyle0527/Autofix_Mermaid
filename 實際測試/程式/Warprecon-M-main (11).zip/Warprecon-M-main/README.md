# Warprecon-M

[English README](README_EN.md)

可擴充的多協定漏洞掃描器，設計用於 CI 快速掃描與研究情境。
採模組化流程與外掛系統，10 分鐘內即可部署並產出報告。
支援 HTTP/gRPC/OpenAPI 等協定，並以 Scorecard 度量結果。

## 快速開始
1. 使用安裝腳本準備虛擬環境並載入套件：
   ```bash
   ./scripts/install.sh --dev
   source .venv/bin/activate
   ```
   - `--dev` 會安裝測試與靜態分析所需的 extras，可改用 `--extras dom,grpc` 精簡依賴。
   - 若執行環境沒有 root 權限，可加上 `--skip-playwright` 再手動安裝瀏覽器。
2. 使用 CLI 設定精靈產生專案設定檔：
   ```bash
   warprecon-m configure campaign --target https://target.example --output config/campaign.local.yaml
   warprecon-m configure accounts --output config/accounts.local.yaml
   ```
   - 按照提示填入預設帳號池與權限偏好，生成的 YAML 可透過 `make m0 CFG=config/campaign.local.yaml` 或環境變數直接套用。
   - 若已有現成設定，可略過此步驟並使用既有的 `campaign.yaml` / `accounts.yaml`。
   - `accounts.yaml` 支援 `${ENV_VAR:default}` 樣式的環境變數占位符，可避免將密碼或 Token 寫入版本庫。
3. 一鍵執行 M0→M3：
   ```bash
   make m0 m1 m2 m3 WORKDIR=work/run1 DOMAIN=https://target.example
   ```
   > 提示：`warprecon-m pipeline` 現已自動執行 gRPC 反射枚舉與 HTTP Misconfig 檢查，並輸出 `ranked.merged.json` 及 `ranked.final.json`。可透過 `--gate-threshold` 與 `--gate-topn` 調整 Precision Gate 的分數門檻與 Top-N。
4. 檢視輸出：`work/run1/report_v2.html`、`work/run1/out.sarif`、`work/run1/deliverable.zip`

### Docker Compose 快速啟動

```bash
docker compose -f deploy/docker-compose.yml up --build
```

- 預設會啟動 UI、Agent 與 Interactsh OOB 服務，並透過 `bootstrap` 容器跑一次 pipeline 產生 HTML/SARIF/ZIP。
- 透過 `WARPRECON_BOOTSTRAP_DOMAIN=https://demo.example` 覆寫第一次掃描的目標，或設定 `WARPRECON_SKIP_BOOTSTRAP=1` 略過預熱。
- 工作目錄持久化於 `warprecon-data` volume，可重複掛載並由 UI 直接載入。

## 常用指令
| 指令 | 說明 |
| --- | --- |
| `make bootstrap` | 安裝依賴並執行 pip-audit/容器安全檢查 |
| `make m0 WORKDIR=... DOMAIN=...` | 基礎掃描並產出初步報告 |
| `pytest -q` | 單元與整合測試 |
| `python scripts/scorecard.py work/run1` | 計算 Scorecard 分數 |

## 成果物一覽
- `report_v2.html`：圖表化報告
- `out.sarif`：SARIF 格式輸出
- `deliverable.zip`：所有 artifacts 打包

## 專案結構與模組角色
```text
src/
├─ op_core/     # 掌管 M0→M3 流程與排名
├─ op_proto/    # 協定探測器（HTTP/gRPC/OpenAPI）
├─ op_output/   # 報告與 artifacts 產生器
└─ op_plugins/  # 外掛檢查器與擴充點
```
> 詳細架構與 I/O 契約請見 [docs/ARCH.md](docs/ARCH.md)

## 常見問題
1. **找不到 command `warprecon-m`？**
   - 確認已安裝並在虛擬環境中執行。
   - 全新的 Typer 版 CLI 支援 `warprecon-m --help`，可檢視所有子指令與說明。
2. **沒有產生 `out.sarif`？**
   - 檢查 `make m0` 是否成功執行，並確認 `work/run1` 目錄存在。
3. **Scorecard 低於門檻？**
   - 重新檢查 `ranked.final.json` 是否完整，或調整掃描設定。
4. **gRPC 枚舉失敗？**
   - 目標可能未開啟 reflection，請提供 proto 檔或略過 M1。
5. **如何追蹤度量？**
   - 參閱 `work/run1/metrics.jsonl`（或最新快照 `metrics.json`）中的 `ttfp` 與 `hits`。
6. **UI API 401 Unauthorized？**
   - UI 介面已預設啟用 Token 驗證，可透過 `warprecon-m ui --auth-token <token>` 指定，或設定環境變數 `WARPRECON_UI_TOKEN`（逗號分隔多組）。
   - 後端與 CLI 呼叫 `/api/*` 時需帶上 `Authorization: Bearer <token>`，瀏覽器端會在首次載入時提示輸入 Token。

## 開發品質檢查建議
為避免合併後殘留衝突標記或重複定義，建議在每次合併、rebase 或大量 refactor 完成後執行以下步驟：

1. **掃描衝突標記**：
   ```bash
   rg --hidden --glob '!*.pyc' '<<<<<<<|=======|>>>>>>>'
   ```
   快速找出 `<<<<<<<` 等衝突字串，避免遺漏未處理區段。
2. **靜態語法驗證**：
   ```bash
   python -m compileall src
   ```
   對整個 `src/` 編譯，可提前發現縮排或語法錯誤。
3. **完整測試**：
   ```bash
   pytest
   ```
   若 CI 或本地設定預設加上 `--cov` 但缺少模組，可暫時使用 `pytest -o addopts=''` 作為替代，確認測試行為是否正常。

將以上檢查流程納入開發慣例，可在最短時間內攔截殘留的衝突片段與重複程式碼，避免再次影響匯入或測試。

## GraphQL 探測強化
- 透過 `op_proto.graphql.schema` 解析 introspection schema，針對 Query/Mutation/Subscription 自動產生帶變數的操作，並依欄位的必填/可為空狀態調整型別宣告。
- `UNION` 與 `INTERFACE` 會自動產出 inline fragment，遞迴深度由 `limits.graphql_max_depth` 控制，預設為 3 層。
- 新增 `limits.graphql_budget` 控制每個 GraphQL 端點的查詢預算，可透過 YAML 或 `OP_LIMITS__GRAPHQL_BUDGET` 覆寫，避免測試造成額外負載。

## RateLimiter 穩定度調校
- `run_hunt(..., workdir=...)` 會在工作目錄維護 `limiter_state.json`，下次執行時自動載入共享退避，避免多輪掃描重新踩到同一批封鎖。
- `RateLimiter.update_from_response()` 會依 HTTP 狀態碼與延遲自動微調 `global_rps`、`per_host_rps`，掃描器內建的 HTTP/GraphQL/WebSocket 引擎已回傳 `_status`、`_latency` 訊號，無須額外設定即可生效。
- 需要重置時刪除 `limiter_state.json`；如需客製調整策略，可從 `limiter_state.json` 觀察每個 host 的桶狀資訊再呼叫 API 調整。

## 連結
- [操作流程 Runbook](docs/OPERATION.md)
- [架構與介面](docs/ARCH.md)
- [外掛 Hooks 指南](docs/ARCH.md#plugin-hooks)
- [版本變更](CHANGELOG.md)
