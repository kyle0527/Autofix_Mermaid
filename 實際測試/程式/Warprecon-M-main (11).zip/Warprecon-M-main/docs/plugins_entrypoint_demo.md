# Entry Point Plugin Demo

此範例展示如何將外掛封裝成套件，並透過 `warprecon_m.plugins`
entry point 讓 Warprecon-M 自動載入。範例套件位於
`ext/plugins/examples/warprecon_m_demo_plugin/`，提供三個 hooks：
`vector_probe`、`post_rank` 與 `artifact_exporter`。

## 安裝步驟

1. 在專案根目錄執行：
   ```bash
   pip install ./ext/plugins/examples/warprecon_m_demo_plugin
   ```
2. 執行 Warprecon-M 任務或在 REPL 中呼叫：
   ```python
   from pathlib import Path
   from op_plugins.loader import load_plugins

   hooks = load_plugins(Path("work/demo"))
   ```
3. 取得的 hooks 會包含 `entrypoint_demo` 相關的函式，例如：
   ```python
   for probe in hooks.get("vector_probe", []):
       print(probe.__module__, probe.__name__)
   ```

若流程順利，`artifact_exporter` 會在工作目錄產生
`plugins/entrypoint_demo.txt`，確認外掛已載入。
