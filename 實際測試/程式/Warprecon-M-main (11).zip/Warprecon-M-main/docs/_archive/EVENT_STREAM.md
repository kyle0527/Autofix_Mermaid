已合併到 docs/ARCH.md，僅供歷史參考

# EVENT_STREAM — 事件流與工單模板
- 事件：run.start/run.retry/run.end/finding/error
- 工單：Jira/GitLab 模板以 JSONL/JSON 形式輸出，後續由外部腳本發送。