⚠️ 此文件已合併至 docs/ARCH.md，僅供歷史參考。

原 API 細節已併入 docs/ARCH.md 並回歸各模組 docstring。
