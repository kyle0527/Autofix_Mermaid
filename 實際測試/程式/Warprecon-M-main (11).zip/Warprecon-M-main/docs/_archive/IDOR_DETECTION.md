已合併到 docs/ARCH.md，僅供歷史參考

# IDOR Detection MVP - Usage Guide

This document describes how to use the IDOR (Insecure Direct Object References) detection functionality in Warprecon-M.

## Overview

The IDOR Detection MVP provides comprehensive unauthorized access testing by:

- **Session Management**: Automatically manages different user role sessions (admin, user, anonymous)
- **ID Variant Generation**: Extracts IDs from URLs and generates test variants
- **Request Replay**: Systematically tests endpoints with different authentication contexts
- **Vulnerability Detection**: Identifies multiple types of authorization issues

## Vulnerability Types Detected

1. **Unauthorized Access** (High): Protected resources accessible with modified IDs
2. **Authorization Bypass** (Critical): Sensitive data accessible without authentication  
3. **Privilege Escalation** (High): User roles accessing admin-level content
4. **Information Disclosure** (Medium): Different content accessible through ID manipulation

## Usage

### 1. Direct CLI Command

```bash
# Test specific endpoints for IDOR vulnerabilities
warprecon-m checks --check idor --apis endpoints.json --out findings.jsonl

# Test a single URL
warprecon-m checks --check idor --apis "https://example.com/api/users/123" --out findings.jsonl

# Include working directory for session data
warprecon-m checks --check idor --apis endpoints.json --workdir ./work --out findings.jsonl
```

### 2. Using Scripts

```bash
# Run IDOR check using the standalone script
python scripts/run_checks.py --in endpoints.json --checks idor --out findings.jsonl
```

### 3. Programmatic Usage

```python
from op_checks.idor import IdorCheck

# Initialize check
check = IdorCheck()

# Define test endpoints
endpoints = [
    "https://example.com/api/users/123",
    "https://example.com/documents/456", 
    "https://example.com/api/resource?id=789"
]

# Run detection
findings = list(check.run(apis=endpoints))

# Process results
for finding in findings:
    print(f"{finding.severity.upper()}: {finding.title}")
    print(f"Target: {finding.target}")
    print(f"Detail: {finding.detail}")
```

## Configuration

### Campaign Configuration

Add IDOR settings to your `campaign.yaml`:

```yaml
idor:
  enabled: true
  max_variants_per_id: 10
  test_roles: ["admin", "user", "anonymous"]
  session_config:
    admin:
      headers: {"X-User-Role": "admin"}
      token_header: "Authorization"
    user:
      headers: {"X-User-Role": "user"}  
      token_header: "Authorization"
    anonymous: {}
```

### Bandit Arms Integration

Include IDOR in your bandit arms configuration:

```yaml
bandit:
  arms:
    - {mode: "idor", protocol: "http", location: "path"}
    # ... other arms
```

## Input Formats

### JSON Endpoint List

```json
[
  "https://api.example.com/users/123",
  "https://api.example.com/documents/456",
  {
    "url": "https://api.example.com/resource",
    "method": "GET"
  }
]
```

### Single URL

Pass a single URL directly as the `--apis` parameter.

## Output Format

IDOR findings are saved in JSONL format:

```json
{
  "check": "idor",
  "target": "https://api.example.com/users/123", 
  "severity": "critical",
  "title": "IDOR: Authorization Bypass",
  "detail": "Sensitive data accessible without authentication...",
  "meta": {
    "idor_type": "idor_authorization_bypass",
    "variant_url": "https://api.example.com/users/124",
    "role": "anonymous",
    "evidence": {
      "original_response": {...},
      "variant_response": {...}
    }
  },
  "ts": 1725689123.456
}
```

## Advanced Features

### Authentication Integration

The IDOR detector can automatically attempt to authenticate with target services:

- Tries common login endpoints (`/login`, `/auth/login`)
- Captures session cookies and tokens
- Uses real authentication in testing

### ID Extraction Patterns

Automatically detects IDs in:

- **Path segments**: `/users/123/documents/456`
- **Query parameters**: `/api/resource?id=123&user_id=456` 
- **Multiple formats**: Numeric IDs, UUIDs, alphanumeric tokens

### Variant Generation

For each detected ID, generates test variants:

- **Incremental**: `123` → `124`, `122`
- **Common values**: `1`, `2`, `999`, `9999`
- **Edge cases**: `0`, `-1`
- **String variants**: For alphanumeric IDs

## Demo and Testing

### Run the Demo

```bash
# Run comprehensive demo with mock service
python tests/demo_idor_detection.py
```

This starts a mock vulnerable service and demonstrates all IDOR detection capabilities.

### Run Tests

```bash
# Run all IDOR tests
python -m pytest tests/test_idor_check_mvp.py -v

# Run integration tests
python -m pytest tests/test_checks_smoke.py -v
```

## Example Vulnerabilities Found

The demo detects these common IDOR patterns:

1. **User Profile Access**: Anonymous users accessing `/users/123` and retrieving email addresses
2. **Document Disclosure**: Accessing `/documents/456` without authorization checks
3. **API Parameter Manipulation**: Modifying `?id=123` parameters to access different resources
4. **Privilege Escalation**: Regular users accessing admin-only content

## Best Practices

1. **Test with Real Authentication**: Configure proper login credentials when possible
2. **Scope Testing**: Limit to authorized test targets to avoid ethical issues
3. **Rate Limiting**: Be mindful of request rates to avoid overwhelming target services
4. **Review Findings**: Manually verify IDOR findings before reporting
5. **Baseline Testing**: Test both vulnerable and secure endpoints to validate detection

## Troubleshooting

### No Findings Detected

- Verify endpoints contain extractable IDs (numeric, UUID, or alphanumeric)
- Check that authentication sessions are properly configured
- Ensure target service is accessible and responsive
- Review endpoint URL formats and response patterns

### Authentication Issues

- Verify login endpoint URL and credentials
- Check session cookie handling and token extraction
- Review target service authentication mechanism
- Consider manual session configuration if auto-detection fails

### False Positives

- Review response content and status codes in finding evidence
- Check if differences are due to legitimate access controls vs. IDOR
- Validate findings manually by testing with different user contexts
- Adjust detection thresholds if needed

## Security Considerations

⚠️ **Important**: Only test IDOR detection on:
- Applications you own or have explicit permission to test
- Designated testing/staging environments
- Bug bounty programs with appropriate scope

Unauthorized testing may violate laws and service terms.