已合併到 docs/OPERATION.md，僅供歷史參考

# M5 — OpenAPI 真實資料綁定（2025-08-30）
新增 binder 與 sequence_v2（可 --run 測試）。