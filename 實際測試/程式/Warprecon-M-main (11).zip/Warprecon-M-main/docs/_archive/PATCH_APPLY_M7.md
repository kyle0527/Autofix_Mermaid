已合併到 docs/OPERATION.md，僅供歷史參考

# M7 — 外掛起手包與事件流（2025-08-30）
含 starter plugins 與 Jira/GitLab issue 範本產生器。