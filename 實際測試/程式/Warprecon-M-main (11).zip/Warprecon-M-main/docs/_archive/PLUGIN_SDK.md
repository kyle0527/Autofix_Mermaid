已合併到 docs/ARCH.md，僅供歷史參考

# PLUGIN_SDK — 起手包介面說明
- 輸入：ranked findings（list[dict]）
- 輸出：list[dict]（可修改 _score/tags/severity）
- 建議：保持純函式、可重複執行。