已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 11 – Ultra)
Built: 2025-08-27 17:42:52

**功能**
- **GraphQL 多步策略引擎**：從錯誤訊息萃取類型與期望 → 連續嘗試（最多 3 步），命中機率更高。
- **Payload 變形增強**：`urlenc/urlenc_all/comment_break/param_pollution/html_entity`。
- **DOM/JS 探索可用環境變數調參**：
  - `OP_DOM_MAX_PAGES`（預設 5）
  - `OP_DOM_MAX_REQ`（預設 200）
  - `OP_JS_MAX_SCRIPTS`（預設 20）
- **CLI `--ultra`**：自動擴 transforms、提高 per_target_payloads、默認啟用 DOM Crawl（如可用）。
- 提供 Profile：`config/profiles/p10-ultra.yaml`。

**使用**
```powershell
# 可選：提高探索上限
$env:OP_DOM_MAX_PAGES = "5"
$env:OP_DOM_MAX_REQ   = "200"
$env:OP_JS_MAX_SCRIPTS = "20"

python -m op_core.cli pipeline `
  --domain <your-domain> `
  --cfg config\campaign.yaml `
  --workdir .\work\ultra `
  --profile config\profiles\p10-ultra.yaml `
  --max-concurrency 8 `
  --poc-top 8 `
  --history-ttl 30 `
  --capture `
  --dom-crawl `
  --ultra
```
