已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 7)
Built: 2025-08-27 15:49:57

**新功能**
- **DOM/SPA 探索（可選）**：若環境安裝 Playwright，`--dom-crawl` 會渲染首頁、點擊同站連結數頁，抽取 `fetch/axios/WebSocket`、`/api/*`、`/graphql` 等端點。
  - 輸出：`discovery\dom-endpoints.json`、`discovery\dom-details.json`。
- **表單與 CSRF**：新增 `op_proto.http.forms`，可解析 `<form>` 與 hidden inputs（猜測 `csrf/token` 名稱）。
- **會話 Cookie 載入**：若存在 `work\session\cookies.json`（Chrome 匯出格式），會在掃描時帶入（無需改碼）。
- **CLI**：`pipeline` 增加 `--dom-crawl` 旗標。

**使用**
```powershell
Set-Location 'C:\D槽\電腦知識\warprecon-m-i4p1'
.\.venv\Scripts\Activate.ps1

python -m op_core.cli pipeline ^
  --domain davincisnotebook.blog ^
  --cfg config\campaign.yaml ^
  --workdir .\work\report ^
  --profile config\profiles\p4-high-precision.yaml ^
  --max-concurrency 6 ^
  --poc-top 5 ^
  --history-ttl 30 ^
  --capture ^
  --dom-crawl
```
> 若未安裝 Playwright，會自動略過 DOM 探索。

**輸出新增**
- `discovery\dom-endpoints.json`, `discovery\dom-details.json`
- `work\session\cookies.json`（由你放入；若存在則自動載入）
