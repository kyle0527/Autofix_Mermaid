已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 9)
Built: 2025-08-27 16:06:58

**內容**
- **GraphQL 策略引擎（error-driven）**：解析錯誤訊息（`Cannot query field ... on type "X"`, `Expected type ...`）→ 產生下一步查詢（inline fragment/alias fan-out），在 `graphql_probe` 中自動再嘗試一次（最多 1 步）。
- 與現有 `gql_variants()` 搭配，對 **禁 introspection** 情境可持續前進，提升命中率與訊號。

**使用**
無需額外參數，`runner` 呼叫 `graphql_probe` 時會自動啟用 strategist（可在程式內改 `strategist=False` 停用）。
