已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 4)
Built: 2025-08-27 13:50:29

**What's new**
- **Discovery++**：`recon_pipeline` 會解析首頁 HTML（bs4 可選、無則 regex fallback）、讀取 `robots.txt` 與 `sitemap.xml`，自動擴列 `/graphql`、`/api/*`、`wss://`、`*socket*` 端點。
- **GraphQL Schema**：對發現的 `/graphql` 嘗試輕量 introspection，輸出到 `work\schema\graphql-introspection.json`（若可用）。
- **Deliverable+**：打包加入 `discovery/**` 與 `schema/**`。
- **UI 擴充**：新增 Targets 與 Discovery 區塊；執行前可勾選 `Capture`。
- **Profiles**：`p4-high-precision.yaml` 與 `p4-aggressive.yaml` 兩種策略檔。

**Apply**
1. 解壓本包至專案根目錄，允許覆蓋。
2. 建議 `config\campaign.yaml` 確認 `limits.retries: 2` 與 transforms（沿用 Patch 2/3）。
3. 以 CLI 執行：
   ```powershell
   .\.venv\Scripts\Activate.ps1
   python -m op_core.cli pipeline --domain <your-domain> --cfg config\campaign.yaml --workdir .\work\report --profile config\profiles\p4-high-precision.yaml --max-concurrency 6 --poc-top 5 --history-ttl 30 --capture
   ```
4. UI：
   ```powershell
   python -m op_core.cli ui --workdir .\work\report --cfg config\campaign.yaml --port 8787
   ```
   頁面可看到 Targets/Discovery，並可切換 Profile、勾選 Capture。

> 註：`bs4` 非必裝，本包會自動 fallback；如要更準確的 HTML 解析，建議 `pip install beautifulsoup4`。
