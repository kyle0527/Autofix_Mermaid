已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M Ultimate — M0→M3 PLUS 補包
版本：2025-08-30

此補包在前一份 M0→M3 的基礎上新增：
- **op_core.merge_findings**（合併多來源發現 → 同一份 ranked）
- **CI workflow**（.github/workflows/warprecon-m-ci.yml）
- **一鍵 orchestrator**（scripts/warprecon_m0_m3.sh）
- **Scorecard**（docs/SCORECARD.md + scripts/scorecard.py）
- **Checklist**（docs/CHECKLIST_M0_M3.md）
- **Interactsh 自建 compose**（deploy/interactsh/docker-compose.yml）
- **Makefile** 快速目標

## 套用方式
```bash
unzip /path/to/warprecon-m_M0-M3_plus_2025-08-30.zip -d /tmp/warprecon-m_plus
rsync -av /tmp/warprecon-m_plus/overlay/ ./
```

## 一鍵執行（範例）
```bash
bash scripts/warprecon_m0_m3.sh example.com https://api.example.com work/m_full
```

