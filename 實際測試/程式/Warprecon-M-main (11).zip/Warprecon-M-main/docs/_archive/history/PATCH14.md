已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 14 – Docs & Examples)
Built: 2025-09-06 18:00:00

**新增**
- README 新增模組說明與外掛範例，強化文件。
- 新增 `post_rank` 邏輯測試與詳細 docstring。
- 持續改進外掛相關文件與範例。

**差異**
- 文件內容：原本缺少模組說明與外掛範例 → 現在在 README 中補齊並加強說明。
- `post_rank` 測試：原本測試覆蓋不足 → 現在新增測試與 docstring 提供更完整行為描述。
- 外掛文件：原本示例稀少 → 現在提供更多使用範例與最佳實務。

**使用**
同 Patch 13，更多外掛示例請參考 README。
