已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 10)
Built: 2025-08-27 16:26:06

**新增**
- **JS baseURL 辨識與端點解析**：可從 JS 抽出 `axios.defaults.baseURL`、`window.__env.*`、`BASE_URL` 等，將相對路徑端點解成同站完整 URL，輸出至 `discovery/js-endpoints.json`（含 `raw/resolved/from_script`）。
- **共享退避（檔案版）**：`RateLimiter` 可把主機退避寫入 `work\limiter_state.json`，多程序/多次執行共享，避免被封。
- **Runner 與 Cookies**：`run_hunt(..., workdir=...)` → 用 `work\session\cookies.json` 自動載 Cookie；`RateLimiter` 狀態也寫在此 workdir。
- **UI 強化**：表單加入 **DOM Crawl** 勾選；右上顯示 OOB 事件數；Discovery 面板新增 DOM/JS 細節。

**使用**
1. 解壓覆蓋到專案根目錄。
2. 執行（可同時啟用 DOM/SPA 探索）：
   ```powershell
   python -m op_core.cli pipeline `
     --domain <your-domain> `
     --cfg config\campaign.yaml `
     --workdir .\work\report `
     --profile config\profiles\p4-high-precision.yaml `
     --max-concurrency 6 `
     --poc-top 5 `
     --history-ttl 30 `
     --capture `
     --dom-crawl
   ```
3. UI：`python -m op_core.cli ui --workdir .\work\report --cfg config\campaign.yaml --port 8787`
   - 頁面可勾選 **DOM Crawl**，並看到 DOM/JS 探索結果及 OOB 次數。
