已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 6)
Built: 2025-08-27 15:33:05

**包含內容**
- **Interactsh 正式化客戶端（可選 RSA）**：`src/op_oob/interactsh.py`
  - 自動產生 `correlation-id` 與 `secret`；若環境有 `cryptography` 套件，會建立 RSA key 並以 `public-key` 註冊。
  - `register()` 與 `poll()` 具「彈性 JSON/Query/Header」支援，盡量相容不同部署。
  - `poll()` 結果寫入 `work\oob\events.json`；`correlate_findings()` 會把命中的 OOB 事件掛回 finding 並將嚴重度提升為 **critical**。

- **GraphQL 進階隱身變體**：`src/op_fuzz/grammar.py`
  - Alias/Fragment/Variable/Error-based 多組合（在禁用 introspection 時仍可推進）。
  - `synth.py` 會自動使用，不需修改 `synth.py`。

- **JS 深度探索**：`src/op_adapters/pd_tools.py` → `recon_plus(domain)`
  - 解析首頁 HTML 找出 script，同主機 JS 下載掃描 `fetch/axios/WebSocket`、`/api/*`、`/graphql`、完整 `http(s)://...` URL。
  - 輸出：
    - `work\discovery\targets.json`（目標）
    - `work\discovery\details.json`（HTML/JS 候選、script 清單）
    - `work\discovery\js-endpoints.json`（JS 解析出的端點）

- **Pipeline 串接**：`src/op_core/pipeline.py`
  - 優先使用 `recon_plus`；若不可用，回退到 `recon_pipeline` 或單純 roots。
  - 建立 OOB client、poll 並關聯事件；輸出報表與 PoC 不變。

**如何套用**
1. 將本壓縮檔解至專案根目錄（覆蓋同名檔）。
2. 執行範例：
   ```powershell
   Set-Location 'C:\D槽\電腦知識\warprecon-m-i4p1'
   .\.venv\Scripts\Activate.ps1
   python -m op_core.cli pipeline `
     --domain davincisnotebook.blog `
     --cfg config\campaign.yaml `
     --workdir .\work\report `
     --profile config\profiles\p4-high-precision.yaml `
     --max-concurrency 6 `
     --poc-top 5 `
     --history-ttl 30 `
     --capture
   ```
3. 檢查輸出：
   - `work\discovery\details.json`、`work\discovery\js-endpoints.json`
   - `work\schema\graphql-introspection.json`（若可）
   - `work\oob\events.json`（OOB 命中與狀態）
   - `ranked.json`（若有 OOB 命中，對應 finding `severity: critical` 並含 `evidence.oob_events`）

**注意**
- 若環境沒有 `cryptography`，RSA 註冊會自動關閉，流程仍可運作。
- JS 掃描有速限（最多 8 支同主機 script），避免影響速度與風險。
