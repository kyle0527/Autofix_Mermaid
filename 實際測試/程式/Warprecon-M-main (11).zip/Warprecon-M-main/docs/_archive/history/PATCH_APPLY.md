已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M Ultimate — M0→M3 補包（Patch Bundle）
版本：2025-08-30

本補包以「覆蓋式 overlay」提供：將 `overlay/` 內檔案 **直接複製/覆蓋** 到你的專案根目錄（`Warprecon/`）即可。

> **不動到你現有檔案** 的原則：
> - 只「新增或覆寫」下列模組：`op_adapters/pd_wrappers.py`、`op_proto/grpc/*`、`op_checks/misconfig.py`、`op_bandit/contextual.py`、
>   `op_core/precision_gate.py`、`op_proto/openapi/*`、`op_output/html_v2.py`、以及 `docs/*`、`scripts/*`。
> - 不移除你專案內既有檔案（如 `op_output/deliver.py` 已存在且保持相容）。

---

## 一、如何套用補包

1. **進入你的專案根目錄**  
   ```bash
   cd /path/to/Warprecon
   ```

2. **解壓補包並覆蓋 overlay**  
   ```bash
   unzip /path/to/warprecon-m_M0-M3_patch_2025-08-30.zip -d /tmp/warprecon-m_patch
   rsync -av /tmp/warprecon-m_patch/overlay/ ./
   ```

3. **（可選）安裝必要套件**  
   - 仍以 **optional** 方式引用，未安裝時功能會自動降級：
   ```bash
   python -m pip install --upgrade grpcio grpcio-reflection PyYAML httpx pydantic
   ```

4. **開發模式安裝**（如尚未安裝）：
   ```bash
   python -m pip install -e .
   ```

---

## 二、快速驗收（M0→M3）

- **M0：PD Recon 整合與交付 zip**
  ```bash
  # 以 PD 工具為主的資產展開（會自動偵測工具是否存在）
  python -m op_adapters.pd_wrappers --domain example.com --workdir work/m0
  # 產出 targets.txt 後，可直接跑內建流程（如你平常使用方式）
  warprecon-m pipeline --domain example.com --cfg config/campaign.yaml --workdir work/m0 --capture
  # 一鍵打包交付物
  warprecon-m deliver --workdir work/m0 --out work/m0/deliverable.zip
  ```

- **M1：gRPC 反射列舉 + 基礎檢查 + 5 項常見錯誤設定（HTTP）**
  ```bash
  # gRPC 反射與端點列舉（產出 schema/grpc_*.json 與 findings.grpc.json）
  python -m op_proto.grpc.enumerate --target api.example.com:443 --workdir work/m1
  # HTTP 常見錯誤設定快速檢查（產出 findings.misconfig.json）
  python -m op_checks.misconfig --targets work/m0/targets.txt --workdir work/m1
  ```

- **M2：排序 Bandit（LinUCB）與 Precision Gate**
  ```bash
  # 例：以人工標註（accept/reject）回饋強化排序（labels.jsonl）
  python -m op_core.precision_gate --in work/m0/ranked.json --labels work/m2/labels.jsonl                                    --out work/m2/ranked.gated.json --min-score 0.35 --confirm-top-n 20
  ```

- **M3：OpenAPI Create→Use（最小 POST→GET 序列） + HTML v2 報表**
  ```bash
  # 從 OpenAPI 規格建立最小測試序列（產生 sequence/ 下的 PoC 與請求腳本）
  python -m op_proto.openapi.sequence --spec docs/openapi.yaml --base https://api.example.com                                       --workdir work/m3 --emit-requests
  # 以新版 HTML 報表產生器輸出（對 ranked.json）
  python -m op_output.html_v2 --in work/m0/ranked.json --out work/m3/report_v2.html
  ```

> **注意**：若你想把 M1/M3 產出的發現整合進 `ranked.json`，可在 CI 階段合併 JSON（`jq` 或 `python` merge）後，再走 `warprecon-m report` 與 `warprecon-m deliver`。

---

## 三、回滾
只要刪除覆蓋的檔案或以 git 還原即可。所有新增檔案皆在上述模組路徑中。

---

## 四、安全與合規
- 本補包預設 **不會把任何流量送到第三方**；OOB 仍建議使用自建（見 `docs/OOB_SELF_HOST.md`）。
- CLI 與模組均以 **失敗即降級** 設計，不會中斷主流程。

