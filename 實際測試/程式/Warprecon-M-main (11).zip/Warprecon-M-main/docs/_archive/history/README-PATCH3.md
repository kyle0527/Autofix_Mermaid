已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 3)
Built: 2025-08-27 13:45:40

What's new:
- **Shared host backoff** in `RateLimiter` + engines feed `_penalize` on 429/5xx/Timeout → fewer bans, more stability.
- **Retry/Backoff** retained (from Patch 2), now coordinated across tasks targeting the same host.
- **Recon++**: parse homepage HTML for likely endpoints (`/graphql`, `/api/*`, `ws(s)://...`, `*socket*`) and add to targets.
- **Deliverable+**: now includes `targets.txt` and `history.sqlite3`.
- **Profiles in UI**: choose WAF-friendly or Fast GraphQL and run; server merges YAML overlay on-the-fly.
- **CLI**: `pipeline` gains `--profile` (e.g., `--profile config\\profiles\\p2-waf-friendly.yaml`).

How to apply:
1. Unzip this patch into your project root (same-level files will be overwritten).
2. Optionally update `config\\campaign.yaml` with `limits.retries: 2` and add transforms (see Patch 2 README).
3. Run:
   ```powershell
   .\\.venv\\Scripts\\Activate.ps1
   python -m op_core.cli pipeline --domain <your-domain> --cfg config\\campaign.yaml --workdir .\\work\\report --profile config\\profiles\\p2-waf-friendly.yaml --max-concurrency 6 --poc-top 5
   ```
4. UI:
   ```powershell
   python -m op_core.cli ui --workdir .\\work\\report --cfg config\\campaign.yaml --port 8787
   ```
   Pick a profile from the dropdown and click **Run Now**.
