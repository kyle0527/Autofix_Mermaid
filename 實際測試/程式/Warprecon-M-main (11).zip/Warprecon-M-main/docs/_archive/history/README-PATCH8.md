已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 8)
Built: 2025-08-27 16:06:58

**內容**
- **DOM/SPA 探索（可選）**：`op_dom.capture.crawl_and_capture()` 使用 Playwright（如有）渲染頁面、攔截同站請求，輸出：
  - `discovery/dom-requests.json`
  - `discovery/dom-endpoints.json`（擴列 `/api/*`、`/graphql`、`ws(s)`）
- **表單解析與回放上下文**：`op_forms.simple` 解析 `<form>`/`<input>`/`<textarea>`，自動帶入 CSRF/hidden，僅替換被 fuzz 欄位。
- **Cookie 會話注入（httpx）**：從 `work/session/cookies.json` 自動載入（若存在）。
- **CLI**：`pipeline` 新增 `--dom-crawl` 開關。

**使用**
```powershell
python -m op_core.cli pipeline `
  --domain <your-domain> `
  --cfg config\campaign.yaml `
  --workdir .\work\report `
  --profile config\profiles\p4-high-precision.yaml `
  --max-concurrency 6 `
  --poc-top 5 `
  --history-ttl 30 `
  --capture `
  --dom-crawl
```
