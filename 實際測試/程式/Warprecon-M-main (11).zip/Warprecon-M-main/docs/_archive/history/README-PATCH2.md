已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 2)
Built: 2025-08-27 13:23:51

This pack adds:
- **Retry/Backoff** for HTTP/GraphQL/WS (handles 429/5xx with exponential backoff + jitter).
- **Content-Type guided probing** (skip irrelevant XSS/SQLi probes on non-HTML/JSON endpoints).
- **New transforms**: `case_flip`, `param_spread` (placeholder), `unicode_confuse`.
- **UI**: expandable details per finding (payload/vector/evidence).
- **Quickstart**: default outputs into `work\report\<domain>\<timestamp>`.

## Apply
Unzip and **copy/overwrite** files into your project root (e.g. `C:\D槽\電腦知識\warprecon-m-i4p1`). Structure in this zip mirrors your repo layout.

## Recommended config edits
Edit `config\campaign.yaml` and set:
```yaml
limits:
  retries: 2         # NEW: enable backoff retries
  max_concurrency: 6 # keep or adjust
synth:
  transforms: ["identity","double_encode","quote_flip","split_keywords","unicode_confuse","case_flip"]
```

You can also try the new profiles:
- `config/profiles/p2-waf-friendly.yaml`
- `config/profiles/p2-fast-gql.yaml`

## Run (single line, safest)
```powershell
python -m op_core.cli pipeline --domain <your-domain> --cfg config\campaign.yaml --workdir .\work\report --max-concurrency 6 --poc-top 5 --history-ttl 30
```

## Notes
- Tests remain valid (mocks tolerant of new logic). No changes required to tests.
- If PATH misses `warprecon-m`, always use `python -m op_core.cli` form.
