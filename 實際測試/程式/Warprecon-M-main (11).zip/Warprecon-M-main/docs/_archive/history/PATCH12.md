已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 12 – Plan A++)
Built: 2025-09-03 18:00:00

**核心**
- 整合 Plan A++ 架構與安全覆層，提供更完善的檢查與硬化。

**維運**
- 修正 Bandit 覆蓋套件，採用 Plan A++ 版 `contextual.py`。
- 修復 CI `pytest-cov` 依賴並清理多餘 build 產物。
- 專案名稱統一為 **Warprecon-M**。

**差異**
- Bandit 覆蓋套件：原本使用舊版 `contextual.py`，覆蓋率不正確 → 改用 Plan A++ 版本修復問題。
- CI `pytest-cov`：原本因缺少依賴而失敗 → 補齊依賴並清理多餘 build 產物。
- 專案名稱：原本名稱混用 `Warprecon` 與 `Warprecon-M` → 現在統一為 **Warprecon-M**。

**使用**
1. 覆蓋到專案根目錄。
2. 執行 `pre-commit run --all-files` 以確保通過所有檢查。
