已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 5)
Built: 2025-08-27 14:29:28

What's new:
- **True OOB integration (best-effort)** with an Interactsh-like client:
  - `InteracClient.mint()` issues unique tokens (fqdn if server available; graceful fallback otherwise).
  - `poll()` collects OOB interactions; results saved to `work\oob\events.json`.
  - Pipeline **correlates** OOB hits back to findings via `evidence.oob_token` and **promotes severity to Critical** when verified.
- **GraphQL stealth variants** (alias / fragment / error-based) without touching your `synth.py`:
  - Implemented in `src/op_fuzz/grammar.py` and automatically used by the generator.
- **Deliverable** now also includes `oob/**` in the ZIP for audit/repro.

How to apply:
1. Unzip to your project root (`C:\...\warprecon-m-i4p1`) and allow overwrite.
2. Run with any profile (e.g., p4-high-precision) as before:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   python -m op_core.cli pipeline --domain <your-domain> --cfg config\campaign.yaml --workdir .\work\report --profile config\profiles\p4-high-precision.yaml --max-concurrency 6 --poc-top 5 --history-ttl 30 --capture
   ```
3. After run, inspect:
   - `work\oob\events.json` – raw OOB events and state
   - `ranked.json` – findings with `evidence.oob_events` added and severity bumped to `critical` when confirmed
   - `deliverable.zip` will include `oob/**` automatically
