已合併到 CHANGELOG.md，僅供歷史參考

# Warprecon-M – Enhancement Pack (Patch 13 – Plugin Framework)
Built: 2025-09-06 10:00:00

**新增**
- 新增 `load_plugins` 函式，搜尋並載入自訂外掛。
- 內建外掛 (`network_priority`, `path_dedupe`) 更新並附測試覆蓋。
- README 擴充外掛指令與使用示例。

**差異**
- 外掛載入：原本須在程式中手動匯入外掛 → 現在透過 `load_plugins` 自動搜尋載入。
- 內建外掛：原本缺少測試與更新 → 現在提供新版並加入測試覆蓋。
- README 指引：原本僅簡略提及外掛 → 現在補充完整指令與範例。

**使用**
1. 將外掛 `.py` 檔置於 `plugins/` 或 `ext/plugins/` 目錄。
2. 執行時自動載入，或於程式中呼叫 `load_plugins(Path(workdir))`。
