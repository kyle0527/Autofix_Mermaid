已合併到 CHANGELOG.md，僅供歷史參考

# PATCH_NOTES — M0→M3 完成事項概覽

## M0
- 新增 `op_adapters/pd_wrappers.py`：封裝 `subfinder` / `naabu` / `httpx`（自動偵測可用性）→ 產出 `discovery/pd.jsonl` 與 `targets.txt`。
- `op_output/deliver.py` 已存在，沿用。新增 `docs/UPGRADE_M0_M3.md` 中的驗收腳本。

## M1
- **gRPC**：
  - 完整覆寫 `op_proto/grpc/enumerate.py` 為可執行腳本（反射列舉 Service/Method/Message）並輸出 schema 與初步風險（如 plaintext on 443）。
  - 新增 `op_proto/grpc/utils.py`，共用通道建立與 TLS/明文測試。
  - 提供 `engine.py` 之 CLI 入口，維持 `grpc_probe(...)` API 相容（若被主流程呼叫不到，也可獨立執行）。
- **HTTP 常見錯誤設定**：`op_checks/misconfig.py` 實作 5 項：HSTS 缺失、CORS `*`+`credentials`、允許 `TRACE`、寬鬆 CSP、TLS 版本過舊（握手層級）。

## M2
- **排序強化**：覆寫 `op_bandit/contextual.py` 實作 LinUCB（context 向量含：OOB/len_delta/latency/協定/來源工具…）。
- **Precision Gate**：新增 `op_core/precision_gate.py`，支援：`--min-score`、`--confirm-top-n` 與標註檔（labels.jsonl）整合。

## M3
- **OpenAPI Create→Use**：`op_proto/openapi/loader.py` + `sequence.py` 自 `OpenAPI v3.0` 生成最小 `POST→GET` 序列與 PoC 腳本（cURL/requests）。
- **HTML v2 報表**：`op_output/html_v2.py`（可並存，不覆蓋舊版），新增證據展開、PoC 連結、來源工具徽章。

> 所有模組以「無依賴即可載入、缺少外部工具自動降級」為設計原則。
