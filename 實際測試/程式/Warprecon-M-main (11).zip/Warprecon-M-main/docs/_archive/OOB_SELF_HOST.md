已合併到 docs/OPERATION.md，僅供歷史參考

# OOB_SELF_HOST — Interactsh 自建指引（最小可行）

> 建議以自建 OOB 伺服器避免資料外洩風險。

## 1. 以 Docker Compose 快速啟動
```yaml
# docker-compose.yml
version: "3.8"
services:
  interactsh-server:
    image: projectdiscovery/interactsh-server:latest
    ports:
      - "80:80"
      - "443:443"
      - "53:53/udp"
    environment:
      - SERVER_V4=true
      - SERVER_V6=false
      - DOMAIN=your-oob.example.com
```
```bash
docker compose up -d
```

## 2. 客戶端設定
- 在 `warprecon-m` 的設定中改為你的自建網域與金鑰（若使用 TLS，請匯入證書）。

## 3. 風險與建議
- 建議在內網或受控環境部署；開放互聯網前務必設定 ACL 與存取審計。
