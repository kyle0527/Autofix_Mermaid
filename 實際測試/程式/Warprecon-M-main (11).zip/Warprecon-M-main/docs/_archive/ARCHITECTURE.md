⚠️ 此文件已合併至 docs/ARCH.md，僅供歷史參考。

# Warprecon-M 系統架構

## 目錄與角色

| 模組 | 角色 |
| ---- | ---- |
| **src/op_core/**    | 核心流程：CLI、Pipeline、歷史去重、速率限制、排行 (LinUCB) 與外掛載入。 |
| **src/op_auth/**    | 認證策略架構，可插拔 Cookie、JWT、OAuth2 等策略。 |
| **src/op_control/** | Campaign 設定載入與合併；`config/` 內為預設樣板與 profiles。 |
| **src/op_adapters/**| 介接第三方工具與服務。 |
| **src/op_crawl/**  | DOM 探勘與端點發掘。 |
| **src/op_dom/**    | 瀏覽器 DOM 擷取與快照。 |
| **src/op_checks/** | 內建檢查（IDOR、OAuth、誤設等）。 |
| **src/op_fuzz/**   | 語法與 payload fuzzing 工具。 |
| **src/op_synth/**  | Payload 合成與候選生成。 |
| **src/op_proto/**  | 協定探測引擎，提供 `http`、`graphql`、`grpc`、`ws`、`openapi` 等 `probe` 函式。 |
| **src/op_oob/**    | OOB 互動/取證支援（Interactsh 等）。 |
| **src/op_bandit/** | 排序模型與多臂 bandit 演算法。 |
| **src/op_chain/**  | 漏洞關聯與攻擊鏈組合。 |
| **src/op_output/** | 報表產出（SARIF、HTML、PoC、deliver 打包）。 |
| **src/op_stream/** | 輸出串流至 Issue Tracker（GitLab、Jira）。 |
| **src/op_plugins/**| 外掛系統與內建外掛（`path_dedupe`、`network_priority`）。 |
| **src/op_data/**   | 範本與資料載入工具。 |
| **src/op_forms/**  | HTML 表單抽取與欄位選擇。 |
| **src/op_dist/**   | 檔案佇列與 agent 分散式執行。 |
| **src/op_ui/**     | 簡易 Web UI。 |

## 資料流（Pipeline）
1. **入口**：`warprecon-m pipeline` 透過 `op_core.cli` 啟動，可搭配 `op_dist` 的檔案佇列分散任務。
2. **設定**：`prepare_campaign` 使用 `op_control` 載入 Campaign，`op_auth` 掛載認證策略，並讀取 `op_data` 範本與 `plugins/` 外掛。
3. **目標蒐集**：`collect_targets` 透過 `op_adapters` 執行 recon；若啟用 DOM 探勘則由 `op_crawl`、`op_dom` 擷取端點與快照，再交給 `op_forms` 抽取 HTML 表單與欄位。
4. **探測**：`run_hunt` 由 `op_fuzz`、`op_synth`（搭配 `op_data` 範本與 `op_forms` 欄位）產生候選，`op_checks` 驗證，`op_proto.*` 送出 probe；`AuthManager` 管理身分，`RateLimiter` 控速，`HistoryDB` 去重，`op_oob` 監聽 OOB 回傳。
5. **排序與關聯**：`rank_findings` 使用 `op_bandit`、`op_chain` 排序與關聯，並可由 `op_plugins.post_rank` 調整。
6. **輸出**：`op_output` 產生 SARIF/HTML/PoC 等報告，`op_stream` 可同步到 Issue Tracker，`deliver` 打包成果；`op_plugins.artifact_exporter` 與 `vector_probe` 等 hook 可擴充。
7. **展示**：如部署 `op_ui`，則可透過 `op_dist` 佇列展示任務與結果。

## 接口契約
- **Finding**：`op_core.finding_contract.Finding`
  - 欄位：`check`、`target`、`severity`、`title`、`detail`、`meta`、`ts`。
  - `to_json()/from_json()` 序列化至報告。
- **Plugin Hooks**（模組可實作任一）：
  ```python
  def vector_probe(workdir: Path, camp: Dict, targets: List[str]) -> List[Dict]
  def post_rank(ranked: List[Dict]) -> List[Dict]
  def artifact_exporter(workdir: Path, ranked: List[Dict]) -> None
  ```
- **Protocol Probe**：各 `op_proto` 模組暴露 `*_probe` 函式，簽名類似：
  ```python
  async def http_probe(target: str, cand: Dict, mint, client, retries: int = 1) -> Dict | None
  ```
  傳入目標與候選向量，回傳包含 `payload`、`evidence`、`severity` 等欄位的 finding 字典，或回傳 `{"_penalize": delay}` 表示需要降速。

## 測試
- 使用 `pytest` 模擬協定與外部工具，以確保模組可被導入並基本運作。
