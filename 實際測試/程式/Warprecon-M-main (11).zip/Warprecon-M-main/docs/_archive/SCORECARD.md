⚠️ 此文件已合併至 docs/OPERATION.md，僅供歷史參考。

# SCORECARD — 評分通則 v1.7（自動化計算介面）

> 權重：Discovery 20%、Protocol 25%、Verification 15%、Ranking 10%、Delivery 10%、Ecosystem 10%、Compliance 5%、Performance 5%。

請填入以下度量（可由 CI 產生）：
- discovery.urls（M0 產出的 URL 數）
- protocol.grpc_schema（M1 反射列舉成功的 service 數）
- misconfig.findings（M1 misconfig 條目數）
- ranking.topN_confirmed（M2 Gate 前後 Top-N 命中差）
- delivery.artifacts（報告與 PoC 檔案數）
- ecosystem.plugins（外掛/整合數）
- compliance.oob_self_host（0/1）
- performance.rate_controls（0/1/2：無/基本/進階）

計算方式可使用 `scripts/scorecard.py`。
