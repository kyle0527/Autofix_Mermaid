已合併到 docs/OPERATION.md，僅供歷史參考

# UPGRADE_M0_M3 — 驗收與測試指南

## 前置
- 建議 Python 3.10+、Linux/macOS。Windows 亦可，但 PD 工具可用性視安裝而定。

## M0 測試
1. `python -m op_adapters.pd_wrappers --domain example.com --workdir work/m0`
2. 檢查 `work/m0/discovery/pd.jsonl`、`work/m0/targets.txt` 是否產出。
3. 跑你原本的 `warprecon-m pipeline` + `warprecon-m deliver`，確認 `deliverable.zip` 內容包含：`ranked.json`、`out.sarif`、`report.html`、`poc/*`。

## M1 測試
1. `python -m op_proto.grpc.enumerate --target api.example.com:443 --workdir work/m1`
2. 確認 `work/m1/schema/grpc_api.example.com_443.json` 與 `work/m1/findings.grpc.json`。
3. `python -m op_checks.misconfig --targets work/m0/targets.txt --workdir work/m1`
4. 確認輸出 `findings.misconfig.json`，內容含每個檢查的證據欄位。

## M2 測試
1. 準備 `labels.jsonl`（每行 `{"fingerprint":"...", "label":"accept"|"reject"}`）。
2. `python -m op_core.precision_gate --in work/m0/ranked.json --labels work/m2/labels.jsonl --out work/m2/ranked.gated.json`
3. 比較分數與 Top-N 排名變化。

## M3 測試
1. 準備 `docs/openapi.yaml`（OpenAPI v3）。
2. `python -m op_proto.openapi.sequence --spec docs/openapi.yaml --base https://api.example.com --workdir work/m3 --emit-requests`
3. 檢查 `work/m3/sequence/` 內的 cURL 與 `requests.py` PoC。
4. `python -m op_output.html_v2 --in work/m0/ranked.json --out work/m3/report_v2.html` 檢查新版報表。

