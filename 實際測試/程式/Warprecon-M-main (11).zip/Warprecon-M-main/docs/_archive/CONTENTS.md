已合併到 README.md，僅供歷史參考

# 內容與路徑說明（I4 Patch 1 Verified, 2025-08-27 11:14:29）
- 主要可執行：`warprecon-m`（由 `src/op_core/cli.py`）
- 配置：`config/campaign.yaml`、`config/profiles/*.yaml`
- 指令腳本：`bin/*.ps1`
- UI 入口：`warprecon-m ui --workdir work --cfg config/campaign.yaml --port 8787`
- 交付打包：`warprecon-m deliver --workdir work` 或 UI 的 Download
- 測試：`pytest`（mock 為主，不依賴外部二進位）
- **注意**：`work/` 內報告/證據為執行後產生；壓縮檔不含 runtime 產物。
- Roadmap：`docs/ROADMAP.md`
