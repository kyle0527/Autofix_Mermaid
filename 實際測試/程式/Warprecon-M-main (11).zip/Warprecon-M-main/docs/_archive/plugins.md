已合併到 docs/ARCH.md，僅供歷史參考


# Plugin System

## Discovery Paths

`op_plugins.loader.load_plugins(workdir)` scans for `*.py` modules in the following locations (earliest entry wins on duplicates):

1. `<workdir>/plugins/` – run-scoped plugins.
2. `./plugins/` – project-level plugins.
3. `./ext/plugins/` – external/community plugins.
4. `op_plugins/builtin/` – bundled plugins.

Place a plugin file in any of these directories and it will be auto-imported.

## Hook Signatures

A plugin module may implement any subset of the hooks below:

```python
from pathlib import Path
from typing import List, Dict

def vector_probe(workdir: Path, camp: Dict, targets: List[str]) -> List[Dict]:
    """Return additional findings before scanning."""


def post_rank(ranked: List[Dict]) -> List[Dict]:
    """Adjust scores or ordering after ranking."""


def artifact_exporter(workdir: Path, ranked: List[Dict]) -> None:
    """Emit extra artifacts such as reports or logs."""
```

## Configuration

The loader requires no extra setup: presence of a `.py` file in a discovery path enables the plugin. Any plugin-specific options should be handled by the plugin itself (e.g. reading environment variables or files under the work directory).

Community maintained plugins are indexed in `ext/plugins/registry.json`.

## CI

Run plugin linting and tests before submitting a change:


pre-commit run --files README.md docs/plugins.md ext/plugins/registry.json
pytest tests/test_builtin_plugins.py tests/test_plugins_dom.py
```

# Plugin Guide

Warprecon-M supports a lightweight plugin system. Plugins can extend scanning
behaviour by implementing hook functions and placing them in discovery paths.

## Discovery

Plugins are discovered from the following locations:

- `ext/plugins/`
- Python packages listed under `warprecon.plugins` entry point.

Each plugin module can expose any of the optional hooks:

- `vector_probe(findings)`
- `post_rank(findings)`
- `artifact_exporter(workdir, findings)`

## Configuration

Enable or disable plugins via campaign configuration:

```yaml
plugins:
  - name: sample_plugin
  - path: ./ext/plugins/custom_plugin.py
```

## Registry

A simple registry of community plugins is kept at `ext/plugins/registry.json`.
Contributions are welcome.

