已合併到 README.md，僅供歷史參考

# Branching Rules (Trunk-Based)
- `main` is the only long-lived branch.
- Short-lived branches: `feat/*`, `fix/*`, `refactor/*`, `chore/*`, `docs/*`, `test/*`.
- Open PRs early; merge when CI green; delete branch after merge.
- Optional: `integrate/*` for one-shot integration PRs.
