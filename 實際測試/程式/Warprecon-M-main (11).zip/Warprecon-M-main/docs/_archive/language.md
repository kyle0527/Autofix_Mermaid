已合併到 README.md，僅供歷史參考

| 模組 | 目前語言 | 建議語言 | 主要理由 | 備註／替代方案 |
| --- | --- | --- | --- | --- |
| Parsers（Python 語言解析） | TypeScript（Node，可接 tree-sitter） | TypeScript | 與其餘模組共享型別/IR，易於在 Node/瀏覽器共用；tree-sitter 在 JS/TS 生態成熟 | Rust+WASM（維持 IR 不變）或 CPython AST microservice |
| Analyzers（CFG/CallGraph） | TypeScript | TypeScript | 與 Parsers/Emitters 緊耦合於 IR；JS/TS 有足夠圖算法實作；最快整合 | 熱點可改以 Rust/Go 寫核心，透過 N-API/WASM 封裝 |
| Emitters（Mermaid） | TypeScript | TypeScript | 字串與模板生成在 TS 最順，呼應前後端同構 | — |
| Fix Rules（Mermaid 兼容/EnsureParticipants） | TypeScript | TypeScript | 規則式轉換與文字處理在 TS 生態簡潔、可測性高 | — |
| Core Pipeline（runPipeline） | TypeScript | TypeScript | 維持單語言可降低跨界成本與錯誤面 | — |
| Renderer（web） | TypeScript（嚴格 Mermaid 包裝） | TypeScript | 與 Web 環境天然契合；可擴充 web-worker + web-tree-sitter | — |
| CLI | TypeScript（編譯後 Node 執行） | TypeScript | 與核心共享型別與模組，打包/釋出流程一致 | — |
| Types/IR | TypeScript（d.ts） | TypeScript + JSON Schema（可選） | 保持單一真相來源（TS types）；必要時產生 schema 供多語言驗證 | — |

