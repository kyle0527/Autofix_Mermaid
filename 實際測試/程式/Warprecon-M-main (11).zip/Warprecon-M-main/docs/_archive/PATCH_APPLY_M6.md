已合併到 docs/OPERATION.md，僅供歷史參考

# M6 — 效能與可觀測性（2025-08-30）
新增 ndjson 事件流、限速/退避封裝，見 `op_core/*` 與 `scripts/warprecon_events_watch.py`。