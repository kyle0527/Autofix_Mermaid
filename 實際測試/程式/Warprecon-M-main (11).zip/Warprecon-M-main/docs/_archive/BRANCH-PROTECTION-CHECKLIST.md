已合併到 README.md，僅供歷史參考

# Branch Protection Checklist
- Protect `main`:
  - Require pull request before merging
  - Require status checks (CI) to pass
  - Require linear history
  - Restrict who can push (optional)
