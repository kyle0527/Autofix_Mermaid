已合併到 docs/ARCH.md，僅供歷史參考

# Gated UCB Sorting (Plan A++)

- Default behavior: legacy (no sorting in `order(ctx)`).
- Turn on sorting by setting environment variable:

  ```bash
  export BANDIT_ENABLE_UCB_SORT=1
  # optional:
  export BANDIT_UCB_ALPHA=0.8
  export BANDIT_DIM=16
  ```

- Provide per-arm context vectors `x` via `ctx` using one of:

  ```python
  # Option A
  ctx = {'x_map': {'armA':[...], 'armB':[...]}}

  # Option B
  ctx = {'x': [[...], [...]]}  # aligned with arms

  # Option C
  ctx = [{'name':'armA','x':[...]} , {'name':'armB','x':[...]}]
  ```

- On error / missing data: it will silently fall back to legacy order.
