已合併到 docs/OPERATION.md，僅供歷史參考

# M4 — gRPC 泛型動態呼叫（2025-08-30）
見 `src/op_proto/grpc/dynamic.py` 與 `python -m op_proto.grpc.dynamic -h`。