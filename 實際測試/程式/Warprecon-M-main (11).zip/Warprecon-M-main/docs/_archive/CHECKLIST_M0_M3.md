⚠️ 此文件已合併至 docs/OPERATION.md，僅供歷史參考。

# CHECKLIST — M0→M3 驗收清單

## M0
- [ ] `op_adapters.pd_wrappers.py` 可執行（有/無 PD 工具皆不報錯）。
- [ ] 產出 `work/m0/discovery/pd.jsonl` 與 `work/m0/targets.txt`。
- [ ] `warprecon-m pipeline` 與 `warprecon-m deliver` 產出 `ranked.json`、`out.sarif`、`report.html`、`poc/`。

## M1
- [ ] `op_proto.grpc.enumerate` 對有反射的端點輸出 `schema/grpc_*.json`。
- [ ] `op_checks.misconfig` 產出 `findings.misconfig.json`（含 5 項檢查）。

## M2
- [ ] `op_core.precision_gate` 可以將 `ranked.json` 與 `labels.jsonl` 合成 `ranked.gated.json`。

## M3
- [ ] `op_proto.openapi.sequence` 產出 `sequence/seq_*.sh` 與（可選）`requests.py`。
- [ ] `op_output.html_v2` 產生新版報表 `report_v2.html`。

## 整合
- [ ] `op_core.merge_findings` 能合併 `ranked.json` + `findings.misconfig.json` + `findings.grpc.json` → `ranked.merged.json`。
- [ ] 將 `ranked.merged.json` 再經 `precision_gate` → `ranked.final.json`。
