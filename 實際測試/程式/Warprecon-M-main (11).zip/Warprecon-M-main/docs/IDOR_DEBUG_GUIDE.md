IDOR Debugging & Reproduction Guide

This document summarizes the changes made during debugging and gives step-by-step instructions to reproduce the local test environment, run diagnostics, and interpret the outputs.

Goals

- Make IDOR CLI integration tests reproducible locally.
- Add focused instrumentation to observe request/response flows between the detector and the mock test server.
- Provide small debug helpers to reproduce failing cases and collect traces.

What I changed (summary)

1. tests/mock_idor_app.py
   - Added routes used by CLI tests:
     - `GET /api/v1/notes/<int:nid>`: returns document info or 404
     - `GET /api/v1/secret-docs/<int:doc_id>`: reverse-bypass behavior (owner denied, others allowed). For high ids (e.g. 201) owner mapped via `owner = doc_id - 199`.
     - `GET /api/v1/item`: returns JSON for query param `id`.
   - Purpose: ensure test server responds to the URLs used by tests (prevent 404s), and simulate the insecure behaviors tests expect.

2. src/op_checks/idor.py
   - Enhanced `RequestReplay.replay_request` to log: request headers, request cookies, response headers and a short response snippet (first 1000 chars).
   - When no findings are found, `IdorDetector.detect_idor_single_url` now appends a debug `idor_none` entry containing owner_status and owner request/response details. This helps tests and devs inspect what owner request actually sent/received.

3. tests/debug_test_idor_probe.py
   - New debug test that starts the mock server and calls `IdorDetector.detect_idor_single_url` for `/api/v1/secret-docs/201`, printing the raw probe results.

How to reproduce locally (in the dev container)

1. Install dev deps (if not already done):

```bash
python -m pip install -e .[dev] pytest-asyncio anyio
```

2. Run the focused debug test to see raw replay traces:

```bash
pytest -q tests/debug_test_idor_probe.py -s
```

You should see printed JSON `DEBUG RESULTS` containing at least one entry. If there's an `idor_none` entry, it will include keys such as:

- `owner_status` (HTTP status owner got)
- `owner_request_headers` (what the detector sent for the owner request)
- `owner_request_cookies`
- `owner_response_headers`
- `owner_response_snippet`

These let you verify the owner request actually represented the expected user id (e.g., X-User-ID: 2).

Key debugging observations

- If the owner request headers do not show the expected owner id (e.g., `X-User-ID: 2`), the detector or IdorCheck might be selecting the wrong owner role. Investigate how `roles` are passed to `IdorDetector.detect_idor_single_url` and how owner selection is computed.
- If the owner request shows the expected header but server responded 200 instead of 403, check mock server ownership mapping (the `secret-docs` route uses a simple derivation for high ids: `owner = doc_id - 199`).
- If cookies or tokens are expected but `owner_request_cookies` is empty, examine `SessionManager._attempt_login` and cookie handling. Note: httpx per-request cookies emits a DeprecationWarning; consider setting cookies on the client instance if you need persistence.

Next steps (recommended)

- Quick test: modify `tests/debug_test_idor_probe.py` to explicitly assert owner role is the expected one or to pass roles with owner first, to force the detector to use that owner. This verifies whether the owner's selection is the issue.
- Add more verbose logging to `tests/mock_idor_app.py` handlers to print incoming headers for direct comparison.
- Longer-term: consider refactoring `SessionManager` so it returns explicit token/cookie pairs that `RequestReplay` attaches to a client instance (instead of per-request cookies) to avoid DeprecationWarning and ambiguity.

Files changed / added in this session

- tests/mock_idor_app.py (modified)
- src/op_checks/idor.py (modified)
- tests/debug_test_idor_probe.py (added)
- docs/IDOR_DEBUG_GUIDE.md (added)

If you want, I can

- Apply Option 1: update the debug test to force the owner role to X-User-ID:2 and re-run.
- Apply Option 2: add header-logging prints to `mock_idor_app.py` routes.
- Apply Option 3: change `IdorDetector` owner selection to respect `owner_user_id` deterministically.

Tell me which you'd like next, or I can proceed with Option 1 now and report results.
