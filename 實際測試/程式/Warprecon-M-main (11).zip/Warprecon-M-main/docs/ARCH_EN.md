# ARCH — Architecture & Interface Index

## System Overview
```mermaid
flowchart TD
    subgraph op_core
        pipeline[op_core.pipeline]
        rank[op_core.rank]
    end
    subgraph op_proto
        http[op_proto.http/ws]
        grpc[op_proto.grpc]
        openapi[op_proto.openapi]
    end
    subgraph op_output
        html[op_output.html_v2]
        sarif[op_output.sarif]
        deliver[op_output.deliver]
    end

    Targets --> pipeline
    pipeline --> http
    pipeline --> grpc
    pipeline --> openapi
    http --> rank
    grpc --> rank
    openapi --> rank
    rank --> html
    rank --> sarif
    rank --> deliver
```

## Core Module Interface Index
| Module | Role | Primary Interface |
| --- | --- | --- |
| `op_core.pipeline` | Orchestrates M0→M3 tasks and scheduling | `run_pipeline(targets)` |
| `op_iast.*` | IAST agent lifecycle & ingestion | `op_iast.session.create_session`, `op_core.pipeline.iast.collect_iast_results` |
| `op_chain.workflow` | Business-logic workflow executor | `WorkflowExecutor`, `op_core.pipeline.logic.run_logic_workflows` |
| `op_proto.*` | Protocol probes (HTTP/gRPC/OpenAPI/GraphQL/WebSocket) | `http_probe`, `grpc.enumerate`, `openapi.sequence`, `graphql.engine.schema_payloads_for`, `graphql.runner.generate_candidates`, `ws.engine.ws_probe` |
| `op_core.rank` | Aggregates and sorts findings | `rank_findings(list[dict])`, CLI `precision_gate` |
| `op_output.*` | Report generation and artifact packaging | `html_v2`, `sarif`, `deliver` |
| `op_plugins.*` | Extension hooks and custom checkers | `registry.json`, hooks: `vector_probe`, `post_rank`, `artifact_exporter` |

## Discovery Outputs

When DOM crawling is enabled, the `discovery/` directory contains additional artifacts that the UI surfaces and that can be used for offline analysis:

- `dom-requests.json`: condensed HAR of same-origin requests (method/url/headers/body) captured during the crawl.
- `dom-endpoints.json`: heuristically extracted `/api`, `/graphql`, and WebSocket endpoints discovered from DOM/JS content.
- `dom-artifacts.json`: per-page index describing where HTML snapshots and screenshots were written, plus any endpoints detected on that page.
- `dom-capture/snapshots/*.html` and `dom-capture/screenshots/*.png`: raw DOM snapshots and PNG captures for each visited page.

### GraphQL query planning

- `op_proto.graphql.schema.GraphQLSchema` parses introspection payloads and records `possible_types`, field arguments, and input object definitions.
- `op_proto.graphql.runner.generate_candidates()` builds Query/Mutation/Subscription operations with variables, emitting inline fragments when encountering `UNION` or `INTERFACE` types.
- `op_proto.graphql.engine.schema_payloads_for()` selects operations from the schema cache while honouring `limits.graphql_budget` and `limits.graphql_max_depth`; when schema data is incomplete it falls back to lightweight `query { __typename }` probes.

## IAST agent integration

The `op_iast` package manages IAST agent lifecycles and payload schemas, while `op_core.pipeline.iast.collect_iast_results` gathers agent evidence after the scanning stage:

- The default `embedded` transport watches `workdir/iast/findings.jsonl` (JSON or JSONL) and converts the payloads into `Finding` objects, writing the normalised output to `workdir/iast/findings.json`.
- Telemetry emits an `iast.collect` stage and augments the execution metrics with an `execution.iast` count so that agent health is visible from CLI summaries.
- The `_merge_and_gate` phase adds `findings.json` to the ranking and gate pipeline, ensuring IAST evidence is merged with the rest of the findings and subjected to the same gating rules.

To integrate a custom agent, configure the campaign `iast` block (e.g., `transport`, `endpoint`, `buffer_path`) or override `op_iast.session.create_session` to register a bespoke transport.

## Business-logic workflows and state machines

The `op_chain.workflow` module and the pipeline `logic` stage provide a YAML DSL for modelling multi-step business journeys (cart, privilege escalation, and more). Successful paths emit findings enriched with execution traces.

- Campaign `logic` block:
  - `enabled`: disabled by default; enable to load workflow manifests.
  - `base_url`: default value for `{{ base_url }}` when a workflow does not override the endpoint.
  - `context`: shared variables (accounts, static tokens) injected into the template environment via `{{ vars.foo }}` / `{{ context.foo }}`.
  - `workflows[]`: each entry may reference a `path` (relative to `workdir/` or `config/`) or provide an inline `manifest`. Optional overrides include `variables` (merged into the workflow context), `check`, `severity`, and `entry`.

- DSL capabilities:
  - `states.<name>.steps[].http` issues HTTP requests with `expect.status`, `expect.contains`, `expect.absent`, and `expect.json` assertions. `capture` extracts values from `json.foo`, `headers.Set-Cookie`, `status`, or `regex` expressions.
  - `store`, `assert`, and `emit` steps update context, validate conditions, and emit findings respectively. `emit` defaults to `check=chain.workflow` and attaches the current `trace` plus `workflow` metadata to the result.
  - `transitions` honour `success`, `failure`, `equals`, `contains`, `exists` / `not_exists`, `all`, and `any` predicates, enabling multi-branch state machines and loops.

- Execution summaries are written to `workdir/logic/findings.json`, including `variables` and full step-by-step `trace` payloads for troubleshooting.
- Findings produced by `emit` are merged with the regular scan results, gated by the same precision policies, and Telemetry emits `logic.workflow` events to capture success/failure outcomes.

An end-to-end example lives in `docs/examples/workflows/checkout-bypass.yaml`, illustrating a three-state cart manipulation workflow.

## Extension Points
- **Plugins registry**: `ext/plugins/registry.json`
  ```json
  [
    {"name": "path_dedupe", "module": "op_plugins.builtin.path_dedupe"}
  ]
  ```
- **Custom checkers**: Add a `.py` file and implement any hook (names must match `op_plugins.loader.HOOK_NAMES`).

### Plugin Hooks

The Warprecon-M plugin loader `src/op_plugins/loader.py` scans for `*.py` files under the following paths:

1. `<workdir>/plugins`
2. `./plugins`
3. `./ext/plugins`
4. `op_plugins/builtin` (built-in package)

Each module that implements any function listed in `HOOK_NAMES = ["vector_probe", "post_rank", "artifact_exporter"]` will be appended to the queue for that hook. The queue is ordered by source path and filename. As long as the return value matches the interface below, it will be invoked in the core pipeline.

#### Execution Order Overview
1. **Vector hooks**: Called before M0. All `vector_probe` functions run before the core scheduler generates default target findings. The aggregated findings are passed to the pipeline.
2. **Ranking hooks**: After M2 ranking completes, each `post_rank` is invoked in load order. The results are forwarded to the report generator.
3. **Exporter hooks**: After M3 produces standard artifacts, every `artifact_exporter` runs in sequence to create additional files or integrate with external services.

#### `vector_probe`
- **When it runs**: Before scheduling (pre-M0), prior to the core scheduler producing default target findings.
- **Signature**: `def vector_probe(workdir: Path, camp: dict, targets: list[str]) -> list[dict]`
- **Parameters**:
  - `workdir`: Current working directory, e.g. `work/run1`. Use it to read/write temporary data.
  - `camp`: Campaign configuration for this scan. Common keys include `name`, `scope`, `tags`, etc.
  - `targets`: List of scheduled targets. Do not mutate in place; copy if adjustments are required.
- **Return value**: `list[dict]`. Each dict should satisfy the basic fields of `ranked.json` (`check`, `target`, `severity`, `_score`, etc.). Return an empty list if there are no additional findings.
- **Common use cases**:
  - Perform additional HTTP/gRPC probing on existing targets and feed the results back as findings.
  - Inject static findings based on campaign metadata (e.g., activity type or custom lists).
  - Import offline scan results or third-party intelligence.
- **Implementation notes**: Keep the function resilient. Return an empty list on failure; log errors to `workdir / "logs"` or use the standard logger.

#### `post_rank`
- **When it runs**: After ranking (between M2 and M3), once the core pipeline consolidates all findings.
- **Signature**: `def post_rank(ranked: list[dict]) -> list[dict]`
- **Parameters**:
  - `ranked`: List of findings sorted by `_score`. You may modify in place (e.g., adjust `_score`, add fields) or return a new list.
- **Return value**: `list[dict]`, typically the modified `ranked`. Each element must remain JSON-serializable.
- **Common use cases**:
  - Adjust scoring strategies (e.g., reweight specific protocols).
  - Add report fields (`tags`, `owner`, etc.) or label risk levels.
  - Filter out findings that do not meet acceptance criteria before output.
- **Implementation notes**: When updating `_rank`, ensure it starts at 1 and is sequential to satisfy downstream report requirements.

#### `artifact_exporter`
- **When it runs**: After reports are generated (post-M3) and all findings are finalized.
- **Signature**: `def artifact_exporter(workdir: Path, ranked: list[dict]) -> None`
- **Parameters**:
  - `workdir`: Directory containing the final artifacts. Use it to write additional files or folders.
  - `ranked`: Final sorted results. By default this is the content of `ranked.final.json`; treat it as read-only.
- **Return value**: `None`. Catch and handle exceptions (e.g., write failures) to avoid interrupting the pipeline.
- **Common use cases**:
  - Produce PDF/Markdown summaries for manual review.
  - Integrate with external systems such as issue trackers or Slack webhooks.
  - Export additional data (e.g., JSON Lines, CSV).
- **Implementation notes**: Prefer writing to a subdirectory under `workdir / "plugins"` to avoid clashing with core outputs.

### Example Plugin
```python
# plugins/demo_plugin.py
from pathlib import Path
from typing import Any, Dict, List

def vector_probe(workdir: Path, camp: Dict[str, Any], targets: List[str]) -> List[Dict[str, Any]]:
    """Add default findings for /healthz endpoints before scheduling."""
    return [
        {
            "check": "demo/vector",
            "target": t,
            "severity": "info",
            "evidence": {"note": "preflight"},
            "_score": 0.1,
        }
        for t in targets
        if t.endswith("/healthz")
    ]


def post_rank(ranked: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Promote critical findings and renumber _rank."""
    for item in ranked:
        if item.get("severity") == "critical":
            item["_score"] = item.get("_score", 0) + 10
    ranked.sort(key=lambda x: float(x.get("_score", 0)), reverse=True)
    for idx, item in enumerate(ranked, start=1):
        item["_rank"] = idx
    return ranked


def artifact_exporter(workdir: Path, ranked: List[Dict[str, Any]]) -> None:
    """Output a text summary for manual review."""
    report = workdir / "plugins" / "demo_report.txt"
    report.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"#{item.get('_rank', '?')} {item.get('target')} {item.get('severity')}" for item in ranked]
    report.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    # Minimal invocation: load hooks via the loader and execute each of them.
    from pathlib import Path
    from op_plugins.loader import load_plugins

    workdir = Path("work/run1")
    workdir.mkdir(parents=True, exist_ok=True)
    hooks = load_plugins(workdir)
    camp = {"name": "demo"}
    targets = ["https://app.example/", "https://app.example/healthz"]

    for probe in hooks.get("vector_probe", []):
        findings = probe(workdir, camp, targets)
        print("vector findings", findings)
```

    ranked = [{"target": "https://app.example/", "severity": "critical", "_score": 5}]
    for modifier in hooks.get("post_rank", []):
        ranked = modifier(ranked)

    for exporter in hooks.get("artifact_exporter", []):
        exporter(workdir, ranked)
```

> To enable this plugin in the production pipeline, place the file in `plugins/` or `ext/plugins/`, then add the following to `ext/plugins/registry.json`:
> ```json
> [
>   {"name": "demo_plugin", "module": "plugins.demo_plugin"}
> ]
> ```
> Running `python plugins/demo_plugin.py` prints the hooks returned by the loader and shows the artifact created by `artifact_exporter`, for example:
> ```text
> vector findings [{'check': 'demo/vector', 'target': 'https://app.example/healthz', 'severity': 'info', 'evidence': {'note': 'preflight'}, '_score': 0.1}]
> ```
> Extend logging, error handling, and additional outputs as needed.

## Data Contracts
### ranked.json / ranked.final.json
| Field | Description |
| --- | --- |
| `check` | Checker name |
| `target` | Probe target |
| `severity` | Severity |
| `evidence` | Supporting data |
| `_score` | Ranking score |
| `_rank` | Ranking order |

### metrics.jsonl / metrics.json
| Field | Description |
| `status` | `running`, `success`, or `error` |
| `ttfp_seconds` | Time to First Finding (seconds) |
| `duration_seconds` | Total run duration (seconds) |
| `hits` | Total findings |
| `confirmed_hits` | Confirmed finding count |
| `first_hit_ts` / `first_confirmed_ts` | Timestamp of first hit/confirmed hit |

### events.log
- JSON lines capturing `pipeline.start`, per-stage updates, and `pipeline.finish` / `pipeline.error` entries.

### deliverable.zip
Contains `report_v2.html`, `out.sarif`, `ranked.final.json`, and other artifacts.

> See module docstrings for API details; this document tracks only the minimal I/O contracts.

## Progress Snapshot
### Completed
- Expanded the WebSocket probe with handshake matrices (subprotocols, heartbeats, compression), layered JSON/binary payload strategies, and automated GraphQL Subscription flows to capture richer evidence from real-time endpoints.
- Telemetry now segments round trips by handshake profile (including STOMP and Socket.IO) and payload strategy, exposing per-mode success rates, latency, and failure reasons in the CLI and reports.

### Next
- Use the per-handshake telemetry to drive automated retry recommendations (e.g., prioritising the most reliable profile) and evaluate additional scenario-specific payloads if gaps remain.
