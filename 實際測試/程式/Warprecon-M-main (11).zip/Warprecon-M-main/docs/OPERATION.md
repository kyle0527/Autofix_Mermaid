# OPERATION — M0→M3 Runbook & 驗收標準

## 環境前置
- Python 3.11+
- 可選：Docker `python:3.11` 映像
- 安裝依賴：`pip install -r requirements-dev.txt`
- DOM 探勘／gRPC reflection 需額外安裝：`pip install -e .[dom,grpc]` 並執行 `playwright install`
- 啟動 UI 前請以 `warprecon-m ui --auth-token <token>` 指定或設定 `WARPRECON_UI_TOKEN`（逗號可配置多組 token）
- 可選：在專案根目錄建立 `.env` 檔案，集中管理掃描參數

### 工作目錄與模板
請勿在版本庫根目錄下保留掃描輸出，避免污染原始碼。預設已忽略 `work/`
資料夾，可在執行前建立工作空間：

```bash
mkdir -p work/run1
```

若需要參考歷史掃描結果的結構，可自 `resources/workspace-templates/`
複製樣板後再啟動流程：

```bash
cp -R resources/workspace-templates/tmp-idor-test work/
```

### `.env` 與環境變數優先權
設定採用 `OP_` 前綴並支援巢狀鍵，例如 `OP_LIMITS__GLOBAL_RPS`、`OP_OOB__API_KEY`。
可於 `.env` 檔或系統環境變數中設定；後者會覆寫 `.env` 與 YAML 檔的值。

```dotenv
# .env 範例
OP_LIMITS__GLOBAL_RPS=45
OP_LIMITS__PER_HOST_RPS=8
OP_OOB__API_KEY=sk_live_example
```

優先順序為：**系統環境變數 > `.env` 檔案 > YAML 設定檔 > 內建預設值**。
若需要覆寫陣列設定（如 allow 列表），可提供 JSON 陣列字串：

```dotenv
OP_SCOPES__ALLOW=["https://example.com", "https://api.example"]
```

## M0：基礎掃描
```bash
make m0 WORKDIR=work/run1 DOMAIN=https://target.example
```
輸出：`work/run1/ranked.json`、`work/run1/out.sarif`、`work/run1/report.html`、`work/run1/poc/`
驗收：`ls work/run1/report.html`

## M1：服務枚舉
```bash
make m1 WORKDIR=work/run1 DOMAIN=https://target.example
```
輸出：`work/run1/schema/grpc_*.json`、`work/run1/findings.misconfig.json`
驗收：`ls work/run1/schema/grpc_*.json`

## M2：排序與 Gate
```bash
make m2 WORKDIR=work/run1
```
輸出：`work/run1/ranked.merged.json`、`work/run1/ranked.final.json`
驗收：`jq '.|length' work/run1/ranked.final.json`

## M3：OpenAPI 與新版報表
```bash
make m3 WORKDIR=work/run1 BASE=https://api.example
```
輸出：`work/run1/sequence/seq_*.sh`、`work/run1/requests.py`（可選）、`work/run1/report_v2.html`
驗收：`ls work/run1/report_v2.html work/run1/out.sarif`

## 驗收門檻
- `pytest -q` 全綠
- 乾跑 E2E 產出 HTML/SARIF/ZIP artifacts
- `python scripts/scorecard.py work/run1` ≥ 70/100（Discovery 45 / Verification 15 / Delivery 20 / Ecosystem 10 / Compliance 10）

## 疑難排解
1. 缺少模組 `requests` → `pip install requests`
2. `grpc.enumerate` 超時 → 確認目標支援 reflection
3. `precision_gate` 無輸出 → 確認 `ranked.merged.json` 路徑
4. Scorecard 未達標 → 檢查 `ranked.final.json` 是否存在
5. 命令找不到 → 先執行 `pip install -e .`
6. UI API 401 → 確認已透過環境變數或 `.env` 設定 `WARPRECON_UI_TOKEN`，並於請求帶上 `Authorization: Bearer <token>`

## RateLimiter 與退避共享
- 同一個 `workdir` 會產生 `limiter_state.json`，`run_hunt` 啟動時會載入上次掃描留下的 buckets，讓多次或多程序掃描沿用既有退避，避免再次觸發封鎖。
- HTTP、GraphQL、WebSocket 引擎會在遇到 429/5xx 或高延遲時回傳 `_status`、`_latency` 訊號給 `RateLimiter.update_from_response()`，自動調整 `global_rps` 與 `per_host_rps`，穩定控制速率。
- 需要重置退避時，刪除 `workdir/limiter_state.json` 即可重新從預設速率起跑。

## 度量與追蹤
`work/run1/metrics.jsonl`（以及快照 `metrics.json`）包含 `ttfp`（Time to First Finding）、`hits`、`duration_seconds` 等度量，`events.log` 則記錄每個階段的開始與結束事件，可用於比對不同設定的效果。

## GraphQL 探測設定
- `limits.graphql_budget`：控制每個 GraphQL 端點的查詢數量上限（預設 4）。可透過 `.env`（`OP_LIMITS__GRAPHQL_BUDGET`）或 profiles YAML 覆寫。
- `limits.graphql_max_depth`：調整自動產生 selection set 的遞迴深度上限（預設 3），可限制 inline fragment 展開程度。
- 管線會快取 introspection schema，並依上述限制產生帶變數的 Query/Mutation/Subscription；若 schema 缺漏則退回輕量的 `query { __typename }` 探針。

## 版本相容性
重大變更請參閱 [CHANGELOG.md](../CHANGELOG.md)。
