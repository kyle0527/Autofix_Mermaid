# ARCH — 架構與介面索引

## 系統概覽
```mermaid
flowchart TD
    subgraph op_core
        pipeline[op_core.pipeline]
        rank[op_core.rank]
    end
    subgraph op_proto
        http[op_proto.http/ws]
        grpc[op_proto.grpc]
        openapi[op_proto.openapi]
    end
    subgraph op_output
        html[op_output.html_v2]
        sarif[op_output.sarif]
        deliver[op_output.deliver]
    end
    subgraph op_dist
        queue[op_dist.queue]
        agent[op_dist.agent]
    end
    subgraph op_ui
        ui[op_ui.server]
    end
    subgraph op_stream
        stream[op_stream.*]
    end

    Targets --> pipeline
    pipeline --> http
    pipeline --> grpc
    pipeline --> openapi
    http --> rank
    grpc --> rank
    openapi --> rank
    rank --> html
    rank --> sarif
    rank --> deliver
    rank --> stream
    queue --> agent
    agent --> pipeline
    agent -.-> queue
    ui --> pipeline
    ui --> queue
    pipeline -.-> ui
    ui --> deliver
```

## 核心模組介面索引
| 模組 | 角色 | 主要介面 |
| --- | --- | --- |
| `op_core.pipeline` | 串接 M0→M3 任務與排程 | `run_pipeline(targets)` |
| `op_iast.*` | IAST 代理管理與成果擷取 | `op_iast.session.create_session`, `op_core.pipeline.iast.collect_iast_results` |
| `op_chain.workflow` | 商業邏輯 DSL 執行與攻擊鏈模擬 | `WorkflowExecutor`, `op_core.pipeline.logic.run_logic_workflows` |
| `op_proto.*` | 協定探測器（HTTP/gRPC/OpenAPI/GraphQL/WebSocket） | `http_probe`, `grpc.enumerate`, `openapi.sequence`, `graphql.engine.schema_payloads_for`, `graphql.runner.generate_candidates`, `ws.engine.ws_probe` |
| `op_core.rank` | 統整並排序 findings | `rank_findings(list[Finding])`, CLI `precision_gate` |
| `op_output.*` | 報告產生與 artifacts 封裝 | `html_v2`, `sarif`, `deliver` |
| `op_plugins.*` | 擴充 hook 與自訂檢查器 | `registry.json`, hooks：`vector_probe`, `post_rank`, `artifact_exporter` |
| `op_dist.queue` | 檔案系統佇列（pending/processing/done） | `FSQueue.enqueue`, `FSQueue.dequeue`, `FSQueue.status` |
| `op_dist.agent` | 輕量工作節點，輪詢佇列後呼叫 pipeline | `run_agent(workdir, cfg_path, max_loops=None)` |
| `op_ui.server` | Flask API + 簡易 UI，整合 queue 與報表瀏覽 | `/api/run`, `/api/queue/add`, `/api/findings` |
| `op_stream.*` | Issue Tracker 串流模板（GitLab/Jira） | `python -m op_stream.gitlab --in ranked.json --out out.json` |

## 分散式佇列與 Agent

`op_dist.queue` 以檔案系統為儲存層，在 `queue/` 下建立 `pending`、`processing`、`done` 三個資料夾，透過 `fcntl` 檔鎖確保多個節點安全操作。佇列中每個 `.json` 檔皆代表一筆 `{domain, cfg}` 任務，`status()` 可隨時掌握目前各狀態的數量。

`op_dist.agent.run_agent` 會持續呼叫 `FSQueue.dequeue()`，若無任務則依 `sleep_sec` 休眠；取得任務後會執行 `op_core.pipeline.run_pipeline()`，完成時再以 `FSQueue.complete()` 回寫成果並移動任務檔案至 `done`。核心流程簡化如下：

```python
while True:
    item = queue.dequeue()
    if not item:
        time.sleep(sleep_sec)
        continue
    tid, payload_path = item
    job = json.loads(payload_path.read_text())
    run_pipeline(job["domain"], cfg_path, runs_dir / tid)
    queue.complete(tid, {"ok": True})
```

典型操作流程：

```bash
# 1. 由任務入口（CLI/UI/自動化）加入排程
warprecon-m queue-add --workdir work/campA --domain example.com --cfg config/campaign.yaml

# 2. 在一台或多台 agent 節點輪詢 queue，依據工作量調整 --max-concurrency
warprecon-m agent run --workdir work/campA --cfg config/campaign.yaml --max-concurrency 6

# 3. 查看佇列現況
python - <<'PY'
from pathlib import Path
from op_dist.queue import FSQueue
print(FSQueue(Path('work/campA/queue')).status())
PY
```

多個 agent 可共用同一個 `workdir/queue`，檔案鎖會協調搬移 `pending → processing`，達到簡易的水平擴展。

## UI 與互動式流程

`op_ui.server.create_app` 提供一個 Flask Web UI，綜合指揮排程與展示成果：

- `/api/run`：立即啟動 pipeline（建立背景執行緒），支援 `profile`、`max_concurrency`、`capture`、`dom_crawl` 等參數。
- `/api/queue/add`：以 POST 方式新增佇列任務，交由外部 agent 消化。
- `/api/findings`、`/api/targets`、`/api/discovery`、`/api/oob`：以 JSON 回傳最新的輸出檔案，前端每 5 秒輪詢更新表格與建議攻擊鏈。
- `/api/deliver`：呼叫 `op_output.deliver` 打包成果供下載。

啟動方式：

```bash
warprecon-m ui --workdir work/campA --cfg config/campaign.yaml --port 8787
```

使用者可直接在 UI 內執行「Run Now」觸發即時掃描，或按「Queue」堆疊任務；UI 也會讀取 pipeline 輸出的 `ranked.json`、`targets.txt`、`discovery/` 等資料夾，自動刷新畫面。

啟用 DOM 探勘時，`discovery/` 會額外產出下列成果，方便 UI 與後續驗證使用：

- `dom-requests.json`：同站網路請求的精簡 HAR（method/url/headers/body）。
- `dom-endpoints.json`：從 DOM/JS 中推測的 `/api`、`/graphql`、WebSocket 端點。
- `dom-artifacts.json`：每個已擷取頁面的索引，記錄 HTML 快照與截圖的相對路徑，以及抽出的端點。
- `dom-capture/snapshots/*.html`、`dom-capture/screenshots/*.png`：對應的原始 DOM 快照與 PNG 螢幕截圖。

### GraphQL 查詢規劃

- `op_proto.graphql.schema.GraphQLSchema` 解析 introspection 結果並記錄 `possible_types`、欄位參數與輸入型別。
- `op_proto.graphql.runner.generate_candidates()` 依 schema 自動產出 Query/Mutation/Subscription 操作，補上參數化 variables，遇到 `UNION`/`INTERFACE` 會插入 inline fragment。
- `op_proto.graphql.engine.schema_payloads_for()` 從快取挑選操作並套用 `limits.graphql_budget`、`limits.graphql_max_depth` 限制；若 schema 不完整則回落到 `query { __typename }` 類型的輕量探針。

## 外部串流（op_stream.*）

`op_stream` 模組包含範例串流器，將 `ranked.json` 轉為 Issue Tracker 可讀的格式：

- `op_stream.gitlab`：輸出 GitLab Issue 陣列（JSON）。
- `op_stream.jira`：輸出 Jira 匯入用 JSONL，每筆對應一張票。

範例：

```bash
python -m op_stream.gitlab --in work/campA/ranked.json --out work/campA/gitlab-issues.json
python -m op_stream.jira --in work/campA/ranked.json --out work/campA/jira.ndjson --project SEC
```

此流程通常接在 `ranked.final.json` 產生後執行，可搭配 CI/CD 或額外腳本自動推送至既有追蹤系統。

## IAST 代理整合

`op_iast` 模組提供 IAST 代理的生命週期與資料模型，`op_core.pipeline.iast.collect_iast_results` 則在掃描階段結束後啟動收集：

- 預設的 `embedded` 傳輸會監看 `workdir/iast/findings.jsonl`（支援 JSON 與 JSONL），自動轉換成 `Finding` 物件並輸出為 `workdir/iast/findings.json`。
- Telemetry 新增 `iast.collect` 階段與 `execution.iast` 計數，可追蹤代理是否回傳證據與耗時。
- 合併階段 `_merge_and_gate` 會把 `findings.json` 納入排名與 Gate 流程，IAST 證據因此與其他掃描結果一併輸出、套用 Gate 規則。

若需整合自訂代理，可在 campaign 檔 `iast` 區塊調整 `transport`、`endpoint`、`buffer_path` 等設定，或覆寫 `op_iast.session.create_session` 掛載額外傳輸模式。

## 商業邏輯流程與狀態機

`op_chain.workflow` 模組與 pipeline 的 `logic` 階段提供 YAML DSL，模擬購物車、權限逸出等多步驟流程，並在觸發成功條件後輸出 Findings 與調試軌跡。

- Campaign `logic` 區塊：
  - `enabled`：預設為 `false`，開啟後才會解析 DSL。
  - `base_url`：未在 workflow 內覆寫時，會作為 `{{ base_url }}` 的預設值。
  - `context`：注入共用變數（例如帳號、固定 token），執行時可於模板以 `{{ vars.foo }}` 或 `{{ context.foo }}` 取用。
  - `workflows[]`：每項可指定 `path`（相對於 `workdir/` 或 `config/`）或 inline `manifest`，並支援 `variables`（合併進 workflow `context`）、`check`、`severity`、`entry` 等覆寫欄位。

- DSL 能力：
  - `states.<name>.steps[].http` 發送 HTTP 請求，支援 `expect.status`、`expect.contains`、`expect.absent` 與 `expect.json`；`capture` 可從 `json.foo`、`headers.Set-Cookie`、`status` 或 `regex` 抽取值。
  - `store`、`assert`、`emit` 步驟可分別寫入暫存變數、驗證條件、產生 findings。`emit` 預設 `check=chain.workflow`，並會將當前 `trace` 與 `workflow` 資訊寫入 `meta`。
  - `transitions` 支援 `success`、`failure`、`equals`、`contains`、`exists`／`not_exists`、`all`、`any` 條件，用於組合多分支狀態機與循環步驟。

- 執行結果會寫入 `workdir/logic/findings.json`，每筆紀錄包含 `variables` 與完整 `trace`（每一步的請求、回應與擷取資料），方便排除誤報或調整流程。
- Pipeline 會將所有由 `emit` 產生的 findings 與其他掃描結果一併排名、套用 Gate，Telemetry 則新增 `logic.workflow` 事件追蹤每個流程的成功與錯誤。

範例 DSL 位於 `docs/examples/workflows/checkout-bypass.yaml`，展示如何以三個狀態實作「加入購物車 → 手動改寫結帳 → 輸出證據」的攻擊鏈。

## 擴充點
- **Plugins registry**：`ext/plugins/registry.json`
  ```json
  [
    {"name": "path_dedupe", "module": "op_plugins.builtin.path_dedupe"}
  ]
  ```
- **自訂檢查器**：新增 `.py` 並實作任一 hook（名稱需與 `op_plugins.loader.HOOK_NAMES` 一致）。

### Plugin Hooks



1. `<workdir>/plugins`、`./plugins`、`./ext/plugins`、`op_plugins/builtin` 下的 `*.py` 檔案。
2. `registry.json` 所列出的模組（可放在 `<workdir>/plugins/registry.json`、`./plugins/registry.json` 或 `ext/plugins/registry.json`）。
3. 註冊於 `warprecon_m.plugins` entry point 群組的套件（透過 `pip install` 安裝即可載入）。

每個模組若實作 `HOOK_NAMES = ["vector_probe", "post_rank", "artifact_exporter"]` 中的函式，便會被加入對應 hook 名稱的佇列。載入器會自動去除重複的函式，確保相同檔案只會執行一次。只要回傳值與下列介面相符，即可在核心流程中被調用。

#### 執行順序概覽
1. **Vector hooks**：M0 開始前先呼叫所有 `vector_probe`，聚合回傳的 findings 後交由 pipeline 排程。
2. **Ranking hooks**：M2 排名完成後，以先載入先呼叫的順序套用 `post_rank`，結果會餵給報告產生器。
3. **Exporter hooks**：M3 產出標準 artifacts 後，依序執行 `artifact_exporter` 以生成額外檔案或對接外部服務。

#### `vector_probe`
- **執行時機**：排程前（M0 前），在核心排程產生預設 targets findings 之前。
- **函式簽章**：`def vector_probe(workdir: Path, camp: dict, targets: list[str]) -> list[dict]`
- **參數**：
  - `workdir`：目前工作路徑，例如 `work/run1`，可用於讀取／寫入暫存資料。
  - `camp`：此次掃描的活動設定（Campaign），常見鍵有 `name`、`scope`、`tags` 等。
  - `targets`：排程輸入的目標列表，請勿就地修改內容；如需變化，可複製後處理。
- **回傳值**：`list[dict]`，每個 dict 應符合 `ranked.json` 的基本欄位（`check`、`target`、`severity`、`_score` 等）。若沒有額外 findings，回傳空 list。
- **常見用途**：
  - 對既有 targets 執行額外 HTTP/gRPC 探測並將結果回填成 findings。
  - 根據 `camp` 的 metadata（例如活動類型、客製清單）注入靜態 findings。
  - 產生離線掃描結果或導入第三方情資。
- **實作備註**：確保函式穩定，失敗時可回傳空陣列；若需紀錄錯誤可寫入 `workdir / "logs"` 或使用 logging。

#### `post_rank`
- **執行時機**：排名之後（M2→M3 之間），核心已整併完所有 findings。
- **函式簽章**：`def post_rank(ranked: list[dict]) -> list[dict]`
- **參數**：
  - `ranked`：依 `_score` 排序的 findings list。可就地修改（例如更新 `_score`、新增欄位），亦可回傳新的 list。
- **回傳值**：`list[dict]`，通常為修改後的 `ranked`。必須保持每個元素能序列化為 JSON。
- **常見用途**：
  - 自訂排序策略（例如針對特定協定加權）。
  - 為報告新增欄位（`tags`、`owner` 等）或標記風險分級。
  - 在輸出前過濾掉不符條件的 findings。
- **實作備註**：建議在更新 `_rank` 時確保從 1 開始連號，以符合下游報告顯示需求。

#### `artifact_exporter`
- **執行時機**：報告產出後（M3），所有 findings 皆已最終化。
- **函式簽章**：`def artifact_exporter(workdir: Path, ranked: list[dict]) -> None`
- **參數**：
  - `workdir`：最終 artifacts 所在目錄，可用於寫入額外文件或資料夾。
  - `ranked`：最終排序結果。預設為 `ranked.final.json` 內容，應視為唯讀。
- **回傳值**：`None`。若有例外應自行攔截並回報（例如寫入失敗），避免中斷整體流程。
- **常見用途**：
  - 產出 PDF／Markdown 摘要或團隊簡報。
  - 對接 Issue Tracker、Slack webhook 等外部系統。
  - 匯出額外資料（如 JSON lines、CSV）。
- **實作備註**：建議在 `workdir / "plugins"` 下建立子資料夾，避免與核心輸出衝突。

#### 以 entry point 註冊 plugin

將 plugin 打包成 Python 套件時，可在 `pyproject.toml` 中加入 entry point，使執行
環境自動載入對應模組：

```toml
[project.entry-points."warprecon.plugins"]
demo_plugin = "my_package.plugins.demo"
```

`op_plugins.loader` 會在啟動時載入這些模組並蒐集 hook 函式；同時
`op_core.plugins` 也會載入相同 entry point，讓模組能在匯入時呼叫
`register_protocol()` 來註冊額外的協定探測器。

### 範例 Plugin
```python
# plugins/demo_plugin.py
from pathlib import Path
from typing import Any, Dict, List

def vector_probe(workdir: Path, camp: Dict[str, Any], targets: List[str]) -> List[Dict[str, Any]]:
    """在排程前針對 /healthz 端點新增預設 findings。"""
    return [
        {
            "check": "demo/vector",
            "target": t,
            "severity": "info",
            "evidence": {"note": "preflight"},
            "_score": 0.1,
        }
        for t in targets
        if t.endswith("/healthz")
    ]


def post_rank(ranked: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """將 critical findings 提前，並重新編號 _rank。"""
    for item in ranked:
        if item.get("severity") == "critical":
            item["_score"] = item.get("_score", 0) + 10
    ranked.sort(key=lambda x: float(x.get("_score", 0)), reverse=True)
    for idx, item in enumerate(ranked, start=1):
        item["_rank"] = idx
    return ranked


def artifact_exporter(workdir: Path, ranked: List[Dict[str, Any]]) -> None:
    """輸出文字摘要，方便人工複核。"""
    report = workdir / "plugins" / "demo_report.txt"
    report.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"#{item.get('_rank', '?')} {item.get('target')} {item.get('severity')}" for item in ranked]
    report.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    # Minimal invocation：由 loader 收集 hooks 並逐一呼叫。
    from pathlib import Path
    from op_plugins.loader import load_plugins

    workdir = Path("work/run1")
    workdir.mkdir(parents=True, exist_ok=True)
    hooks = load_plugins(workdir)
    camp = {"name": "demo"}
    targets = ["https://app.example/", "https://app.example/healthz"]

    for probe in hooks.get("vector_probe", []):
        findings = probe(workdir, camp, targets)
        print("vector findings", findings)

    ranked = [{"target": "https://app.example/", "severity": "critical", "_score": 5}]
    for modifier in hooks.get("post_rank", []):
        ranked = modifier(ranked)

    for exporter in hooks.get("artifact_exporter", []):
        exporter(workdir, ranked)
```

> 若要在正式流程中啟用此 plugin，可將檔案放在 `plugins/` 或 `ext/plugins/` 後，在 `ext/plugins/registry.json`（或對應工作目錄的 `registry.json`）加入模組名稱，例如：
> ```json
> [
>   {"name": "demo_plugin", "module": "plugins.demo_plugin"}
> ]
> ```
> 亦可在外掛套件的 `pyproject.toml` 中設定 `[project.entry-points."warprecon_m.plugins"]`，並透過 `pip install` 讓 loader 自動載入。
> 執行 `python plugins/demo_plugin.py` 會顯示 loader 回傳的 hooks 以及 `artifact_exporter` 寫出的檔案，例如：
> ```text
> vector findings [{'check': 'demo/vector', 'target': 'https://app.example/healthz', 'severity': 'info', 'evidence': {'note': 'preflight'}, '_score': 0.1}]
> ```
> 插件可依需求擴充 logging、錯誤處理與額外輸出檔案。

> 亦可參考 `docs/plugins_entrypoint_demo.md` 了解如何建立 entry point 外掛並驗證載入流程。

## 資料契約
### ranked.json / ranked.final.json
| 欄位 | 說明 |
| --- | --- |
| `check` | 檢查器名稱 |
| `target` | 探測目標 |
| `severity` | 嚴重度 |
| `evidence` | 佐證資料 |
| `_score` | 排名分數 |
| `_rank` | 排名順序 |

### metrics.jsonl / metrics.json
| 欄位 | 說明 |
| `status` | `running`、`success` 或 `error` |
| `ttfp_seconds` | Time to First Finding（秒） |
| `duration_seconds` | 總耗時（秒） |
| `hits` | Findings 總數 |
| `confirmed_hits` | 確認命中數 |
| `first_hit_ts` / `first_confirmed_ts` | 首次命中的時間戳 |

### events.log
- JSON Lines，紀錄 `pipeline.start`、各階段狀態與 `pipeline.finish` / `pipeline.error`。

### deliverable.zip
包含 `report_v2.html`、`out.sarif`、`ranked.final.json` 等 artifacts。

> API 細節請見各模組的 docstring，此處僅維護最小 I/O 契約。

## 開發進度快照
### 已完成
- WebSocket 探測器擴充握手矩陣（子協定、心跳、壓縮）並加入 JSON／二進位 payload 策略與 GraphQL Subscription 自動化，以提升即時訊息端點的命中率與佐證資訊。
- 遙測指標新增握手（含 STOMP、Socket.IO）與 payload 策略維度，統計成功率、延遲與錯誤原因，並輸出至 CLI／報表摘要。

### 下一步
- 針對蒐集到的握手／策略統計設計自動化建議（例如優先重試表現最佳的 profile），並評估是否需擴充更多情境化 payload。
