# OPERATION — M0→M3 Runbook & Acceptance Criteria

## Environment Preparation
- Python 3.11+
- Optional: Docker image `python:3.11`
- Install dependencies: `pip install -r requirements-dev.txt`
- Optional extras (DOM discovery / gRPC reflection): `pip install -e .[dom,grpc]` then run `playwright install`
- UI requires tokens: provide one via `warprecon-m ui --auth-token <token>` or export `WARPRECON_UI_TOKEN` (comma separated for multiple tokens) before launching

## Workspace hygiene
Keep runtime artifacts outside the repository tree. The top-level `work/`
directory is ignored, so prepare a workspace before running the make targets:

```bash
mkdir -p work/run1
```

When you need a reference structure, copy one of the templates under
`resources/workspace-templates/` prior to launching the scan:

```bash
cp -R resources/workspace-templates/tmp-idor-test work/
```

## M0: Baseline Scan
```bash
make m0 WORKDIR=work/run1 DOMAIN=https://target.example
```
Outputs: `work/run1/ranked.json`, `work/run1/out.sarif`, `work/run1/report.html`, `work/run1/poc/`
Acceptance: `ls work/run1/report.html`

## M1: Service Enumeration
```bash
make m1 WORKDIR=work/run1 DOMAIN=https://target.example
```
Outputs: `work/run1/schema/grpc_*.json`, `work/run1/findings.misconfig.json`
Acceptance: `ls work/run1/schema/grpc_*.json`

## M2: Ranking & Gate
```bash
make m2 WORKDIR=work/run1
```
Outputs: `work/run1/ranked.merged.json`, `work/run1/ranked.final.json`
Acceptance: `jq '.|length' work/run1/ranked.final.json`

## M3: OpenAPI & New Report
```bash
make m3 WORKDIR=work/run1 BASE=https://api.example
```
Outputs: `work/run1/sequence/seq_*.sh`, optional `work/run1/requests.py`, `work/run1/report_v2.html`
Acceptance: `ls work/run1/report_v2.html work/run1/out.sarif`

## Acceptance Gate
- `pytest -q` must pass
- Dry-run E2E to produce HTML/SARIF/ZIP artifacts
- `python scripts/scorecard.py work/run1` ≥ 70/100 (Discovery 45 / Verification 15 / Delivery 20 / Ecosystem 10 / Compliance 10)

## Troubleshooting
1. Missing module `requests` → `pip install requests`
2. `grpc.enumerate` timeout → Ensure the target supports reflection
3. `precision_gate` produces no output → Confirm the `ranked.merged.json` path
4. Scorecard below target → Check whether `ranked.final.json` exists
5. Command not found → Run `pip install -e .` first
6. UI API returns 401 → Set `WARPRECON_UI_TOKEN` and include `Authorization: Bearer <token>`

## Metrics & Tracking
`work/run1/metrics.jsonl` (and the snapshot `metrics.json`) records `ttfp`, `hits`, and `duration_seconds`; `events.log` captures stage-level `pipeline.start` / `pipeline.finish` progress for comparing configurations.

## GraphQL probing knobs
- `limits.graphql_budget`: caps the number of GraphQL operations scheduled per endpoint (default 4). Override via `.env` (`OP_LIMITS__GRAPHQL_BUDGET`) or profile YAML.
- `limits.graphql_max_depth`: bounds the recursive selection depth (default 3), limiting how many levels of inline fragments are expanded.
- The pipeline caches introspection schemas and uses them to craft parameterised Query/Mutation/Subscription probes; if schema data is missing it falls back to lightweight `query { __typename }` checks.

## Version Compatibility
Refer to [CHANGELOG.md](../CHANGELOG.md) for breaking changes.
