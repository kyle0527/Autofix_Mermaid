from __future__ import annotations

import json, threading, time, socket, subprocess, sys, os
from contextlib import closing
from pathlib import Path

import pytest

from tests.mock_idor_app import create_mock_app


def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def live(tmp_path_factory):
    port = _free_port()
    app = create_mock_app()
    th = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False), daemon=True)
    th.start()
    for _ in range(60):
        import httpx
        try:
            httpx.get(f"http://127.0.0.1:{port}/", timeout=0.2)
            break
        except Exception:
            time.sleep(0.05)
    return port


def test_cli_idor_basic(tmp_path, live):
    base = f"http://127.0.0.1:{live}"
    targets = tmp_path/"targets.json"
    
    # Use JSON format to properly specify owner_user_id
    target_data = [
        {"url": f"{base}/api/v1/notes/2", "owner_user_id": 2},        # insecure
        {"url": f"{base}/api/v1/secret-docs/201", "owner_user_id": 2}, # reverse bypass
        {"url": f"{base}/api/v1/item?id=52", "owner_user_id": 2}      # query param with owner_user_id
    ]
    targets.write_text(json.dumps(target_data, indent=2), encoding="utf-8")
    
    out = tmp_path/"out.json"
    cmd = [sys.executable, "-m", "op_core.cli", "idor", "--targets", str(targets), "--out", str(out), "--expand-variants", "--json"]
    
    # Set environment with correct PYTHONPATH
    env = os.environ.copy()
    src_path = Path(__file__).resolve().parents[1] / "src"
    existing = env.get("PYTHONPATH")
    if existing:
        env["PYTHONPATH"] = f"{src_path}{os.pathsep}{existing}"
    else:
        env["PYTHONPATH"] = str(src_path)

    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=40, env=env)
    assert proc.returncode == 0, proc.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    
    # Check for reverse bypass detection
    reverse_bypass_found = any(f.get("meta", {}).get("pattern") == "reverse_bypass" for f in data)
    
    # Debug output if test fails
    if not reverse_bypass_found:
        print("\\nDEBUG: Findings:")
        for f in data:
            print(f"  - {f.get('title', 'No title')}: {f.get('meta', {}).get('pattern', 'No pattern')}")
            print(f"    URL: {f.get('meta', {}).get('url')}")
            print(f"    Owner status: {f.get('meta', {}).get('owner_status')}, Alt status: {f.get('meta', {}).get('alt_status')}")
    
    assert reverse_bypass_found, f"Expected reverse_bypass pattern not found in findings: {[f.get('meta', {}).get('pattern') for f in data]}"
    
    # Also check that some variant testing occurred
    urls_tested = {f.get("meta", {}).get("url") for f in data}
    assert any("item" in url for url in urls_tested), "Expected item URL variants to be tested"


def test_cli_idor_exclude(tmp_path, live):
    base = f"http://127.0.0.1:{live}"
    targets = tmp_path/"targets.txt"
    targets.write_text(f"{base}/api/v1/notes/2\n{base}/api/v1/secret-docs/201\n", encoding="utf-8")
    out = tmp_path/"out.json"
    cmd = [sys.executable, "-m", "op_core.cli", "idor", "--targets", str(targets), "--out", str(out), "--expand-variants", "--exclude", "secret-docs"]
    
    # Set environment with correct PYTHONPATH
    env = os.environ.copy()
    src_path = Path(__file__).resolve().parents[1] / "src"
    existing = env.get("PYTHONPATH")
    if existing:
        env["PYTHONPATH"] = f"{src_path}{os.pathsep}{existing}"
    else:
        env["PYTHONPATH"] = str(src_path)
    
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=40, env=env)
    assert proc.returncode == 0, proc.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    # Ensure secret-docs excluded
    assert not any("secret-docs" in f.get("meta", {}).get("url", "") for f in data)