from __future__ import annotations

import json
from pathlib import Path

import pytest

from op_core.session import (
    CookieFormatError,
    CookieParseError,
    load_cookies,
)


def _write_cookie_file(tmp_path: Path, data: object) -> Path:
    session_dir = tmp_path / "session"
    session_dir.mkdir()
    cookie_file = session_dir / "cookies.json"
    cookie_file.write_text(json.dumps(data), encoding="utf-8")
    return cookie_file


def test_load_cookies_chrome_export(tmp_path: Path) -> None:
    data = {
        "cookies": [
            {
                "name": "a",
                "value": "1",
                "domain": ".example.com",
                "hostOnly": True,
                "path": "/",
            },
            {"name": "b", "value": "2", "domain": "", "path": ""},
        ]
    }
    _write_cookie_file(tmp_path, data)
    jar = load_cookies(tmp_path)

    assert jar.get("a") == "1"
    assert jar.get("b") == "2"
    if hasattr(jar, "jar"):
        domains = {cookie.domain for cookie in jar.jar}
        assert "example.com" in domains


def test_load_cookies_list_json(tmp_path: Path) -> None:
    data = [{"name": "token", "value": "xyz", "path": "/app"}]
    _write_cookie_file(tmp_path, data)
    jar = load_cookies(tmp_path)

    assert jar.get("token") == "xyz"


def test_load_cookies_invalid_json(tmp_path: Path) -> None:
    session_dir = tmp_path / "session"
    session_dir.mkdir()
    (session_dir / "cookies.json").write_text("{not valid", encoding="utf-8")

    with pytest.raises(CookieParseError):
        load_cookies(tmp_path)


def test_load_cookies_missing_required_fields(tmp_path: Path) -> None:
    data = [{"value": "1"}]
    _write_cookie_file(tmp_path, data)

    with pytest.raises(CookieFormatError):
        load_cookies(tmp_path)

