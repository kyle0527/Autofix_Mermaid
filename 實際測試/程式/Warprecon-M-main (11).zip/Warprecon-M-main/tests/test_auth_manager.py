from __future__ import annotations

import inspect
from types import SimpleNamespace

import pytest

from op_auth import AuthManager, AuthStrategy


class DummyStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.login_calls = 0

    def login(self, client) -> None:
        self.login_calls += 1
        client["token"] = "ok"

    def ensure_session(self, client) -> None:
        if "token" not in client:
            self.login(client)


@pytest.mark.asyncio
async def test_multi_role_manager_handles_sessions() -> None:
    admin_strategy = DummyStrategy()
    user_strategy = DummyStrategy()

    mgr = AuthManager(
        {"admin": admin_strategy, "user": user_strategy},
        client_factory=dict,
    )

    admin_client = await mgr.client_for("admin")
    assert admin_strategy.login_calls == 1

    # simulate expiry
    del admin_client["token"]
    admin_client = await mgr.client_for("admin")
    assert admin_strategy.login_calls == 2

    user_client = await mgr.client_for("user")
    assert user_strategy.login_calls == 1
    assert admin_client is not user_client


@pytest.mark.asyncio
async def test_prime_logs_in_all_roles() -> None:
    admin_strategy = DummyStrategy()
    user_strategy = DummyStrategy()

    mgr = AuthManager(
        {"admin": admin_strategy, "user": user_strategy},
        client_factory=dict,
    )

    await mgr.prime()

    assert admin_strategy.login_calls == 1
    assert user_strategy.login_calls == 1


class RefreshStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.login_calls = 0
        self.refresh_calls = 0
        self._needs_refresh = False

    async def login(self, client) -> None:  # type: ignore[override]
        self.login_calls += 1

    async def ensure_session(self, client) -> None:  # type: ignore[override]
        return None

    def needs_refresh(self, client) -> bool:  # type: ignore[override]
        return self._needs_refresh

    async def refresh(self, client) -> None:  # type: ignore[override]
        self.refresh_calls += 1
        self._needs_refresh = False

    def mark_for_refresh(self) -> None:  # type: ignore[override]
        self._needs_refresh = True


class HookClient:
    def __init__(self) -> None:
        self.event_hooks = {"response": []}

    async def request(self, *args, **kwargs):  # type: ignore[override]
        response = SimpleNamespace(
            status_code=401,
            request=SimpleNamespace(url=kwargs.get("url") or args[1] if len(args) > 1 else None),
        )
        for hook in list(self.event_hooks.get("response", [])):
            result = hook(response)
            if inspect.isawaitable(result):
                await result
        return response

    async def aclose(self) -> None:  # type: ignore[override]
        return None


@pytest.mark.asyncio
async def test_manager_marks_refresh_after_unauthorised_response() -> None:
    strategy = RefreshStrategy()
    mgr = AuthManager({"default": strategy}, client_factory=HookClient)

    client = await mgr.client_for("default")
    assert strategy.login_calls == 1

    await client.request("GET", "https://example.test/api")
    assert strategy.needs_refresh(client)

    await mgr.client_for("default")
    assert strategy.refresh_calls == 1


class ExportStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.login_calls = 0

    async def login(self, client) -> None:  # type: ignore[override]
        self.login_calls += 1

    async def ensure_session(self, client) -> None:  # type: ignore[override]
        return None

    def export_state(self) -> dict:  # type: ignore[override]
        return {
            "artifacts": {
                "headers": {"X-Test": "1"},
                "cookies": {"session": "abc"},
                "query": {"mode": "debug"},
                "body": {"extra": True},
                "token": "token-123",
            }
        }


@pytest.mark.asyncio
async def test_session_artifacts_export() -> None:
    strategy = ExportStrategy()
    mgr = AuthManager({"user": strategy}, client_factory=dict)

    await mgr.client_for("user")

    artifacts = mgr.session_artifacts("user")
    assert artifacts["headers"]["X-Test"] == "1"
    assert artifacts["cookies"]["session"] == "abc"
    assert artifacts["query"]["mode"] == "debug"
    assert artifacts["body"]["extra"] is True
    assert artifacts["token"] == "token-123"
    assert mgr.session_artifacts("missing") == {}
