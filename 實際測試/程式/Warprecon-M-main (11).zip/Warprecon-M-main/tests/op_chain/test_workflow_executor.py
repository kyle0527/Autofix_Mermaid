import asyncio
from types import SimpleNamespace


from op_chain.workflow import Workflow, WorkflowExecutor


class StubResponse:
    def __init__(self, method: str, url: str, status: int, *, text: str = "", json_data=None, headers=None):
        self.status_code = status
        self._text = text
        self._json = json_data
        self.headers = headers or {}
        self.request = SimpleNamespace(url=url, method=method)

    @property
    def text(self) -> str:
        return self._text

    def json(self):
        if self._json is None:
            raise ValueError("no json available")
        return self._json


class StubClient:
    def __init__(self, responses):
        self._responses = list(responses)

    async def request(self, method: str, url: str, **kwargs):
        if not self._responses:
            raise AssertionError("no responses remaining")
        response = self._responses.pop(0)
        response.request = SimpleNamespace(url=url, method=method)
        return response

    async def aclose(self):  # pragma: no cover - compatibility shim
        return None


def test_workflow_executor_emits_finding():
    manifest = {
        "id": "checkout-bypass",
        "entry": "start",
        "states": {
            "start": {
                "steps": [
                    {
                        "http": {
                            "name": "add-to-cart",
                            "method": "POST",
                            "url": "{{ base_url }}/cart",
                            "json": {"sku": "sku-1", "qty": 1},
                            "expect": {"status": 200, "contains": "OK"},
                            "capture": {"receipt": "json.receipt"},
                        }
                    },
                    {
                        "emit": {
                            "title": "Checkout bypass",
                            "detail": "Receipt {{ vars.receipt }} processed",
                            "severity": "high",
                        }
                    },
                ],
            }
        },
    }
    workflow = Workflow.from_mapping(manifest)
    responses = [
        StubResponse(
            "POST",
            "https://shop.local/cart",
            200,
            text="OK",
            json_data={"receipt": "abc123"},
        )
    ]
    client = StubClient(responses)
    executor = WorkflowExecutor(workflow, base_context={"base_url": "https://shop.local"})
    run = asyncio.run(executor.run(client))

    assert run.success is True
    assert run.variables["receipt"] == "abc123"
    assert len(run.findings) == 1
    finding = run.findings[0]
    assert finding.detail.endswith("abc123 processed")
    assert finding.meta["workflow"]["id"] == "checkout-bypass"
    assert any(step["action"] == "http" for step in run.trace)


def test_workflow_executor_transitions_on_failure():
    manifest = {
        "id": "login-guard",
        "entry": "start",
        "states": {
            "start": {
                "steps": [
                    {
                        "http": {
                            "method": "POST",
                            "url": "{{ base_url }}/login",
                            "json": {"username": "user", "password": "bad"},
                            "expect": {"status": 200},
                        }
                    }
                ],
                "transitions": [
                    {"when": {"failure": True}, "target": "report"},
                    {"when": {"success": True}, "target": "done"},
                ],
            },
            "report": {
                "steps": [
                    {
                        "emit": {
                            "title": "Login bypass detected",
                            "detail": "Server returned {{ last.response.status }}",
                            "severity": "medium",
                        }
                    }
                ]
            },
            "done": {"steps": []},
        },
    }
    workflow = Workflow.from_mapping(manifest)
    responses = [
        StubResponse(
            "POST",
            "https://shop.local/login",
            403,
            text="Denied",
        )
    ]
    client = StubClient(responses)
    executor = WorkflowExecutor(workflow, base_context={"base_url": "https://shop.local"})
    run = asyncio.run(executor.run(client))

    assert run.success is True
    assert len(run.findings) == 1
    assert "403" in run.findings[0].detail
    assert run.trace[0]["success"] is False
