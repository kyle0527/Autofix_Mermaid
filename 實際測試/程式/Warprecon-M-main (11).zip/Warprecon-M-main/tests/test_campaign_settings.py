from __future__ import annotations

import yaml

from op_control.campaign import load_campaign


def test_load_campaign_env_overrides(tmp_path, monkeypatch):
    cfg_path = tmp_path / "campaign.yaml"
    cfg_path.write_text(
        yaml.safe_dump(
            {
                "limits": {"global_rps": 12, "per_host_rps": 3},
                "oob": {"api_key": "yaml-key"},
                "accounts": {"default_profile": "yaml-profile", "sources": ["cfg"]},
                "precision": {"gate": {"threshold": 0.25}},
                "deploy": {"compose_file": "docker-compose.local.yml"},
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setenv("OP_LIMITS__GLOBAL_RPS", "80")
    monkeypatch.setenv("OP_OOB__API_KEY", "env-secret")
    monkeypatch.setenv("OP_ACCOUNTS__DEFAULT_PROFILE", "env-profile")
    monkeypatch.setenv("OP_PRECISION__GATE__TOP_N", "42")
    monkeypatch.setenv("OP_DEPLOY__COMPOSE_FILE", "docker-compose.env.yml")

    campaign = load_campaign(cfg_path)

    assert campaign.limits.global_rps == 80  # environment overrides YAML
    assert campaign.limits.per_host_rps == 3  # unchanged value remains
    assert campaign.oob.api_key == "env-secret"
    assert campaign.accounts.default_profile == "env-profile"
    assert campaign.accounts.sources == ["cfg"]
    assert campaign.precision.gate.threshold == 0.25
    assert campaign.precision.gate.top_n == 42
    assert campaign.deploy.compose_file == "docker-compose.env.yml"
