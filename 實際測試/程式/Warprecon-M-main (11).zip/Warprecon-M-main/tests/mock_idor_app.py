
#!/usr/bin/env python3
"""
Mock IDOR service for testing unauthorized access detection.
Simulates various endpoint behaviors including secure and insecure access patterns.
"""

from flask import Flask, jsonify, request, session
from typing import Dict, Any, Optional
import requests
import secrets
import threading
import time

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Mock user database
USERS = {
    "admin": {"id": 1, "role": "admin", "password": "admin123", "email": "admin@example.com"},
    "user1": {"id": 2, "role": "user", "password": "user123", "email": "user1@example.com"},
    "user2": {"id": 3, "role": "user", "password": "user456", "email": "user2@example.com"},
}

# Mock data - documents that users should/shouldn't access
DOCUMENTS = {
    1: {"id": 1, "title": "Public Document", "content": "This is public", "owner_id": None, "public": True},
    2: {"id": 2, "title": "User1 Private Doc", "content": "User1's private document", "owner_id": 2, "public": False},
    3: {"id": 3, "title": "User2 Private Doc", "content": "User2's private document", "owner_id": 3, "public": False},
    4: {"id": 4, "title": "Admin Only Doc", "content": "Admin only document", "owner_id": 1, "public": False},
}

ORDERS = {
    10: {"id": 10, "owner": 1, "total": 49.0},
    11: {"id": 11, "owner": 2, "total": 29.0},
}

PROFILES = {
    user_data["id"]: {
        "id": user_data["id"],
        "username": username,
        "email": user_data["email"],
        "role": user_data["role"],
        "plan": "enterprise" if user_data["role"] == "admin" else "standard",
    }
    for username, user_data in USERS.items()
}

# Mock sessions storage
SESSIONS = {}

def get_current_user() -> Optional[Dict[str, Any]]:
    """Get current authenticated user from session."""
    user_id = session.get("user_id")
    if user_id:
        for username, user_data in USERS.items():
            if user_data["id"] == user_id:
                return {"username": username, **user_data}
    return None

def is_admin(user: Optional[Dict[str, Any]]) -> bool:
    """Check if user has admin role."""
    return user and user.get("role") == "admin"

def can_access_document(user: Optional[Dict[str, Any]], doc_id: int) -> bool:
    """Check if user can access the document."""
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        return False
    
    # Public documents are accessible to all
    if doc.get("public"):
        return True
    
    # No user logged in
    if not user:
        return False
    
    # Admin can access everything
    if is_admin(user):
        return True
    
    # User can access their own documents
    return doc.get("owner_id") == user.get("id")

@app.route("/")
def index():
    """Root endpoint."""
    return jsonify({"message": "IDOR Test Service", "version": "1.0"})

@app.route("/login", methods=["POST"])
def login():
    """Login endpoint."""
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    
    user = USERS.get(username)
    if user and user["password"] == password:
        session["user_id"] = user["id"]
        session["username"] = username
        token = secrets.token_hex(16)
        SESSIONS[token] = {
            "user_id": user["id"],
            "username": username,
            "created_at": time.time()
        }
        return jsonify({
            "success": True,
            "message": "Login successful",
            "token": token,
            "user": {"id": user["id"], "username": username, "role": user["role"]}
        })
    
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route("/logout", methods=["POST"])
def logout():
    """Logout endpoint."""
    session.clear()
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if token in SESSIONS:
        del SESSIONS[token]
    return jsonify({"success": True, "message": "Logged out"})

@app.route("/profile")
def profile():
    """User profile endpoint - requires authentication."""
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    
    return jsonify({
        "id": user["id"],
        "username": user["username"],
        "email": user["email"],
        "role": user["role"]
    })

@app.route("/documents")
def list_documents():
    """List documents endpoint."""
    user = get_current_user()
    accessible_docs = []
    
    for doc_id, doc in DOCUMENTS.items():
        if can_access_document(user, doc_id):
            accessible_docs.append({
                "id": doc["id"],
                "title": doc["title"],
                "public": doc.get("public", False)
            })
    
    return jsonify({"documents": accessible_docs})

@app.route("/documents/<int:doc_id>")
def get_document(doc_id: int):
    """Get specific document - VULNERABLE to IDOR."""
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    
    # VULNERABILITY: No access control check!
    return jsonify(doc)


# Additional routes used by CLI tests (notes, secret-docs, item)
@app.route("/api/v1/notes/<int:nid>")
def api_notes(nid: int):
    # Reuse DOCUMENTS where possible: map note id to DOCUMENTS if present
    doc = DOCUMENTS.get(nid)
    if not doc:
        return jsonify({"error": "missing"}), 404
    # naive owner check via X-User-ID header
    uid = request.headers.get("X-User-ID")
    payload = {
        "id": doc["id"],
        "owner": doc.get("owner_id"),
        "content": doc.get("content", ""),
    }
    if uid and uid.isdigit() and int(uid) == doc.get("owner_id"):
        return jsonify(payload)
    # unintended exposure (simulate vulnerable endpoint)
    return jsonify(payload)


@app.route("/api/v1/secret-docs/<int:doc_id>")
def api_secret_docs(doc_id: int):
    # Reverse bypass: determine owner of the document and deny access to the owner,
    # while allowing others. For simple test coverage we derive an owner for
    # higher doc IDs so tests like /secret-docs/201 can map to owner 2.
    uid = request.headers.get("X-User-ID")
    # Determine owner from DOCUMENTS mapping if present
    owner = None
    doc = DOCUMENTS.get(doc_id)
    if doc:
        owner = doc.get("owner_id") or doc.get("owner") or doc.get("owner_id")
    else:
        # Derive a simple owner mapping for synthetic high IDs: owner = doc_id - 199
        # so 200 -> 1, 201 -> 2, etc. This keeps tests deterministic.
        try:
            owner = int(doc_id) - 199
        except Exception:
            owner = None

    if uid and uid.isdigit() and owner is not None and int(uid) == int(owner):
        return ("denied", 403)
    return jsonify({"doc": doc_id, "data": "classified"})


@app.route("/api/v1/item")
def api_item():
    iid = request.args.get("id")
    if not iid:
        return jsonify({"error": "missing id"}), 400
    return jsonify({"id": iid, "value": f"val-{iid}"})


@app.route("/api/v1/orders/<int:order_id>")
def api_orders(order_id: int):
    uid = request.headers.get("X-User-ID")
    if not uid or not uid.isdigit():
        return jsonify({"error": "Authentication required"}), 401
    order = ORDERS.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404
    if int(uid) != order.get("owner"):
        return jsonify({"error": "Access denied"}), 403
    return jsonify({"id": order["id"], "owner": order.get("owner"), "total": order.get("total", 0)})


@app.route("/api/v1/profile/<int:user_id>")
def api_profile(user_id: int):
    profile = PROFILES.get(user_id)
    if not profile:
        return jsonify({"error": "Profile not found"}), 404

    uid = request.headers.get("X-User-ID")
    if uid and uid.isdigit() and int(uid) == user_id:
        return jsonify(profile)
    if not uid:
        return jsonify({"error": "Authentication required"}), 401

    partial = {
        "id": profile["id"],
        "username": profile["username"],
        "email": "redacted",
        "plan": profile.get("plan", "basic"),
    }
    return jsonify(partial), 206


@app.route("/secure/documents/<int:doc_id>")
def get_document_secure(doc_id: int):
    """Get specific document - SECURE version with proper access control."""
    user = get_current_user()

    if not can_access_document(user, doc_id):
        return jsonify({"error": "Access denied"}), 403
    
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    
    return jsonify(doc)

@app.route("/users/<int:user_id>")
def get_user(user_id: int):
    """Get user info - VULNERABLE to IDOR."""
    for username, user_data in USERS.items():
        if user_data["id"] == user_id:
            # VULNERABILITY: Returns sensitive data without access control
            return jsonify({
                "id": user_data["id"],
                "username": username,
                "email": user_data["email"],
                "role": user_data["role"]
            })
    
    return jsonify({"error": "User not found"}), 404

@app.route("/secure/users/<int:user_id>")
def get_user_secure(user_id: int):
    """Get user info - SECURE version."""
    current_user = get_current_user()
    
    # Only admin or the user themselves can access user data
    if not current_user or (current_user["id"] != user_id and not is_admin(current_user)):
        return jsonify({"error": "Access denied"}), 403
    
    for username, user_data in USERS.items():
        if user_data["id"] == user_id:
            return jsonify({
                "id": user_data["id"],
                "username": username,
                "email": user_data["email"],
                "role": user_data["role"]
            })
    
    return jsonify({"error": "User not found"}), 404

@app.route("/api/v1/resource")
def api_resource():
    """API endpoint that checks query parameter access."""
    resource_id = request.args.get("id")
    if not resource_id:
        return jsonify({"error": "Missing id parameter"}), 400
    
    try:
        resource_id = int(resource_id)
    except ValueError:
        return jsonify({"error": "Invalid id parameter"}), 400
    
    # VULNERABILITY: No access control on query parameter
    if resource_id in DOCUMENTS:
        return jsonify({"resource": DOCUMENTS[resource_id]})
    
    return jsonify({"error": "Resource not found"}), 404

@app.route("/auth/token", methods=["GET"])
def check_token():
    """Check if token-based auth is valid."""
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    
    if token in SESSIONS:
        session_data = SESSIONS[token]
        return jsonify({
            "valid": True,
            "user_id": session_data["user_id"],
            "username": session_data["username"]
        })
    
    return jsonify({"valid": False}), 401

# Global variable to store the server
_server = None
_thread = None
_server_port: Optional[int] = None

def start_mock_server(port: int = 5555) -> str:
    """Start the mock server in a background thread."""
    global _server, _thread, _server_port

    base_url = f"http://127.0.0.1:{port}"
    if _thread and _thread.is_alive() and _server_port == port:
        return base_url

    def run_server():
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)

    _thread = threading.Thread(target=run_server, daemon=True)
    _thread.start()
    _server_port = port

    # Wait for readiness
    deadline = time.time() + 5.0
    while time.time() < deadline:
        try:
            requests.get(f"{base_url}/", timeout=0.3)
            break
        except Exception:
            time.sleep(0.05)

    return base_url

def stop_mock_server():
    """Stop the mock server."""
    global _server, _thread
    # Flask doesn't provide an easy way to stop from code, 
    # but since it's running in daemon thread, it will stop when main process ends
    pass

def create_mock_app():
    """Create and return the mock Flask app for testing."""
    return app

if __name__ == "__main__":
    print("Starting IDOR mock service...")
    print("Available endpoints:")
    print("  POST /login - Login with username/password")
    print("  GET /profile - Get user profile (requires auth)")
    print("  GET /documents - List accessible documents")
    print("  GET /documents/<id> - Get document (VULNERABLE)")
    print("  GET /secure/documents/<id> - Get document (SECURE)")
    print("  GET /users/<id> - Get user info (VULNERABLE)")
    print("  GET /secure/users/<id> - Get user info (SECURE)")
    print("  GET /api/v1/resource?id=<id> - API resource access (VULNERABLE)")
    print("\nTest users:")
    for username, user_data in USERS.items():
        print(f"  {username}: password={user_data['password']}, role={user_data['role']}")
    
    app.run(host="127.0.0.1", port=5555, debug=True)

