from __future__ import annotations

import pytest


from op_proto.graphql import engine as gql_engine
from op_proto.graphql.schema import GraphQLSchema
from op_synth.synth import generate_candidates as synth_generate


graphql_runner = pytest.importorskip("op_proto.graphql.runner")
generate_candidates = graphql_runner.generate_candidates
probe_set = graphql_runner.probe_set

SAMPLE_INTROSPECTION = {
    "data": {
        "__schema": {
            "queryType": {"name": "Query"},
            "mutationType": {"name": "Mutation"},
            "subscriptionType": {"name": "Subscription"},
            "types": [
                {
                    "kind": "OBJECT",
                    "name": "Query",
                    "fields": [
                        {
                            "name": "user",
                            "args": [
                                {
                                    "name": "id",
                                    "defaultValue": None,
                                    "type": {
                                        "kind": "NON_NULL",
                                        "name": None,
                                        "ofType": {
                                            "kind": "SCALAR",
                                            "name": "ID",
                                            "ofType": None,
                                        },
                                    },
                                }
                            ],
                            "type": {
                                "kind": "OBJECT",
                                "name": "User",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "version",
                            "args": [],
                            "type": {
                                "kind": "SCALAR",
                                "name": "String",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "search",
                            "args": [
                                {
                                    "name": "term",
                                    "defaultValue": None,
                                    "type": {
                                        "kind": "SCALAR",
                                        "name": "String",
                                        "ofType": None,
                                    },
                                }
                            ],
                            "type": {
                                "kind": "UNION",
                                "name": "SearchResult",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "entity",
                            "args": [
                                {
                                    "name": "key",
                                    "defaultValue": None,
                                    "type": {
                                        "kind": "SCALAR",
                                        "name": "ID",
                                        "ofType": None,
                                    },
                                }
                            ],
                            "type": {
                                "kind": "INTERFACE",
                                "name": "Entity",
                                "ofType": None,
                            },
                        },
                    ],
                },
                {
                    "kind": "OBJECT",
                    "name": "Mutation",
                    "fields": [
                        {
                            "name": "createUser",
                            "args": [
                                {
                                    "name": "input",
                                    "defaultValue": None,
                                    "type": {
                                        "kind": "NON_NULL",
                                        "name": None,
                                        "ofType": {
                                            "kind": "INPUT_OBJECT",
                                            "name": "UserInput",
                                            "ofType": None,
                                        },
                                    },
                                }
                            ],
                            "type": {
                                "kind": "OBJECT",
                                "name": "User",
                                "ofType": None,
                            },
                        }
                    ],
                },
                {
                    "kind": "OBJECT",
                    "name": "Subscription",
                    "fields": [
                        {
                            "name": "userCreated",
                            "args": [],
                            "type": {
                                "kind": "OBJECT",
                                "name": "User",
                                "ofType": None,
                            },
                        }
                    ],
                },
                {
                    "kind": "OBJECT",
                    "name": "User",
                    "fields": [
                        {
                            "name": "id",
                            "args": [],
                            "type": {
                                "kind": "SCALAR",
                                "name": "ID",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "name",
                            "args": [],
                            "type": {
                                "kind": "SCALAR",
                                "name": "String",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "profile",
                            "args": [],
                            "type": {
                                "kind": "OBJECT",
                                "name": "Profile",
                                "ofType": None,
                            },
                        },
                    ],
                },
                {
                    "kind": "INTERFACE",
                    "name": "Entity",
                    "fields": [
                        {
                            "name": "id",
                            "args": [],
                            "type": {
                                "kind": "SCALAR",
                                "name": "ID",
                                "ofType": None,
                            },
                        }
                    ],
                    "possibleTypes": [
                        {"kind": "OBJECT", "name": "User"},
                        {"kind": "OBJECT", "name": "Profile"},
                    ],
                },
                {
                    "kind": "OBJECT",
                    "name": "Profile",
                    "fields": [
                        {
                            "name": "bio",
                            "args": [],
                            "type": {
                                "kind": "SCALAR",
                                "name": "String",
                                "ofType": None,
                            },
                        }
                    ],
                },
                {
                    "kind": "UNION",
                    "name": "SearchResult",
                    "possibleTypes": [
                        {"kind": "OBJECT", "name": "User"},
                        {"kind": "OBJECT", "name": "Profile"},
                    ],
                },
                {
                    "kind": "INPUT_OBJECT",
                    "name": "UserInput",
                    "inputFields": [
                        {
                            "name": "name",
                            "defaultValue": None,
                            "type": {
                                "kind": "SCALAR",
                                "name": "String",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "age",
                            "defaultValue": None,
                            "type": {
                                "kind": "SCALAR",
                                "name": "Int",
                                "ofType": None,
                            },
                        },
                        {
                            "name": "profile",
                            "defaultValue": None,
                            "type": {
                                "kind": "INPUT_OBJECT",
                                "name": "ProfileInput",
                                "ofType": None,
                            },
                        },
                    ],
                },
                {
                    "kind": "INPUT_OBJECT",
                    "name": "ProfileInput",
                    "inputFields": [
                        {
                            "name": "bio",
                            "defaultValue": None,
                            "type": {
                                "kind": "SCALAR",
                                "name": "String",
                                "ofType": None,
                            },
                        }
                    ],
                },
                {"kind": "SCALAR", "name": "String"},
                {"kind": "SCALAR", "name": "ID"},
                {"kind": "SCALAR", "name": "Int"},
                {"kind": "SCALAR", "name": "Boolean"},
            ],
        }
    }
}


def test_graphql_schema_tree_building():
    schema = GraphQLSchema.from_introspection(SAMPLE_INTROSPECTION)
    user_type = schema.get_type("User")
    assert user_type is not None
    assert "profile" in user_type.fields
    profile_field = user_type.fields["profile"]
    assert profile_field.type.unwrap().name == "Profile"
    profile_type = schema.get_type("Profile")
    assert profile_type is not None
    assert "bio" in profile_type.fields
    entity = schema.get_type("Entity")
    assert entity is not None
    assert "User" in entity.possible_types


def test_graphql_generate_and_probe():
    qs = generate_candidates(SAMPLE_INTROSPECTION, budget=6, max_depth=3)
    assert qs and all("query" in cand for cand in qs)
    query_ops = [cand for cand in qs if cand["query"].startswith("query")]
    assert query_ops
    assert any("__typename" in cand["query"] for cand in query_ops)
    user_query = next((cand for cand in query_ops if "user(" in cand["query"]), None)
    assert user_query is not None
    assert "profile" in user_query["query"] and "bio" in user_query["query"]
    assert user_query.get("variables") and "user_id" in user_query["variables"]
    assert user_query.get("operation") == "query"
    search_query = next((cand for cand in query_ops if "search" in cand["query"]), None)
    assert search_query is not None
    assert "... on User" in search_query["query"]
    entity_query = next((cand for cand in query_ops if "entity" in cand["query"]), None)
    assert entity_query is not None
    assert entity_query["query"].count("... on") >= 1
    assert any(cand["query"].startswith("mutation") for cand in qs)
    assert any(cand["query"].startswith("subscription") for cand in qs)
    out = probe_set("http://127.0.0.1:9/graphql", qs[:1], timeout=0.5)
    assert isinstance(out, list)
    assert out and "error" in out[0]



def test_graphql_schema_payloads_drive_candidates():
    gql_engine.SCHEMA_CACHE.clear()
    schema = {
        "data": {
            "__schema": {
                "queryType": {"name": "RootQuery"},
                "types": [
                    {"name": "RootQuery", "kind": "OBJECT"},
                    {"name": "User", "kind": "OBJECT"},
                ],
            }
        }
    }
    gql_engine.seed_schemas({"https://demo/graphql": schema})
    payloads = gql_engine.schema_payloads_for("https://demo/graphql", limit=2)
    assert any("__type(name: \"RootQuery\"" in item["payload"] for item in payloads)

    cands = synth_generate(
        "https://demo/graphql",
        {"protocol": "graphql", "mode": "gql", "location": "body"},
        per_target=2,
        transforms=[],
    )
    assert any("__type(name: \"RootQuery\"" in c.get("payload", "") for c in cands)
    gql_engine.SCHEMA_CACHE.clear()


def test_schema_payload_budget_limit():
    gql_engine.SCHEMA_CACHE.clear()
    gql_engine.seed_schemas({"https://demo/graphql": SAMPLE_INTROSPECTION})
    payloads = gql_engine.schema_payloads_for(
        "https://demo/graphql", limit=10, budget=2
    )
    assert len(payloads) == 2
    gql_engine.SCHEMA_CACHE.clear()

