from __future__ import annotations

from typing import Any, Dict

import pytest

from op_control.campaign import Campaign
from op_core.runner import run_hunt


class DummyResponse:
    def __init__(self, text: str, url: str) -> None:
        self.text = text
        self.headers = {"content-type": "text/html"}
        self.status_code = 200
        self.url = url


class DummyClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []

    async def get(self, url: str, **_kwargs: Any) -> DummyResponse:
        self.calls.append(("GET", url))
        if "?" in url:
            return DummyResponse("<html><script>alert(1)</script></html>", url)
        return DummyResponse("<html>ok</html>", url)

    async def post(self, url: str, **_kwargs: Any) -> DummyResponse:
        self.calls.append(("POST", url))
        return DummyResponse("<html>ok</html>", url)

    async def aclose(self) -> None:
        return None


@pytest.mark.parametrize("target", ["http://scan.test"])
def test_run_hunt_http_probe_returns_finding(monkeypatch: pytest.MonkeyPatch, tmp_path, target: str) -> None:
    camp = Campaign()
    camp.bandit.arms = [{"mode": "xss", "protocol": "http", "location": "query"}]
    camp.synth.transforms = ["identity"]
    camp.limits.per_target_payloads = 1
    camp.limits.max_concurrency = 1
    camp.limits.retries = 0

    base_candidate: Dict[str, Any] = {
        "mode": "xss",
        "protocol": "http",
        "location": "query",
        "param": "q",
        "payload": "<script>alert(1)</script>",
        "transform": "identity",
    }

    async def fake_positions(*_args: Any, **_kwargs: Any) -> list[Dict[str, Any]]:
        return []

    def fake_generate_candidates(*_args: Any, **_kwargs: Any) -> list[Dict[str, Any]]:
        return [dict(base_candidate)]

    def make_dummy_client(*_args: Any, **_kwargs: Any) -> DummyClient:
        return DummyClient()

    monkeypatch.setattr("op_core.runner.make_async_client", make_dummy_client)
    monkeypatch.setattr("op_core.runner.probe_positions", fake_positions)
    monkeypatch.setattr("op_core.runner.generate_candidates", fake_generate_candidates)

    findings = run_hunt([target], camp, workdir=tmp_path)
    assert findings, "expected at least one finding from HTTP probe"

    finding = findings[0]
    assert finding["vector"]["protocol"] == "http"
    assert finding["vector"]["location"] == "query"
    assert finding["severity"] == "medium"
    assert "<script>" in finding["evidence"].get("snippet", "")
