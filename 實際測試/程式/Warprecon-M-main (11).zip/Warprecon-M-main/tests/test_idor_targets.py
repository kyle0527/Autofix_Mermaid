from __future__ import annotations

"""Tests validating the behavior of the mock IDOR target endpoints.

These tests DO NOT assert the IdorCheck logic (implemented elsewhere) —
they ensure our controlled targets exhibit the vulnerability patterns
we intend to detect later.
"""

import json
from typing import Any, Dict

import pytest

from .mock_idor_app import create_mock_app


@pytest.fixture(scope="module")
def client():
    app = create_mock_app()
    with app.test_client() as c:
        yield c


def _get(client, path: str, user: int | None = None):
    headers = {"X-User-ID": str(user)} if user is not None else {}
    return client.get(path, headers=headers)


def test_insecure_note_allows_cross_user_access(client):
    # user 1 fetches note 2 (owned by user 2) -> should succeed (vuln)
    r = _get(client, "/api/v1/notes/2", user=1)
    assert r.status_code == 200, r.text
    data = r.get_json()
    assert data["owner"] == 2


def test_secure_order_blocks_cross_user_access(client):
    # user 1 tries to access order 11 (owner 2) -> forbidden
    r = _get(client, "/api/v1/orders/11", user=1)
    assert r.status_code == 403

    # correct owner can access
    r2 = _get(client, "/api/v1/orders/11", user=2)
    assert r2.status_code == 200
    assert r2.get_json()["owner"] == 2


def test_profile_partial_disclosure(client):
    # user 1 views profile 2 -> partial content 206
    r = _get(client, "/api/v1/profile/2", user=1)
    assert r.status_code == 206
    j = r.get_json()
    assert j["email"] == "redacted"
    assert "plan" in j

    # owner sees full
    r2 = _get(client, "/api/v1/profile/2", user=2)
    assert r2.status_code == 200
    j2 = r2.get_json()
    assert j2["email"].endswith("@example.com")


def test_anonymous_access_behaviour(client):
    # anonymous cannot read secure order
    r = _get(client, "/api/v1/orders/10", user=None)
    assert r.status_code == 401
    # anonymous can (in this mock) still read notes (vuln amplifier)
    n = _get(client, "/api/v1/notes/1", user=None)
    assert n.status_code == 200
