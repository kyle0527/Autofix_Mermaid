from __future__ import annotations
from op_forms.simple import extract_forms


def test_extract_forms_method_parsing():
    html = (
        '<form action="/a"><input name="x"></form>'
        '<form action="/b" method="POST"><input name="y"></form>'
    )
    forms = extract_forms("http://h/", html)
    assert forms[0]["method"] == "get"
    assert forms[1]["method"] == "post"
