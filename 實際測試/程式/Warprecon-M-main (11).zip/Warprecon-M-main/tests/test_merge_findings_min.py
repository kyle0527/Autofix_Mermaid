from pathlib import Path
from op_core.merge_findings import merge


def test_merge_findings_dedupe_and_score(tmp_path: Path):
    f1 = tmp_path / "a.json"
    f2 = tmp_path / "b.json"
    f1.write_text('[{"fingerprint":"x","severity":"high"}, {"fingerprint":"y","severity":"low"}]')
    f2.write_text('[{"fingerprint":"x","severity":"medium"}]')
    out = merge([f1, f2])
    assert len(out) == 2
    by_fp = {it["fingerprint"]: it for it in out}
    assert by_fp["x"]["severity"] == "high"
    assert by_fp["x"]["_score"] >= 0.75
    assert by_fp["y"]["_rank"] == 2
