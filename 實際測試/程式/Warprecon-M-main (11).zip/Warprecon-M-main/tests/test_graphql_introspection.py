from __future__ import annotations

from typing import Any, Dict, List

import pytest

from op_proto.graphql import schema


class DummyResponse:
    def __init__(
        self,
        status_code: int = 200,
        payload: Any | None = None,
        headers: Dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        self._payload = payload if payload is not None else {"data": {}}
        self.headers = headers or {"content-type": "application/json"}

    def json(self) -> Any:
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


class DummyAsyncClient:
    def __init__(self, responses: Dict[str, List[DummyResponse]]) -> None:
        self._responses = responses
        self.calls: List[str] = []

    async def __aenter__(self) -> "DummyAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:  # type: ignore[override]
        return None

    async def post(self, url: str, **kwargs: Any) -> DummyResponse:
        if "json" in kwargs:
            self.calls.append("post-json")
            queue = self._responses.get("post_json", [])
            if queue:
                return queue.pop(0)
            return DummyResponse(status_code=599)
        headers = kwargs.get("headers") or {}
        if headers.get("Content-Type") == "application/graphql":
            self.calls.append("post-graphql")
            queue = self._responses.get("post_graphql", [])
            if queue:
                return queue.pop(0)
            return DummyResponse(status_code=599)
        raise AssertionError("unexpected POST arguments")

    async def get(self, url: str, **kwargs: Any) -> DummyResponse:
        self.calls.append("get")
        queue = self._responses.get("get", [])
        if queue:
            return queue.pop(0)
        return DummyResponse(status_code=404)


@pytest.mark.anyio
async def test_try_introspect_fallbacks_to_application_graphql(monkeypatch: pytest.MonkeyPatch) -> None:
    responses = {
        "post_json": [DummyResponse(status_code=415, payload={"error": "nope"})],
        "post_graphql": [DummyResponse(payload={"data": {"__schema": {"types": []}}})],
    }
    client = DummyAsyncClient(responses)
    monkeypatch.setattr(schema.httpx, "AsyncClient", lambda **_: client)

    payload = await schema.try_introspect("https://api.example.com/graphql")

    assert payload == {"data": {"__schema": {"types": []}}}
    assert client.calls == ["post-json", "post-graphql"]


@pytest.mark.anyio
async def test_try_introspect_uses_get_when_posts_fail(monkeypatch: pytest.MonkeyPatch) -> None:
    responses = {
        "post_json": [DummyResponse(status_code=405, payload={"errors": ["disabled"]})],
        "post_graphql": [DummyResponse(status_code=415, payload={"errors": ["unsupported"]})],
        "get": [DummyResponse(payload={"data": {"__schema": {"queryType": {"name": "Query"}}}})],
    }
    client = DummyAsyncClient(responses)
    monkeypatch.setattr(schema.httpx, "AsyncClient", lambda **_: client)

    payload = await schema.try_introspect("https://demo.example.com/graphql")

    assert payload["data"]["__schema"]["queryType"]["name"] == "Query"
    assert client.calls == ["post-json", "post-graphql", "get"]


@pytest.mark.anyio
async def test_try_introspect_returns_none_when_all_strategies_fail(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    responses = {
        "post_json": [DummyResponse(status_code=500, payload={"errors": ["boom"]})],
        "post_graphql": [DummyResponse(payload=ValueError("bad json"))],
        "get": [DummyResponse(status_code=200, payload={"message": "not graphql"})],
    }
    client = DummyAsyncClient(responses)
    monkeypatch.setattr(schema.httpx, "AsyncClient", lambda **_: client)

    payload = await schema.try_introspect("https://fail.example.com/graphql")

    assert payload is None
    assert client.calls == ["post-json", "post-graphql", "get"]


@pytest.mark.anyio
async def test_try_introspect_accepts_custom_strategy(monkeypatch: pytest.MonkeyPatch) -> None:
    responses = {
        "get": [DummyResponse(payload={"data": {"__schema": {"types": []}}})],
    }
    client = DummyAsyncClient(responses)
    monkeypatch.setattr(schema.httpx, "AsyncClient", lambda **_: client)

    async def _only_get(client: DummyAsyncClient, url: str) -> DummyResponse:
        return await client.get(url)

    strategy = schema.IntrospectionStrategy("only-get", _only_get)

    payload = await schema.try_introspect(
        "https://api.example.com/graphql",
        strategies=[strategy],
    )

    assert payload == {"data": {"__schema": {"types": []}}}
    assert client.calls == ["get"]

