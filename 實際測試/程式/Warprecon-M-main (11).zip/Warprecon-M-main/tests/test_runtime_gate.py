from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from op_core.runtime_gate import wait_if_paused


def test_wait_if_paused_returns_immediately_when_no_workdir() -> None:
    asyncio.run(wait_if_paused(None))


def test_wait_if_paused_propagates_cancellation(tmp_path: Path) -> None:
    async def runner() -> None:
        control = tmp_path / "control.json"
        control.write_text('{"pause": true}', encoding="utf-8")

        task = asyncio.create_task(wait_if_paused(tmp_path, poll_interval=0.01))
        await asyncio.sleep(0)
        task.cancel()

        with pytest.raises(asyncio.CancelledError):
            await task

    asyncio.run(runner())
