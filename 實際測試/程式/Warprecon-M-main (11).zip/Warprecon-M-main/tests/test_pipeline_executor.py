import logging
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List, Optional

import pytest

from op_core.pipeline.executor import ExecutorHooks, run_scans


class DummyHistory:
    def __init__(self, path, ttl_days):
        self.path = path
        self.ttl_days = ttl_days

    def target_status(self, target: str) -> None:
        return None


class DummyInteract:
    def __init__(self, base_url: str | None, api_key: str | None) -> None:
        self.base_url = base_url
        self.api_key = api_key

    def poll(self) -> List[Any]:
        return []

    def export_events(self) -> Dict[str, Any]:
        return {}

    def correlate_findings(self, findings: Iterable[Any]) -> Iterable[Any]:
        return findings


class DummyAuth:
    def __init__(self, strategies, make_client, default_role=None) -> None:
        self.strategies = strategies
        self.make_client = make_client
        self.default_role = default_role


class DummyIdorCheck:
    def __init__(self, **_: Any) -> None:
        pass

    def run(self, _: Iterable[Any]) -> List[Any]:
        return []


class FlakyRunHunt:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    def __call__(self, *args: Any, **kwargs: Any) -> List[Any]:
        self.calls.append(kwargs)
        if "protocol_hints" in kwargs:
            raise TypeError("run_hunt() got an unexpected keyword argument 'protocol_hints'")
        if "resume" in kwargs:
            raise TypeError("run_hunt() got an unexpected keyword argument 'resume'")
        return []


def _make_hooks(run_hunt_callable, interact_factory=DummyInteract) -> ExecutorHooks:
    return ExecutorHooks(
        HistoryDB=DummyHistory,
        InteractClient=interact_factory,
        AuthManager=DummyAuth,
        load_strategy=lambda name: SimpleNamespace(name=name),
        make_async_client=lambda *_, **__: None,
        jitter_backoff=lambda *_, **__: 0,
        run_hunt=run_hunt_callable,
        classify_target_protocols=lambda target: ["http"],
        run_nuclei=lambda *_, **__: [],
        run_sqlmap=lambda *_, **__: [],
        run_xsstrike=lambda *_, **__: [],
        rank_findings=lambda findings, *_: findings,
        as_findings=lambda payload: list(payload),
        as_finding=lambda payload: payload,
        IdorCheck=DummyIdorCheck,
        filter_targets_by_scope=lambda targets, camp: list(targets),
    )


class DummyCamp:
    def __init__(self) -> None:
        self.limits = SimpleNamespace(
            http_timeout=None,
            http_proxy=None,
            retries=None,
            max_external_targets=0,
            sqlmap_timeout=30,
            xsstrike_timeout=30,
            oob_final_polls=0,
            oob_poll_interval=0,
        )
        self.output = SimpleNamespace(poc_top=0, capture=False, history_ttl_days=0)
        self.oob = SimpleNamespace(base_url="", api_key="")
        self.accounts = None
        self.precision = None
        self.idor = None


def test_run_scans_logs_parameter_downgrade(monkeypatch: pytest.MonkeyPatch, tmp_path, caplog):
    downgrade_events: List[tuple[str, Dict[str, Any]]] = []

    monkeypatch.setattr(
        "op_core.pipeline.executor.Telemetry.event",
        lambda name, payload: downgrade_events.append((name, dict(payload))),
    )
    monkeypatch.setattr("op_core.pipeline.executor.Telemetry.observe_findings", lambda *_: None)

    hooks = _make_hooks(FlakyRunHunt())
    camp = DummyCamp()

    caplog.set_level(logging.WARNING)
    run_scans(["https://example.com"], camp, tmp_path, resume=True, hooks=hooks)

    messages = [record.message for record in caplog.records]
    assert any("protocol_hints" in msg for msg in messages)
    assert any("resume" in msg for msg in messages)

    downgrade_payloads = [payload for name, payload in downgrade_events if name == "executor.run_hunt.downgrade"]
    assert downgrade_payloads == [{"parameter": "protocol_hints"}, {"parameter": "resume"}]


def test_run_scans_polls_oob_multiple_times(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    from op_core.pipeline import executor as pipeline_executor

    monkeypatch.setattr(pipeline_executor.Telemetry, "observe_findings", lambda *_: None)
    monkeypatch.setattr(pipeline_executor.Telemetry, "event", lambda *_, **__: None)

    class TrackingInteract(DummyInteract):
        last_instance: Optional["TrackingInteract"] = None

        def __init__(self, base_url: str | None, api_key: str | None) -> None:
            super().__init__(base_url, api_key)
            self.queue: List[List[Dict[str, Any]]] = [
                [{"id": 1}],
                [],
                [{"id": 2}],
                [],
            ]
            self.poll_history: List[List[Dict[str, Any]]] = []
            type(self).last_instance = self

        def poll(self) -> List[Dict[str, Any]]:
            batch = self.queue.pop(0) if self.queue else []
            self.poll_history.append(batch)
            return batch

        def export_events(self) -> Dict[str, Any]:
            return {"polled": len(self.poll_history)}

    hooks = _make_hooks(lambda *_, **__: [], interact_factory=TrackingInteract)
    camp = DummyCamp()
    camp.limits.oob_final_polls = 2
    camp.limits.oob_poll_interval = 0

    ranked, events, state = run_scans(["https://example.com"], camp, tmp_path, hooks=hooks)

    interact = TrackingInteract.last_instance
    assert interact is not None
    assert len(interact.poll_history) >= 4
    assert events == [{"id": 1}, {"id": 2}]
    assert state == {"polled": len(interact.poll_history)}
    assert ranked == []
