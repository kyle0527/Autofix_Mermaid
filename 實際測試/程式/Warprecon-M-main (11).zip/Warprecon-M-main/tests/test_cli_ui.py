from __future__ import annotations

from pathlib import Path
from typing import Any

from typer.testing import CliRunner

from op_core.cli import app


def test_ui_command_passes_tokens(monkeypatch: Any, tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    class DummyApp:
        def run(self, host: str, port: int, debug: bool) -> None:
            captured["run"] = {"host": host, "port": port, "debug": debug}

    def fake_create_app(workdir: Path, cfg: Path, *, auth_tokens: Any = None) -> DummyApp:
        captured["workdir"] = workdir
        captured["cfg"] = cfg
        captured["tokens"] = tuple(auth_tokens or ())
        return DummyApp()

    monkeypatch.setattr("op_core.cli.create_app", fake_create_app)

    cfg_path = tmp_path / "campaign.yaml"
    cfg_path.write_text("{}", encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "ui",
            "--workdir",
            str(tmp_path),
            "--cfg",
            str(cfg_path),
            "--port",
            "9999",
            "--auth-token",
            "alpha",
            "--auth-token",
            "beta",
        ],
    )

    assert result.exit_code == 0
    assert captured["tokens"] == ("alpha", "beta")
    assert captured["run"] == {"host": "127.0.0.1", "port": 9999, "debug": False}


def test_ui_command_reports_runtime_error(monkeypatch: Any, tmp_path: Path) -> None:
    def fake_create_app(*_: Any, **__: Any) -> Any:
        raise RuntimeError("missing token")

    monkeypatch.setattr("op_core.cli.create_app", fake_create_app)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "ui",
            "--workdir",
            str(tmp_path),
            "--cfg",
            str(tmp_path / "campaign.yaml"),
        ],
    )

    assert result.exit_code == 1
    assert "missing token" in result.stdout
