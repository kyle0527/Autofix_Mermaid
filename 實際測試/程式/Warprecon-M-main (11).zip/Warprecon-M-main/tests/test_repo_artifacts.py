from __future__ import annotations

from pathlib import Path


def test_no_runtime_artifacts_checked_in() -> None:
    root = Path(__file__).resolve().parent.parent
    banned_prefixes = ("tmp-", "work-", "scan-")
    offenders: list[str] = []
    for entry in root.iterdir():
        if not entry.is_dir():
            continue
        name = entry.name
        if name in {".git", "cache", "logs", "scripts", "tests"}:
            continue
        if name.startswith(banned_prefixes):
            offenders.append(name)
    assert not offenders, f"remove runtime artifacts from repository root: {offenders}"
