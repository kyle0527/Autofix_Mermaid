from __future__ import annotations
import json, threading, time, socket, subprocess, sys
from contextlib import closing
from pathlib import Path
import httpx
import pytest

# Minimal inline mock app (simplified variant of prior mock) so test is self-contained
from flask import Flask, jsonify, request

def create_mock_app():
    app = Flask(__name__)

    # Simulate simple per-user notes: /api/v1/notes/<id>
    NOTES = {
        1: {"id":1, "owner":1, "content":"note1"},
        2: {"id":2, "owner":2, "content":"note2-secret"},
    }

    # Reverse bypass target: owner blocked, outsider allowed
    @app.route("/api/v1/secret-docs/<int:doc_id>")
    def secret_docs(doc_id: int):
        # if user header matches doc id treat as blocked else allowed
        uid = request.headers.get("X-User-ID")
        if uid and uid.isdigit() and int(uid) == doc_id:
            return ("denied", 403)
        return jsonify({"doc": doc_id, "data": "classified"})

    @app.route("/api/v1/notes/<int:nid>")
    def get_note(nid: int):
        uid = request.headers.get("X-User-ID")
        note = NOTES.get(nid)
        if not note:
            return ("missing", 404)
        # naive owner check
        if uid and uid.isdigit() and int(uid) == note["owner"]:
            return jsonify(note)
        # unintended exposure (IDOR)
        return jsonify({"id": note["id"], "content": note["content"]})

    @app.route("/api/v1/item")
    def item():
        iid = request.args.get("id")
        return jsonify({"id": iid, "value": f"val-{iid}"})

    @app.route("/")
    def root():
        return "ok"

    return app

def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]

@pytest.fixture(scope="module")
def live():
    port = _free_port()
    app = create_mock_app()
    th = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False), daemon=True)
    th.start()
    for _ in range(60):
        try:
            httpx.get(f"http://127.0.0.1:{port}/", timeout=0.2)
            break
        except Exception:
            time.sleep(0.05)
    return port


def test_cli_idor_basic(tmp_path, live):
    base = f"http://127.0.0.1:{live}"
    targets = tmp_path/"targets.txt"
    targets.write_text("\n".join([
        f"{base}/api/v1/notes/2",
        f"{base}/api/v1/secret-docs/1",
        f"{base}/api/v1/item?id=52"
    ]), encoding="utf-8")
    out = tmp_path/"out.json"
    cmd = [sys.executable, "-m", "op_core.cli", "idor", "--targets", str(targets), "--out", str(out), "--expand-variants"]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=40)
    assert proc.returncode == 0, proc.stderr
    assert out.exists(), proc.stdout + proc.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    # reverse bypass present
    assert any(f.get("meta", {}).get("pattern") == "reverse_bypass" for f in data)
    # query variant present
    assert any("item?id=52" in f.get("meta", {}).get("url", "") for f in data)


def test_cli_idor_exclude(tmp_path, live):
    base = f"http://127.0.0.1:{live}"
    targets = tmp_path/"targets.txt"
    targets.write_text(f"{base}/api/v1/notes/2\n{base}/api/v1/secret-docs/1\n", encoding="utf-8")
    out = tmp_path/"out.json"
    cmd = [sys.executable, "-m", "op_core.cli", "idor", "--targets", str(targets), "--out", str(out), "--expand-variants", "--exclude", "secret-docs"]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=40)
    assert proc.returncode == 0, proc.stderr
    assert out.exists(), proc.stdout + proc.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    assert not any("secret-docs" in f.get("meta", {}).get("url", "") for f in data)
