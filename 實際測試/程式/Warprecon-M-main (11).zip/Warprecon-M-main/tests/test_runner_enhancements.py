from __future__ import annotations

import logging
import asyncio
from pathlib import Path
import asyncio
from pathlib import Path
from typing import Any, Dict, List

import pytest

from op_control.campaign import Campaign
from op_core.history import HistoryDB
from op_core.runner import (
    classify_target_protocols,
    filter_targets_by_scope,
    run_hunt_async,
)


class _DummyResponse:
    def __init__(self, url: str, text: str = "<html></html>") -> None:
        self.url = url
        self.text = text
        self.headers = {"content-type": "text/html"}


class _DummyClient:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    async def get(self, url: str, **_kwargs: Any) -> _DummyResponse:
        self.calls.append({"method": "GET", "url": url})
        return _DummyResponse(url)

    async def aclose(self) -> None:
        return None


def test_filter_targets_by_scope_honors_allow_and_deny() -> None:
    camp = Campaign()
    camp.allow = ["https://*.example.com", "api.example.org/*"]
    camp.deny = ["https://admin.example.com/*"]

    targets = [
        "https://www.example.com/",
        "https://admin.example.com/dashboard",
        "https://api.example.org/v1/users",
        "https://out.of.scope/",
    ]

    scoped = filter_targets_by_scope(targets, camp)
    assert "https://www.example.com/" in scoped
    assert "https://api.example.org/v1/users" in scoped
    assert "https://admin.example.com/dashboard" not in scoped
    assert "https://out.of.scope/" not in scoped


def test_classify_target_protocols_normalizes_grpcs() -> None:
    protocols = classify_target_protocols("grpcs://api.example.com")

    assert "grpc" in protocols
    assert "grpcs" not in protocols


def test_run_hunt_records_target_status(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    camp = Campaign()
    camp.bandit.arms = [{"mode": "xss", "protocol": "http", "location": "query"}]
    camp.synth.transforms = ["identity"]
    camp.limits.per_target_payloads = 1
    camp.limits.max_concurrency = 1

    history = HistoryDB(tmp_path / "history.jsonl", ttl_days=1)

    monkeypatch.setattr("op_core.runner.probe_positions", lambda *_: [])
    monkeypatch.setattr("op_core.runner.generate_candidates", lambda *_, **__: [])
    monkeypatch.setattr("op_core.runner.make_async_client", lambda *_args, **_kwargs: _DummyClient())

    findings = asyncio.run(
        run_hunt_async(["https://demo.example.com"], camp, history=history, workdir=tmp_path)
    )
    assert findings == []

    status = history.target_status("https://demo.example.com")
    assert status == "success"
    record = history.target_record("https://demo.example.com")
    assert record is not None
    assert record.get("m", {}).get("findings") == 0
    history.close()


def test_run_hunt_applies_rate_limiter(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    camp = Campaign()
    camp.bandit.arms = [{"mode": "xss", "protocol": "http", "location": "query"}]
    camp.synth.transforms = ["identity"]
    camp.limits.per_target_payloads = 1
    camp.limits.max_concurrency = 1

    history = HistoryDB(tmp_path / "history.jsonl", ttl_days=1)

    limiter_calls: List[str] = []

    class DummyLimiter:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def acquire(self, host: str) -> None:
            limiter_calls.append(host)

        def penalize(self, *_args: Any, **_kwargs: Any) -> None:
            return None

        def load_state(self) -> None:
            return None

        def save_state(self) -> None:
            return None

    class ProbeClient(_DummyClient):
        pass

    async def stub_probe(target: str, cand: Dict[str, Any], _mint: Any, **_kwargs: Any) -> Dict[str, Any]:
        return {
            "target": target,
            "vector": {"protocol": "http", "location": "query"},
            "severity": "low",
            "payload": cand.get("payload", ""),
        }

    monkeypatch.setattr("op_core.runner.RateLimiter", DummyLimiter)
    monkeypatch.setattr("op_core.runner.generate_candidates", lambda *_args, **_kwargs: [
        {"mode": "xss", "protocol": "http", "location": "query", "param": "q", "payload": "x"}
    ])
    monkeypatch.setattr("op_core.runner.probe_positions", lambda *_: [])
    monkeypatch.setattr("op_core.runner.extract_forms", lambda *_: [])
    monkeypatch.setattr("op_core.runner.choose_form_fields", lambda *_: [])
    monkeypatch.setattr("op_core.runner.make_async_client", lambda *_a, **_k: ProbeClient())
    monkeypatch.setattr("op_core.runner.get_protocol", lambda name: stub_probe if name == "http" else None)

    asyncio.run(run_hunt_async(["https://rate.example.com"], camp, history=history, workdir=tmp_path))

    assert limiter_calls, "expected limiter.acquire to be called"
    assert all(call == "rate.example.com" for call in limiter_calls)
    history.close()


def test_resolve_probe_logs_missing(monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture) -> None:
    from op_core import runner

    runner._MISSING_PROBE_WARNINGS.clear()
    monkeypatch.setattr(runner, "get_protocol", lambda *_: None)
    monkeypatch.setitem(runner.PROBE_AVAILABILITY, "ws", False)

    caplog.set_level(logging.WARNING)
    probe = runner._resolve_probe("ws")

    assert probe is None
    assert "Protocol probe for 'ws' is unavailable" in caplog.text
