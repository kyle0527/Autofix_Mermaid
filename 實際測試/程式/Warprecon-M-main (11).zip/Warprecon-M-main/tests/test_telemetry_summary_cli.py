from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from op_core.cli import app as cli_app
from op_core.metrics import TelemetrySummary, load_summary, render_text


def _sample_snapshot() -> dict[str, object]:
    return {
        "status": "success",
        "duration_seconds": 42.5,
        "ttfp_seconds": 5.25,
        "hits": 4,
        "confirmed_hits": 2,
        "auth": {
            "switch": {
                "count": 3,
                "avg_ms": 82.5,
                "max_ms": 120.0,
                "success_rate": 1.0,
                "roles": {
                    "admin": {"count": 1, "avg_ms": 90.0, "max_ms": 120.0, "success_rate": 1.0},
                    "user": {"count": 2, "avg_ms": 78.0, "max_ms": 95.0, "success_rate": 1.0},
                },
            },
            "refresh": {
                "count": 2,
                "avg_ms": 110.0,
                "max_ms": 200.0,
                "success_rate": 0.5,
                "roles": {
                    "admin": {
                        "count": 1,
                        "avg_ms": 140.0,
                        "max_ms": 200.0,
                        "success_rate": 0.0,
                    },
                    "user": {
                        "count": 1,
                        "avg_ms": 80.0,
                        "max_ms": 80.0,
                        "success_rate": 1.0,
                    },
                },
            },
            "incidents": {
                "count": 1,
                "statuses": {"401": 1},
                "reasons": {"expired": 1},
                "roles": {
                    "admin": {"count": 1, "statuses": {"401": 1}, "reasons": {"expired": 1}},
                },
            },
        },
        "websocket": {
            "roundtrip": {
                "count": 5,
                "avg_ms": 210.0,
                "max_ms": 350.0,
                "success_rate": 0.8,
                "reasons": {"timeout": 1},
                "endpoints": {
                    "wss://example/ws": {
                        "count": 5,
                        "avg_ms": 210.0,
                        "max_ms": 350.0,
                        "success_rate": 0.8,
                    }
                },
                "handshakes": {
                    "vanilla": {
                        "count": 5,
                        "avg_ms": 210.0,
                        "max_ms": 350.0,
                        "success_rate": 0.8,
                        "reasons": {"timeout": 1},
                        "strategies": {
                            "json-probe": {
                                "count": 3,
                                "avg_ms": 190.0,
                                "max_ms": 220.0,
                                "success_rate": 1.0,
                            },
                            "binary-probe": {
                                "count": 2,
                                "avg_ms": 250.0,
                                "max_ms": 350.0,
                                "success_rate": 0.5,
                            },
                        },
                    }
                },
            }
        },
    }


def test_summary_from_snapshot() -> None:
    summary = TelemetrySummary.from_snapshot(_sample_snapshot())
    assert summary.status == "success"
    assert summary.duration_seconds == 42.5
    assert summary.auth_switch is not None
    assert summary.auth_switch.totals.count == 3
    assert summary.websocket is not None
    assert summary.websocket.per_handshake
    rendered = render_text(summary)
    assert "Switch: count=3" in rendered
    assert "Round trips: count=5" in rendered
    assert "<vanilla>" in rendered
    assert "[json-probe]" in rendered


def test_load_summary_prefers_metrics_json(tmp_path: Path) -> None:
    snapshot = _sample_snapshot()
    (tmp_path / "metrics.json").write_text(json.dumps(snapshot), encoding="utf-8")
    summary = load_summary(tmp_path)
    assert summary.hits == 4


def test_load_summary_from_jsonl(tmp_path: Path) -> None:
    snapshot = _sample_snapshot()
    jsonl = tmp_path / "metrics.jsonl"
    jsonl.write_text("\n".join(["not json", "", json.dumps(snapshot)]), encoding="utf-8")
    summary = load_summary(jsonl)
    assert summary.websocket is not None
    assert summary.websocket.totals.count == 5
    assert "vanilla" in summary.websocket.per_handshake


def test_cli_summarize_text(tmp_path: Path) -> None:
    snapshot = _sample_snapshot()
    (tmp_path / "metrics.json").write_text(json.dumps(snapshot), encoding="utf-8")
    runner = CliRunner()
    result = runner.invoke(cli_app, ["telemetry", "summarize", str(tmp_path)])
    assert result.exit_code == 0
    assert "Pipeline" in result.stdout
    assert "Authentication" in result.stdout
    assert "<vanilla>" in result.stdout


def test_cli_summarize_json(tmp_path: Path) -> None:
    snapshot = _sample_snapshot()
    (tmp_path / "metrics.json").write_text(json.dumps(snapshot), encoding="utf-8")
    runner = CliRunner()
    result = runner.invoke(
        cli_app,
        ["telemetry", "summarize", str(tmp_path), "--format", "json"],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["hits"] == 4
    assert payload["auth_refresh"]["totals"]["count"] == 2
    assert payload["websocket"]["per_handshake"]["vanilla"]["totals"]["count"] == 5
