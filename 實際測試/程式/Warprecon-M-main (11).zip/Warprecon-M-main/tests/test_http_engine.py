from __future__ import annotations

import asyncio
from typing import Any, Dict, List

from op_proto.http.engine import http_probe


class DummyResponse:
    def __init__(self, text: str, *, status: int = 200, headers: Dict[str, str] | None = None) -> None:
        self.text = text
        self.status_code = status
        self.headers = headers or {}
        self.url = "https://api.example.com/items"


class DummyClient:
    def __init__(self, responses: List[DummyResponse]) -> None:
        self._responses = list(responses)
        self.calls: List[Dict[str, Any]] = []

    async def request(self, method: str, url: str, **kwargs: Any) -> DummyResponse:
        self.calls.append({"method": method, "url": url, "kwargs": kwargs})
        if not self._responses:
            raise RuntimeError("no more responses queued")
        return self._responses.pop(0)

    async def get(self, url: str, **kwargs: Any) -> DummyResponse:
        return await self.request("GET", url, **kwargs)


def test_http_probe_aligns_baseline_with_candidate() -> None:
    baseline = DummyResponse("{\"ok\": true}", headers={"content-type": "application/json"})
    attack = DummyResponse(
        "SQL syntax error near 'payload'",
        status=500,
        headers={"content-type": "text/html"},
    )
    client = DummyClient([baseline, attack])
    cand = {
        "mode": "sqli",
        "location": "json",
        "param": "user.id",
        "json_ctx": {"user": {"id": 1}},
        "method": "POST",
        "payload": "' or 1=1 --",
    }

    result = asyncio.run(
        http_probe("https://api.example.com/items", cand, None, client, retries=0)
    )

    assert result is not None
    assert len(client.calls) >= 2, "expected baseline and attack requests"
    baseline_call = client.calls[0]
    assert baseline_call["method"] == "POST"
    assert baseline_call["kwargs"]["json"] == {"user": {"id": 1}}
    attack_call = client.calls[1]
    assert attack_call["kwargs"]["json"]["user"]["id"] == "' or 1=1 --"
    baseline_len = len(baseline.text)
    attack_len = len(attack.text)
    assert result["evidence"]["len_delta"] == attack_len - baseline_len
    assert result["evidence"]["method"] == "POST"
