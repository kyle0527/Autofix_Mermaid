import pytest
pytest.skip("protocol probe tests disabled", allow_module_level=True)
