from __future__ import annotations

import json
import subprocess

import pytest

from op_adapters.errors import ExternalToolNotInstalledError
from op_adapters.nuclei import run_nuclei
from op_adapters.sqlmap import run_sqlmap
from op_adapters.xsstrike import run_xsstrike


def test_sqlmap_timeout(monkeypatch):
    captured: dict[str, int] = {}

    def fake_run(cmd, capture_output, text, timeout):
        captured["timeout"] = timeout
        raise subprocess.TimeoutExpired(cmd, timeout)

    monkeypatch.setattr(subprocess, "run", fake_run)
    out = run_sqlmap("http://a", timeout=75)
    assert captured["timeout"] == 75
    assert out and out[0]["evidence"]["error"] == "timeout"


def test_sqlmap_default_timeout(monkeypatch):
    captured: dict[str, int] = {}

    def fake_run(cmd, capture_output, text, timeout):
        captured["timeout"] = timeout
        raise subprocess.TimeoutExpired(cmd, timeout)

    monkeypatch.setattr(subprocess, "run", fake_run)
    run_sqlmap("http://a")
    assert captured["timeout"] == 120


def test_xsstrike_timeout(monkeypatch):
    captured: dict[str, int] = {}

    def fake_run(cmd, capture_output, text, timeout):
        captured["timeout"] = timeout
        raise subprocess.TimeoutExpired(cmd, timeout)

    monkeypatch.setattr(subprocess, "run", fake_run)
    out = run_xsstrike("http://a", timeout=90)
    assert captured["timeout"] == 90
    assert out and out[0]["evidence"]["error"] == "timeout"


def test_xsstrike_default_timeout(monkeypatch):
    captured: dict[str, int] = {}

    def fake_run(cmd, capture_output, text, timeout):
        captured["timeout"] = timeout
        raise subprocess.TimeoutExpired(cmd, timeout)

    monkeypatch.setattr(subprocess, "run", fake_run)
    run_xsstrike("http://a")
    assert captured["timeout"] == 120


def test_sqlmap_missing_tool(monkeypatch):
    def _raise(*args, **kwargs):
        raise FileNotFoundError

    monkeypatch.setattr(subprocess, "run", _raise)
    with pytest.raises(ExternalToolNotInstalledError):
        run_sqlmap("http://example")


def test_xsstrike_missing_tool(monkeypatch):
    def _raise(*args, **kwargs):
        raise FileNotFoundError

    monkeypatch.setattr(subprocess, "run", _raise)
    with pytest.raises(ExternalToolNotInstalledError):
        run_xsstrike("http://example")


def test_nuclei_missing_tool(monkeypatch):
    class DummyPopen:
        def __init__(self, *args, **kwargs):
            raise FileNotFoundError

    monkeypatch.setattr(subprocess, "Popen", DummyPopen)
    with pytest.raises(ExternalToolNotInstalledError):
        run_nuclei("targets.txt")


def test_run_nuclei_parses_results(monkeypatch):
    captured: dict[str, object] = {}

    class DummyPopen:
        def __init__(self, cmd, stdout, stderr, text, encoding, errors):
            captured["cmd"] = cmd
            captured["text"] = text
            captured["encoding"] = encoding
            captured["errors"] = errors
            self.stdout = iter(
                [
                    json.dumps(
                        {
                            "host": "api.example.com",
                            "matched-at": "https://api.example.com/login",
                            "matcher-name": "status",
                            "template-id": "http/basic", 
                            "info": {"name": "Basic Template", "severity": "high"},
                        }
                    )
                    + "\n",
                    "not-json\n",
                    json.dumps({"matched-at": "https://example.com/oob", "info": {}}) + "\n",
                ]
            )
            self._returncode = 0

        def wait(self):
            return self._returncode

    monkeypatch.setattr(subprocess, "Popen", DummyPopen)

    results = run_nuclei("targets.txt", templates_dir="tpls")

    assert captured["cmd"] == ["nuclei", "-l", "targets.txt", "-jsonl", "-t", "tpls"]
    assert captured["text"] is True
    assert captured["encoding"] == "utf-8"
    assert captured["errors"] == "replace"
    assert len(results) == 2
    first = results[0]
    assert first["tool"] == "nuclei"
    assert first["severity"] == "high"
    assert first["vector"] == {"protocol": "http", "location": "nuclei", "param": None}
    assert first["url"] == "https://api.example.com/login"


def test_run_nuclei_raises_on_failure(monkeypatch):
    class DummyPopen:
        def __init__(self, cmd, stdout, stderr, text, encoding, errors):
            self.stdout = iter(["not-json\n"])
            self._returncode = 5

        def wait(self):
            return self._returncode

    monkeypatch.setattr(subprocess, "Popen", DummyPopen)

    with pytest.raises(RuntimeError) as excinfo:
        run_nuclei("targets.txt")

    assert "status 5" in str(excinfo.value)
