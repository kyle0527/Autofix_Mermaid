from __future__ import annotations

from tests.scaffolds.idor_target import ResponseSnapshot, SyntheticIdorTarget


def test_synthetic_idor_diff() -> None:
    target = SyntheticIdorTarget()

    admin = target.fetch("admin", "alpha")
    user = target.fetch("user", "alpha")
    anonymous = target.fetch("anonymous", "alpha")

    user_diff = target.diff(admin, user)
    assert not user_diff["status_changed"]
    assert user_diff["field_differences"]["balance"] == (900, 120)
    assert not user_diff["identifier_changed"]

    anon_diff = target.diff(admin, anonymous)
    assert anon_diff["status_changed"]
    assert anon_diff["identifier_changed"]
    assert anon_diff["field_differences"]["balance"] == (900, None)
    assert set(target.enumerate()) == {"admin", "user", "anonymous"}


def test_snapshot_is_immutable() -> None:
    snapshot = ResponseSnapshot(
        role="user",
        resource_id="alpha",
        status_code=200,
        identifier="alpha-record",
        fields={"balance": 120},
    )

    assert snapshot.fields == {"balance": 120}
    # dataclass is frozen; attempting to mutate should raise an error
    try:
        snapshot.fields["balance"] = 0  # type: ignore[misc]
    except TypeError:
        pass
    else:  # pragma: no cover - defensive in case dataclass options change
        raise AssertionError("snapshot must remain immutable for diff stability")
