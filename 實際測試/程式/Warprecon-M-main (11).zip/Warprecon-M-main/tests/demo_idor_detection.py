#!/usr/bin/env python3
"""
IDOR Detection Demonstration Script

This script demonstrates the IDOR detection capabilities by:
1. Starting the mock IDOR service
2. Running IDOR detection on vulnerable endpoints
3. Showing the results
"""

import sys
import os
import time
import json
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
sys.path.insert(0, os.path.dirname(__file__))

from mock_idor_app import start_mock_server, stop_mock_server
from op_checks.idor import IdorCheck


def main():
    print("=== IDOR Detection MVP Demonstration ===\n")
    
    # Start mock server
    print("1. Starting mock IDOR service...")
    base_url = start_mock_server(port=5566)
    print(f"   Mock service running at: {base_url}")
    
    # Give server time to start
    time.sleep(2)
    
    # Define test endpoints that should reveal IDOR vulnerabilities
    test_endpoints = [
        f"{base_url}/documents/2",        # Vulnerable document endpoint
        f"{base_url}/users/1",           # Vulnerable user endpoint
        f"{base_url}/api/v1/resource?id=3",  # Vulnerable query parameter endpoint
        f"{base_url}/secure/documents/2", # This should be secure but might have issues
    ]
    
    print(f"\n2. Testing IDOR detection on {len(test_endpoints)} endpoints:")
    for endpoint in test_endpoints:
        print(f"   - {endpoint}")
    
    # Initialize and run IDOR check
    print("\n3. Running IDOR detection...")
    check = IdorCheck()
    
    try:
        findings = list(check.run(apis=test_endpoints))
        
        print(f"\n4. Results: Found {len(findings)} IDOR findings")
        
        if findings:
            print("\n=== IDOR Vulnerability Report ===\n")
            
            for i, finding in enumerate(findings, 1):
                print(f"Finding #{i}:")
                print(f"  Title: {finding.title}")
                print(f"  Target: {finding.target}")
                print(f"  Severity: {finding.severity.upper()}")
                print(f"  Detail: {finding.detail}")
                
                if finding.meta:
                    meta = finding.meta
                    if meta.get('idor_type'):
                        print(f"  IDOR Type: {meta['idor_type']}")
                    if meta.get('variant_url'):
                        print(f"  Variant URL: {meta['variant_url']}")
                    if meta.get('role'):
                        print(f"  Tested Role: {meta['role']}")
                    
                    # Show evidence if available
                    evidence = meta.get('evidence', {})
                    if evidence:
                        orig = evidence.get('original_response', {})
                        variant = evidence.get('variant_response', {})
                        if orig and variant:
                            print(f"  Evidence:")
                            print(f"    Original: {orig.get('status_code')} (length: {orig.get('content_length')})")
                            print(f"    Variant:  {variant.get('status_code')} (length: {variant.get('content_length')})")
                
                print()
        else:
            print("\n   No IDOR vulnerabilities detected.")
            print("   This could mean:")
            print("   - The endpoints are properly secured")
            print("   - No ID patterns were found in the URLs")
            print("   - The authentication setup needs configuration")
        
        # Show some technical details
        print("\n=== Technical Details ===")
        print("IDOR Detection Features:")
        print("• Session Management: Multi-role authentication (admin, user, anonymous)")
        print("• ID Variant Generation: Automatic ID extraction and variant testing")
        print("• Request Replay: Systematic testing with different authentication contexts")
        print("• Pattern Analysis: Response comparison to detect unauthorized access")
        print("• Vulnerability Types: Unauthorized access, content disclosure detection")
        
        print(f"\nTest completed. Mock service was running at {base_url}")
        
    except Exception as e:
        print(f"\nError during IDOR detection: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Clean up
        print("\n5. Stopping mock service...")
        stop_mock_server()
        print("   Demo completed.")


if __name__ == "__main__":
    main()