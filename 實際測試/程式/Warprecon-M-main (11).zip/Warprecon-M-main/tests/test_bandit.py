from __future__ import annotations
from pathlib import Path
from op_bandit.contextual import LinUCB
import inspect
import pytest

if 'state_file' not in inspect.signature(LinUCB).parameters:
    pytest.skip('LinUCB state persistence not supported', allow_module_level=True)

def test_linucb_order_and_update(tmp_path: Path):
    arms = [
        {"mode":"xss","protocol":"http","location":"query"},
        {"mode":"sqli","protocol":"http","location":"query"},
    ]
    s = tmp_path/"bandit_state.json"
    b = LinUCB(arms, state_file=s)
    order1 = b.order({})
    b.update(0, 1.0)
    order2 = b.order({})
    assert len(order1)==2 and len(order2)==2
    assert s.exists()


def test_choose_returns_highest_score():
    b = LinUCB(["a", "b"])
    b.update(0, 1.0)
    b.update(1, 2.0)
    assert b.choose() == 1
