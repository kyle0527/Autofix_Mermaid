from __future__ import annotations

import tempfile
from pathlib import Path

from op_core.finding_contract import Finding


def make_workdir(prefix: str = "warprecon-m_test_") -> Path:
    """Create and return a temporary working directory."""

    return Path(tempfile.mkdtemp(prefix=prefix))


def sample_ranked() -> list[Finding]:
    """Return a representative ranked findings list for output tests."""

    payloads = [
        {
            "severity": "high",
            "vector": {"protocol": "http", "location": "query"},
            "payload": "<script>alert(1)</script>",
            "evidence": {"variant_hits": ["urlenc"]},
            "_score": 95,
            "_rank": 1,
            "url": "https://example.com/",
            "mode": "xss",
            "cwe": "CWE-79",
            "cvss": {
                "base_score": 5.4,
                "severity": "Medium",
                "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/A:N",
                "metrics": {
                    "AV": "NETWORK",
                    "AC": "LOW",
                    "PR": "NONE",
                    "UI": "REQUIRED",
                    "S": "UNCHANGED",
                    "C": "LOW",
                    "I": "LOW",
                    "A": "NONE",
                },
            },
        },
        {
            "severity": "medium",
            "vector": {"protocol": "graphql", "location": "query"},
            "payload": "query{__typename}",
            "evidence": {},
            "_score": 50,
            "_rank": 2,
            "url": "https://api.example.com/graphql",
            "mode": "gql",
            "cwe": "CWE-89",
            "cvss": {
                "base_score": 9.4,
                "severity": "Critical",
                "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L",
                "metrics": {
                    "AV": "NETWORK",
                    "AC": "LOW",
                    "PR": "NONE",
                    "UI": "NONE",
                    "S": "UNCHANGED",
                    "C": "HIGH",
                    "I": "HIGH",
                    "A": "LOW",
                },
            },
        },
    ]
    return [Finding.from_dict(item) for item in payloads]
