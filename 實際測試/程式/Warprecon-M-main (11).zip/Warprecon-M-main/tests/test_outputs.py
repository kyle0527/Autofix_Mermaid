from __future__ import annotations

import builtins
import logging
import sys
import types
from pathlib import Path

import pytest

from op_output.artifacts import try_capture
from op_output.html import export_html
from op_output.html_cards import export_html_cards
from op_output.sarif import export_sarif
from tests.common import make_workdir, sample_ranked


@pytest.fixture(autouse=True)
def _restore_import(monkeypatch):
    original_import = builtins.__import__
    yield
    monkeypatch.setattr(builtins, "__import__", original_import)


def test_exporters_create_files(tmp_path: Path):
    workdir = make_workdir("warprecon-m_out_")
    ranked = sample_ranked()

    sarif_path = export_sarif(workdir, ranked)
    html_path = export_html(workdir, ranked)
    cards_path = export_html_cards(workdir, ranked)

    assert Path(sarif_path).exists()
    assert Path(html_path).exists()
    assert Path(cards_path).exists()


def test_try_capture_import_warning(monkeypatch, caplog, tmp_path: Path):
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "playwright.sync_api":
            raise ImportError("no playwright")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    caplog.set_level("WARNING")

    har, png, err = try_capture("http://example.com", tmp_path)

    assert har is None and png is None
    assert err and "no playwright" in err
    assert "Playwright import failed" in caplog.text


def test_try_capture_import_failure(monkeypatch, tmp_path: Path, caplog):
    caplog.set_level(logging.WARNING)
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "playwright.sync_api":
            raise RuntimeError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    har, png, err = try_capture("http://example.com", tmp_path)
    assert har is None and png is None and err
    assert "Playwright import failed" in caplog.text


def test_try_capture_goto_failure(monkeypatch, tmp_path: Path, caplog):
    caplog.set_level(logging.WARNING)

    class DummyPage:
        def goto(self, url, timeout):
            raise RuntimeError("boom")

        def screenshot(self, path, full_page):
            pass

    class DummyContext:
        def new_page(self):
            return DummyPage()

        def close(self):  # pragma: no cover - simple stub
            pass

    class DummyBrowser:
        def new_context(self, record_har_path):
            return DummyContext()

        def close(self):  # pragma: no cover - simple stub
            pass

    class DummyBrowserType:
        def launch(self, headless=True):
            return DummyBrowser()

    class DummyPW:
        def __enter__(self):
            return types.SimpleNamespace(chromium=DummyBrowserType())

        def __exit__(self, exc_type, exc, tb):
            return False

    def fake_sync_playwright():
        return DummyPW()

    sync_api_module = types.ModuleType("playwright.sync_api")
    sync_api_module.sync_playwright = fake_sync_playwright
    playwright_module = types.ModuleType("playwright")
    playwright_module.sync_api = sync_api_module

    monkeypatch.setitem(sys.modules, "playwright", playwright_module)
    monkeypatch.setitem(sys.modules, "playwright.sync_api", sync_api_module)

    har, png, err = try_capture("http://example.com", tmp_path)
    assert har is None and png is None
    assert err == "boom"
    assert "page.goto failed" in caplog.text
