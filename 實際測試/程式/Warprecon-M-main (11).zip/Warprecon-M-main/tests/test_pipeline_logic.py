import asyncio
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml

from op_control.campaign import Campaign, LogicCfg, LogicWorkflowCfg
from op_core.pipeline import run_pipeline_async
from op_core.pipeline.logic import run_logic_workflows


class StubResponse:
    def __init__(self, method: str, url: str, status: int, *, text: str = "", json_data=None, headers=None):
        self.status_code = status
        self._text = text
        self._json = json_data
        self.headers = headers or {}
        self.request = SimpleNamespace(url=url, method=method)

    @property
    def text(self) -> str:
        return self._text

    def json(self):
        if self._json is None:
            raise ValueError("no json available")
        return self._json


class StubAsyncClient:
    def __init__(self, responses):
        self._responses = list(responses)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def request(self, method: str, url: str, **kwargs):
        if not self._responses:
            raise AssertionError("no responses remaining")
        response = self._responses.pop(0)
        response.request = SimpleNamespace(url=url, method=method)
        return response

    async def aclose(self):  # pragma: no cover - compatibility shim
        return None


def test_run_logic_workflows_disabled(tmp_path):
    camp = Campaign()  # defaults to logic disabled
    findings, artifact = asyncio.run(
        run_logic_workflows(camp, tmp_path, "https://example.com")
    )
    assert findings == []
    assert artifact is None


def test_run_logic_workflows_executes(monkeypatch, tmp_path):
    manifest = {
        "id": "health-check",
        "entry": "start",
        "states": {
            "start": {
                "steps": [
                    {
                        "http": {
                            "method": "GET",
                            "url": "{{ base_url }}/health",
                            "expect": {"status": 200},
                            "capture": {"status": "status"},
                        }
                    },
                    {
                        "emit": {
                            "title": "Health probe",
                            "detail": "Service responded with {{ vars.status }}",
                        }
                    },
                ]
            }
        },
    }
    camp = Campaign(
        logic=LogicCfg(
            enabled=True,
            base_url="https://api.example",
            workflows=[LogicWorkflowCfg(id="health-check", manifest=manifest)],
        )
    )

    def make_responses():
        return [StubResponse("GET", "https://api.example/health", 200, text="OK")]

    monkeypatch.setattr(
        "op_core.pipeline.logic.make_async_client",
        lambda *args, **kwargs: StubAsyncClient(make_responses()),
    )

    findings, artifact = asyncio.run(
        run_logic_workflows(camp, tmp_path, "https://api.example")
    )
    assert len(findings) == 1
    assert artifact is not None and artifact.exists()
    data = json.loads(artifact.read_text(encoding="utf-8"))
    assert data[0]["workflow"]["id"] == "health-check"
    assert "trace" in data[0]


def test_run_pipeline_async_includes_logic(monkeypatch, tmp_path):
    workdir = tmp_path / "work"
    manifest = {
        "id": "workflow-check",
        "entry": "start",
        "states": {
            "start": {
                "steps": [
                    {
                        "http": {
                            "method": "GET",
                            "url": "{{ base_url }}/status",
                            "expect": {"status": 200, "contains": "OK"},
                        }
                    },
                    {
                        "emit": {
                            "title": "Logic workflow hit",
                            "detail": "Status ok",
                            "check": "logic.workflow",
                            "severity": "low",
                        }
                    },
                ]
            }
        },
    }

    campaign_path = tmp_path / "campaign.yaml"
    campaign_payload = {
        "logic": {
            "enabled": True,
            "base_url": "https://target.example",
            "workflows": [
                {
                    "id": "workflow-check",
                    "manifest": manifest,
                }
            ],
        }
    }
    campaign_path.write_text(yaml.safe_dump(campaign_payload), encoding="utf-8")

    def make_responses():
        return [
            StubResponse(
                "GET",
                "https://target.example/status",
                200,
                text="Service OK",
            )
        ]

    monkeypatch.setattr(
        "op_core.pipeline.logic.make_async_client",
        lambda *args, **kwargs: StubAsyncClient(make_responses()),
    )

    captured = {}

    def fake_collect_targets(domain, workdir, dom_crawl, loop=None):
        return []

    def fake_run_scans(targets, camp, workdir, resume=False):
        return [], [], {}

    def fake_export_results(ranked, events, oob_state, camp, workdir):
        captured["ranked"] = [item.to_dict() for item in ranked]
        return {}

    def fake_merge_and_gate(
        workdir,
        *,
        precision_cfg,
        gate_threshold,
        gate_topn,
        gate_labels,
        iast_artifact=None,
    ):
        merged = Path(workdir) / "merged.json"
        final = Path(workdir) / "final.json"
        merged.write_text("[]", encoding="utf-8")
        final.write_text("[]", encoding="utf-8")
        return [], [], merged, final

    monkeypatch.setattr("op_core.pipeline.collect_targets", fake_collect_targets)
    monkeypatch.setattr("op_core.pipeline.run_scans", fake_run_scans)
    monkeypatch.setattr("op_core.pipeline.export_results", fake_export_results)
    monkeypatch.setattr("op_core.pipeline._collect_grpc_targets", lambda domain, targets: [])
    monkeypatch.setattr("op_core.pipeline._run_grpc_enumeration", lambda workdir, targets: [])
    monkeypatch.setattr("op_core.pipeline._run_misconfig_checks", lambda workdir, targets: [])
    monkeypatch.setattr("op_core.pipeline._merge_and_gate", fake_merge_and_gate)

    artifacts = asyncio.run(
        run_pipeline_async("https://target.example", campaign_path, workdir)
    )

    assert len(captured.get("ranked", [])) == 1
    assert captured["ranked"][0]["check"] == "logic.workflow"
    assert "logic" in artifacts
    assert Path(artifacts["logic"]).exists()
