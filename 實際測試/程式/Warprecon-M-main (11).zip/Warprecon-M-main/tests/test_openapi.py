from __future__ import annotations

from pathlib import Path

import pytest

openapi_seq = pytest.importorskip("op_adapters.openapi_seq")
execute_sequences = openapi_seq.execute_sequences
process_openapi = openapi_seq.process_openapi

SAMPLE = """
openapi: 3.0.0
servers: [{url: 'https://api.example.com'}]
paths:
  /items:
    post: {requestBody: {content: {application/json: {schema: {type: object}}}}, responses: {201: {description: ok}}}
  /items/{id}:
    get: {responses: {200: {description: ok}}}
"""


def test_openapi_process_and_execute(tmp_path: Path):
    spec = tmp_path / "openapi.yaml"
    spec.write_text(SAMPLE, encoding="utf-8")
    work = tmp_path / "work"
    work.mkdir()
    targets = process_openapi(spec, work, server_override="https://api.example.com")
    assert any("/items/" in t for t in targets)
    execute_sequences(spec, work, server_override="https://api.example.com")
    # no network expected; but function should complete and write discovery file
    d = work / "discovery" / "openapi-seqs.json"
    assert d.exists()
