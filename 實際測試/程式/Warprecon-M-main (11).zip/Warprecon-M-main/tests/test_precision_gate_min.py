from op_core.precision_gate import apply_gate


def test_precision_gate_filters_and_confirms_topn():
    items = [
        {"fingerprint": "a", "_score": 0.9, "_rank": 1},
        {"fingerprint": "b", "_score": 0.4, "_rank": 2},
        {"fingerprint": "c", "_score": 0.7, "_rank": 3},
    ]
    out = apply_gate(items, min_score=0.5, confirm_top_n=1, accept_fps=set())
    assert [it["fingerprint"] for it in out] == ["a", "c"]
    assert [it["_rank"] for it in out] == [1, 2]


def test_precision_gate_keeps_high_severity():
    items = [
        {"fingerprint": "h", "severity": "high", "_score": 0.1, "_rank": 40},
        {"fingerprint": "l", "severity": "low", "_score": 0.1, "_rank": 41},
    ]
    out = apply_gate(items, min_score=0.5, confirm_top_n=1, accept_fps=set())
    assert any(it["fingerprint"] == "h" for it in out)
    assert all(it["fingerprint"] != "l" for it in out)
