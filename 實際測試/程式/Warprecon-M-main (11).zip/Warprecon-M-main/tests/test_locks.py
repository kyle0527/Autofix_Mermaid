from __future__ import annotations

import errno
import types
from pathlib import Path

from op_dist import locks


def test_filelock_posix(monkeypatch, tmp_path: Path) -> None:
    calls: list[int] = []

    class DummyFcntl:
        LOCK_EX = 1
        LOCK_UN = 2

        @staticmethod
        def flock(fd: int, mode: int) -> None:
            calls.append(mode)

    monkeypatch.setattr(locks, "IS_WINDOWS", False)
    monkeypatch.setattr(locks, "fcntl", DummyFcntl)

    lock = locks.FileLock(tmp_path / "lock")
    with lock.locked():
        pass

    assert calls == [DummyFcntl.LOCK_EX, DummyFcntl.LOCK_UN]


def test_filelock_windows_retry(monkeypatch, tmp_path: Path) -> None:
    attempts: list[int] = []
    sleeps: list[float] = []

    class DummyMSVCRT:
        LK_NBLCK = 1
        LK_UNLCK = 2

        def __init__(self) -> None:
            self._first = True

        def locking(self, fd: int, mode: int, length: int) -> None:
            attempts.append(mode)
            if mode == self.LK_NBLCK and self._first:
                self._first = False
                raise OSError(errno.EACCES, "busy")

    monkeypatch.setattr(locks, "IS_WINDOWS", True)
    monkeypatch.setattr(locks, "msvcrt", DummyMSVCRT())
    monkeypatch.setattr(locks, "time", types.SimpleNamespace(sleep=lambda value: sleeps.append(value)))

    lock = locks.FileLock(tmp_path / "lock")
    with lock.locked():
        pass

    assert attempts.count(locks.msvcrt.LK_NBLCK) >= 2
    assert attempts[-1] == locks.msvcrt.LK_UNLCK
    assert sleeps  # retry occurred
