import asyncio
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from op_control.campaign import Campaign, IastCfg
from op_core.pipeline import run_pipeline_async, _merge_and_gate
from op_core.pipeline.iast import collect_iast_results


@pytest.fixture
def sample_iast_payload():
    return {
        "check": "iast.xss",
        "target": "GET /profile",
        "severity": "medium",
        "title": "Reflected XSS",
        "detail": "Agent observed reflected HTML script execution.",
        "fingerprint": "iast-001",
        "evidence": {"sink": "render_template", "parameter": "name"},
        "location": {"file": "views/profile.py", "line": 18},
    }


def test_collect_iast_results_writes_artifact(tmp_path: Path, sample_iast_payload):
    workdir = tmp_path
    buffer_path = workdir / "iast" / "findings.jsonl"
    buffer_path.parent.mkdir(parents=True, exist_ok=True)
    buffer_path.write_text(json.dumps(sample_iast_payload) + "\n", encoding="utf-8")

    camp = Campaign(iast=IastCfg(enabled=True, transport="embedded"))
    findings, artifact = collect_iast_results(camp, workdir)

    assert len(findings) == 1
    assert artifact is not None and artifact.exists()
    stored = json.loads(artifact.read_text(encoding="utf-8"))
    assert stored[0]["meta"]["iast"]["fingerprint"] == "iast-001"


def test_collect_iast_results_disabled(tmp_path: Path):
    camp = Campaign(iast=IastCfg(enabled=False))
    findings, artifact = collect_iast_results(camp, tmp_path)
    assert findings == []
    assert artifact is None


def test_merge_and_gate_receives_iast(monkeypatch, tmp_path: Path, sample_iast_payload):
    recorded = {}

    def fake_merge(inputs):
        recorded["inputs"] = inputs
        return []

    class DummyPrecision:
        def __init__(self, *args, **kwargs):
            self.ignored = []
            self.suppressed = []
            self.gate_threshold = 0.0
            self.gate_topn = 0
            self.stats = SimpleNamespace(
                scored=0,
                kept=0,
                ignored=0,
                suppressed=0,
                baseline_hits=0,
                reasons={},
            )

        def apply_gate(self, findings, accept_fingerprints=None):
            self.stats.scored = len(findings)
            self.stats.kept = len(findings)
            self.stats.ignored = len(self.ignored)
            self.stats.suppressed = len(self.suppressed)
            return findings, []

    monkeypatch.setattr("op_core.pipeline.merge_finding_files", fake_merge)
    monkeypatch.setattr("op_core.pipeline.PrecisionEngine", DummyPrecision)
    monkeypatch.setattr("op_core.pipeline.rank_findings", lambda findings, *_: [])

    ranked_path = tmp_path / "ranked.json"
    ranked_path.write_text("[]", encoding="utf-8")
    iast_path = tmp_path / "iast" / "findings.json"
    iast_path.parent.mkdir(parents=True, exist_ok=True)
    iast_path.write_text(json.dumps([sample_iast_payload]), encoding="utf-8")

    _merge_and_gate(
        tmp_path,
        precision_cfg=None,
        gate_threshold=None,
        gate_topn=None,
        gate_labels=None,
        iast_artifact=iast_path,
    )

    assert any(Path(item) == iast_path for item in recorded["inputs"])


def test_run_pipeline_async_includes_iast(monkeypatch, tmp_path: Path, sample_iast_payload):
    workdir = tmp_path / "work"
    campaign_path = tmp_path / "campaign.yaml"
    campaign_path.write_text("iast:\n  enabled: true\n  transport: embedded\n", encoding="utf-8")

    buffer_path = workdir / "iast" / "findings.jsonl"
    buffer_path.parent.mkdir(parents=True, exist_ok=True)
    buffer_path.write_text(json.dumps(sample_iast_payload) + "\n", encoding="utf-8")

    captured = {}

    def fake_collect_targets(domain, workdir, dom_crawl, loop=None):
        return []

    def fake_run_scans(targets, camp, workdir, resume=False):
        return [], [], {}

    def fake_export_results(ranked, events, oob_state, camp, workdir):
        captured["ranked"] = [item.to_dict() for item in ranked]
        return {}

    def fake_merge_and_gate(
        workdir,
        *,
        precision_cfg,
        gate_threshold,
        gate_topn,
        gate_labels,
        iast_artifact=None,
    ):
        merged = Path(workdir) / "merged.json"
        final = Path(workdir) / "final.json"
        merged.write_text("[]", encoding="utf-8")
        final.write_text("[]", encoding="utf-8")
        return [], [], merged, final

    monkeypatch.setattr("op_core.pipeline.collect_targets", fake_collect_targets)
    monkeypatch.setattr("op_core.pipeline.run_scans", fake_run_scans)
    monkeypatch.setattr("op_core.pipeline.export_results", fake_export_results)
    monkeypatch.setattr("op_core.pipeline._collect_grpc_targets", lambda domain, targets: [])
    monkeypatch.setattr("op_core.pipeline._run_grpc_enumeration", lambda workdir, targets: [])
    monkeypatch.setattr("op_core.pipeline._run_misconfig_checks", lambda workdir, targets: [])
    monkeypatch.setattr("op_core.pipeline._merge_and_gate", fake_merge_and_gate)

    artifacts = asyncio.run(run_pipeline_async("https://example.com", campaign_path, workdir))

    assert len(captured.get("ranked", [])) == 1
    assert captured["ranked"][0]["check"] == "iast.xss"
    assert "iast" in artifacts
    assert Path(artifacts["iast"]).exists()
