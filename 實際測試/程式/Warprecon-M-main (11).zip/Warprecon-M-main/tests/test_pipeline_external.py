from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

from op_adapters.errors import ExternalToolNotInstalledError
from op_core import campaign_prepare
from op_core import pipeline
from op_core import recon_manager
from op_core import scan_manager
from op_core.pipeline.discovery import DiscoveryHooks, collect_targets


def test_pipeline_logs_and_scans(monkeypatch, tmp_path, caplog):
    calls = {"sqlmap": 0, "xsstrike": 0, "sqlmap_timeout": None, "xsstrike_timeout": None}

    def fake_sqlmap(url, **kwargs):
        calls["sqlmap"] += 1
        calls["sqlmap_timeout"] = kwargs.get("timeout")
        return []

    def fake_xsstrike(url, **kwargs):
        calls["xsstrike"] += 1
        calls["xsstrike_timeout"] = kwargs.get("timeout")
        return []

    monkeypatch.setattr(pipeline, "run_sqlmap", fake_sqlmap)
    monkeypatch.setattr(pipeline, "run_xsstrike", fake_xsstrike)

    def fake_recon(domain):
        return ["http://a/graphql", "http://b", "http://c"], {}

    monkeypatch.setattr(recon_manager, "_run_recon", fake_recon)

    class DummyCamp:
        def __init__(self):
            self.limits = type(
                "L",
                (),
                {
                    "max_concurrency": 0,
                    "per_target_payloads": 0,
                    "max_external_targets": 2,
                    "sqlmap_timeout": 33,
                    "xsstrike_timeout": 44,
                },
            )()
            self.output = type("O", (), {"poc_top": 0, "capture": False, "history_ttl_days": 0})()
            self.oob = type("Oob", (), {"base_url": "", "api_key": ""})()


    def fake_prepare_campaign(*args, **kwargs):
        dom = args[-1] if args else False
        return DummyCamp(), dom

  
    monkeypatch.setattr(campaign_prepare, "load_campaign", lambda p: DummyCamp())
    monkeypatch.setattr(pipeline, "prepare_campaign", fake_prepare_campaign)
    monkeypatch.setattr(pipeline, "run_hunt", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "run_nuclei", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "rank_findings", lambda f, *_: f)
    monkeypatch.setattr(pipeline, "write_poc_files", lambda *a, **k: None)
    monkeypatch.setattr(pipeline, "export_html", lambda w, r: str(w/"out.html"))
    monkeypatch.setattr(pipeline, "to_sarif", lambda r: "")
    monkeypatch.setattr(pipeline, "try_capture", lambda *a, **k: (None, None))
    monkeypatch.setattr(scan_manager, "run_hunt", lambda *a, **k: [])
    monkeypatch.setattr(scan_manager, "run_nuclei", lambda *a, **k: [])
    monkeypatch.setattr(scan_manager, "rank_findings", lambda m, *_: m)
    monkeypatch.setattr(scan_manager, "write_poc_files", lambda *a, **k: None)
    monkeypatch.setattr(scan_manager, "export_html", lambda w, r: str(w/"out.html"))
    monkeypatch.setattr(scan_manager, "to_sarif", lambda r: "")
    monkeypatch.setattr(scan_manager, "try_capture", lambda *a, **k: (None, None))
    monkeypatch.setattr(recon_manager, "try_capture", lambda *a, **k: (None, None))


    class DummyInteract:
        def poll(self):
            raise RuntimeError("oob fail")
        def export_events(self):
            return {}
        def correlate_findings(self, f):
            return f

    monkeypatch.setattr(pipeline, "InteractClient", lambda b, k: DummyInteract())
    async def fail_dom(domain: str):
        raise RuntimeError("dom fail")

    monkeypatch.setattr(recon_manager, "crawl_and_capture", fail_dom)
    monkeypatch.setattr(pipeline, "crawl_and_capture", fail_dom)
    def fail_introspect(url: str):
        raise RuntimeError("gql fail")

    monkeypatch.setattr(recon_manager, "try_introspect", fail_introspect)
    monkeypatch.setattr(pipeline, "try_introspect", fail_introspect)
    monkeypatch.setattr(recon_manager, "try_capture", lambda *a, **k: (None, None))


    caplog.set_level(logging.ERROR)
    asyncio.run(
        pipeline.run_pipeline_async(
            "example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True
        )
    )

    assert calls["sqlmap"] >= 1
    assert calls["xsstrike"] >= 1
    assert calls["sqlmap_timeout"] == 33
    assert calls["xsstrike_timeout"] == 44
    text = caplog.text
    assert "dom fail" in text
    assert "oob fail" in text

    metrics_path = tmp_path / "metrics.jsonl"
    assert metrics_path.exists()
    metrics_lines = [ln for ln in metrics_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert metrics_lines
    latest_metrics = json.loads(metrics_lines[-1])
    assert latest_metrics.get("status") == "success"
    assert latest_metrics.get("hits") == 0

    events_path = tmp_path / "events.log"
    assert events_path.exists()
    events = [json.loads(ln) for ln in events_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert any(evt.get("type") == "pipeline.start" for evt in events)
    assert events[-1].get("type") == "pipeline.finish"
    assert events[-1].get("status") == "success"


def test_pipeline_missing_tools_emit_events(monkeypatch, tmp_path):
    monkeypatch.setattr(recon_manager, "_run_recon", lambda domain: ([], {}))

    class DummyCamp:
        def __init__(self) -> None:
            self.limits = type(
                "L",
                (),
                {
                    "max_concurrency": 0,
                    "per_target_payloads": 0,
                    "max_external_targets": 2,
                    "sqlmap_timeout": 30,
                    "xsstrike_timeout": 30,
                },
            )()
            self.output = type(
                "O",
                (),
                {"poc_top": 0, "capture": False, "history_ttl_days": 0}
            )()
            self.oob = type("Oob", (), {"base_url": "", "api_key": ""})()

    def fake_prepare(*args, **kwargs):
        return DummyCamp(), False

    monkeypatch.setattr(campaign_prepare, "load_campaign", lambda p: DummyCamp())
    monkeypatch.setattr(pipeline, "prepare_campaign", fake_prepare)
    monkeypatch.setattr(pipeline, "run_hunt", lambda *a, **k: [])

    def raise_nuclei(*args, **kwargs):
        raise ExternalToolNotInstalledError("nuclei")

    def raise_sqlmap(*args, **kwargs):
        raise ExternalToolNotInstalledError("sqlmap")

    def raise_xsstrike(*args, **kwargs):
        raise ExternalToolNotInstalledError("xsstrike")

    monkeypatch.setattr(pipeline, "run_nuclei", raise_nuclei)
    monkeypatch.setattr(pipeline, "run_sqlmap", raise_sqlmap)
    monkeypatch.setattr(pipeline, "run_xsstrike", raise_xsstrike)
    monkeypatch.setattr(pipeline, "rank_findings", lambda findings, *_: findings)
    monkeypatch.setattr(pipeline, "write_poc_files", lambda *a, **k: None)
    monkeypatch.setattr(pipeline, "export_html", lambda w, r: str(w / "out.html"))
    monkeypatch.setattr(pipeline, "to_sarif", lambda r: "")
    monkeypatch.setattr(pipeline, "try_capture", lambda *a, **k: (None, None))

    class DummyInteract:
        def poll(self):
            return []

        def export_events(self):
            return {}

        def correlate_findings(self, findings):
            return findings

    monkeypatch.setattr(pipeline, "InteractClient", lambda base, key: DummyInteract())

    asyncio.run(
        pipeline.run_pipeline_async(
            "example.com", Path("config/campaign.yaml"), tmp_path
        )
    )

    events_path = tmp_path / "events.log"
    events = [json.loads(ln) for ln in events_path.read_text(encoding="utf-8").splitlines() if ln.strip()]

    missing_events = [evt for evt in events if evt.get("type") == "external_tool.missing"]
    assert {evt.get("tool") for evt in missing_events} == {"nuclei", "sqlmap", "xsstrike"}


def test_collect_targets_deduplicates(monkeypatch, tmp_path, caplog):
    events: list[tuple[str, dict[str, object]]] = []

    monkeypatch.setattr(
        "op_core.pipeline.discovery.Telemetry.event",
        lambda name, payload: events.append((name, dict(payload))),
    )

    async def _introspect(_: str) -> None:
        return None

    hooks = DiscoveryHooks(
        run_recon=lambda domain: (
            [
                "https://example.com",  # duplicate root
                "https://example.com",
                "https://example.com/graphql",
            ],
            {},
        ),
        crawl_and_capture=None,
        try_capture=lambda *_: None,
        try_introspect=_introspect,
        classify_target_protocols=lambda target: ["http"],
    )

    caplog.set_level(logging.INFO)
    results = collect_targets("example.com", tmp_path, dom_crawl=False, hooks=hooks)

    assert results == ["https://example.com", "https://example.com/graphql"]
    targets_file = (tmp_path / "targets.txt").read_text(encoding="utf-8").splitlines()
    assert targets_file == results
    assert any("duplicate discovery targets" in record.message for record in caplog.records)

    # ensure telemetry was invoked with the deduplicated count
    recon_events = [evt for evt in events if evt[0] == "discovery.recon"]
    assert recon_events and recon_events[0][1]["targets"] == 2
