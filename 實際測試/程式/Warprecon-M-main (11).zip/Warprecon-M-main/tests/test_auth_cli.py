import json
from pathlib import Path

from typer.testing import CliRunner

from op_core.cli import app as cli_app


def _write_accounts(path: Path) -> None:
    path.write_text(
        """
default_profile: default
profiles:
  default:
    accounts:
      - name: Admin
        role: admin
        strategy: none
        artifacts:
          headers:
            X-User-ID: "1"
          cookies:
            session: admin-token
      - name: User
        role: user
        strategy: none
        artifacts:
          headers:
            X-User-ID: "2"
          cookies:
            session: user-token
        tags:
          tier: beta
"""
        .strip()
        + "\n",
        encoding="utf-8",
    )


def test_auth_sync_outputs_json(tmp_path):
    accounts_file = tmp_path / "accounts.yaml"
    _write_accounts(accounts_file)

    runner = CliRunner()
    result = runner.invoke(
        cli_app,
        [
            "auth",
            "sync",
            "--accounts",
            str(accounts_file),
            "--profile",
            "default",
            "--workdir",
            str(tmp_path),
            "--json",
        ],
    )

    assert result.exit_code == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["profile"] == "default"
    assert payload["default_role"] in {"admin", "user", "default"}
    assert sorted(payload["sources"]) == [str(accounts_file)]

    roles = payload["roles"]
    assert "admin" in roles
    admin_state = roles["admin"]
    assert admin_state["artifacts"]["headers"]["X-User-ID"] == "1"
    assert admin_state["artifacts"]["cookies"]["session"] == "admin-token"
    assert "meta" in admin_state
    assert admin_state["meta"]["canonical_role"] == "admin"

    # Human summary should be emitted to stderr
    assert "Primed 2 role" in result.stderr


def test_auth_sync_role_filter_and_dump(tmp_path):
    accounts_file = tmp_path / "accounts.yaml"
    _write_accounts(accounts_file)

    dump_dir = tmp_path / "sessions"

    runner = CliRunner()
    result = runner.invoke(
        cli_app,
        [
            "auth",
            "sync",
            "--accounts",
            str(accounts_file),
            "--profile",
            "default",
            "--role",
            "user",
            "--workdir",
            str(tmp_path),
            "--dump-dir",
            str(dump_dir),
            "--json",
        ],
    )

    assert result.exit_code == 0, result.stderr
    payload = json.loads(result.stdout)
    assert sorted(payload.get("missing_roles", [])) == []
    assert sorted(payload.get("requested_roles", [])) == ["user"]
    assert list(payload["roles"].keys()) == ["user"]

    exported = dump_dir / "user.json"
    assert exported.exists()
    exported_payload = json.loads(exported.read_text(encoding="utf-8"))
    assert exported_payload["meta"]["canonical_role"] == "user"

    assert "Wrote 1 session file" in result.stderr
