from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Iterable, List

from op_core import cli
from op_core.commands import hunt as hunt_cmd
from op_core.commands import rank as rank_cmd
from op_core.commands import report as report_cmd
from op_core.runtime_gate import wait_if_paused


def test_hunt_command_writes_json_lines(monkeypatch, tmp_path):
    targets_file = tmp_path / "targets.txt"
    targets_file.write_text("first\n\nsecond\n", encoding="utf-8")
    cfg_file = tmp_path / "camp.yaml"
    cfg_file.write_text("cfg", encoding="utf-8")
    out_file = tmp_path / "out.ndjson"

    captured: dict[str, object] = {}

    def fake_load_campaign(path: Path) -> str:
        captured["cfg_path"] = path
        return "campaign"

    produced = [
        {"id": 1, "target": "first"},
        {"id": 2, "target": "second"},
    ]

    def fake_run_hunt(targets: List[str], campaign: str, history: object) -> List[dict[str, object]]:
        captured["targets"] = targets
        captured["campaign"] = campaign
        captured["history"] = history
        return produced

    monkeypatch.setattr(hunt_cmd, "load_campaign", fake_load_campaign)
    monkeypatch.setattr(hunt_cmd, "run_hunt", fake_run_hunt)

    hunt_cmd.run(targets_file, cfg_file, out_file)

    assert captured["cfg_path"] == cfg_file
    assert captured["targets"] == ["first", "second"]
    assert captured["campaign"] == "campaign"
    assert captured["history"] is None

    lines = out_file.read_text(encoding="utf-8").splitlines()
    assert [json.loads(line) for line in lines] == produced


def test_hunt_command_allows_missing_workdir(monkeypatch, tmp_path):
    targets_file = tmp_path / "targets.txt"
    targets_file.write_text("target\n", encoding="utf-8")
    cfg_file = tmp_path / "camp.yaml"
    cfg_file.write_text("cfg", encoding="utf-8")
    out_file = tmp_path / "out.ndjson"

    def fake_run_hunt(targets: List[str], campaign: str, history: object) -> List[dict[str, object]]:
        # wait_if_paused used to crash when workdir was None; ensure it now returns immediately
        asyncio.run(wait_if_paused(None))
        return [{"target": targets[0], "campaign": campaign}]

    monkeypatch.setattr(hunt_cmd, "load_campaign", lambda path: "campaign")
    monkeypatch.setattr(hunt_cmd, "run_hunt", fake_run_hunt)

    hunt_cmd.run(targets_file, cfg_file, out_file)

    contents = out_file.read_text(encoding="utf-8").strip()
    assert json.loads(contents) == {"target": "target", "campaign": "campaign"}


def test_rank_command_writes_ranked(monkeypatch, tmp_path):
    infile = tmp_path / "rank.json"
    payload = [
        {"check": "c1", "target": "t1"},
        {"check": "c2", "target": "t2"},
    ]
    infile.write_text(json.dumps(payload), encoding="utf-8")
    outfile = tmp_path / "out.json"

    captured: dict[str, object] = {}

    def fake_rank_findings(items: Iterable[dict[str, object]]) -> List[dict[str, object]]:
        captured["items"] = [dict(item) for item in items]
        ranked: List[dict[str, object]] = []
        for idx, finding in enumerate(captured["items"], start=1):
            payload = dict(finding)
            payload["_rank"] = idx
            ranked.append(payload)
        return ranked

    monkeypatch.setattr(rank_cmd, "rank_findings", fake_rank_findings)

    rank_cmd.run(infile, outfile)

    assert [item["target"] for item in captured["items"]] == ["t1", "t2"]
    assert json.loads(outfile.read_text(encoding="utf-8")) == [
        dict(item, _rank=idx)
        for idx, item in enumerate(captured["items"], start=1)
    ]


def test_report_command_uses_to_sarif(monkeypatch, tmp_path):
    infile = tmp_path / "report.json"
    infile.write_text(json.dumps([{"a": 1}]), encoding="utf-8")
    outfile = tmp_path / "report.sarif"

    captured: dict[str, object] = {}

    def fake_to_sarif(items: Iterable[dict[str, int]]) -> str:
        captured["items"] = list(items)
        return "sarif-data"

    monkeypatch.setattr(report_cmd, "to_sarif", fake_to_sarif)

    report_cmd.run(infile, outfile)

    assert captured["items"] == [{"a": 1}]
    assert outfile.read_text(encoding="utf-8") == "sarif-data"


def test_pipeline_command_calls_run_pipeline(monkeypatch, tmp_path, capsys):
    cfg = tmp_path / "cfg.yaml"
    workdir = tmp_path / "work"
    profile = tmp_path / "profile.yaml"

    captured: dict[str, object] = {}

    def fake_run_pipeline(domain: str, cfg_path: Path, workdir_path: Path, **kwargs: object) -> dict[str, str]:
        captured["domain"] = domain
        captured["cfg"] = cfg_path
        captured["workdir"] = workdir_path
        captured["kwargs"] = kwargs
        return {"status": "ok"}

    monkeypatch.setattr(cli, "run_pipeline", fake_run_pipeline)

    cli.pipeline(
        domain="example.com",
        cfg=cfg,
        workdir=workdir,
        max_concurrency=5,
        poc_top=3,
        capture=True,
        history_ttl=10,
        profile=profile,
        dom_crawl=True,
        ultra=True,
        resume=False,
    )

    out = capsys.readouterr().out.strip()
    assert json.loads(out) == {"status": "ok"}
    assert captured["domain"] == "example.com"
    assert captured["cfg"] == cfg
    assert captured["workdir"] == workdir
    assert captured["kwargs"] == {
        "max_concurrency": 5,
        "poc_top": 3,
        "capture": True,
        "history_ttl": 10,
        "profile": profile,
        "dom_crawl": True,
        "ultra": True,
        "resume": False,
        "gate_threshold": None,
        "gate_topn": None,
        "gate_labels": None,
    }


def test_queue_add_prints_enqueue(monkeypatch, tmp_path, capsys):
    workdir = tmp_path / "wd"
    records: dict[str, object] = {}

    class DummyQueue:
        def __init__(self, path: Path) -> None:
            records["path"] = path

        def enqueue(self, domain: str, cfg: str) -> str:
            records["domain"] = domain
            records["cfg"] = cfg
            return "tid-1"

    monkeypatch.setattr(cli, "FSQueue", DummyQueue)

    cli.queue_add(workdir=workdir, domain="example.com", cfg=tmp_path / "cfg.yaml")

    output = json.loads(capsys.readouterr().out.strip())
    assert output == {"queued": "tid-1", "domain": "example.com"}
    assert records["path"] == workdir / "queue"
    assert records["domain"] == "example.com"
    assert records["cfg"] == str(tmp_path / "cfg.yaml")


def test_agent_run_invokes_runner(monkeypatch, tmp_path):
    called: dict[str, object] = {}

    def fake_run_agent(workdir: Path, cfg_path: Path, *, max_loops: int | None, max_concurrency: int | None) -> None:
        called["workdir"] = workdir
        called["cfg"] = cfg_path
        called["max_loops"] = max_loops
        called["max_concurrency"] = max_concurrency

    monkeypatch.setattr(cli, "run_agent", fake_run_agent)

    cli.agent_run(
        workdir=tmp_path,
        cfg=tmp_path / "agent.yaml",
        max_concurrency=4,
        max_loops=10,
    )

    assert called == {
        "workdir": tmp_path,
        "cfg": tmp_path / "agent.yaml",
        "max_loops": 10,
        "max_concurrency": 4,
    }


def test_ui_calls_create_app(monkeypatch, tmp_path):
    called: dict[str, object] = {}

    class DummyApp:
        def run(self, host: str, port: int, debug: bool) -> None:
            called["host"] = host
            called["port"] = port
            called["debug"] = debug

    def fake_create_app(workdir: Path, cfg: Path) -> DummyApp:
        called["workdir"] = workdir
        called["cfg"] = cfg
        return DummyApp()

    monkeypatch.setattr(cli, "create_app", fake_create_app)

    cli.ui(workdir=tmp_path, cfg=tmp_path / "cfg.yaml", port=1234)

    assert called["workdir"] == tmp_path
    assert called["cfg"] == tmp_path / "cfg.yaml"
    assert called["host"] == "127.0.0.1"
    assert called["port"] == 1234
    assert called["debug"] is False


def test_deliver_prints_zip(monkeypatch, tmp_path, capsys):
    monkeypatch.setattr(cli, "make_deliverable_zip", lambda workdir, out=None: "archive.zip")

    cli.deliver(workdir=tmp_path, out=None)

    assert json.loads(capsys.readouterr().out.strip()) == {"zip": "archive.zip"}


def test_idor_command_serialises_findings(monkeypatch, tmp_path, capsys):
    targets = tmp_path / "targets.txt"
    targets.write_text("https://example.com/api/1", encoding="utf-8")
    out_file = tmp_path / "idor.json"

    class DummyCheck:
        def __init__(self, **kwargs: object) -> None:
            self.kwargs = kwargs

        def run(self, apis: List[dict[str, str]]) -> Iterable[dict[str, object]]:
            return [{"target": apis[0]["url"], "severity": "high"}]

    monkeypatch.setattr(cli, "IdorCheck", DummyCheck)

    cli.idor(
        targets=targets,
        out=out_file,
        expand_variants=True,
        max_variants=20,
        exclude=("skip",),
    )

    data = json.loads(out_file.read_text(encoding="utf-8"))
    assert data and data[0]["target"] == "https://example.com/api/1"
    assert data[0].get("severity") == "high"
    summary = json.loads(capsys.readouterr().out.strip())
    assert summary == {"findings": 1, "out": str(out_file)}


def test_checks_command_serialises_findings(monkeypatch, tmp_path, capsys):
    out_file = tmp_path / "results.ndjson"

    class DummyCheck:
        def run(self, *, apis: list[str], workdir: Path | None = None) -> Iterable[dict[str, str]]:
            assert workdir == tmp_path
            return [{"target": api} for api in apis]

    monkeypatch.setattr(cli, "REGISTRY", {"dummy": DummyCheck})

    cli.checks(check="dummy", apis=json.dumps(["https://example.com"]), out=out_file, workdir=tmp_path)

    lines = out_file.read_text(encoding="utf-8").splitlines()
    assert [json.loads(line) for line in lines] == [{"target": "https://example.com"}]

    output = capsys.readouterr().out
    assert "Completed dummy check" in output
    assert "Results written" in output
