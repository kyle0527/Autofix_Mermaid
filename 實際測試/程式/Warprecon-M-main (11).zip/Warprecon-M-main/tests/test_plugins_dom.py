from __future__ import annotations

import importlib
from pathlib import Path
from types import SimpleNamespace

import pytest

load_plugins = pytest.importorskip("op_plugins.loader").load_plugins
metadata = pytest.importorskip("importlib.metadata")
EntryPoint = metadata.EntryPoint
EntryPoints = metadata.EntryPoints

PLUGIN = """
def post_rank(ranked):
    for f in ranked:
        f['_score'] = f.get('_score',0) + 1
    return ranked
"""


def test_plugin_loader(tmp_path: Path):
    w = tmp_path
    (w / "plugins").mkdir()
    (w / "plugins" / "p_custom.py").write_text(PLUGIN, encoding="utf-8")
    hooks = load_plugins(w)
    assert "post_rank" in hooks and hooks["post_rank"]
    # ensure custom plugin loaded
    custom_path = w / "plugins" / "p_custom.py"
    assert any(f.__code__.co_filename == str(custom_path) for f in hooks["post_rank"])
    # ensure builtin plugins loaded
    builtin_dir = Path(__file__).resolve().parents[1] / "src" / "op_plugins" / "builtin"
    assert any(Path(f.__code__.co_filename).parent == builtin_dir for f in hooks["post_rank"])



def test_entry_point_plugin(monkeypatch, tmp_path: Path):
    module_path = tmp_path / "ep_module.py"
    module_path.write_text("# entry point module", encoding="utf-8")

    def _vector_probe(workdir, camp, targets):
        return [{"target": "via-entry"}]

    def _post_rank(items):
        return items

    def _exporter(workdir, ranked):
        workdir.joinpath("from-entry.txt").write_text("ok", encoding="utf-8")

    plugin_obj = SimpleNamespace(
        vector_probe=_vector_probe,
        post_rank=_post_rank,
        artifact_exporter=_exporter,
        __file__=str(module_path),
        __name__="entry_point_plugin",
    )

    class _EntryPoint:
        name = "entry-plugin"
        value = "pkg.module:plugin"

        def load(self):
            return plugin_obj

    class _EntryPoints(list):
        def select(self, group):
            return self if group == "warprecon.plugins" else _EntryPoints()

        def get(self, group, default=None):  # pragma: no cover - legacy API
            return self if group == "warprecon.plugins" else (default or [])

    monkeypatch.setattr(
        "importlib.metadata.entry_points", lambda: _EntryPoints([_EntryPoint()])
    )

    hooks = load_plugins(tmp_path)
    assert any(func is plugin_obj.post_rank for func in hooks.get("post_rank", []))
    assert any(func is plugin_obj.vector_probe for func in hooks.get("vector_probe", []))
    assert any(func is plugin_obj.artifact_exporter for func in hooks.get("artifact_exporter", []))


def test_protocol_entry_point(monkeypatch):
    async def _probe(*args, **kwargs):  # pragma: no cover - simple stub
        return None

    class _EntryPoint:
        name = "proto"
        value = "pkg.module:proto"

        def load(self):
            from op_core import plugins as plugin_module

            plugin_module.register_protocol("entry-proto", _probe)
            return SimpleNamespace(__file__="proto.py")

    class _EntryPoints(list):
        def select(self, group):
            return self if group == "warprecon.plugins" else _EntryPoints()

        def get(self, group, default=None):  # pragma: no cover - legacy API
            return self if group == "warprecon.plugins" else (default or [])

    monkeypatch.setattr(
        "importlib.metadata.entry_points", lambda: _EntryPoints([_EntryPoint()])
    )

    import op_core.plugins as plugin_module

    importlib.reload(plugin_module)

    try:
        assert plugin_module.get_protocol("entry-proto") is _probe
    finally:
        monkeypatch.setattr("importlib.metadata.entry_points", lambda: _EntryPoints([]))
        importlib.reload(plugin_module)

def test_entry_point_plugins(monkeypatch, tmp_path: Path):
    pkg_dir = tmp_path / "ep_pkg"
    pkg_dir.mkdir()
    (pkg_dir / "__init__.py").write_text("", encoding="utf-8")
    (pkg_dir / "plugin.py").write_text(
        "def post_rank(items):\n    return [{'check': 'ep', '_score': 1}]\n",
        encoding="utf-8",
    )

    monkeypatch.syspath_prepend(str(tmp_path))

    ep = EntryPoint(name="ep_demo", value="ep_pkg.plugin", group="warprecon_m.plugins")

    def fake_entry_points():
        return EntryPoints((ep,))

    monkeypatch.setattr(metadata, "entry_points", fake_entry_points)

    hooks = load_plugins(tmp_path)
    assert "post_rank" in hooks
    assert any(func.__module__ == "ep_pkg.plugin" for func in hooks["post_rank"])



def test_dom_browser_returns_dict():
    browser_mod = pytest.importorskip("op_dom.browser")
    extract_hints_with_playwright = browser_mod.extract_hints_with_playwright
    out = extract_hints_with_playwright("http://localhost:9")
    assert isinstance(out, dict)


def test_wordlist_writer(tmp_path: Path):
    wordlist_mod = pytest.importorskip("op_synth.wordlist")
    p = wordlist_mod.save_wordlist(tmp_path, ["alpha", "beta", "alpha"], name="unit")
    assert Path(p).exists()
