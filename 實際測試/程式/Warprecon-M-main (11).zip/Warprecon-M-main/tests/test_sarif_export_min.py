import json
from pathlib import Path
from op_output.sarif import export_sarif


def test_sarif_export_min(tmp_path: Path):
    items = [
        {"fingerprint": "a", "severity": "high", "url": "http://a"},
        {"fingerprint": "b", "severity": "low"},
    ]
    path = export_sarif(tmp_path, items)
    data = json.loads(Path(path).read_text())
    assert "runs" in data and data["runs"][0]["results"][0]["ruleId"]
    assert len(data["runs"][0]["results"]) == 2


def test_sarif_includes_cvss_properties(tmp_path: Path):
    items = [
        {
            "severity": "high",
            "url": "http://a",
            "cwe": "CWE-89",
            "cvss": {
                "base_score": 9.4,
                "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L",
                "severity": "Critical",
                "metrics": {
                    "AV": "NETWORK",
                    "AC": "LOW",
                    "PR": "NONE",
                    "UI": "NONE",
                    "S": "UNCHANGED",
                    "C": "HIGH",
                    "I": "HIGH",
                    "A": "LOW",
                },
            },
        }
    ]
    path = export_sarif(tmp_path, items)
    result = json.loads(Path(path).read_text())["runs"][0]["results"][0]
    props = result["properties"]
    assert props["cwe"] == "CWE-89"
    assert props["cvssBaseScore"] == 9.4
    assert props["cvssVector"].startswith("CVSS:3.1/")
    assert props["cvssMetrics"]["AV"] == "NETWORK"
