from __future__ import annotations

import asyncio
import asyncio
from typing import Any, Dict, List
from types import SimpleNamespace

import pytest

pytest.importorskip("op_proto.grpc.engine")
pytest.importorskip("op_proto.grpc.reflector")
pytest.importorskip("op_proto.grpc.enumerate")

from op_proto.grpc.engine import probe_unary_unary, reflect_services, grpc_probe
from op_proto.grpc.reflector import call_reflect_json
from op_proto.grpc.enumerate import _split_target, enumerate_methods


def test_grpc_modules_import_and_fail_gracefully():
    # Should not crash even if grpc libs or network not available
    ev = probe_unary_unary("localhost:50051", "/pkg.Svc/Method", b"", tls=False, timeout=0.5)
    assert isinstance(ev, dict)
    r = reflect_services("localhost:50051", tls=False, timeout=0.5)
    assert isinstance(r, dict)
    j = call_reflect_json("localhost:50051", "/pkg.Svc/Method", {"a": 1}, tls=False, timeout=0.5)
    assert isinstance(j, dict)
    assert j.get("status") in {"ok", "degraded", "error"}
    assert j.get("method") == "/pkg.Svc/Method"
    ms = enumerate_methods("localhost:50051", tls=False, timeout=0.5)
    assert isinstance(ms, list)
    gp = asyncio.run(grpc_probe("localhost:50051", {}, None))
    assert isinstance(gp, list)


def test_grpc_probe_returns_list():
    res = asyncio.run(grpc_probe("localhost:50051", {}, None))
    assert isinstance(res, list)


def test_call_reflect_json_summarizes_descriptors(monkeypatch: pytest.MonkeyPatch) -> None:
    descriptor_pb2 = pytest.importorskip("google.protobuf.descriptor_pb2")
    json_format = pytest.importorskip("google.protobuf.json_format")
    descriptor_pool = pytest.importorskip("google.protobuf.descriptor_pool")
    descriptor = pytest.importorskip("google.protobuf.descriptor")

    from op_proto.grpc import reflector

    fd = descriptor_pb2.FileDescriptorProto()
    fd.name = "echo.proto"
    fd.package = "pkg"
    svc = fd.service.add()
    svc.name = "Echo"
    method = svc.method.add()
    method.name = "Ping"
    method.input_type = ".pkg.PingRequest"
    method.output_type = ".pkg.PingReply"
    req_msg = fd.message_type.add()
    req_msg.name = "PingRequest"
    req_field = req_msg.field.add()
    req_field.name = "code"
    req_field.number = 1
    req_field.label = descriptor.FieldDescriptor.LABEL_OPTIONAL
    req_field.type = descriptor.FieldDescriptor.TYPE_STRING
    res_msg = fd.message_type.add()
    res_msg.name = "PingReply"
    res_field = res_msg.field.add()
    res_field.name = "ok"
    res_field.number = 1
    res_field.label = descriptor.FieldDescriptor.LABEL_OPTIONAL
    res_field.type = descriptor.FieldDescriptor.TYPE_BOOL

    deps = reflector._ReflectionDeps(  # type: ignore[attr-defined]
        grpc=SimpleNamespace(),
        grpc_reflection=SimpleNamespace(),
        descriptor_pb2=descriptor_pb2,
        json_format=json_format,
        descriptor_pool=descriptor_pool,
        pb_descriptor=descriptor,
    )

    schema = {
        "services": [
            {
                "name": "pkg.Echo",
                "methods": [
                    {
                        "name": "Ping",
                        "type": "unary-unary",
                        "fq_name": "/pkg.Echo/Ping",
                        "input": ".pkg.PingRequest",
                        "output": ".pkg.PingReply",
                    }
                ],
            }
        ]
    }

    channel = SimpleNamespace(close=lambda: None)
    stub = object()

    monkeypatch.setattr(reflector, "_load_reflection_dependencies", lambda: deps)
    monkeypatch.setattr(reflector, "_enumerate_services", lambda *args, **kwargs: schema)
    monkeypatch.setattr(reflector, "_create_stub", lambda *args, **kwargs: (channel, stub))
    monkeypatch.setattr(reflector, "_wait_for_channel_ready", lambda *args, **kwargs: None)
    monkeypatch.setattr(reflector, "_collect_file_descriptors", lambda *args, **kwargs: ([fd], []))

    result = reflector.call_reflect_json(
        "localhost:50051",
        "/pkg.Echo/Ping",
        {"sample": True},
        tls=False,
        timeout=0.5,
    )

    assert result["status"] == "ok"
    assert result["method_info"]["service"] == "pkg.Echo"
    assert result["request_schema"]["type"] == "pkg.PingRequest"
    request_fields = {field["name"] for field in result["request_schema"]["fields"]}
    assert "code" in request_fields
    assert result["response_schema"]["type"] == "pkg.PingReply"
    response_fields = {field["name"] for field in result["response_schema"]["fields"]}
    assert "ok" in response_fields
    assert result["descriptors"]


def test_call_reflect_json_handles_missing_dependencies(monkeypatch: pytest.MonkeyPatch) -> None:
    from op_proto.grpc import reflector

    def raise_runtime() -> Any:
        raise RuntimeError("missing deps")

    monkeypatch.setattr(reflector, "_load_reflection_dependencies", raise_runtime)

    result = reflector.call_reflect_json(
        "localhost:50051", "/pkg.Svc/Method", {}, tls=False, timeout=0.1
    )

    assert result["status"] == "degraded"
    assert "missing deps" in result.get("error", "")
    assert result["method"] == "/pkg.Svc/Method"


def test_grpc_probe_auto_discovers_unary(monkeypatch: pytest.MonkeyPatch) -> None:
    from op_proto.grpc import engine as grpc_engine

    sample_schema = {
        "services": [
            {
                "name": "pkg.Echo",
                "methods": [
                    {"name": "Ping", "type": "unary-unary", "fq_name": "/pkg.Echo/Ping"}
                ],
            }
        ]
    }

    monkeypatch.setattr(grpc_engine, "_enumerate_services", lambda *args, **kwargs: sample_schema)

    def fake_probe(target: str, method: str, payload: bytes, **kwargs: Any) -> Dict[str, Any]:
        return {"status": "ok", "request_preview": "", "response_preview": ""}

    monkeypatch.setattr(grpc_engine, "probe_unary_unary", fake_probe)

    findings = grpc_engine.grpc_probe_sync("example.com:50051", {})
    method_finding = next(f for f in findings if f["vector"]["location"] == "method")
    assert method_finding["vector"]["param"] == "/pkg.Echo/Ping"
    assert method_finding["evidence"].get("auto_discovered") is True


def test_grpc_probe_retries_plaintext(monkeypatch: pytest.MonkeyPatch) -> None:
    from op_proto.grpc import engine as grpc_engine

    calls: List[bool] = []

    def fake_enum(target: str, use_tls: bool = True, timeout: float = 5.0) -> Dict[str, Any]:
        calls.append(use_tls)
        if use_tls:
            return {"error": "TLS handshake failed"}
        return {
            "services": [
                {
                    "name": "pkg.Echo",
                    "methods": [
                        {"name": "Ping", "type": "unary-unary", "fq_name": "/pkg.Echo/Ping"}
                    ],
                }
            ]
        }

    monkeypatch.setattr(grpc_engine, "_enumerate_services", fake_enum)
    monkeypatch.setattr(grpc_engine, "plaintext_on_tls_port", lambda *_: True)
    monkeypatch.setattr(grpc_engine, "tls_min_version", lambda *_args, **_kwargs: False)

    probe_calls: List[bool | None] = []

    def fake_probe(target: str, method: str, payload: bytes, **kwargs: Any) -> Dict[str, Any]:
        probe_calls.append(kwargs.get("tls"))
        return {"status": "ok", "request_preview": "", "response_preview": ""}

    monkeypatch.setattr(grpc_engine, "probe_unary_unary", fake_probe)

    findings = grpc_engine.grpc_probe_sync("api.example.com:443", {})

    reflection = next(f for f in findings if f["vector"]["location"] == "reflection")
    evidence = reflection["evidence"]
    assert evidence["use_tls"] is False
    attempts = evidence.get("enumeration_attempts")
    assert attempts and attempts[0]["use_tls"] is True and attempts[1]["use_tls"] is False
    assert calls == [True, False]
    assert probe_calls == [False]


def test_grpc_probe_retains_tls_when_reflection_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    from op_proto.grpc import engine as grpc_engine

    calls: List[bool] = []

    def fake_enum(target: str, use_tls: bool = True, timeout: float = 5.0) -> Dict[str, Any]:
        calls.append(use_tls)
        return {"services": [{"name": "pkg.Service", "methods": []}]}

    monkeypatch.setattr(grpc_engine, "_enumerate_services", fake_enum)
    monkeypatch.setattr(grpc_engine, "plaintext_on_tls_port", lambda *_: True)
    monkeypatch.setattr(grpc_engine, "tls_min_version", lambda *_args, **_kwargs: False)
    monkeypatch.setattr(
        grpc_engine,
        "probe_unary_unary",
        lambda *args, **kwargs: {"status": "error", "request_preview": ""},
    )

    findings = grpc_engine.grpc_probe_sync("secure.example.com:443", {"method": "/pkg.Service/Ping"})

    reflection = next(f for f in findings if f["vector"]["location"] == "reflection")
    evidence = reflection["evidence"]
    assert evidence["use_tls"] is True
    attempts = evidence.get("enumeration_attempts")
    assert attempts and len(attempts) == 1
    assert calls == [True]


@pytest.mark.parametrize(
    ("target", "expected"),
    [
        ("localhost:50051", ("localhost", 50051)),
        ("Example.COM:50051", ("Example.COM", 50051)),
        ("example.com", ("example.com", 443)),
        ("[2001:db8::1]:50051", ("2001:db8::1", 50051)),
        ("[2001:db8::1]", ("2001:db8::1", 443)),
        ("2001:db8::1", ("2001:db8::1", 443)),
        ("2001:db8::1:443", ("2001:db8::1:443", 443)),
    ],
)
def test_split_target_valid_inputs(target, expected):
    assert _split_target(target) == expected


@pytest.mark.parametrize(
    "target",
    [
        "",
        "localhost:",
        "localhost:notaport",
        "localhost:70000",
        "[2001:db8::1",
        "[2001:db8::1]:70000",
        "[2001:db8::1]:notaport",
        "[2001:db8::1]:",
        "[]:443",
        "example.com/path",
        "example.com?foo=bar",
        "user@example.com:443",
    ],
)
def test_split_target_invalid_inputs(target):
    with pytest.raises(ValueError):
        _split_target(target)
