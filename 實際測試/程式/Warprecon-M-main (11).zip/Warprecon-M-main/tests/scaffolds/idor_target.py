from __future__ import annotations

from typing import Any, Dict, Iterable

from op_checks.idor_diff import ResponseSnapshot, diff_snapshots


class SyntheticIdorTarget:
    """Fixture target exposing predictable ACL and IDOR behaviours."""

    def __init__(self) -> None:
        self._responses: Dict[str, Dict[str, Any]] = {
            "admin": {
                "status_code": 200,
                "identifier": "alpha-record",
                "fields": {"balance": 900, "email": "admin@example.com"},
            },
            "user": {
                "status_code": 200,
                "identifier": "alpha-record",
                "fields": {"balance": 120, "email": "user@example.com"},
            },
            "anonymous": {
                "status_code": 403,
                "identifier": None,
                "fields": {},
            },
        }

    def fetch(self, role: str, resource_id: str) -> ResponseSnapshot:
        template = dict(self._responses.get(role, self._responses["anonymous"]))
        return ResponseSnapshot(
            role=role,
            resource_id=resource_id,
            status_code=int(template["status_code"]),
            identifier=template.get("identifier"),
            fields=dict(template.get("fields", {})),
        )

    @staticmethod
    def diff(baseline: ResponseSnapshot, candidate: ResponseSnapshot) -> Dict[str, Any]:
        return diff_snapshots(baseline, candidate)

    def enumerate(self) -> Iterable[str]:
        return self._responses.keys()
