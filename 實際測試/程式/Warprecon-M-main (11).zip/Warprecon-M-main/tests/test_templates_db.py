from op_data import templates


def test_template_counts():
    gql = templates.load_templates("graphql_detection")
    grpc = templates.load_templates("grpc_enumeration")
    assert len(gql) == 10
    assert len(grpc) == 10


def test_load_templates_cache(monkeypatch):
    calls = {"count": 0}

    def fake_load_all():
        calls["count"] += 1
        return {"graphql_detection": [{"name": "a", "query": "b"}]}

    monkeypatch.setattr(templates, "_load_all", fake_load_all)
    templates.load_templates.cache_clear()
    templates.load_templates("graphql_detection")
    templates.load_templates("graphql_detection")
    assert calls["count"] == 1
