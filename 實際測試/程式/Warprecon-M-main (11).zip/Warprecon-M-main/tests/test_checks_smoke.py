def test_imports():
    from src.op_checks.base import REGISTRY
    assert "idor" in REGISTRY and "oauth" in REGISTRY
