from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
from pathlib import Path
from types import SimpleNamespace

import pytest

from op_core import pipeline, recon_manager, scan_manager
from op_core.history import HistoryDB


# Helper to patch heavy deps

def patch_basics(monkeypatch: pytest.MonkeyPatch, targets: list[str] | None = None) -> None:
    if targets is None:
        targets = ["https://example.com"]

    monkeypatch.setattr(pipeline, "_run_recon", lambda domain: (targets, {}))

    monkeypatch.setattr(
        pipeline,
        "run_hunt",
        lambda targets, camp, history, oob_client, workdir, auth, **kwargs: [],
    )
    monkeypatch.setattr(pipeline, "rank_findings", lambda findings, *_: findings)
    monkeypatch.setattr(pipeline, "run_nuclei", lambda path, profile: [])
    monkeypatch.setattr(pipeline, "run_sqlmap", lambda target, **_: [])
    monkeypatch.setattr(pipeline, "run_xsstrike", lambda target, **_: [])
    monkeypatch.setattr(pipeline, "export_html", lambda workdir, ranked: str(workdir / "out.html"))
    monkeypatch.setattr(pipeline, "to_sarif", lambda ranked: "")
    monkeypatch.setattr(pipeline, "write_poc_files", lambda workdir, findings, inputs: None)
    monkeypatch.setattr(pipeline, "try_capture", lambda *a, **k: recon_manager.try_capture(*a, **k))
    monkeypatch.setattr(pipeline, "try_introspect", lambda url: recon_manager.try_introspect(url))
    monkeypatch.setattr(pipeline, "crawl_and_capture", lambda *a, **k: recon_manager.crawl_and_capture(*a, **k))

    monkeypatch.setattr(
        scan_manager,
        "run_hunt",
        lambda targets, camp, history, oob_client, workdir, auth=None, **_: [],
    )
    monkeypatch.setattr(scan_manager, "rank_findings", lambda findings, *_: findings)
    monkeypatch.setattr(scan_manager, "run_nuclei", lambda path, profile: [])
    monkeypatch.setattr(scan_manager, "run_sqlmap", lambda target, **_: [])
    monkeypatch.setattr(scan_manager, "run_xsstrike", lambda target, **_: [])
    monkeypatch.setattr(scan_manager, "export_html", lambda workdir, ranked: str(workdir / "out.html"))
    monkeypatch.setattr(scan_manager, "to_sarif", lambda ranked: "")
    monkeypatch.setattr(scan_manager, "write_poc_files", lambda workdir, findings, inputs: None)
    monkeypatch.setattr(scan_manager, "try_capture", lambda *a, **k: (None, None))


def test_dom_crawl_failure(monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, tmp_path: Path) -> None:
    patch_basics(monkeypatch)

    async def fail_crawl(domain: str):
        raise RuntimeError("boom")

    monkeypatch.setattr(recon_manager, "crawl_and_capture", fail_crawl)
    monkeypatch.setattr(pipeline, "crawl_and_capture", fail_crawl)
    caplog.set_level(logging.ERROR)
    asyncio.run(
        pipeline.run_pipeline_async(
            "example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True
        )
    )
    disc = tmp_path / "discovery"
    assert json.loads((disc / "dom-requests.json").read_text()) == []
    assert json.loads((disc / "dom-endpoints.json").read_text()) == []
    assert "DOM capture failed" in caplog.text


def test_graphql_introspection_failure(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, tmp_path: Path
) -> None:
    patch_basics(monkeypatch, targets=["https://example.com/graphql"])

    def fail_introspect(url: str) -> None:
        raise RuntimeError("nope")

    monkeypatch.setattr(recon_manager, "try_introspect", fail_introspect)
    monkeypatch.setattr(pipeline, "try_introspect", fail_introspect)
    caplog.set_level(logging.ERROR)
    asyncio.run(
        pipeline.run_pipeline_async("example.com", Path("config/campaign.yaml"), tmp_path)
    )
    assert not (tmp_path / "schema").exists()
    assert "GraphQL introspection failed" in caplog.text


def test_graphql_introspection_multiple(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from op_proto.graphql import engine as gql_engine

    gql_engine.SCHEMA_CACHE.clear()
    targets = [
        "https://example.com/graphql",
        "https://demo.test/graphql",
        "https://other.test/api",
    ]
    patch_basics(monkeypatch, targets=targets)

    schemas = {
        "https://example.com/graphql": {
            "data": {
                "__schema": {
                    "queryType": {"name": "Query"},
                    "types": [{"name": "Query", "kind": "OBJECT"}],
                }
            }
        },
        "https://demo.test/graphql": {
            "data": {
                "__schema": {
                    "queryType": {"name": "Root"},
                    "types": [
                        {"name": "Root", "kind": "OBJECT"},
                        {"name": "Thing", "kind": "OBJECT"},
                    ],
                }
            }
        },
    }

    async def fake_introspect(url: str):
        return schemas.get(url)

    monkeypatch.setattr(pipeline, "try_introspect", fake_introspect)

    asyncio.run(pipeline.run_pipeline_async("example.com", Path("config/campaign.yaml"), tmp_path))

    sdir = tmp_path / "schema"
    aggregated = json.loads((sdir / "graphql-introspection.json").read_text())
    assert aggregated == schemas

    for url, schema in schemas.items():
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:12]
        path = sdir / f"graphql-introspection-{digest}.json"
        assert path.exists()
        assert json.loads(path.read_text()) == schema
        payloads = gql_engine.schema_payloads_for(url, limit=1)
        assert payloads and "__type" in payloads[0]["payload"]

    gql_engine.SCHEMA_CACHE.clear()


def test_oob_poll_failure(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, tmp_path: Path
) -> None:
    patch_basics(monkeypatch)

    class DummyOOB:
        def __init__(self, base_url: str | None, api_key: str | None) -> None:
            pass

        def poll(self) -> list[dict]:
            raise RuntimeError("poll fail")

        def export_events(self) -> dict:
            return {"events": []}

        def correlate_findings(self, findings):
            return findings

    monkeypatch.setattr(scan_manager, "InteractClient", DummyOOB)
    monkeypatch.setattr(pipeline, "InteractClient", DummyOOB)
    caplog.set_level(logging.ERROR)
    asyncio.run(
        pipeline.run_pipeline_async("example.com", Path("config/campaign.yaml"), tmp_path)
    )
    oob_dir = tmp_path / "oob"
    data = json.loads((oob_dir / "events.json").read_text())
    assert data["events"] == []
    assert "OOB poll failed" in caplog.text


def test_dom_screenshot_failure(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, tmp_path: Path
) -> None:
    patch_basics(monkeypatch)

    async def ok_crawl(domain: str):
        return {
            "requests": [],
            "endpoints": [],
            "pages": [
                {
                    "url": f"https://{domain}/",
                    "html": "<html>demo</html>",
                    "screenshot": "!!!not-base64!!!",
                }
            ],
        }

    monkeypatch.setattr(recon_manager, "crawl_and_capture", ok_crawl)
    caplog.set_level(logging.ERROR)
    asyncio.run(
        pipeline.run_pipeline_async(
            "example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True
        )
    )

    artifacts_path = tmp_path / "discovery" / "dom-artifacts.json"
    data = json.loads(artifacts_path.read_text(encoding="utf-8"))
    assert data and data[0]["url"] == "https://example.com/"
    assert "snapshot" in data[0]
    assert "screenshot" not in data[0]


def test_dom_snapshot_cleanup_missing(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, tmp_path: Path
) -> None:
    patch_basics(monkeypatch)

    async def ok_crawl(domain: str):
        return {
            "requests": [],
            "endpoints": [],
            "pages": [
                {
                    "url": f"https://{domain}/page",
                    "html": "<html>page</html>",
                    "screenshot": base64.b64encode(b"img").decode("ascii"),
                }
            ],
        }

    monkeypatch.setattr(recon_manager, "crawl_and_capture", ok_crawl)
    caplog.set_level(logging.WARNING)
    asyncio.run(
        pipeline.run_pipeline_async(
            "example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True
        )
    )

    artifacts_path = tmp_path / "discovery" / "dom-artifacts.json"
    data = json.loads(artifacts_path.read_text(encoding="utf-8"))
    assert data and data[0]["screenshot"].endswith(".png")
    screenshot_file = tmp_path / data[0]["screenshot"]
    snapshot_file = tmp_path / data[0]["snapshot"]
    assert screenshot_file.read_bytes() == b"img"
    assert snapshot_file.read_text(encoding="utf-8") == "<html>page</html>"


def test_run_scans_resume_skips_completed_targets(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    patch_basics(monkeypatch)

    history_path = tmp_path / "history.sqlite3"
    db = HistoryDB(history_path, ttl_days=30)
    db.remember_target("https://done", "success")
    db.close()

    camp = SimpleNamespace(
        output=SimpleNamespace(history_ttl_days=30, poc_top=0, capture=False),
        oob=SimpleNamespace(base_url=None, api_key=None),
        limits=SimpleNamespace(max_external_targets=10),
    )

    class DummyAuthManager:
        def __init__(self, *args, **kwargs) -> None:
            pass

    class DummyClient:
        def __init__(self, base_url: str | None, api_key: str | None) -> None:
            pass

        def poll(self) -> list[dict]:
            return []

        def export_events(self) -> dict:
            return {"events": []}

        def correlate_findings(self, findings):
            return findings

    monkeypatch.setattr(pipeline, "AuthManager", DummyAuthManager)
    monkeypatch.setattr(pipeline, "load_strategy", lambda name: object())
    monkeypatch.setattr(pipeline, "make_async_client", lambda workdir: object())
    monkeypatch.setattr(pipeline, "InteractClient", DummyClient)

    captured: dict[str, object] = {}

    def capture_run_hunt(targets, camp, history, oob_client, workdir, auth, **kwargs):
        captured["targets"] = list(targets)
        captured["resume"] = bool(kwargs.get("resume"))
        captured["history_path"] = history.path
        return []

    monkeypatch.setattr(pipeline, "run_hunt", capture_run_hunt)

    targets = ["https://done", "https://pending"]
    ranked, events, oob_state = pipeline.run_scans(targets, camp, tmp_path, resume=True)

    assert captured["targets"] == ["https://pending"]
    assert captured["resume"] is True
    assert captured["history_path"] == history_path

    assert ranked == []
    assert events == []
    assert oob_state["events"] == []
