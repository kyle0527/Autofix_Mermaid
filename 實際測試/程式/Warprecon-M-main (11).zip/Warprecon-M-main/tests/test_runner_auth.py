from __future__ import annotations

import sys
import types

from op_auth import AuthManager, AuthStrategy
from op_core import plugins


class DummyStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.login_called = 0
        self.ensure_called = 0

    def login(self, client):  # type: ignore[override]
        self.login_called += 1

    def ensure_session(self, client):  # type: ignore[override]
        self.ensure_called += 1


class DummyResponse:
    headers = {"content-type": "text/html"}
    text = ""
    url = "http://example.com"


class DummyClient:
    async def get(self, *args, **kwargs):  # pragma: no cover - simple stub
        return DummyResponse()

    async def aclose(self) -> None:
        pass


class DummyCamp:
    class Limits:
        global_rps = 30
        per_host_rps = 6
        jitter_ms = 120
        max_concurrency = 8
        per_target_payloads = 8
        retries = 1
        http_timeout = 10.0
        http_proxy = None

    class Bandit:
        arms: list = []

    class OOBCfg:
        base_url = None
        api_key = None

    class SynthCfg:
        transforms: list = []

    limits = Limits()
    bandit = Bandit()
    oob = OOBCfg()
    synth = SynthCfg()


def test_run_hunt_invokes_auth_manager(tmp_path, monkeypatch):
    # Inject stub campaign module before importing runner
    sys.modules["op_control.campaign"] = types.SimpleNamespace(Campaign=DummyCamp)

    class _DummyDeDup:
        def __init__(self, *args, **kwargs):
            pass

        def seen_before(self, item):
            return False

    sys.modules["op_core.dedupe"] = types.SimpleNamespace(
        DeDup=_DummyDeDup, fp=lambda item: "0"
    )

    from op_core.runner import run_hunt

    strat = DummyStrategy()
    mgr = AuthManager({"default": strat}, lambda: DummyClient())
    camp = DummyCamp()

    monkeypatch.setattr("op_core.runner.generate_candidates", lambda *a, **k: [])
    monkeypatch.setattr("op_core.runner.probe_positions", lambda *a, **k: [])

    async def _noop_probe(*args, **kwargs):
        return None

    monkeypatch.setattr(plugins, "_probe_registry", {})
    for proto in ["http", "graphql", "ws", "grpc"]:
        plugins.register_protocol(proto, _noop_probe)

    findings = run_hunt(
        ["http://example.com"], camp, workdir=tmp_path, auth=mgr
    )
    assert findings == []
    assert strat.login_called == 1


def test_run_hunt_uses_candidate_role(tmp_path, monkeypatch):
    sys.modules["op_control.campaign"] = types.SimpleNamespace(Campaign=DummyCamp)

    class _DummyDeDup:
        def __init__(self, *args, **kwargs):
            pass

        def seen_before(self, item):
            return False

    sys.modules["op_core.dedupe"] = types.SimpleNamespace(
        DeDup=_DummyDeDup, fp=lambda item: "0"
    )

    from op_core.runner import run_hunt

    class RoleStrategy(AuthStrategy):
        def __init__(self, role: str) -> None:
            self.role = role
            self.login_called = 0

        async def login(self, client):  # type: ignore[override]
            self.login_called += 1
            client.role = self.role

        async def ensure_session(self, client):  # type: ignore[override]
            client.role = self.role

    class TrackingClient:
        def __init__(self) -> None:
            self.role = "unassigned"

        async def get(self, *args, **kwargs):  # pragma: no cover - simple stub
            return DummyResponse()

        async def aclose(self) -> None:
            pass

    strategies = {
        "default": RoleStrategy("default"),
        "user": RoleStrategy("user"),
    }
    mgr = AuthManager(strategies, lambda: TrackingClient(), default_role="default")

    monkeypatch.setattr("op_core.runner.generate_candidates", lambda *a, **k: [
        {
            "mode": "xss",
            "protocol": "http",
            "location": "query",
            "param": "id",
            "payload": "1",
            "auth_role": "user",
        }
    ])
    monkeypatch.setattr("op_core.runner.probe_positions", lambda *a, **k: [])
    monkeypatch.setattr("op_core.runner.extract_forms", lambda *a, **k: [])
    monkeypatch.setattr("op_core.runner.choose_form_fields", lambda *a, **k: [])

    recorded_roles: list[str | None] = []

    async def _http_probe(target, cand, oob, client, retries=0):
        recorded_roles.append(getattr(client, "role", None))
        return None

    monkeypatch.setattr(plugins, "_probe_registry", {})
    plugins.register_protocol("http", _http_probe)
    for proto in ["graphql", "ws", "grpc"]:
        plugins.register_protocol(proto, lambda *a, **k: None)

    camp = DummyCamp()

    findings = run_hunt(["http://example.com"], camp, workdir=tmp_path, auth=mgr)
    assert findings == []
    assert recorded_roles, "expected candidate probe to be executed"
    assert set(recorded_roles) == {"user"}
    assert strategies["user"].login_called >= 1


def test_run_hunt_merges_session_artifacts(tmp_path, monkeypatch):
    sys.modules["op_control.campaign"] = types.SimpleNamespace(Campaign=DummyCamp)

    class _DummyDeDup:
        def __init__(self, *args, **kwargs):
            pass

        def seen_before(self, item):
            return False

    sys.modules["op_core.dedupe"] = types.SimpleNamespace(
        DeDup=_DummyDeDup, fp=lambda item: "0"
    )

    from op_core.runner import run_hunt

    class ArtifactStrategy(AuthStrategy):
        def __init__(self, role: str) -> None:
            self.role = role
            self.login_called = 0

        async def login(self, client):  # type: ignore[override]
            self.login_called += 1

        async def ensure_session(self, client):  # type: ignore[override]
            return None

        def export_state(self):  # type: ignore[override]
            return {
                "artifacts": {
                    "headers": {"X-Role": self.role},
                    "cookies": {"session": f"{self.role}-cookie"},
                    "token": f"{self.role}-token",
                }
            }

    strategies = {
        "default": ArtifactStrategy("default"),
        "user": ArtifactStrategy("user"),
    }
    mgr = AuthManager(strategies, lambda: DummyClient(), default_role="default")

    monkeypatch.setattr(
        "op_core.runner.generate_candidates",
        lambda *a, **k: [
            {
                "mode": "xss",
                "protocol": "http",
                "location": "query",
                "param": "id",
                "payload": "1",
                "auth": {"role": "user"},
                "headers": {"X-Override": "candidate"},
            }
        ],
    )
    monkeypatch.setattr("op_core.runner.probe_positions", lambda *a, **k: [])
    monkeypatch.setattr("op_core.runner.extract_forms", lambda *a, **k: [])
    monkeypatch.setattr("op_core.runner.choose_form_fields", lambda *a, **k: [])

    recorded_candidates: list[dict] = []

    async def _http_probe(target, cand, oob, retries=0):
        recorded_candidates.append(dict(cand))
        return None

    monkeypatch.setattr(plugins, "_probe_registry", {})
    plugins.register_protocol("http", _http_probe)
    for proto in ["graphql", "ws", "grpc"]:
        plugins.register_protocol(proto, lambda *a, **k: None)

    camp = DummyCamp()

    findings = run_hunt(["http://example.com"], camp, workdir=tmp_path, auth=mgr)
    assert findings == []
    assert recorded_candidates, "expected probe execution"
    cand = recorded_candidates[0]
    assert cand["headers"]["X-Role"] == "user"
    assert cand["headers"]["X-Override"] == "candidate"
    assert cand["cookies"]["session"] == "user-cookie"
    assert cand["token"] == "user-token"
    assert strategies["user"].login_called >= 1
