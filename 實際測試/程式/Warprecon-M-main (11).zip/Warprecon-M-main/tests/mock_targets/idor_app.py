from __future__ import annotations
from flask import Flask, jsonify, request, abort

"""
Very small mock application to simulate an IDOR prone REST API.
Roles:
  - admin: can read any user/project
  - user<N>: can only read their own user record and owned projects
Auth scheme (simplified):
  - Header X-Auth: token string
  - Tokens mapping defined in TOKENS
Vulnerability toggle:
  - If ENFORCE_AUTH=False the endpoints become IDOR vulnerable (no owner check)
  - Tests can flip this to validate detector behavior.
Resources:
  - /api/v1/users/<id>
  - /api/v1/projects/<id>
"""

def build_app(enforce_auth: bool = True):
    app = Flask(__name__)

    TOKENS = {
        "admin-token": {"role": "admin", "user_id": 0},
        "user1-token": {"role": "user", "user_id": 1},
        "user2-token": {"role": "user", "user_id": 2},
    }

    USERS = {
        0: {"id": 0, "username": "root", "email": "root@example"},
        1: {"id": 1, "username": "alice", "email": "alice@example"},
        2: {"id": 2, "username": "bob", "email": "bob@example"},
    }

    PROJECTS = {
        10: {"id": 10, "name": "alpha", "owner_id": 1, "secret": "ALPHA-SECRET"},
        11: {"id": 11, "name": "beta", "owner_id": 2, "secret": "BETA-SECRET"},
    }
    ORDERS = {
        100: {"id": 100, "item": "laptop", "owner_id": 1, "price": 1999},
        101: {"id": 101, "item": "phone", "owner_id": 2, "price": 999},
    }
    MESSAGES = {
        200: {"id": 200, "sender_id": 1, "recipient_id": 2, "body": "Hi Bob"},
        201: {"id": 201, "sender_id": 2, "recipient_id": 1, "body": "Hey Alice"},
    }

    def get_identity():
        token = request.headers.get("X-Auth")
        return TOKENS.get(token)

    @app.route("/api/v1/users/<int:uid>", methods=["GET"])
    def get_user(uid: int):
        ident = get_identity()
        user = USERS.get(uid)
        if not user:
            abort(404)
        if enforce_auth:
            if not ident:
                return jsonify({"error": "missing auth"}), 401
            if ident["role"] != "admin" and ident["user_id"] != uid:
                return jsonify({"error": "forbidden"}), 403
        return jsonify(user)

    @app.route("/api/v1/projects/<int:pid>", methods=["GET"])
    def get_project(pid: int):
        ident = get_identity()
        prj = PROJECTS.get(pid)
        if not prj:
            abort(404)
        if enforce_auth:
            if not ident:
                return jsonify({"error": "missing auth"}), 401
            if ident["role"] != "admin" and ident["user_id"] != prj["owner_id"]:
                return jsonify({"error": "forbidden"}), 403
        return jsonify(prj)

    @app.route("/api/v1/orders/<int:oid>")
    def get_order(oid: int):
        ident = get_identity()
        order = ORDERS.get(oid)
        if not order:
            abort(404)
        if enforce_auth:
            if not ident:
                return jsonify({"error": "missing auth"}), 401
            if ident["role"] != "admin" and ident["user_id"] != order["owner_id"]:
                return jsonify({"error": "forbidden"}), 403
        return jsonify(order)

    @app.route("/api/v1/messages/<int:mid>")
    def get_message(mid: int):
        ident = get_identity()
        msg = MESSAGES.get(mid)
        if not msg:
            abort(404)
        if enforce_auth:
            if not ident:
                return jsonify({"error": "missing auth"}), 401
            allowed_ids = {msg["sender_id"], msg["recipient_id"]}
            if ident["role"] != "admin" and ident["user_id"] not in allowed_ids:
                return jsonify({"error": "forbidden"}), 403
        return jsonify(msg)

    @app.route("/healthz")
    def healthz():
        return "ok"

    return app

if __name__ == "__main__":  # manual debug
    build_app(enforce_auth=False).run(host="0.0.0.0", port=5009, debug=True)
