from __future__ import annotations

import pytest

from op_core.finding_contract import Finding, as_finding, as_findings


def test_as_finding_from_dict() -> None:
    payload = {
        "check": "demo",
        "target": "https://api.example.com/v1",
        "severity": "medium",
        "title": "Example",
        "detail": "demo detail",
    }

    finding = as_finding(payload)

    assert isinstance(finding, Finding)
    assert finding.check == "demo"
    assert finding.target == "https://api.example.com/v1"
    assert finding.severity == "medium"
    # ensure original payload not mutated by conversion
    assert payload["check"] == "demo"


def test_as_finding_returns_existing_instance() -> None:
    finding = Finding.from_dict({"check": "c", "target": "t"})

    result = as_finding(finding)

    assert result is finding


def test_as_findings_handles_mixed_iterable() -> None:
    existing = Finding.from_dict({"check": "a", "target": "t"})
    items = [existing, {"check": "b", "target": "u", "severity": "high"}]

    converted = as_findings(items)

    assert converted[0] is existing
    assert converted[1].check == "b"
    assert converted[1].severity == "high"


def test_as_finding_rejects_unsupported() -> None:
    with pytest.raises(TypeError):
        as_finding(object())  # type: ignore[arg-type]


def test_as_findings_bubbles_invalid_entries() -> None:
    with pytest.raises(TypeError):
        as_findings([{"check": "ok"}, 123])  # type: ignore[list-item]
