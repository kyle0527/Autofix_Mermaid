from __future__ import annotations

import asyncio
import base64
import json
import sys
import types
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pytest

from op_crawl.dom import render_discover
from op_core import recon_manager
from op_dom.capture import crawl_and_capture


def test_collect_targets_merges_dom_targets(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    async def fake_crawl(domain: str) -> Dict[str, Any]:
        await asyncio.sleep(0)
        return {
            "requests": ["req"],
            "endpoints": ["https://example.com/api"],
            "pages": [
                {
                    "url": f"https://{domain}/",
                    "html": "<html>root</html>",
                    "screenshot": base64.b64encode(b"shot").decode("ascii"),
                    "endpoints": [f"https://{domain}/api"],
                }
            ],
        }

    def fake_recon(domain: str) -> Tuple[List[str], Dict[str, List[str]]]:
        return ["https://example.com"], {"js_endpoints": ["/foo.js"]}

    def fake_capture(url: str, destination: Path):
        return None, None

    monkeypatch.setattr(recon_manager, "crawl_and_capture", fake_crawl)
    monkeypatch.setattr(recon_manager, "_run_recon", fake_recon)
    monkeypatch.setattr(recon_manager, "try_capture", fake_capture)

    async def runner() -> None:
        targets = recon_manager.collect_targets("example.com", tmp_path, True)
        assert targets == ["https://example.com", "https://example.com/api"]

        artifacts_path = tmp_path / "discovery" / "dom-artifacts.json"
        assert artifacts_path.exists()

        artifacts = json.loads(artifacts_path.read_text(encoding="utf-8"))
        assert artifacts and artifacts[0]["url"] == "https://example.com/"
        snapshot_rel = artifacts[0].get("snapshot")
        screenshot_rel = artifacts[0].get("screenshot")
        assert snapshot_rel and screenshot_rel

        snapshot_path = tmp_path / snapshot_rel
        screenshot_path = tmp_path / screenshot_rel
        assert snapshot_path.read_text(encoding="utf-8") == "<html>root</html>"
        assert screenshot_path.read_bytes() == b"shot"

    asyncio.run(runner())


# Regression tests for DOM collection within an active asyncio loop.


@pytest.fixture
def patched_recon(monkeypatch: pytest.MonkeyPatch):
    """Stub out recon to avoid external dependencies during testing."""

    def fake_recon(domain: str) -> Tuple[List[str], Dict[str, List[str]]]:
        return [f"https://{domain}"], {"js_endpoints": [f"https://{domain}/script.js"]}

    monkeypatch.setattr(recon_manager, "_run_recon", fake_recon)


@pytest.fixture
def patched_dom(monkeypatch: pytest.MonkeyPatch):
    """Replace DOM crawler with a deterministic async implementation."""

    async def fake_crawl(domain: str) -> Dict[str, List[str]]:
        await asyncio.sleep(0)
        return {
            "requests": [
                f"https://{domain}/",
                f"https://{domain}/api/dynamic",
            ],
            "endpoints": [
                f"https://{domain}/dom",
                f"https://{domain}/api/dynamic",
            ],
        }

    monkeypatch.setattr(recon_manager, "crawl_and_capture", fake_crawl)


@pytest.fixture
def patched_capture(monkeypatch: pytest.MonkeyPatch):
    """Skip actual artifact capture during testing."""

    def fake_capture(url: str, outdir: Path):
        return None, None

    monkeypatch.setattr(recon_manager, "try_capture", fake_capture)


def test_collect_targets_inside_running_loop(
    tmp_path: Path, patched_recon, patched_dom, patched_capture
) -> None:
    """``collect_targets`` should not raise when invoked within ``asyncio.run``."""

    async def runner() -> List[str]:
        return recon_manager.collect_targets("example.com", tmp_path, True)

    targets = asyncio.run(runner())

    assert targets == [
        "https://example.com",
        "https://example.com/dom",
        "https://example.com/api/dynamic",
    ]

    dom_requests = json.loads(
        (tmp_path / "discovery" / "dom-requests.json").read_text(encoding="utf-8")
    )
    dom_endpoints = json.loads(
        (tmp_path / "discovery" / "dom-endpoints.json").read_text(encoding="utf-8")
    )

    assert dom_requests == [
        "https://example.com/",
        "https://example.com/api/dynamic",
    ]
    assert dom_endpoints == [
        "https://example.com/dom",
        "https://example.com/api/dynamic",
    ]


def test_render_discover_captures_dynamic_requests(monkeypatch: pytest.MonkeyPatch) -> None:
    class DummyRequest:
        def __init__(self, url: str) -> None:
            self.url = url

    class DummyPage:
        def __init__(self) -> None:
            self._url = "https://example.com"
            self._handlers: Dict[str, List] = {}

        def on(self, event: str, handler) -> None:
            self._handlers.setdefault(event, []).append(handler)

        def goto(self, url: str, wait_until: str = "domcontentloaded") -> None:
            self._url = url
            for handler in self._handlers.get("request", []):
                handler(DummyRequest("https://example.com/api/data"))
                handler(DummyRequest("https://example.com/api/data"))
                handler(DummyRequest("wss://example.com/socket"))

        def content(self) -> str:
            return "<html></html>"

        def query_selector_all(self, selector: str):
            return []

        def wait_for_timeout(self, ms: int) -> None:
            return None

        @property
        def url(self) -> str:
            return self._url

    class DummyContext:
        def __init__(self) -> None:
            self._page = DummyPage()

        def new_page(self):
            return self._page

    class DummyBrowser:
        def new_context(self, ignore_https_errors: bool = True):
            return DummyContext()

        def close(self) -> None:
            return None

    class DummyChromium:
        def launch(self, headless: bool = True):
            return DummyBrowser()

    class DummyPlaywright:
        def __init__(self) -> None:
            self.chromium = DummyChromium()

    class SyncManager:
        def __enter__(self):
            return DummyPlaywright()

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    def fake_sync_playwright():
        return SyncManager()

    fake_module = types.ModuleType("playwright")
    sync_module = types.ModuleType("playwright.sync_api")
    sync_module.sync_playwright = fake_sync_playwright
    fake_module.sync_api = sync_module
    monkeypatch.setitem(sys.modules, "playwright", fake_module)
    monkeypatch.setitem(sys.modules, "playwright.sync_api", sync_module)

    endpoints, details = render_discover("https://example.com", max_pages=1)

    assert "https://example.com/api/data" in endpoints
    assert "wss://example.com/socket" in endpoints
    assert endpoints.count("https://example.com/api/data") == 1
    assert details["pages"][0]["endpoints"] == [
        "https://example.com/api/data",
        "wss://example.com/socket",
    ]


def test_crawl_and_capture_collects_snapshots(monkeypatch: pytest.MonkeyPatch) -> None:
    class DummyRequest:
        def __init__(self, url: str) -> None:
            self.url = url
            self.method = "GET"
            self.headers = {}

        @property
        def post_data(self):  # type: ignore[override]
            return None

    class DummyPage:
        def __init__(self) -> None:
            self._url = "https://example.com/"
            self._handlers: Dict[str, List] = {}

        def on(self, event: str, handler) -> None:
            self._handlers.setdefault(event, []).append(handler)

        async def goto(self, url: str, wait_until: str = "domcontentloaded", timeout: int = 0) -> None:
            self._url = url
            for handler in self._handlers.get("request", []):
                handler(DummyRequest("https://example.com/api/data"))

        async def eval_on_selector_all(self, selector: str, script: str):
            return []

        async def content(self) -> str:
            return "<html><script>fetch('/api/info')</script></html>"

        async def screenshot(self, full_page: bool = True):
            return b"shotdata"

        @property
        def url(self) -> str:
            return self._url

    class DummyContext:
        def __init__(self) -> None:
            self._page = DummyPage()

        async def new_page(self):
            return self._page

        async def close(self) -> None:
            return None

    class DummyBrowser:
        async def new_context(self):
            return DummyContext()

        async def close(self) -> None:
            return None

    class DummyChromium:
        async def launch(self, headless: bool = True):
            return DummyBrowser()

    class DummyPlaywright:
        def __init__(self) -> None:
            self.chromium = DummyChromium()

    class DummyManager:
        async def __aenter__(self):
            return DummyPlaywright()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    fake_module = types.ModuleType("playwright")
    async_module = types.ModuleType("playwright.async_api")

    def fake_async_playwright():  # type: ignore[override]
        return DummyManager()

    async_module.async_playwright = fake_async_playwright
    fake_module.async_api = async_module
    monkeypatch.setitem(sys.modules, "playwright", fake_module)
    monkeypatch.setitem(sys.modules, "playwright.async_api", async_module)

    result = asyncio.run(crawl_and_capture("example.com"))

    assert result["requests"] and result["requests"][0]["url"].endswith("/api/data")
    assert result["endpoints"]
    pages = result.get("pages") or []
    assert pages and pages[0]["html"].startswith("<html>")
    assert pages[0]["endpoints"] == ["https://example.com/api/info"]
    assert base64.b64decode(pages[0]["screenshot"]) == b"shotdata"
