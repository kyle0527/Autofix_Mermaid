from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from op_core.precision import PrecisionEngine
from op_core.rank import rank_findings


@pytest.fixture()
def precision_workdir(tmp_path: Path) -> Path:
    return tmp_path


def _make_config(**overrides):
    base = {
        "weights": {
            "severity": {"high": 2.0},
            "penalties": {"misconfig": -0.5},
            "oob_hit": 1.5,
        },
        "baseline": {},
        "ignore": [],
        "gate": {"threshold": 0.4, "top_n": 2, "prefer_confirmed": True},
    }
    base.update(overrides)
    return SimpleNamespace(**base)


def _finding(**kwargs):
    payload = {
        "check": "xss",
        "target": "https://example.com/resource",
        "severity": "high",
        "title": "Example",
        "detail": "",
        "vector": {"protocol": "http"},
        "evidence": {},
    }
    payload.update(kwargs)
    return payload


def test_precision_scoring_applies_weights_and_penalties(precision_workdir: Path) -> None:
    config = _make_config()
    engine = PrecisionEngine(config, workdir=precision_workdir)

    good = _finding(
        severity="high",
        evidence={"dns_log": "hit"},
        fingerprint="good",
    )
    misconfig = _finding(
        check="misconfig",
        severity="medium",
        fingerprint="noisy",
    )

    ranked = rank_findings([misconfig, good], None, engine)
    assert [f.get("fingerprint") for f in ranked] == ["good", "noisy"]
    assert ranked[0].score and ranked[0].score > ranked[1].score
    components = ranked[0].get("_precision", {}).get("components", {})
    assert pytest.approx(components["oob"], rel=1e-3) == engine.oob_weight
    assert ranked[1].get("_precision", {}).get("components", {}).get("penalties") == pytest.approx(
        engine.penalties.get("misconfig")
    )


def test_precision_ignore_rules_remove_matches(precision_workdir: Path) -> None:
    config = _make_config(ignore=[{"path": "logout", "reason": "noise"}])
    engine = PrecisionEngine(config, workdir=precision_workdir)

    noisy = _finding(target="https://example.com/logout")
    valid = _finding(target="https://example.com/profile", fingerprint="keep")

    ranked = rank_findings([noisy, valid], None, engine)
    assert [f.get("fingerprint") for f in ranked] == ["keep"]
    assert engine.ignored
    assert engine.ignored[0].get("_precision", {}).get("ignored", {}).get("reason") == "noise"


def test_precision_baseline_suppresses_entries(precision_workdir: Path) -> None:
    baseline_file = precision_workdir / "baseline.jsonl"
    baseline_file.write_text(
        "\n".join(
            [
                '{"fingerprint": "old", "action": "suppress", "reason": "legacy"}',
            ]
        ),
        encoding="utf-8",
    )
    config = _make_config(baseline={"history_path": str(baseline_file)})
    engine = PrecisionEngine(config, workdir=precision_workdir)

    finding = _finding(fingerprint="old")
    ranked = rank_findings([finding], None, engine)
    assert ranked == []
    assert engine.suppressed
    baseline_meta = engine.suppressed[0].get("_precision", {}).get("baseline", {})
    assert baseline_meta.get("reason") == "legacy"
    assert baseline_meta.get("action") == "suppress"


def test_precision_gate_accepts_labels_and_topn(precision_workdir: Path) -> None:
    config = _make_config(gate={"threshold": 0.6, "top_n": 1, "prefer_confirmed": False})
    engine = PrecisionEngine(config, workdir=precision_workdir)

    items = [
        {"fingerprint": "fp1", "_score": 0.3, "severity": "medium"},
        {"fingerprint": "fp2", "_score": 0.5, "severity": "medium"},
        {"fingerprint": "fp3", "_score": 0.7, "severity": "medium"},
    ]

    kept, dropped = engine.apply_gate(items, accept_fingerprints={"fp2"})
    assert [i["fingerprint"] for i in kept] == ["fp3", "fp2"]
    assert any(i["fingerprint"] == "fp1" for i in dropped)
    reasons = engine.stats.reasons
    assert reasons["label"] >= 1
    assert engine.stats.gate_kept == 2
