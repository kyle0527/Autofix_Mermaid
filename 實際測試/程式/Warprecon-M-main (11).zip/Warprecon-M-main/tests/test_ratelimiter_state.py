import asyncio
import json

import pytest

from op_core import ratelimit


class _FakeClock:
    def __init__(self) -> None:
        self.wall = 1_000.0
        self.mono = 500.0

    def time(self) -> float:
        return self.wall

    def monotonic(self) -> float:
        return self.mono

    def advance(self, delta: float) -> None:
        self.wall += delta
        self.mono += delta


def test_rate_limiter_persists_tokens(tmp_path, monkeypatch):
    clock = _FakeClock()
    monkeypatch.setattr(ratelimit.time, "time", clock.time)
    monkeypatch.setattr(ratelimit.time, "monotonic", clock.monotonic)

    state_file = tmp_path / "limiter_state.json"
    limiter = ratelimit.RateLimiter(3.0, 3.0, state_file=str(state_file))
    host = "example.com"

    async def _consume_once() -> None:
        await limiter.acquire(host)

    asyncio.run(_consume_once())

    assert state_file.exists()

    saved_global_tokens = limiter.global_bucket.tokens
    saved_host_tokens = limiter._bucket_for(host).tokens

    with state_file.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    assert "updated" in data["global"]
    assert host in data["hosts"]
    assert "updated" in data["hosts"][host]

    limiter_same_time = ratelimit.RateLimiter(3.0, 3.0, state_file=str(state_file))
    assert limiter_same_time.global_bucket.tokens == pytest.approx(saved_global_tokens)
    assert limiter_same_time._bucket_for(host).tokens == pytest.approx(saved_host_tokens)

    clock.advance(5.0)
    limiter_after_wait = ratelimit.RateLimiter(3.0, 3.0, state_file=str(state_file))
    global_bucket = limiter_after_wait.global_bucket
    host_bucket = limiter_after_wait._bucket_for(host)
    expected_global = min(
        global_bucket.capacity, saved_global_tokens + 5.0 * global_bucket.rate
    )
    expected_host = min(host_bucket.capacity, saved_host_tokens + 5.0 * host_bucket.rate)

    assert global_bucket.tokens == pytest.approx(expected_global)
    assert host_bucket.tokens == pytest.approx(expected_host)
