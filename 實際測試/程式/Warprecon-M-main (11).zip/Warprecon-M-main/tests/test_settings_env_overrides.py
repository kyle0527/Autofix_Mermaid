from __future__ import annotations

import json

import pytest

from op_control.settings import Settings


@pytest.mark.parametrize(
    "env_key, env_value, expected",
    [
        ("OP_IAST__ENABLED", "true", True),
        ("OP_IAST__TRANSPORT", "http", "http"),
        (
            "OP_LOGIC__WORKFLOWS",
            json.dumps([{"id": "checkout", "enabled": False}]),
            [
                {
                    "id": "checkout",
                    "enabled": False,
                }
            ],
        ),
    ],
)
def test_settings_to_campaign_overrides(monkeypatch, env_key, env_value, expected):
    monkeypatch.setenv(env_key, env_value)
    settings = Settings(_env_file=None)
    overrides = settings.to_campaign_overrides()

    prefix = env_key.split("__", 1)[0].split("OP_", 1)[1].lower()
    assert prefix in overrides

    nested = overrides[prefix]
    key = env_key.split("__", 1)[1].lower()
    if isinstance(nested, dict):
        assert nested[key] == expected
    else:
        assert nested == expected
