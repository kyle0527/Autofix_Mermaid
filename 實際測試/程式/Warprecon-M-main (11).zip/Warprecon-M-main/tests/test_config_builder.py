import yaml

from op_core.config_builder import (
    AccountArtifacts,
    AccountBlueprint,
    CampaignOptions,
    LoginSpec,
    RefreshSpec,
    build_accounts_yaml,
    build_campaign_yaml,
    build_config,
)


def test_build_config_generates_yaml_with_accounts():
    cfg = build_config(
        "https://example.com",
        spa=True,
        budget=45,
        profile="config/profiles/api-only.yaml",
        accounts_profile="default",
        prefer_roles=["admin", "user", "admin"],
    )
    data = yaml.safe_load(cfg)

    assert data["scopes"]["allow"] == ["https://example.com"]
    assert data["limits"]["max_scan_minutes"] == 45
    assert data["limits"]["global_rps"] == 30
    assert data["profile"] == "config/profiles/api-only.yaml"
    assert data["accounts"]["default_profile"] == "default"
    assert data["accounts"]["prefer_roles"] == ["admin", "user"]
    assert data["notes"]["dom_crawl"] is True


def test_build_campaign_yaml_respects_environment(monkeypatch):
    monkeypatch.setenv("OP_LIMITS__GLOBAL_RPS", "80")
    monkeypatch.setenv("OP_OOB__API_KEY", "env-secret")

    yaml_text = build_campaign_yaml(CampaignOptions(target="https://example.com"))
    data = yaml.safe_load(yaml_text)

    assert data["limits"]["global_rps"] == 80
    assert data["oob"]["api_key"] == "env-secret"


def test_build_accounts_yaml_round_trip():
    blueprint = AccountBlueprint(
        name="admin",
        role="admin",
        strategy="jwt",
        artifacts=AccountArtifacts(
            headers={"Authorization": "Bearer dev-token"},
            cookies={"sessionid": "abc"},
            query={"preview": "1"},
            body={"remember": True},
            token="jwt-token",
        ),
        login=LoginSpec(
            url="https://idp.example.com/login",
            method="POST",
            payload={"username": "admin"},
            headers={"Content-Type": "application/json"},
        ),
        refresh=RefreshSpec(
            url="https://idp.example.com/refresh",
            method="POST",
            payload={"refresh": "1"},
            grace_seconds=15,
            retry_backoff_seconds=2.5,
            token_path="data.access_token",
        ),
        tags={"tier": "prod"},
    )

    yaml_text = build_accounts_yaml(
        "default",
        [blueprint],
        description="Administrator profile",
        default_profile="default",
    )
    data = yaml.safe_load(yaml_text)

    assert data["default_profile"] == "default"
    profile = data["profiles"]["default"]
    assert profile["description"] == "Administrator profile"
    assert len(profile["accounts"]) == 1

    account = profile["accounts"][0]
    assert account["name"] == "admin"
    assert account["strategy"] == "jwt"
    assert account["artifacts"]["headers"]["Authorization"].startswith("Bearer")
    assert account["login"]["url"] == "https://idp.example.com/login"
    assert account["refresh"]["token_path"] == "data.access_token"
    assert account["tags"]["tier"] == "prod"

