from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass

import pytest
import websockets

from op_core.telemetry import Telemetry
from op_proto.ws.engine import ws_probe


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


@dataclass
class DummyMint:
    counter: int = 0

    def mint(self, prefix: str | None = None) -> str:
        self.counter += 1
        base = prefix or "m"
        return f"{base}-token-{self.counter}"


@pytest.mark.anyio("asyncio")
async def test_ws_probe_returns_text_evidence(free_tcp_port: int) -> None:
    received: list[object] = []

    async def handler(ws: websockets.WebSocketServerProtocol) -> None:
        try:
            while True:
                message = await ws.recv()
                received.append(message)
                if isinstance(message, str):
                    await ws.send(json.dumps({"echo": message}))
                    break
        except websockets.ConnectionClosedOK:
            pass

    port = free_tcp_port
    uri = f"ws://127.0.0.1:{port}"  # nosec - local test server
    cand = {"mode": "ws", "location": "message", "payload": "[\"ping\"]"}

    async with websockets.serve(handler, "127.0.0.1", port):
        finding = await ws_probe(uri, cand, DummyMint())

    assert finding is not None
    assert finding["target"] == uri
    evidence = finding["evidence"]
    assert evidence["strategy"] in {"candidate", "json-probe"}
    assert evidence["handshake"] in {"vanilla", "heartbeat", "permessage-deflate"}
    assert "snippet" in evidence and evidence["snippet"]
    assert received  # ensure handler observed at least one message


@pytest.mark.anyio("asyncio")
async def test_ws_probe_falls_back_to_binary_strategy(free_tcp_port: int) -> None:
    messages: list[object] = []

    async def handler(ws: websockets.WebSocketServerProtocol) -> None:
        try:
            while True:
                message = await ws.recv()
                messages.append(message)
                if isinstance(message, bytes):
                    await ws.send(b"\x01\x02" + message[:4])
                    break
        except websockets.ConnectionClosedOK:
            pass

    port = free_tcp_port
    uri = f"ws://127.0.0.1:{port}"  # nosec - local test server
    cand = {"mode": "ws", "location": "message", "payload": "noop"}

    async with websockets.serve(handler, "127.0.0.1", port):
        finding = await ws_probe(uri, cand, DummyMint())

    assert finding is not None
    assert finding["evidence"]["strategy"] == "binary-probe"
    assert finding["evidence"]["response_type"] == "binary"
    assert any(isinstance(msg, bytes) for msg in messages)


@pytest.mark.anyio("asyncio")
async def test_ws_probe_handles_graphql_transport(free_tcp_port: int) -> None:
    async def handler(ws: websockets.WebSocketServerProtocol) -> None:
        assert ws.subprotocol == "graphql-transport-ws"
        headers_obj = getattr(ws, "request_headers", None)
        if headers_obj is None:
            request = getattr(ws, "request", None)
            headers_obj = getattr(request, "headers", None)
        assert headers_obj is not None
        assert headers_obj.get("Authorization") == "Bearer header"
        try:
            init_raw = await ws.recv()
            init_msg = json.loads(init_raw)
            assert init_msg.get("type") == "connection_init"
            payload = init_msg.get("payload", {})
            assert payload.get("Authorization") == "Bearer graphql"
            assert payload.get("token")
            await ws.send(json.dumps({"type": "connection_ack"}))
            subscribe_raw = await ws.recv()
            sub_msg = json.loads(subscribe_raw)
            payload = {"data": {"hello": "world"}}
            await ws.send(json.dumps({"id": sub_msg.get("id"), "type": "next", "payload": payload}))
            await ws.send(json.dumps({"id": sub_msg.get("id"), "type": "complete"}))
        except websockets.ConnectionClosedOK:
            pass

    port = free_tcp_port
    uri = f"ws://127.0.0.1:{port}"  # nosec - local test server
    cand = {
        "mode": "ws",
        "location": "message",
        "payload": "subscription { hello }",
        "init_payload": {"Authorization": "Bearer graphql"},
        "headers": {"Authorization": "Bearer header"},
    }

    async with websockets.serve(
        handler,
        "127.0.0.1",
        port,
        subprotocols=["graphql-transport-ws"],
    ):
        finding = await ws_probe(uri, cand, DummyMint())

    assert finding is not None
    evidence = finding["evidence"]
    assert evidence["handshake"] == "graphql-transport-ws"
    assert evidence["strategy"] == "graphql-subscription"
    assert "graphql" in evidence
    assert evidence["graphql"]["message_type"] in {"next", "data", "complete"}


@pytest.mark.anyio("asyncio")
async def test_ws_probe_supports_stomp(free_tcp_port: int) -> None:
    frames: list[str] = []

    async def handler(ws: websockets.WebSocketServerProtocol) -> None:
        try:
            frames.append(ws.subprotocol or "")
            connect_frame = await ws.recv()
            frames.append(str(connect_frame))
            await ws.send("CONNECTED\nversion:1.2\n\n\x00")
            send_frame = await ws.recv()
            frames.append(str(send_frame))
            await ws.send("MESSAGE\ndestination:/topic/warprecon\n\nack\x00")
        except websockets.ConnectionClosedOK:
            pass

    port = free_tcp_port
    uri = f"ws://127.0.0.1:{port}"  # nosec - local test server
    cand = {"mode": "ws", "payload": "probe-body"}

    async with websockets.serve(handler, "127.0.0.1", port, subprotocols=["v12.stomp"]):
        finding = await ws_probe(uri, cand, DummyMint())

    assert finding is not None
    evidence = finding["evidence"]
    assert evidence["handshake"] == "stomp"
    assert evidence["strategy"] == "stomp-send"
    assert evidence.get("subprotocol") == "v12.stomp"
    assert "stomp" in evidence and "reply" in evidence["stomp"]
    assert frames and frames[0] == "v12.stomp"


@pytest.mark.anyio("asyncio")
async def test_ws_probe_supports_socketio(free_tcp_port: int) -> None:
    observed: list[str] = []

    async def handler(ws: websockets.WebSocketServerProtocol) -> None:
        try:
            await ws.send('0{"sid":"abc","pingInterval":2500,"pingTimeout":5000}')
            msg = await ws.recv()
            observed.append(str(msg))
            payload_msg = await ws.recv()
            observed.append(str(payload_msg))
            await ws.send('43["probe",{"ok":true}]')
            await ws.send("2")
            try:
                pong = await asyncio.wait_for(ws.recv(), timeout=3.0)
                observed.append(str(pong))
            except asyncio.TimeoutError:
                pass
        except websockets.ConnectionClosedOK:
            pass

    port = free_tcp_port
    uri = f"ws://127.0.0.1:{port}"  # nosec - local test server
    cand = {"mode": "ws", "payload": {"hello": "world"}, "socketio_event": "probe"}

    async with websockets.serve(handler, "127.0.0.1", port):
        finding = await ws_probe(uri, cand, DummyMint())

    assert finding is not None
    evidence = finding["evidence"]
    assert evidence["handshake"] == "socketio"
    assert evidence["strategy"] == "socketio-event"
    assert evidence.get("socketio", {}).get("handshake", {}).get("sid") == "abc"
    assert observed and observed[0] == "40"


@pytest.mark.anyio("asyncio")
async def test_ws_probe_records_telemetry_roundtrips(tmp_path, free_tcp_port: int) -> None:
    session_id = Telemetry.start(tmp_path, domain="tests", metadata={})
    cand = {"mode": "ws", "payload": "hello"}

    async def success_handler(ws: websockets.WebSocketServerProtocol) -> None:
        try:
            await ws.recv()
            await ws.send("ok")
        except websockets.ConnectionClosedOK:
            pass

    async def closing_handler(ws: websockets.WebSocketServerProtocol) -> None:
        await ws.close()

    port = free_tcp_port
    uri = f"ws://127.0.0.1:{port}"  # nosec - local test server
    try:
        async with websockets.serve(success_handler, "127.0.0.1", port):
            finding = await ws_probe(uri, cand, DummyMint())
        assert finding is not None
        handshake = finding["evidence"].get("handshake")
        strategy = finding["evidence"].get("strategy")

        async with websockets.serve(closing_handler, "127.0.0.1", port):
            penalty = await ws_probe(uri, cand, DummyMint())
        assert penalty is not None and "_penalize" in penalty

        snapshot = Telemetry.snapshot(session_id)
        ws_bucket = (snapshot.get("websocket") or {}).get("roundtrip")
        assert ws_bucket is not None
        assert ws_bucket["count"] >= 2
        assert ws_bucket["failures"] >= 1
        handshakes = ws_bucket.get("handshakes") or {}
        assert handshake in handshakes
        handshake_bucket = handshakes[handshake]
        assert handshake_bucket["count"] >= 2
        handshake_reasons = handshake_bucket.get("reasons") or {}
        if handshake_reasons:
            assert sum(handshake_reasons.values()) >= 1
        strategies = handshake_bucket.get("strategies") or {}
        if strategy:
            assert strategy in strategies
            assert strategies[strategy]["count"] >= 1
    finally:
        Telemetry.finish(status="success")
