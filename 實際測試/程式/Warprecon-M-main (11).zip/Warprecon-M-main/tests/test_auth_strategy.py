import json
from pathlib import Path

from op_auth import AuthStrategy, NoAuthStrategy, load_strategy


class DummyStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.logged_in = False

    def login(self, client) -> None:
        self.logged_in = True

    def ensure_session(self, client) -> None:
        if not self.logged_in:
            self.login(client)


def test_dummy_strategy_login() -> None:
    dummy = DummyStrategy()
    dummy.ensure_session(None)
    assert dummy.logged_in is True


def test_load_strategy_default() -> None:
    strat = load_strategy("unknown")
    assert isinstance(strat, NoAuthStrategy)


def test_cookie_strategy_loads_cookies(tmp_path: Path) -> None:
    session_dir = tmp_path / "session"
    session_dir.mkdir()
    (session_dir / "cookies.json").write_text(
        json.dumps([{"name": "sid", "value": "abc", "domain": "example.com"}])
    )

    class Client:
        def __init__(self) -> None:
            self.cookies = {}

    client = Client()
    strat = load_strategy("cookie", workdir=tmp_path)
    strat.ensure_session(client)
    assert client.cookies.get("sid") == "abc"


def test_jwt_strategy_sets_header() -> None:
    class Client:
        def __init__(self) -> None:
            self.headers = {}

    client = Client()
    strat = load_strategy("jwt", token="abc123")
    strat.ensure_session(client)
    assert client.headers.get("Authorization") == "Bearer abc123"


def test_oauth_strategy_fetches_token(monkeypatch) -> None:
    class Client:
        def __init__(self) -> None:
            self.headers = {}

    def fake_urlopen(url, data=None):
        class Resp:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def read(self):
                return json.dumps({"access_token": "tok"}).encode()

        return Resp()

    monkeypatch.setattr("op_auth.oauth.request.urlopen", fake_urlopen)

    client = Client()
    strat = load_strategy(
        "oauth",
        token_url="https://idp/token",
        client_id="id",
        client_secret="secret",
    )
    strat.ensure_session(client)
    assert client.headers.get("Authorization") == "Bearer tok"
