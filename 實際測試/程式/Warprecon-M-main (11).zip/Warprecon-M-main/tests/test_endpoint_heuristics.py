from op_core.endpoint_heuristics import (
    extract_request_matches,
    extract_text_matches,
    is_likely_endpoint,
)


def test_is_likely_endpoint_defaults():
    assert is_likely_endpoint("https://example.com/api/v1/users")
    assert is_likely_endpoint("https://example.com/graphql")
    assert not is_likely_endpoint("https://example.com/static/app.js")


def test_extract_request_matches_cover_common_patterns():
    snippet = """
    fetch("/api/users")
    axios.post("/graphql")
    new WebSocket("wss://example.com/socket")
    const absolute = "https://example.com/api/v1/info";
    """
    matches = extract_request_matches(snippet)
    assert "/api/users" in matches
    assert "/graphql" in matches
    assert "wss://example.com/socket" in matches
    assert "https://example.com/api/v1/info" in matches


def test_extract_text_matches_returns_expected_paths():
    text = """
    <div data-endpoint="/api/login"></div>
    GraphQL endpoint at /graphql
    wss://example.com/ws
    """
    matches = extract_text_matches(text)
    assert "/api/login" in matches
    assert "/graphql" in matches
    assert "wss://example.com/ws" in matches
