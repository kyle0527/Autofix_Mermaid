from pathlib import Path

import yaml
from typer.testing import CliRunner

from op_core.cli import app


runner = CliRunner()


def test_configure_campaign_command(tmp_path):
    output = tmp_path / "campaign.yaml"
    result = runner.invoke(
        app,
        [
            "configure",
            "campaign",
            "--target",
            "https://example.com",
            "--budget",
            "50",
            "--no-spa",
            "--accounts-profile",
            "default",
            "--prefer-role",
            "admin",
            "--prefer-role",
            "user",
            "--output",
            str(output),
            "--global-rps",
            "25",
            "--per-host-rps",
            "5",
            "--max-concurrency",
            "4",
            "--http-timeout",
            "12.5",
        ],
        catch_exceptions=False,
    )
    assert result.exit_code == 0
    data = yaml.safe_load(output.read_text())
    assert data["scopes"]["allow"] == ["https://example.com"]
    assert data["limits"]["global_rps"] == 25
    assert data["accounts"]["default_profile"] == "default"


def test_configure_accounts_command(tmp_path):
    output = tmp_path / "accounts.yaml"
    answers = "\n".join(
        [
            "demo",  # profile name
            "Baseline accounts",  # description
            "admin",  # account name
            "admin",  # role
            "jwt",  # strategy
            "Authorization=Bearer seed",  # static headers entry
            "",  # finish static headers
            "",  # static cookies entry
            "",  # default query entry
            "",  # default body entry
            "seed-token",  # static token
            "y",  # configure login?
            "https://auth.local/login",  # login URL
            "",  # login method default
            "username=admin",  # login payload entry
            "",  # finish login payload
            "",  # login headers entry
            "",  # accept default success codes
            "",  # configure refresh? default no
            "",  # tags entry
            "",  # add another account? default no
        ]
    ) + "\n"

    result = runner.invoke(
        app,
        ["configure", "accounts", "--output", str(output)],
        input=answers,
        catch_exceptions=False,
    )
    assert result.exit_code == 0
    data = yaml.safe_load(output.read_text())
    assert data["default_profile"] == "demo"
    profile = data["profiles"]["demo"]
    account = profile["accounts"][0]
    assert account["strategy"] == "jwt"
    assert account["login"]["url"] == "https://auth.local/login"
    assert account["artifacts"]["headers"]["Authorization"] == "Bearer seed"

