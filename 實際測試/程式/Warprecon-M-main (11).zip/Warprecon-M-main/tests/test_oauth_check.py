from __future__ import annotations

import httpx

from op_checks.oauth import EVIL_HOST, OAuthOpenRedirectCheck

def test_oauth_open_redirect_detects_vulnerability():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        return httpx.Response(
            status_code=302,
            headers={"Location": f"{EVIL_HOST}/callback"},
            request=request,
        )

    transport = httpx.MockTransport(handler)

    check = OAuthOpenRedirectCheck()
    apis = [
        {
            "url": "https://idp.example/oauth/authorize?client_id=abc&redirect_uri=https://client.example/cb",
        }
    ]

    findings = list(check.run(apis=apis, transport=transport, timeout=0.1))
    assert len(findings) == 1
    finding = findings[0]
    assert finding["severity"] == "high"
    assert finding["meta"]["parameter"] == "redirect_uri"
    assert finding["meta"]["location"] == "query"
    assert finding["meta"]["redirect_location"].startswith(EVIL_HOST)
    requested_url = str(captured["request"].url)
    assert f"redirect_uri={EVIL_HOST.replace('://', '%3A%2F%2F')}" in requested_url


def test_oauth_open_redirect_handles_form_submission():
    def handler(request: httpx.Request) -> httpx.Response:
        body = request.content.decode()
        assert f"redirect_uri={EVIL_HOST.replace('://', '%3A%2F%2F')}" in body
        return httpx.Response(
            status_code=303,
            headers={"Location": f"{EVIL_HOST}/form"},
            request=request,
        )

    transport = httpx.MockTransport(handler)

    check = OAuthOpenRedirectCheck()
    apis = [
        {
            "url": "https://idp.example/oauth/token",
            "method": "POST",
            "data": {
                "client_id": "abc",
                "redirect_uri": "https://client.example/callback",
            },
        }
    ]

    findings = list(check.run(apis=apis, transport=transport, timeout=0.1))
    assert len(findings) == 1
    finding = findings[0]
    assert finding["meta"]["location"] == "form"


def test_oauth_open_redirect_ignores_safe_redirects():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=302,
            headers={"Location": "https://client.example/callback"},
            request=request,
        )

    transport = httpx.MockTransport(handler)
    check = OAuthOpenRedirectCheck()
    apis = ["https://idp.example/oauth/authorize?redirect_uri=https://client.example/cb"]

    findings = list(check.run(apis=apis, transport=transport, timeout=0.1))
    assert findings == []


def test_oauth_open_redirect_tolerates_network_errors():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom", request=request)

    transport = httpx.MockTransport(handler)
    check = OAuthOpenRedirectCheck()
    apis = ["https://idp.example/oauth/authorize?redirect_uri=https://client.example/cb"]

    findings = list(check.run(apis=apis, transport=transport, timeout=0.1))
    assert findings == []
