import json
from pathlib import Path

from op_iast.config import IastConfig
from op_iast.session import create_session
from op_iast.types import IastFinding


def _sample_payload(**overrides):
    payload = {
        "check": "iast.sql_injection",
        "target": "POST /login",
        "severity": "high",
        "title": "Unsanitised SQL call",
        "detail": "IAST agent observed an unsanitised query string.",
        "fingerprint": "abc123",
        "evidence": {"sink": "db.query", "parameter": "username"},
        "location": {"file": "app/views/auth.py", "line": 42},
        "source": "embedded-agent",
        "ts": 1680000000.0,
    }
    payload.update(overrides)
    return payload


def test_iast_finding_to_finding_meta_roundtrip():
    payload = _sample_payload()
    finding = IastFinding.from_dict(payload).to_finding()
    assert finding.check == payload["check"]
    assert finding.severity == payload["severity"]
    assert finding.target == payload["target"]
    assert finding.meta["iast"]["fingerprint"] == payload["fingerprint"]
    assert finding.meta["iast"]["evidence"]["sink"] == "db.query"


def test_embedded_session_reads_jsonl(tmp_path: Path):
    buffer_path = tmp_path / "iast" / "findings.jsonl"
    buffer_path.parent.mkdir(parents=True, exist_ok=True)
    payloads = [_sample_payload(fingerprint=f"fp-{idx}") for idx in range(2)]
    buffer_path.write_text(
        "\n".join(json.dumps(item) for item in payloads) + "\n",
        encoding="utf-8",
    )

    config = IastConfig(enabled=True, transport="embedded")
    session = create_session(config, tmp_path)
    with session:
        findings = session.collect()

    assert len(findings) == 2
    assert all(isinstance(item, IastFinding) for item in findings)
    assert {item.fingerprint for item in findings} == {"fp-0", "fp-1"}
