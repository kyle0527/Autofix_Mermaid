from __future__ import annotations

import json
from pathlib import Path

from op_dist import agent
from op_dist.queue import FSQueue


def test_agent_continues_after_pipeline_failure(tmp_path: Path, monkeypatch) -> None:
    cfg_path = tmp_path / "campaign.yml"
    cfg_path.write_text("{}", encoding="utf-8")

    queue_root = tmp_path / "queue"
    queue = FSQueue(queue_root)
    failing_id = queue.enqueue("fail.example", str(cfg_path))
    success_id = queue.enqueue("ok.example", str(cfg_path))

    call_count = {"value": 0}

    def fake_run_pipeline(domain: str, campaign_path: Path, workdir: Path, **kwargs):
        call_count["value"] += 1
        if call_count["value"] == 1:
            raise RuntimeError("boom")
        workdir.mkdir(parents=True, exist_ok=True)
        return {"domain": domain}

    monkeypatch.setattr(agent, "run_pipeline", fake_run_pipeline)

    agent.run_agent(tmp_path, cfg_path, max_loops=3, sleep_sec=0.0)

    done_dir = queue_root / "done"
    records = {
        failing_id: json.loads((done_dir / f"{failing_id}.json").read_text(encoding="utf-8")),
        success_id: json.loads((done_dir / f"{success_id}.json").read_text(encoding="utf-8")),
    }

    assert call_count["value"] == 2
    assert {meta["domain"] for meta in records.values()} == {"fail.example", "ok.example"}

    failures = [meta for meta in records.values() if not meta.get("ok")]
    assert len(failures) == 1
    assert failures[0]["error"]["type"] == "RuntimeError"
    assert "traceback" in failures[0]["error"]

    successes = [meta for meta in records.values() if meta.get("ok")]
    assert len(successes) == 1
    assert queue.status() == {"pending": 0, "processing": 0, "done": 2}


def test_agent_records_invalid_job(tmp_path: Path, monkeypatch) -> None:
    cfg_path = tmp_path / "campaign.yml"
    cfg_path.write_text("{}", encoding="utf-8")

    queue_root = tmp_path / "queue"
    FSQueue(queue_root)
    bad_id = "malformed"
    (queue_root / "pending" / f"{bad_id}.json").write_text(
        json.dumps({"cfg": str(cfg_path)}, ensure_ascii=False),
        encoding="utf-8",
    )

    monkeypatch.setattr(agent, "run_pipeline", lambda *args, **kwargs: {})

    agent.run_agent(tmp_path, cfg_path, max_loops=1, sleep_sec=0.0)

    done_dir = queue_root / "done"
    meta = json.loads((done_dir / f"{bad_id}.json").read_text(encoding="utf-8"))

    assert meta["ok"] is False
    assert meta["error"]["type"] == "QueueTaskError"
    assert queue_root.joinpath("processing", f"{bad_id}.json").exists() is False
