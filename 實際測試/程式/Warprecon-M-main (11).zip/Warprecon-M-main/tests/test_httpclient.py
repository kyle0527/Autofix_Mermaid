from __future__ import annotations

import asyncio
import logging
from json import JSONDecodeError
from pathlib import Path

import httpx
import pytest

from op_core.httpclient import make_async_client


def test_make_async_client_missing_cookie_file(tmp_path: Path) -> None:
    async def _run() -> None:
        async with make_async_client(tmp_path) as client:
            assert dict(client.cookies) == {}

    asyncio.run(_run())


def test_make_async_client_invalid_cookie_file(tmp_path: Path, caplog: pytest.LogCaptureFixture) -> None:
    session_dir = tmp_path / "session"
    session_dir.mkdir()
    (session_dir / "cookies.json").write_text("{not json", encoding="utf-8")

    async def _run() -> None:
        async with make_async_client(tmp_path) as client:
            assert dict(client.cookies) == {}

    with caplog.at_level(logging.WARNING):
        asyncio.run(_run())

    assert any(
        "Continuing without cookies after load failure" in record.getMessage()
        for record in caplog.records
    )


@pytest.mark.asyncio
async def test_make_async_client_env_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OP_HTTP_TIMEOUT", "3.5")
    monkeypatch.setenv("OP_HTTP_PROXY", "http://127.0.0.1:8080")
    monkeypatch.setenv("OP_HTTP_RETRIES", "2")

    client = make_async_client(tmp_path)
    assert isinstance(client, httpx.AsyncClient)
    try:
        assert pytest.approx(client.timeout.read, rel=1e-3) == 3.5
        transport = client._transport
        assert isinstance(transport, httpx.AsyncHTTPTransport)
        pool = transport._pool
        assert pool._retries == 2
        assert hasattr(pool, "_proxy_url")
        assert pool._proxy_url.host == b"127.0.0.1"
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_make_async_client_retries_success(tmp_path: Path) -> None:
    attempts = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise httpx.ConnectError("boom", request=request)
        return httpx.Response(200, text="ok")

    client = make_async_client(
        tmp_path,
        retries=2,
        backoff=lambda **_: 0.0,
        transport=httpx.MockTransport(handler),
    )

    try:
        response = await client.get("https://example.com/")
        assert response.status_code == 200
        assert response.text == "ok"
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_make_async_client_config_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    for key in ("OP_HTTP_TIMEOUT", "OP_HTTP_PROXY", "OP_HTTP_RETRIES"):
        monkeypatch.delenv(key, raising=False)

    config_dir = tmp_path / "config"
    config_dir.mkdir()
    (config_dir / "httpclient.yaml").write_text(
        "timeout: 4.2\nproxy: http://localhost:9090\nretries: 3\n",
        encoding="utf-8",
    )

    client = make_async_client(tmp_path)
    try:
        assert pytest.approx(client.timeout.read, rel=1e-3) == 4.2
        transport = client._transport
        assert isinstance(transport, httpx.AsyncHTTPTransport)
        pool = transport._pool
        assert pool._retries == 3
        assert hasattr(pool, "_proxy_url")
        assert pool._proxy_url.host == b"localhost"
        assert pool._proxy_url.port == 9090
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_make_async_client_timeout_retry_exhausted(tmp_path: Path) -> None:
    attempts = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        raise httpx.ReadTimeout("timeout", request=request)

    client = make_async_client(
        tmp_path,
        timeout=httpx.Timeout(0.01),
        retries=1,
        backoff=lambda **_: 0.0,
        transport=httpx.MockTransport(handler),
    )

    try:
        with pytest.raises(httpx.ReadTimeout):
            await client.get("https://example.com/")
        assert attempts == 2
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_make_async_client_explicit_overrides(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OP_HTTP_TIMEOUT", "9.0")
    monkeypatch.setenv("OP_HTTP_PROXY", "http://127.0.0.1:9000")
    monkeypatch.setenv("OP_HTTP_RETRIES", "5")

    client = make_async_client(
        tmp_path,
        timeout=1.5,
        proxy="http://127.0.0.1:8081",
        retries=0,
    )
    try:
        assert pytest.approx(client.timeout.read, rel=1e-3) == 1.5
        transport = client._transport
        assert isinstance(transport, httpx.AsyncHTTPTransport)
        pool = transport._pool
        assert pool._retries == 0
        assert hasattr(pool, "_proxy_url")
        assert pool._proxy_url.port == 8081
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_make_async_client_cookie_failure(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    from op_core import httpclient

    def _broken_loader(workdir: Path) -> None:  # pragma: no cover - patched in test
        raise JSONDecodeError("bad", "{}", 0)

    monkeypatch.setattr(httpclient, "load_cookies", _broken_loader)

    with caplog.at_level("WARNING"):
        client = httpclient.make_async_client(tmp_path)

    try:
        assert "Continuing without cookies" in caplog.text
        assert len(client.cookies) == 0
    finally:
        await client.aclose()
