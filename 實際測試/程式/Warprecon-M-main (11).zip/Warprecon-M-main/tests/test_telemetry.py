from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor

from op_core.telemetry import Telemetry


def _run_session(workdir, label: str):
    Telemetry.start(workdir, domain=f"{label}.example", metadata={"label": label})
    Telemetry.event("test.event", {"label": label})
    Telemetry.observe_findings([
        {"_confirmed": True, "evidence": {"sequence_hit": True}},
    ])
    Telemetry.finish(status="success", extra={"label": label})

    events_path = workdir / "events.log"
    metrics_path = workdir / "metrics.json"

    events = [
        json.loads(line)
        for line in events_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    return events, metrics


def test_telemetry_sessions_are_isolated(tmp_path):
    labels = ("alpha", "beta")

    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = [
            executor.submit(_run_session, tmp_path / label, label)
            for label in labels
        ]
        results = {label: future.result() for label, future in zip(labels, futures)}

    for label, (events, metrics) in results.items():
        assert metrics["domain"] == f"{label}.example"
        assert metrics["status"] == "success"
        assert metrics["hits"] == 1
        assert metrics["confirmed_hits"] == 1

        event_types = {event["type"] for event in events}
        assert event_types == {"pipeline.start", "test.event", "pipeline.finish"}
        assert any(event["type"] == "test.event" and event.get("label") == label for event in events)
        assert all(event.get("label") in (None, label) for event in events)

    assert Telemetry.current_session_id() is None
