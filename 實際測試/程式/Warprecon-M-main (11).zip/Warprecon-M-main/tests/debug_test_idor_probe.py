from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest
import socket
import threading
import time
from contextlib import closing

from tests.mock_idor_app import create_mock_app
from op_checks.idor import IdorDetector, Role


def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.mark.asyncio
async def test_debug_probe():
    port = _free_port()
    app = create_mock_app()
    th = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False), daemon=True)
    th.start()
    # wait for server
    for _ in range(60):
        try:
            import httpx

            httpx.get(f"http://127.0.0.1:{port}/", timeout=0.2)
            break
        except Exception:
            time.sleep(0.05)

    base = f"http://127.0.0.1:{port}"
    url = f"{base}/api/v1/secret-docs/201"

    detector = IdorDetector()

    # Use roles that map owner to user id 2 and ensure owner_role selection
    roles = [Role.from_dict({"name": "user", "headers": {"X-User-ID": "2"}}), Role.from_dict({"name": "admin", "headers": {"X-User-ID": "1"}}), Role.from_dict({"name": "anon", "headers": {}})]

    # directly call detect_idor_single_url to see raw responses; owner_user_id=2 ensures owner role is chosen
    results = await detector.detect_idor_single_url(url, method="GET", roles=roles, owner_user_id=2, expand_variants=False)

    print("DEBUG RESULTS:")
    import json

    print(json.dumps(results, indent=2, ensure_ascii=False))

    # Sanity: we expect at least the debug none entry or findings list
    assert isinstance(results, list)
