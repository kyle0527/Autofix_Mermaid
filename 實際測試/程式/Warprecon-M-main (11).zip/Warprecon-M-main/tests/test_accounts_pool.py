from __future__ import annotations

import yaml
import pytest

from op_auth import (
    AccountPool,
    load_account_pool,
    load_account_sources,
    resolve_role,
)


def _write_accounts(path, data) -> None:
    path.write_text(yaml.safe_dump(data), encoding="utf-8")


def test_load_account_pool(tmp_path) -> None:
    cfg = {
        "default_profile": "default",
        "profiles": {
            "default": {
                "description": "demo",
                "accounts": [
                    {
                        "name": "admin",
                        "role": "admin",
                        "strategy": "jwt",
                        "artifacts": {
                            "headers": {"Authorization": "Bearer dev-admin"}
                        },
                    },
                    {
                        "name": "user",
                        "role": "user",
                        "strategy": "cookie",
                        "artifacts": {"cookies": {"sessionid": "abc"}},
                    },
                ],
            }
        },
    }
    path = tmp_path / "accounts.yaml"
    _write_accounts(path, cfg)

    pool = load_account_pool(path)

    assert isinstance(pool, AccountPool)
    assert pool.default_profile == "default"
    profile = pool.profile()
    assert profile.name == "default"
    assert {a.role for a in profile.accounts} == {"admin", "user"}

    admin = resolve_role(pool, "admin")
    assert admin.profile == "default"
    assert admin.account.strategy == "jwt"
    assert admin.account.artifacts.headers["Authorization"] == "Bearer dev-admin"


def test_account_sources_merge_override(tmp_path) -> None:
    first = tmp_path / "first.yaml"
    second = tmp_path / "second.yaml"
    _write_accounts(
        first,
        {
            "default_profile": "legacy",
            "profiles": {
                "legacy": {
                    "accounts": [
                        {"name": "anon", "role": "anonymous", "strategy": "none"}
                    ]
                }
            },
        },
    )
    _write_accounts(
        second,
        {
            "default_profile": "modern",
            "profiles": {
                "modern": {
                    "accounts": [
                        {
                            "name": "operator",
                            "role": "admin",
                            "strategy": "jwt",
                        }
                    ]
                }
            },
        },
    )

    pool = load_account_sources([first, second])
    assert pool.default_profile == "modern"
    assert set(pool.profiles) == {"legacy", "modern"}
    modern = pool.profile("modern")
    assert modern.role_map()["admin"].name == "operator"


def test_duplicate_role_rejected(tmp_path) -> None:
    path = tmp_path / "bad.yaml"
    _write_accounts(
        path,
        {
            "profiles": {
                "dup": {
                    "accounts": [
                        {"name": "first", "role": "user"},
                        {"name": "second", "role": "user"},
                    ]
                }
            }
        },
    )

    with pytest.raises(ValueError):
        load_account_pool(path)


def test_environment_placeholder_expansion(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("ADMIN_TOKEN", "super-secret")
    path = tmp_path / "accounts.yaml"
    _write_accounts(
        path,
        {
            "default_profile": "default",
            "profiles": {
                "default": {
                    "accounts": [
                        {
                            "name": "admin",
                            "role": "admin",
                            "strategy": "jwt",
                            "artifacts": {
                                "headers": {
                                    "Authorization": "Bearer ${ADMIN_TOKEN}",
                                }
                            },
                        }
                    ]
                }
            },
        },
    )

    pool = load_account_pool(path)
    admin = resolve_role(pool, "admin")

    assert admin.account.artifacts.headers["Authorization"] == "Bearer super-secret"


def test_environment_placeholder_default(monkeypatch, tmp_path) -> None:
    monkeypatch.delenv("MISSING_TOKEN", raising=False)
    path = tmp_path / "accounts.yaml"
    _write_accounts(
        path,
        {
            "default_profile": "default",
            "profiles": {
                "default": {
                    "accounts": [
                        {
                            "name": "user",
                            "role": "user",
                            "strategy": "cookie",
                            "login": {
                                "payload": {
                                    "password": "${MISSING_TOKEN:fallback}"  # noqa: S105
                                }
                            },
                        }
                    ]
                }
            },
        },
    )

    pool = load_account_pool(path)
    user = resolve_role(pool, "user")

    assert user.account.login.payload["password"] == "fallback"


def test_environment_placeholder_missing(monkeypatch, tmp_path) -> None:
    monkeypatch.delenv("REQUIRED_TOKEN", raising=False)
    path = tmp_path / "accounts.yaml"
    _write_accounts(
        path,
        {
            "profiles": {
                "default": {
                    "accounts": [
                        {
                            "name": "admin",
                            "role": "admin",
                            "strategy": "jwt",
                            "artifacts": {
                                "headers": {
                                    "Authorization": "Bearer ${REQUIRED_TOKEN}",
                                }
                            },
                        }
                    ]
                }
            },
        },
    )

    with pytest.raises(ValueError, match="REQUIRED_TOKEN"):
        load_account_pool(path)
