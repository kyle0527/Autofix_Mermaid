from __future__ import annotations

import asyncio
from typing import Any, Dict

import pytest

from op_proto.graphql import engine as gql_engine


class DummyResponse:
    status_code = 200
    text = '{"data": {"__typename": "Demo"}}'
    headers = {"content-type": "application/json"}

    def json(self) -> Dict[str, Any]:
        return {"data": {"__typename": "Demo"}}


class DummyClient:
    def __init__(self) -> None:
        self.calls: list[Dict[str, Any]] = []

    async def post(self, url: str, **kwargs: Any) -> DummyResponse:
        self.calls.append({"url": url, "kwargs": kwargs})
        return DummyResponse()


def test_graphql_probe_uses_provided_client() -> None:
    client = DummyClient()
    cand = {"payload": "query { __typename }", "timeout": 3.5}

    result = asyncio.run(
        gql_engine.graphql_probe(
            "https://api.example.com/graphql",
            cand,
            None,
            client=client,
        )
    )

    assert client.calls, "expected the shared client to be used"
    first = client.calls[0]
    assert first["url"] == "https://api.example.com/graphql"
    assert first["kwargs"]["json"]["query"].strip()  # ensure payload forwarded
    assert result is not None
    assert result.get("payload")
    assert first["kwargs"].get("timeout") == pytest.approx(3.5)
