from __future__ import annotations

from op_core.telemetry import Telemetry


def test_auth_and_ws_metrics(tmp_path) -> None:
    session_id = Telemetry.start(tmp_path)

    Telemetry.record_auth_switch(
        role="admin",
        action="login",
        elapsed_ms=55.5,
        outcome="success",
        error=None,
    )
    Telemetry.record_auth_switch(
        role="admin",
        action="ensure",
        elapsed_ms=12.0,
        outcome="error",
        error={"message": "expired"},
    )

    Telemetry.record_auth_refresh(
        role="admin",
        elapsed_ms=110.0,
        outcome="success",
        attempts=2,
        error=None,
    )
    Telemetry.record_auth_refresh(
        role="user",
        elapsed_ms=95.0,
        outcome="error",
        attempts=1,
        error={"message": "denied"},
    )

    Telemetry.record_auth_incident(
        role="admin",
        status_code=401,
        reason="http_response",
        url="https://example.test/api",
    )

    Telemetry.record_ws_roundtrip(
        endpoint="wss://example.test/ws",
        elapsed_ms=48.0,
        success=True,
        handshake="vanilla",
        strategy="candidate",
    )
    Telemetry.record_ws_roundtrip(
        endpoint="wss://example.test/ws",
        elapsed_ms=62.0,
        success=False,
        reason="timeout",
        handshake="vanilla",
    )

    snapshot = Telemetry.snapshot(session_id)

    assert snapshot["auth"]["switch"]["count"] == 2
    assert snapshot["auth"]["switch"]["roles"]["admin"]["failures"] == 1
    assert snapshot["auth"]["refresh"]["count"] == 2
    assert snapshot["auth"]["refresh"]["failures"] == 1
    assert snapshot["auth"]["refresh"]["roles"]["admin"]["attempts"] == 2
    assert snapshot["auth"]["incidents"]["count"] == 1
    assert snapshot["auth"]["incidents"]["statuses"]["401"] == 1
    assert snapshot["auth"]["incidents"]["roles"]["admin"]["count"] == 1
    assert snapshot["websocket"]["roundtrip"]["count"] == 2
    assert snapshot["websocket"]["roundtrip"]["failures"] == 1
    assert snapshot["websocket"]["roundtrip"]["reasons"]["timeout"] == 1
    handshake_bucket = snapshot["websocket"]["roundtrip"]["handshakes"]["vanilla"]
    assert handshake_bucket["count"] == 2
    assert handshake_bucket["reasons"]["timeout"] == 1
    assert handshake_bucket["strategies"]["candidate"]["count"] == 1

    Telemetry.finish()
