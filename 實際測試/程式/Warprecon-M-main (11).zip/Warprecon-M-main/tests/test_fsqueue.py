from pathlib import Path
import time

from op_dist.queue import FSQueue


def test_requeue_stale_task(tmp_path: Path):
    q = FSQueue(tmp_path, timeout=0.1)
    tid = q.enqueue("example.com", "cfg")

    first = q.dequeue()
    assert first is not None
    assert first[0] == tid
    assert (q.processing / f"{tid}.json").exists()

    time.sleep(0.2)

    second = q.dequeue()
    assert second is not None
    assert second[0] == tid
    assert (q.processing / f"{tid}.json").exists()

    q.complete(tid, {"ok": True})
    assert q.status()["done"] == 1
