from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from op_core.dedupe import DeDup, fp
from op_core.finding_contract import Finding
from op_core.history import HistoryDB
from op_core.rank import rank_findings


def test_rank_sidechannels(tmp_path: Path) -> None:
    noisy = {
        "severity": "medium",
        "vector": {"protocol": "http"},
        "evidence": {"len_delta": 60, "time_delta": 0.3},
    }
    bland = {"severity": "medium", "vector": {"protocol": "http"}, "evidence": {}}

    ranked = rank_findings([bland, noisy])
    assert isinstance(ranked[0], Finding)
    assert ranked[0].get("evidence") == noisy["evidence"]

    item = {
        "target": "https://x",
        "mode": "xss",
        "vector": {"location": "query", "param": "q", "protocol": "http"},
        "payload": "abc",
    }
    dedupe = DeDup(tmp_path / "fingerprints.sqlite3", ttl_days=1)
    assert dedupe.seen_before(item) is False
    assert dedupe.seen_before(item) is True

    hist = HistoryDB(tmp_path / "history.sqlite3", ttl_days=1)
    key = fp(item)
    assert hist.seen(key) is False
    hist.remember(key, {"ok": True})
    assert hist.seen(key) is True


def test_history_records_target_status(tmp_path: Path) -> None:
    hist = HistoryDB(tmp_path / "history.jsonl", ttl_days=1)
    assert hist.target_status("https://example.com") is None

    hist.remember_target("https://example.com", "failed", {"reason": "timeout"})
    record = hist.target_record("https://example.com")
    assert record is not None
    assert record["status"] == "failed"
    assert record.get("m", {}).get("target") == "https://example.com"
    assert hist.target_status("https://example.com") == "failed"

    hist.remember_target("https://example.com", "success")
    assert hist.target_status("https://example.com") == "success"


def test_fp_changes_with_protocol_and_mode() -> None:
    base = {"target": "https://x", "vector": {"location": "query", "param": "q"}, "payload": "abc"}
    a = {**base, "mode": "xss", "vector": {**base["vector"], "protocol": "http"}}
    b = {**base, "mode": "sqli", "vector": {**base["vector"], "protocol": "http"}}
    c = {**base, "mode": "xss", "vector": {**base["vector"], "protocol": "ws"}}

    assert fp(a) != fp(b)
    assert fp(a) != fp(c)


def test_fp_includes_protocol_and_mode() -> None:
    base = {
        "target": "x",
        "vector": {"location": "q", "param": "p", "protocol": "http"},
        "payload": "abc",
        "mode": "xss",
    }
    proto_diff = {
        "target": "x",
        "vector": {"location": "q", "param": "p", "protocol": "ws"},
        "payload": "abc",
        "mode": "xss",
    }
    mode_diff = {
        "target": "x",
        "vector": {"location": "q", "param": "p", "protocol": "http"},
        "payload": "abc",
        "mode": "sqli",
    }
    no_mode = {
        "target": "x",
        "vector": {"location": "q", "param": "p", "protocol": "http"},
        "payload": "abc",
    }

    assert fp(base) != fp(proto_diff)
    assert fp(base) != fp(mode_diff)
    assert fp(no_mode) != fp(base)


def test_dedupe_ttl_expiration(tmp_path: Path) -> None:
    short_ttl_days = 1 / 86400  # one second
    store = DeDup(tmp_path / "dedupe.sqlite3", ttl_days=short_ttl_days)
    item = {
        "target": "https://example.com",
        "vector": {"location": "query", "param": "q", "protocol": "http"},
        "payload": "payload",
    }

    assert store.seen_before(item) is False
    assert store.seen_before(item) is True

    store._conn.execute("UPDATE fingerprints SET expires = ?", (time.time() - 5,))
    assert store.seen_before(item) is False


def test_history_ttl_expiration(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    short_ttl_days = 1 / 86400  # one second
    hist = HistoryDB(tmp_path / "history.sqlite3", ttl_days=short_ttl_days, flush_interval=2)
    key = "abc123"

    real_time = time.time
    base_time = real_time()
    current_time = base_time

    def _fake_time() -> float:
        return current_time

    def _set_time(new_value: float) -> None:
        nonlocal current_time
        current_time = new_value

    monkeypatch.setattr("op_core.history.time.time", _fake_time)
    _set_time(base_time)
    hist.remember(key, {"ok": True})
    assert hist.seen(key) is True
    hist._cache[key] = time.time() - hist.ttl_seconds - 5

    _set_time(base_time + hist.ttl_seconds + 5)
    assert hist.seen(key) is False

    monkeypatch.setattr("op_core.history.time.time", real_time)


def test_history_handles_many_rows(tmp_path: Path) -> None:
    hist = HistoryDB(tmp_path / "history.sqlite3", ttl_days=2, flush_interval=10000)

    start = time.perf_counter()
    for idx in range(5000):
        hist.remember(f"key-{idx}", {"value": idx})
    remember_duration = time.perf_counter() - start

    start = time.perf_counter()
    for idx in range(5000):
        assert hist.seen(f"key-{idx}") is True
    seen_duration = time.perf_counter() - start

    assert remember_duration < 2.5
    assert seen_duration < 1.5
    assert hist.seen("missing") is False

    hist.ttl_seconds = 1
    for idx in range(100):
        hist._cache[f"expired-{idx}"] = time.time() - 5

    start = time.perf_counter()
    for idx in range(100):
        assert hist.seen(f"expired-{idx}") is False
    ttl_cleanup = time.perf_counter() - start

    assert ttl_cleanup < 0.5


def test_history_periodic_flush_prunes_file(tmp_path: Path) -> None:
    hist_path = tmp_path / "history.sqlite3"
    hist = HistoryDB(hist_path, ttl_days=1 / 86400, flush_interval=2)

    hist.remember("expired", {"ok": True})
    hist._cache["expired"] = time.time() - hist.ttl_seconds - 5
    hist.remember("fresh-1", {"ok": True})

    with hist_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)

    assert "expired" not in data
    assert "fresh-1" in data

    hist.remember("fresh-2", {"ok": True})
    hist.close()

    with hist_path.open("r", encoding="utf-8") as handle:
        persisted = json.load(handle)

    assert "fresh-2" in persisted


def test_history_duplicate_detection_refreshes_timestamp(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ttl_days = 1 / 86400  # one second
    hist = HistoryDB(tmp_path / "history.sqlite3", ttl_days=ttl_days)
    key = "dup"

    real_time = time.time
    base_time = real_time()
    current_time = base_time

    def _fake_time() -> float:
        return current_time

    def _set_time(new_value: float) -> None:
        nonlocal current_time
        current_time = new_value

    monkeypatch.setattr("op_core.history.time.time", _fake_time)
    _set_time(base_time)
    hist.remember(key, {"count": 1})
    assert hist.seen(key) is True

    refresh_time = base_time + hist.ttl_seconds / 2
    _set_time(refresh_time)
    assert hist.seen(key) is True
    hist.remember(key, {"count": 2})

    near_expiry = base_time + hist.ttl_seconds + 0.2
    _set_time(near_expiry)
    assert hist.seen(key) is True

    expired = base_time + (hist.ttl_seconds * 2)
    _set_time(expired)
    assert hist.seen(key) is False

    monkeypatch.setattr("op_core.history.time.time", real_time)

