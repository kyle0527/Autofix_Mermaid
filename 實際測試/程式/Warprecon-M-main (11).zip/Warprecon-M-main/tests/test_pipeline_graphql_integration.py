from __future__ import annotations

import json
from pathlib import Path

import pytest

from op_core import pipeline
from op_core import runner as core_runner
from op_core import plugins


@pytest.mark.parametrize("domain", ["example.com"])
def test_pipeline_handles_http_and_graphql(domain: str, tmp_path, monkeypatch):
    targets = ["https://app.local/search", "https://api.local/graphql"]

    monkeypatch.setattr(pipeline, "_run_recon", lambda d: (targets, {}))
    async def _fake_introspect(url: str):
        return {}

    monkeypatch.setattr(pipeline, "try_introspect", _fake_introspect)
    monkeypatch.setattr(pipeline, "run_sqlmap", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "run_xsstrike", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "run_nuclei", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "export_html", lambda w, r: str(w / "out.html"))
    monkeypatch.setattr(pipeline, "write_poc_files", lambda *a, **k: None)

    class DummyInteract:
        def mint(self, prefix: str | None = None) -> str:
            return f"{prefix or 't'}token.oob"

        def poll(self) -> list[dict]:
            return []

        def export_events(self) -> dict:
            return {}

        def correlate_findings(self, findings):
            return findings

    monkeypatch.setattr(pipeline, "InteractClient", lambda *a, **k: DummyInteract())

    class DummyResponse:
        def __init__(self, url: str, content_type: str):
            self.url = url
            self.headers = {"content-type": content_type}
            self.text = ""

    class DummyAsyncClient:
        async def get(self, url: str, timeout: float = 8.0):
            ctype = "application/json" if "graphql" in url else "text/html"
            return DummyResponse(url, ctype)

        async def post(self, url: str, data=None, json=None, timeout: float = 12.0):
            return DummyResponse(url, "application/json")

        async def aclose(self):
            return None

    monkeypatch.setattr(pipeline, "make_async_client", lambda *a, **k: DummyAsyncClient())
    monkeypatch.setattr(core_runner, "make_async_client", lambda *a, **k: DummyAsyncClient())

    async def _fake_probe_positions(url: str):
        return []

    monkeypatch.setattr(core_runner, "probe_positions", _fake_probe_positions)

    async def _http_probe(target, cand, mint, client=None, retries: int = 0):
        if cand.get("mode") != "xss":
            return None
        return {
            "target": target,
            "vector": {"protocol": "http", "location": cand.get("location"), "param": cand.get("param")},
            "payload": cand.get("payload", ""),
            "tool": "test-http",
            "severity": "high",
            "url": target,
        }

    async def _graphql_probe(target, cand, mint, client=None, retries: int = 0):
        if "graphql" not in target or cand.get("mode") != "gql":
            return None
        return {
            "target": target,
            "vector": {"protocol": "graphql", "location": cand.get("location"), "param": cand.get("param")},
            "payload": cand.get("payload", ""),
            "tool": "test-graphql",
            "severity": "medium",
            "url": target,
        }

    monkeypatch.setattr(plugins, "_probe_registry", {})
    plugins.register_protocol("http", _http_probe)
    plugins.register_protocol("graphql", _graphql_probe)

    result = pipeline.run_pipeline(domain, Path("config/campaign.yaml"), tmp_path, dom_crawl=False)

    ranked_path = Path(result["json"])
    graphql_path = Path(result["graphql"])

    ranked = json.loads(ranked_path.read_text(encoding="utf-8"))
    assert {item["vector"]["protocol"] for item in ranked} == {"http", "graphql"}

    gql_ranked = json.loads(graphql_path.read_text(encoding="utf-8"))
    assert gql_ranked and all(item["vector"]["protocol"] == "graphql" for item in gql_ranked)

    proto_map = json.loads((tmp_path / "discovery" / "protocols.json").read_text(encoding="utf-8"))
    assert "https://api.local/graphql" in proto_map
    assert "graphql" in [p.lower() for p in proto_map["https://api.local/graphql"]]
