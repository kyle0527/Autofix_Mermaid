from pathlib import Path

import pytest

from op_chain.assembler import build_graph, suggest_paths
from op_dist.queue import FSQueue

# Skip UI tests if the server module or its dependencies are missing
create_app = pytest.importorskip("op_ui.server").create_app


def test_chain_paths() -> None:
    items = [
        {
            "url": "https://a",
            "vector": {"protocol": "http"},
            "payload": "<script>alert(1)</script>",
            "severity": "medium",
            "_score": 50,
        },
        {
            "url": "https://a",
            "vector": {"protocol": "http"},
            "payload": "') UNION SELECT NULL --",
            "severity": "high",
            "_score": 80,
        },
        {
            "url": "https://b",
            "vector": {"protocol": "http"},
            "payload": "http://169.254.169.254/",
            "severity": "high",
            "_score": 85,
            "evidence": {"oob_token": "t"},
        },
    ]
    graph = build_graph(items)
    paths = suggest_paths(graph, top_k=3)
    assert paths
    assert isinstance(paths[0][0], list)


def test_queue_ops(tmp_path: Path) -> None:
    queue = FSQueue(tmp_path)
    task_id = queue.enqueue("example.com", "cfg")
    assert task_id is not None

    status_before = queue.status()
    assert status_before["pending"] == 1

    dequeued = queue.dequeue()
    assert dequeued is not None

    queue.complete(dequeued[0], {"ok": True})
    status_after = queue.status()
    assert status_after["done"] == 1


def test_ui_health(tmp_path: Path) -> None:
    app = create_app(tmp_path, Path("config/campaign.yaml"))
    client = app.test_client()
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json.get("ok") is True


def test_ui_allows_anonymous_without_tokens(tmp_path: Path) -> None:
    workdir = tmp_path
    (workdir / "ranked.final.json").write_text("[]", encoding="utf-8")
    app = create_app(workdir, Path("config/campaign.yaml"))
    client = app.test_client()

    response = client.get("/api/findings")
    assert response.status_code == 200


def test_ui_auth_guard(tmp_path: Path) -> None:
    workdir = tmp_path
    (workdir / "ranked.json").write_text("[]", encoding="utf-8")
    app = create_app(workdir, Path("config/campaign.yaml"), auth_tokens=("s3cr3t",))
    client = app.test_client()

    unauthorized = client.get("/api/findings")
    assert unauthorized.status_code == 401

    authorized = client.get(
        "/api/findings", headers={"Authorization": "Bearer s3cr3t"}
    )
    assert authorized.status_code == 200
