from __future__ import annotations

import pytest

confirm = pytest.importorskip("op_core.confirm")
_variants = confirm._variants
from op_core import rank as rank_mod
from op_core.finding_contract import Finding
from op_core.rank import rank_findings


def test_variants_contains_new():
    v = dict(_variants("Xx'"))
    assert "case_flip" in v
    assert "space_pad" in v


def test_rank_adds_rank_and_sorts(monkeypatch):
    items = [

        Finding.from_dict({"severity": "low", "vector": {"protocol": "http"}, "evidence": {}}),
        Finding.from_dict({"severity": "high", "vector": {"protocol": "http"}, "evidence": {}}),

    ]

    calls = {"n": 0}
    orig_strength = rank_mod.strength

    def wrapped(f):
        calls["n"] += 1
        return orig_strength(f)

    monkeypatch.setattr(rank_mod, "strength", wrapped)

    ranked = rank_findings(items)
    assert ranked[0]["mode"] == "sqli"
    assert all(
        "_rank" in f and "_score" in f and "cvss" in f and "cwe" in f for f in ranked
    )
    assert ranked[0]["cvss"]["base_score"] >= ranked[1]["cvss"]["base_score"]
    assert ranked[0]["cwe"] == "CWE-89"
    assert calls["n"] == len(items)
