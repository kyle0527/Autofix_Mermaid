
from __future__ import annotations

from typing import Any, Dict

import importlib.util
import sys
from pathlib import Path


import pytest

from op_core import proto_detect

class _DummyResponse:
    def __init__(self, http_version: str, headers: Dict[str, str]) -> None:
        self.http_version = http_version
        self.headers = headers


class _DummyClient:
    def __init__(self, response: _DummyResponse) -> None:
        self._response = response

    def __enter__(self) -> "_DummyClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def get(self, url: str) -> _DummyResponse:
        return self._response


def _patch_httpx_client(monkeypatch: pytest.MonkeyPatch, response: _DummyResponse) -> None:
    def _factory(*args: Any, **kwargs: Any) -> _DummyClient:
        return _DummyClient(response)

    monkeypatch.setattr(proto_detect.httpx, "Client", _factory)


def test_detect_http_versions_http3_success(monkeypatch: pytest.MonkeyPatch) -> None:
    response = _DummyResponse(
        http_version="HTTP/2",
        headers={"alt-svc": 'h3=":443"; ma=2592000'},
    )
    _patch_httpx_client(monkeypatch, response)

    called: Dict[str, Any] = {}

    def _fake_probe(url: str, *, timeout: float, alt_svc: str | None) -> bool:
        called["args"] = (url, timeout, alt_svc)
        return True

    monkeypatch.setattr(proto_detect, "_probe_http3", _fake_probe)

    result = proto_detect.detect_http_versions("https://example.com", timeout=2.5)

    assert result["http2"] is True
    assert result["http3_hint"] is True
    assert result["http3"] is True
    assert called["args"][0] == "https://example.com"
    assert "h3" in (called["args"][2] or "").lower()


def test_detect_http_versions_http3_probe_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    response = _DummyResponse(
        http_version="HTTP/1.1",
        headers={"alt-svc": 'h3="alt.example:8443"; ma=86400'},
    )
    _patch_httpx_client(monkeypatch, response)
    monkeypatch.setattr(proto_detect, "_probe_http3", lambda *args, **kwargs: False)

    result = proto_detect.detect_http_versions("https://example.com")

    assert result["http2"] is False
    assert result["http3_hint"] is True
    assert result["http3"] is False


def test_probe_http3_missing_dependency(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(proto_detect, "_AIOQUIC_AVAILABLE", False)

    assert proto_detect._probe_http3("https://example.com") is False

class DummyResponse:
    def __init__(self, url: str, alt_svc: str | None = None, http_version: str | None = None):
        self.url = url
        self.headers = {"alt-svc": alt_svc} if alt_svc is not None else {}
        self.http_version = http_version


class DummyClient:
    def __init__(self, response: DummyResponse):
        self._response = response

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def get(self, url: str) -> DummyResponse:
        return self._response


@pytest.mark.parametrize("probe_result,http3_expected", [(True, True), (False, False)])
def test_detect_http_versions_http3_probe(monkeypatch, probe_result, http3_expected):
    response = DummyResponse(
        url="https://final.example/path",
        alt_svc='h3=":443"',
        http_version="HTTP/2",
    )

    client = DummyClient(response)

    monkeypatch.setattr(proto_detect.httpx, "Client", lambda *a, **k: client)

    called = {}

    def fake_probe(url: str, timeout: float = 5.0) -> bool:
        called["url"] = url
        called["timeout"] = timeout
        return probe_result

    monkeypatch.setattr(proto_detect, "_probe_http3", fake_probe)

    hints = proto_detect.detect_http_versions("https://origin.example")
    assert hints["http2"] is True
    assert hints["http3_hint"] is True
    assert hints["http3"] is http3_expected
    assert called["url"] == "https://final.example/path"
    assert called["timeout"] == 5.0


def test_detect_http_versions_without_http3_hint(monkeypatch):
    response = DummyResponse(url="https://example.com/", alt_svc=None, http_version=None)
    client = DummyClient(response)
    monkeypatch.setattr(proto_detect.httpx, "Client", lambda *a, **k: client)

    called = {"count": 0}

    def fake_probe(url: str, timeout: float = 5.0) -> bool:
        called["count"] += 1
        return True

    monkeypatch.setattr(proto_detect, "_probe_http3", fake_probe)

    hints = proto_detect.detect_http_versions("https://origin.example")
    assert hints == {"http2": False, "http3_hint": False, "http3": False}
    assert called["count"] == 0


def test_probe_http3_missing_dependency(monkeypatch):
    import builtins

    module_name = "proto_detect_no_aioquic"
    module_path = Path(__file__).resolve().parents[1] / "src" / "op_core" / "proto_detect.py"

    for key in list(sys.modules):
        if key.startswith("aioquic"):
            monkeypatch.delitem(sys.modules, key, raising=False)

    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name.startswith("aioquic"):
            raise ModuleNotFoundError(name)
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    assert spec and spec.loader

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop(module_name, None)

    assert module.quic_connect is None
    assert module._H3ProbeClient is None
    assert module._probe_http3("https://example.com") is False

