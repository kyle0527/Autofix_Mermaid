from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from op_plugins.builtin import path_dedupe, network_priority


def test_path_dedupe_post_rank():
    ranked = [
        {"url": "http://example.com?a=1&b=2", "_score": 1},
        {"url": "http://example.com?b=2&a=1", "_score": 2},
        {"target": "http://example.net/resource", "_score": 1, "vector": {"protocol": "ftp"}},
        {"target": "http://example.net/resource", "_score": 5, "vector": {"protocol": "http"}},
    ]
    out = path_dedupe.post_rank(ranked)
    assert len(out) == 3
    assert out[0]["_score"] == 2 and out[0]["_rank"] == 1
    assert out[1]["vector"]["protocol"] == "ftp" and out[1]["_rank"] == 2
    assert out[2]["vector"]["protocol"] == "http" and out[2]["_rank"] == 3


def test_network_priority_post_rank(tmp_path, monkeypatch):
    caps = [
        {"url": "http://host1/", "http2": True, "http3_hint": True},
        {"url": "http://host3/", "http2": True},
    ]
    workdir = tmp_path / "work" / "upgrade"
    workdir.mkdir(parents=True)
    (workdir / "http-capabilities.json").write_text(json.dumps(caps), encoding="utf-8")
    ranked = [
        {"url": "http://host1/", "_score": 1.0},
        {"url": "http://host2/", "_score": 2.0},
        {"url": "http://host3/", "_score": 0.0},
    ]
    monkeypatch.chdir(tmp_path)
    out = network_priority.post_rank(ranked)
    assert [f["_score"] for f in out] == [6.0, 2.0, 2.0]
    assert [f["_rank"] for f in out] == [1, 2, 3]
    assert [f.get("url") for f in out] == ["http://host1/", "http://host2/", "http://host3/"]
