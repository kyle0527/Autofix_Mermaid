from __future__ import annotations

import pytest

from op_core.rank import rank_findings


def _finding(mode: str) -> dict:
    return {
        "mode": mode,
        "severity": "medium",
        "vector": {"protocol": "http"},
        "evidence": {},
    }


def test_cvss_scores_for_common_modes():
    ranked = rank_findings([
        _finding("xss"),
        _finding("sqli"),
        _finding("ssrf"),
    ])

    by_mode = {f["mode"]: f for f in ranked}

    assert ranked[0]["mode"] == "sqli"
    assert by_mode["xss"]["cwe"] == "CWE-79"
    assert by_mode["sqli"]["cwe"] == "CWE-89"
    assert by_mode["ssrf"]["cwe"] == "CWE-918"

    assert by_mode["xss"]["cvss"]["base_score"] == pytest.approx(5.4, abs=1e-6)
    assert by_mode["sqli"]["cvss"]["base_score"] == pytest.approx(9.4, abs=1e-6)
    assert by_mode["ssrf"]["cvss"]["base_score"] == pytest.approx(8.3, abs=1e-6)

    assert by_mode["xss"]["cvss"]["vector"] == "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/A:N"
    assert by_mode["sqli"]["cvss"]["severity"] == "Critical"
    assert by_mode["xss"]["cvss"]["severity"] == "Medium"
