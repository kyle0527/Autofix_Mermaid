from __future__ import annotations

from op_proto.openapi.sequence_v2 import _extract_identifier_values, _pairs


def _sample_spec() -> dict:
    return {
        "paths": {
            "/orders": {
                "post": {
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {"orderId": {"type": "string"}},
                                }
                            }
                        }
                    },
                    "responses": {"201": {"description": "created"}},
                }
            },
            "/orders/{orderId}": {
                "get": {"responses": {"200": {"description": "ok"}}}
            },
        }
    }


def test_pairs_include_non_generic_identifier_names() -> None:
    spec = _sample_spec()
    pairs = _pairs(spec)
    assert pairs, "expected at least one POST→GET pair"
    post, get, body, params = pairs[0]
    assert post["path"].endswith("/orders")
    assert get["path"].endswith("{orderId}")
    assert params == ["orderId"]
    assert body.get("orderId")


def test_extract_identifier_values_matches_variants() -> None:
    data = {
        "result": {"orderId": 42, "user": {"user_id": "abc-123"}},
        "metadata": {"resourceUUID": "xyz"},
    }
    values = _extract_identifier_values(data, ["orderId", "userId", "resourceUuid"])
    assert values["orderId"] == 42
    assert values["userId"] == "abc-123"
    assert values["resourceUuid"] == "xyz"
