from __future__ import annotations

"""Full-flow test of IdorCheck including variant expansion and CLI.

Spins mock app, writes targets file (pointing at a known insecure
resource), expands variants, and validates number / type of findings.
"""

import json, threading, time, socket, subprocess, sys
from contextlib import closing
from pathlib import Path

import pytest

from tests.mock_idor_app import create_mock_app
from op_checks.idor import IdorCheck


def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def live_base(tmp_path_factory):
    port = _free_port()
    app = create_mock_app()
    th = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False), daemon=True)
    th.start()
    for _ in range(60):
        import httpx
        try:
            httpx.get(f"http://127.0.0.1:{port}/", timeout=0.2)
            break
        except Exception:
            time.sleep(0.05)
    return f"http://127.0.0.1:{port}"


def test_full_flow_variants_and_cli(tmp_path, live_base):
    # choose base id 2 (exists) so +/-1 => 1 and 3 also exist for notes
    base = f"{live_base}/api/v1/notes/2"
    targets_file = tmp_path / "targets.txt"
    targets_file.write_text(base + "\n", encoding="utf-8")

    # Direct API usage with variants
    check = IdorCheck(expand_variants=True)
    apis = [{"url": base, "owner_user_id": 2}]
    findings = list(check.run(apis))
    # Expect at least one finding for each existing note id variant (1,2,3) except those lacking semantics for partial (notes are full access)
    urls_flagged = {f.meta.get("url") for f in findings}
    assert any("/notes/2" in u for u in urls_flagged)
    # Because notes/1 and notes/3 are also insecure, variant expansion should hit them
    assert any("/notes/1" in u for u in urls_flagged)
    assert any("/notes/3" in u for u in urls_flagged)

    # CLI invocation
    out_json = tmp_path / "out.json"
    # launch via python -m style if available; else direct path
    cli_path = Path(__file__).resolve().parents[1] / "src" / "op_checks" / "idor_cli.py"
    cmd = [sys.executable, str(cli_path), "--targets", str(targets_file), "--out", str(out_json), "--expand-variants"]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=25)
    assert proc.returncode == 0, proc.stderr
    parsed_stdout = json.loads(proc.stdout.strip())
    assert parsed_stdout["findings"] >= 3
    data = json.loads(out_json.read_text(encoding="utf-8"))
    assert isinstance(data, list) and data, "output json empty"
    # Ensure meta present
    assert all("meta" in f for f in data)
