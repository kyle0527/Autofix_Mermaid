from __future__ import annotations
def test_pipeline_imports():
    # Import should succeed; we don't execute the pipeline here
    import op_core.pipeline  # noqa
