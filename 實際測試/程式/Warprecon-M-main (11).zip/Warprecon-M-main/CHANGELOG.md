# CHANGELOG

記錄使用者關心的破壞性變更、介面調整與輸出差異。

## [Unreleased]
### Added
- WebSocket 探測引擎支援多種握手矩陣（子協定、心跳、壓縮）與 JSON／二進位 payload 策略，並能自動執行 GraphQL Subscriptions（`graphql-transport-ws`、`graphql-ws`）。
- Telemetry `websocket.roundtrip` 指標新增握手（含 STOMP、Socket.IO）與 payload 策略維度，輸出成功率、延遲與錯誤原因供 CLI／報表使用。
- UI API 新增 Token 驗證，啟動前需設定 `WARPRECON_UI_TOKEN`，並透過 `Authorization: Bearer <token>` 存取。
- `warprecon-m ui` 指令支援 `--auth-token` 參數，方便在部署腳本中直接指定多組 Token，文件同步更新。
- DOM 探勘／gRPC reflection 的依賴改透過 `pip install -e .[dom,grpc]` 提供官方 extra，文件同步更新。
- 外部掃描器（nuclei / sqlmap / xsstrike）缺失時會回報 `external_tool.missing` 遙測事件，並在 `executor.complete` 指標中列出缺失工具。
- 新增跨平台 `FileLock` 實作，FSQueue 支援 Windows 並保留自動重排卡住的工作。
- Makefile 新增 `test` 目標，一次執行併發／外部掃描／UI 等關鍵回歸測試，減少零碎指令。
- `accounts.yaml` 支援 `${ENV_VAR:default}` 環境變數占位符，便於在帳號池中引入密碼與 Token 而不需提交純文字。
- 新增 `op_iast` 模組與 pipeline 整合，支援從 `workdir/iast/findings.jsonl` 收集 IAST 代理證據並寫入 `findings.json` 參與排名與 Gate。
- 商業邏輯狀態機（`op_chain.workflow`）與 pipeline `logic` 階段正式啟用，可透過 YAML DSL 宣告多步驟流程、擷取上下文並輸出 `workdir/logic/findings.json` 與合併後的 Findings。
- 將歷史掃描輸出移入 `resources/workspace-templates/`，新增操作手冊指引並透過測試防止新的 `tmp-*` 目錄被提交。

### Next
- 依據握手／策略遙測的表現排序自動重試優先順序，評估是否需補強特定協定的進階 payload。 

## [0.1.0] - 2025-09-12
### Added
- 重整文件為 4+2 結構並加入 CI 文檔 gate
