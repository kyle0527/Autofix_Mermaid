import os, json, argparse
from src.op_bandit.contextual import LinUCB

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--enable", action="store_true")
    args = ap.parse_args()

    if args.enable:
        os.environ["BANDIT_ENABLE_UCB_SORT"] = "1"

    bandit = LinUCB(arms=["A","B","C"], state_file=None, alpha=0.8, dim=2)
    ordered = bandit.order({"x":[[1,0],[0,1],[0.5,0.5]]})
    print(ordered)

if __name__ == "__main__":
    main()
