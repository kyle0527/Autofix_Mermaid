from __future__ import annotations

import json
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Sequence


USAGE = "python tools/bench_run.py scenarios.json"


def run_cmd(command: str) -> tuple[int, float]:
    """Execute ``command`` and return the exit code and elapsed seconds."""

    start = time.perf_counter()
    result = subprocess.run(shlex.split(command), check=False, timeout=60)
    return result.returncode, time.perf_counter() - start


def precision_at_k(items: Sequence[dict[str, Any]], k: int) -> float:
    if not items or k <= 0:
        return 0.0

    hits = 0
    for finding in items[:k]:
        evidence = finding.get("evidence") or {}
        if finding.get("_confirmed") or evidence.get("variant_hits") or evidence.get("sequence_hit"):
            hits += 1
    return hits / float(k)


def load_ranked(workdir: Path) -> list[dict[str, Any]]:
    ranked_path = workdir / "ranked.json"
    if not ranked_path.exists():
        return []
    return json.loads(ranked_path.read_text(encoding="utf-8"))


def bench_scenarios(config_path: Path) -> dict[str, Any]:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    results: list[dict[str, Any]] = []

    for scenario in config.get("scenarios", []):
        command = scenario.get("cmd")
        if not command:
            continue

        name = scenario.get("name", "scenario")
        workdir = Path(scenario.get("workdir", f"work/bench_{name.replace(' ', '_')}"))
        workdir.mkdir(parents=True, exist_ok=True)

        exit_code, duration = run_cmd(command)
        ranked = load_ranked(workdir)
        poc_dir = workdir / "poc"

        results.append(
            {
                "name": name,
                "cmd": command,
                "returncode": exit_code,
                "duration_sec": duration,
                "p10": round(precision_at_k(ranked, 10), 3) if ranked else 0.0,
                "p20": round(precision_at_k(ranked, 20), 3) if ranked else 0.0,
                "poc_files": len(list(poc_dir.glob("poc_*.*"))) if poc_dir.exists() else 0,
            }
        )

    return {"results": results}


def write_html(destination: Path, data: dict[str, Any]) -> None:
    rows: Iterable[str] = (
        "<tr>"
        f"<td>{entry['name']}</td>"
        f"<td><code>{entry['cmd']}</code></td>"
        f"<td>{entry['duration_sec']:.2f}</td>"
        f"<td>{entry['p10']:.3f}</td>"
        f"<td>{entry['p20']:.3f}</td>"
        f"<td>{entry['poc_files']}</td>"
        "</tr>"
        for entry in data.get("results", [])
    )

    rows_html = "".join(rows)
    html = (
        "<!doctype html><meta charset=\"utf-8\"><title>Bench Report</title>"
        "<style>body{"  # noqa: RUF001 - literal braces required for CSS
        "font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px}"  # noqa: RUF001
        "table{border-collapse:collapse;width:100%}"
        "td,th{border:1px solid #ddd;padding:6px}th{background:#f6f6f6}</style>"
        "<h1>Bench Report</h1><table><thead><tr><th>Name</th><th>Command</th><th>Duration(s)</th>"
        "<th>P@10</th><th>P@20</th><th>PoC</th></tr></thead><tbody>"
        + rows_html
        + "</tbody></table>"
    )

    destination.write_text(html, encoding="utf-8")


def main(argv: Sequence[str] | None = None) -> int:
    argv = tuple(argv or sys.argv[1:])
    if not argv:
        print(USAGE)
        return 2

    config_path = Path(argv[0])
    data = bench_scenarios(config_path)

    output_dir = config_path.parent
    (output_dir / "bench_results.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_html(output_dir / "bench_report.html", data)
    print("Wrote:", output_dir / "bench_report.html")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
