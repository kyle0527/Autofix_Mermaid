from __future__ import annotations
from pathlib import Path
import json, sys

def _load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def precision_at_k(items, k=10):
    top = items[:k]
    good = 0
    for f in top:
        ev = f.get("evidence",{}) or {}
        if f.get("_confirmed") or ev.get("variant_hits") or ev.get("sequence_hit") or ev.get("oob_events"):
            good += 1
    return good/float(max(1,k))

def count_poc(workdir: Path):
    p = workdir/"poc"
    return len(list(p.glob("poc_*.*"))) if p.exists() else 0

def main():
    if len(sys.argv) < 2:
        print("Usage: python tools/bench.py <workdir>"); return 1
    wd = Path(sys.argv[1])
    ranked = _load(wd/"ranked.json")
    p10 = precision_at_k(ranked, k=10)
    p20 = precision_at_k(ranked, k=20)
    pocn = count_poc(wd)
    print("P@10:", round(p10,3))
    print("P@20:", round(p20,3))
    print("PoC files:", pocn)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
