# Warprecon-M

An extensible multi-protocol vulnerability scanner built for rapid CI scans and research scenarios.
Its modular pipeline and plugin system let you deploy and produce reports in under 10 minutes.
Supports HTTP/gRPC/OpenAPI protocols and quantifies results with a Scorecard.

## Quick Start
1. Bootstrap the virtual environment with the installation script:
   ```bash
   ./scripts/install.sh --dev
   source .venv/bin/activate
   ```
   - Use `--extras dom,grpc` to install only runtime extras, or add `--skip-playwright` when browser dependencies cannot be install
ed automatically.
2. Generate starter configuration via the CLI wizard:
   ```bash
   warprecon-m configure campaign --target https://target.example --output config/campaign.local.yaml
   warprecon-m configure accounts --output config/accounts.local.yaml
   ```
   - Follow the prompts to describe account pools and preferred roles; feed the resulting YAML to `make m0 CFG=config/campaign.local.yaml` or export through environment variables.
   - If you already maintain campaign/account files, reuse them and skip this step.
   - `accounts.yaml` accepts `${ENV_VAR:default}` placeholders so secrets can stay in environment variables instead of the repository.
3. Run the one-click M0→M3 flow:
   ```bash
   make m0 m1 m2 m3 WORKDIR=work/run1 DOMAIN=https://target.example
   ```
   > Tip: `warprecon-m pipeline` now runs gRPC reflection enumeration and HTTP misconfiguration checks automatically, emitting both `ranked.merged.json` and `ranked.final.json`. Tune the built-in Precision Gate with `--gate-threshold` and `--gate-topn` if you need different score cut-offs.
4. Inspect the output: `work/run1/report_v2.html`, `work/run1/out.sarif`, `work/run1/deliverable.zip`

### Docker Compose quick start

```bash
docker compose -f deploy/docker-compose.yml up --build
```

- Launches the UI, agent worker, and Interactsh OOB relay, while the `bootstrap` service performs an initial scan to emit HTML/SARIF
/ZIP artifacts.
- Override the first scan target with `WARPRECON_BOOTSTRAP_DOMAIN=https://demo.example` or disable the warm-up via `WARPRECON_SKIP_
BOOTSTRAP=1`.
- Artifacts persist in the `warprecon-data` volume so subsequent runs and the UI can reuse them directly.

## Common Commands
| Command | Description |
| --- | --- |
| `make bootstrap` | Install dependencies and run pip-audit/container QA checks |
| `make m0 WORKDIR=... DOMAIN=...` | Perform the base scan and generate the initial report |
| `pytest -q` | Run unit and integration tests |
| `python scripts/scorecard.py work/run1` | Calculate the Scorecard score |

## Deliverables Overview
- `report_v2.html`: Visualized report
- `out.sarif`: SARIF format output
- `deliverable.zip`: All artifacts packaged together

## Project Structure & Module Roles
```text
src/
├─ op_core/     # Orchestrates the M0→M3 pipeline and ranking
├─ op_proto/    # Protocol probes (HTTP/gRPC/OpenAPI)
├─ op_output/   # Report and artifact generators
└─ op_plugins/  # Plugin checks and extension points
```
> For detailed architecture and I/O contracts, see [docs/ARCH_EN.md](docs/ARCH_EN.md)

## FAQ
1. **Command `warprecon-m` not found?**
   - Ensure the package is installed and you are inside the virtual environment.
2. **`out.sarif` missing?**
   - Check whether `make m0` ran successfully and confirm the `work/run1` directory exists.
3. **Scorecard below threshold?**
   - Verify that `ranked.final.json` is complete, or adjust the scan configuration.
4. **gRPC enumeration fails?**
   - The target may not enable reflection; provide proto files or skip M1.
5. **How do I track metrics?**
   - Refer to `work/run1/metrics.jsonl` (or the latest snapshot `metrics.json`) for `ttfp` and `hits`.
6. **Why does the UI return 401 Unauthorized?**
   - Token authentication is enforced by default. Provide one via `warprecon-m ui --auth-token <token>` or set `WARPRECON_UI_TOKEN` (comma-separated for multiple tokens) before starting the UI.
   - Supply the token via `Authorization: Bearer <token>` for API calls; the browser UI will prompt for it on first load.

## Recommended quality checks for contributors
To avoid lingering merge markers or duplicated definitions, run the following after every merge, rebase, or large refactor:

1. **Scan for conflict markers**
   ```bash
   rg --hidden --glob '!*.pyc' '<<<<<<<|=======|>>>>>>>'
   ```
   Quickly surfaces unresolved `<<<<<<<` sections before they reach the main branch.
2. **Static syntax validation**
   ```bash
   python -m compileall src
   ```
   Compiles the whole `src/` tree to catch indentation or syntax errors early.
3. **Run the full test suite**
   ```bash
   pytest
   ```
   If the project config enforces `--cov` but coverage plugins are unavailable locally, run `pytest -o addopts=''` as a temporary fallback to verify behaviour.

Building these checks into the regular workflow helps catch conflict leftovers and duplicated code before they cause import or test failures.

## GraphQL query planner
- `op_proto.graphql.schema` parses introspection schemas and crafts parameterised Query/Mutation/Subscription operations with variable definitions that respect required vs nullable arguments.
- Inline fragments for `UNION` and `INTERFACE` types are emitted automatically up to the depth set by `limits.graphql_max_depth` (defaults to 3).
- Use `limits.graphql_budget` (override via YAML or `OP_LIMITS__GRAPHQL_BUDGET`) to cap the number of GraphQL requests per endpoint and avoid flooding production APIs.

## Links
- [Operational Runbook](docs/OPERATION_EN.md)
- [Architecture & Interfaces](docs/ARCH_EN.md)
- [Plugin Hooks Guide](docs/ARCH_EN.md#plugin-hooks)
- [Changelog](CHANGELOG.md)
