"""Bootstrap package so ``python -m op_core.cli`` works without editable installs."""

from __future__ import annotations

from pathlib import Path

_pkg_dir = Path(__file__).resolve().parent
_src_pkg = _pkg_dir.parent / "src" / "op_core"

if _src_pkg.exists():
    __path__ = [str(_src_pkg)]
    init_file = _src_pkg / "__init__.py"
    if init_file.exists():
        exec(init_file.read_text(encoding="utf-8"), globals())
else:  # pragma: no cover - defensive guard
    __path__ = []
