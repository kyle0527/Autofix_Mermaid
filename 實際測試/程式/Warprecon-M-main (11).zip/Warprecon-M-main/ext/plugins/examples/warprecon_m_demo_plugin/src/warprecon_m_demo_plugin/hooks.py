"""Hooks exposed via the ``warprecon_m.plugins`` entry point group."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List


def vector_probe(workdir: Path, camp: Dict[str, Any], targets: List[str]) -> List[Dict[str, Any]]:
    """Inject a static finding to showcase pre-M0 discovery."""

    return [
        {
            "check": "demo/entrypoint",
            "target": camp.get("name", "demo"),
            "severity": "info",
            "evidence": {"note": "installed via entry point"},
            "_score": 0.05,
        }
    ]


def post_rank(ranked: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Tag findings created by :func:`vector_probe`."""

    for item in ranked:
        if item.get("check") == "demo/entrypoint":
            item.setdefault("tags", []).append("entrypoint-demo")
    return ranked


def artifact_exporter(workdir: Path, ranked: List[Dict[str, Any]]) -> None:
    """Write a short summary that confirms the plugin executed."""

    report = workdir / "plugins" / "entrypoint_demo.txt"
    report.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"{it.get('target')} -> {it.get('severity')}" for it in ranked]
    report.write_text("\n".join(lines), encoding="utf-8")
