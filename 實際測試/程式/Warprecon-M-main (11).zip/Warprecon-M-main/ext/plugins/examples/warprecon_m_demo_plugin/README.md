# Warprecon-M Demo Plugin

This package illustrates how a Warprecon-M plugin can be distributed via the
`warprecon_m.plugins` entry point. The hooks implement the three standard
extension points:

- `vector_probe`
- `post_rank`
- `artifact_exporter`

## Local installation

```bash
pip install ./ext/plugins/examples/warprecon_m_demo_plugin
```

After installation Warprecon-M will automatically discover the plugin through
the entry point registry. The hooks write a short summary to
`work/<run>/plugins/entrypoint_demo.txt` which can be used to verify that the
plugin executed.
