"""Demo plugin package illustrating entry point based discovery."""

from . import hooks

__all__ = ["hooks"]
