from .templates import load_templates

__all__ = ["load_templates"]
