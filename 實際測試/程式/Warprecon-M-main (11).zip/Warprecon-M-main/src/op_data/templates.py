from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import yaml
from cachetools import cached

from op_core.cache import shared_cache

DB_PATH = Path(__file__).resolve().parents[2] / "db" / "templates.yaml"


def _load_all() -> Dict[str, List[Dict[str, str]]]:
    with DB_PATH.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@cached(cache=shared_cache)
def load_templates(category: str) -> List[Dict[str, str]]:
    data = _load_all()
    return data.get(category, [])
