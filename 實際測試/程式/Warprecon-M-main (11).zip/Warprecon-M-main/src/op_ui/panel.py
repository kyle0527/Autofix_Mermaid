from __future__ import annotations
"""
op_ui.panel — lightweight triage dashboard (no external deps except Flask)
Usage:
  python -m op_ui.panel --workdir work/m_full --port 8080
It serves:
- / -> dashboard UI
- /api/findings -> ranked.final.json (sanitized)
- /api/metrics -> counts/severity buckets
- /api/events -> last N ndjson events (if exists)
"""
import json, argparse
from pathlib import Path
from typing import List, Dict, Any
from threading import Lock

try:
    from flask import Flask, jsonify, send_from_directory, request, Response
except Exception:
    Flask = None  # type: ignore

from op_output.sanitize import sanitize_findings

INDEX_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><title>Warprecon-M Panel</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:24px}
h1{font-size:20px}
#grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
.card{border:1px solid #ddd;border-radius:8px;padding:12px}
.kpi{font-size:28px;font-weight:600}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#eee;margin-right:6px;font-size:12px}
.row{display:flex;gap:8px;align-items:center;margin-bottom:8px}
table{width:100%;border-collapse:collapse}
th,td{border-bottom:1px solid #eee;padding:6px 4px;text-align:left;font-size:13px}
tr:hover{background:#fafafa}
input,select{padding:4px 6px}
</style></head>
<body>
<h1>Warprecon-M Triage Panel</h1>
<div id="grid">
  <div class="card">
    <div class="row">
      <div>Sev:</div>
      <select id="sev"><option value="">All</option><option>critical</option><option>high</option><option>medium</option><option>low</option><option>info</option></select>
      <div>Query:</div><input id="q" placeholder="type/fp/evidence">
      <button onclick="loadFindings()">Apply</button>
      <button onclick="downloadJSON()">Download</button>
    </div>
    <table id="tbl">
      <thead><tr><th>#</th><th>Severity</th><th>Score</th><th>Type</th><th>Fingerprint</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>
  <div class="card" id="metrics"><div class="kpi" id="kpi"></div><div id="sevbar"></div><pre id="evt" style="height:280px;overflow:auto;background:#fafafa;padding:8px"></pre></div>
</div>
<script>
let DATA=[];
async function loadFindings(){
  const sev=document.getElementById('sev').value.toLowerCase();
  const q=(document.getElementById('q').value||'').toLowerCase();
  const r=await fetch('/api/findings'); DATA=await r.json();
  const tb=document.querySelector('#tbl tbody'); tb.innerHTML='';
  DATA.filter(x=>!sev || String(x.severity||'').toLowerCase()==sev)
      .filter(x=>!q || JSON.stringify(x).toLowerCase().includes(q))
      .sort((a,b)=> (b._score||0)-(a._score||0))
      .slice(0,200)
      .forEach((x,i)=>{
        const tr=document.createElement('tr');
        tr.innerHTML=`<td>${i+1}</td><td>${x.severity||''}</td><td>${(x._score||0).toFixed(3)}</td><td>${x.type||''}</td><td style="font-family:monospace">${x.fingerprint||''}</td>`;
        tb.appendChild(tr);
      });
}
async function loadMetrics(){
  const r=await fetch('/api/metrics'); const m=await r.json();
  document.getElementById('kpi').innerText=`Findings: ${m.count} | TopN: ${m.topN}`;
  document.getElementById('sevbar').innerText=JSON.stringify(m.severity);
  try{const e=await fetch('/api/events'); document.getElementById('evt').innerText=await e.text();}catch(err){}
}
function downloadJSON(){
  const blob=new Blob([JSON.stringify(DATA,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='ranked.sanitized.json'; a.click();
}
loadFindings(); loadMetrics(); setInterval(loadMetrics, 5000);
</script>
</body></html>"""

def _load_json(p: Path) -> Any:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []

def create_app(workdir: Path):
    app = Flask(__name__)
    lock = Lock()
    w = workdir

    def _read_metrics() -> Dict[str, Any]:
        for name in ("metrics.jsonl", "metrics.json"):
            path = w / name
            if not path.exists():
                continue
            try:
                if path.suffix == ".jsonl":
                    lines = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]
                    if not lines:
                        continue
                    return json.loads(lines[-1])
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
        return {"status": "idle"}

    def _read_events(limit: int = 200) -> list[str]:
        for name in ("events.log", "events.jsonl", "events.ndjson"):
            path = w / name
            if not path.exists():
                continue
            try:
                lines = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]
            except Exception:
                return []
            return lines[-limit:]
        return []

    @app.get("/")
    def index():
        return INDEX_HTML

    @app.get("/api/findings")
    def findings():
        # prefer ranked.final.json -> ranked.merged.json -> ranked.json
        p = None
        for name in ("ranked.final.json","ranked.merged.json","ranked.json"):
            f = w / name
            if f.exists():
                p = f; break
        if not p: return jsonify([])
        items = _load_json(p)
        items = sanitize_findings(items)
        return app.response_class(json.dumps(items, ensure_ascii=False), mimetype="application/json; charset=utf-8")

    @app.get("/api/metrics")
    def metrics():
        data = _read_metrics()
        return app.response_class(
            json.dumps(data, ensure_ascii=False),
            mimetype="application/json; charset=utf-8",
        )

    @app.get("/api/events")
    def events():
        lines = _read_events()
        return app.response_class("\n".join(lines), mimetype="text/plain; charset=utf-8")

    return app

def main():
    ap = argparse.ArgumentParser(description="Warprecon-M panel")
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--port", type=int, default=8080)
    args = ap.parse_args()
    if Flask is None:
        raise SystemExit("Flask is required: pip install flask")
    app = create_app(Path(args.workdir))
    app.run(host="0.0.0.0", port=args.port, debug=False)

if __name__=="__main__":
    main()
