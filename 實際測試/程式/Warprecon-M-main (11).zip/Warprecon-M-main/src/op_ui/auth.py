"""Authentication helpers for the Flask UI."""

from __future__ import annotations

import hmac
import logging
import os
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

from flask import Flask, Request, Response, jsonify, request

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AuthConfig:
    """Configuration container for API authentication."""

    tokens: tuple[str, ...]
    realm: str = "warprecon-ui"
    allow_anonymous_health: bool = True
    allow_anonymous_root: bool = True

    @classmethod
    def from_sources(
        cls,
        *,
        tokens: Sequence[str] | None = None,
        environ: Mapping[str, str] | None = None,
    ) -> "AuthConfig":
        env = environ or os.environ
        env_tokens_raw = env.get("WARPRECON_UI_TOKENS") or env.get("WARPRECON_UI_TOKEN")
        env_tokens: list[str] = []
        if env_tokens_raw:
            env_tokens.extend(t.strip() for t in env_tokens_raw.split(",") if t.strip())

        combined: list[str] = []
        if tokens:
            combined.extend(t.strip() for t in tokens if t and t.strip())
        combined.extend(env_tokens)

        deduped: list[str] = []
        for token in combined:
            if token and token not in deduped:
                deduped.append(token)

        return cls(tokens=tuple(deduped))

    @property
    def enabled(self) -> bool:
        return bool(self.tokens)


class TokenAuthenticator:
    """Bearer token authentication for Flask endpoints."""

    def __init__(self, config: AuthConfig) -> None:
        self.config = config

    def extract_token(self, auth_header: str | None) -> str | None:
        if not auth_header:
            return None
        parts = auth_header.split(" ", 1)
        if len(parts) != 2:
            return None
        scheme, token = parts
        if scheme.lower() != "bearer":
            return None
        token = token.strip()
        return token or None

    def is_authorized(self, token: str | None) -> bool:
        if not token or not self.config.tokens:
            return False
        for candidate in self.config.tokens:
            if hmac.compare_digest(candidate, token):
                return True
        return False

    def _request_token(self, req: Request) -> str | None:
        token = self.extract_token(req.headers.get("Authorization"))
        if token:
            return token
        query_token = req.args.get("token")
        if query_token:
            return query_token.strip() or None
        bearer = req.cookies.get("warprecon_ui_token")
        if bearer:
            return bearer.strip() or None
        return None

    def register(self, app: Flask) -> None:
        if not self.config.enabled:
            logger.warning(
                "UI API authentication disabled: no tokens configured. Allowing anonymous access."
            )
            return

        logger.info("UI API authentication enabled with %d token(s)", len(self.config.tokens))

        exempt_endpoints: set[str] = {"static"}
        if self.config.allow_anonymous_health:
            exempt_endpoints.add("healthz")
        if self.config.allow_anonymous_root:
            exempt_endpoints.add("home")

        @app.before_request
        def _enforce_auth() -> Response | None:  # pragma: no cover - flask context
            endpoint = request.endpoint or ""
            if endpoint in exempt_endpoints or endpoint.startswith("static"):
                return None
            if request.method == "OPTIONS":
                return None
            token = self._request_token(request)
            if self.is_authorized(token):
                return None
            logger.warning("unauthorized UI API access from %s", request.remote_addr)
            response = jsonify({"error": "unauthorized"})
            response.status_code = 401
            response.headers["WWW-Authenticate"] = f'Bearer realm="{self.config.realm}"'
            return response


def configure_auth(app: Flask, *, tokens: Iterable[str] | None = None) -> TokenAuthenticator:
    config = AuthConfig.from_sources(tokens=tokens)
    authenticator = TokenAuthenticator(config)
    authenticator.register(app)
    return authenticator


__all__ = ["AuthConfig", "TokenAuthenticator", "configure_auth"]
