from __future__ import annotations

import csv
import io
import json
import logging
import socket
import threading
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

try:
    import httpx
except Exception:  # pragma: no cover - optional dependency
    httpx = None  # type: ignore

from flask import (
    Flask,
    Response,
    jsonify,
    request,
    send_file,
    send_from_directory,
)

from op_chain.assembler import build_graph, suggest_paths
from op_core.pipeline import run_pipeline
from op_dist.queue import FSQueue
from op_output.deliver import make_deliverable_zip
from op_output.poc import make_curl
from op_ui.auth import configure_auth

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).with_name("static")
RANKED_FILES = ["ranked.final.json", "ranked.merged.json", "ranked.json"]
METRIC_FILES = ["metrics.json", "metrics.jsonl"]
EVENT_FILES = ["events.jsonl", "events.log", "events.ndjson"]
DISCOVERY_FILES = [
    "details.json",
    "js-endpoints.json",
    "dom-requests.json",
    "dom-endpoints.json",
    "dom-artifacts.json",
]
EXPORT_GROUPS: dict[str, list[str]] = {
    "ranked": ["ranked*.json"],
    "metrics": ["metrics.json", "metrics.jsonl"],
    "events": ["events.log", "events.jsonl", "events.ndjson"],
    "reports": ["report*.html", "reports/**/*.html", "html/**/*.html"],
    "discovery": ["discovery/**", "dom-*/**", "schema/**"],
    "poc": ["poc/**"],
}
DEFAULT_CSV_FIELDS = [
    "_rank",
    "_score",
    "severity",
    "vector.protocol",
    "tool",
    "url",
    "payload",
    "_confirmed",
    "evidence.sequence_hit",
]
EVENT_LIMIT = 200
RUN_LIMIT = 50


@dataclass(frozen=True)
class RemoteConfig:
    name: str
    base_url: str
    token: str | None = None

    def api_url(self, path: str) -> str:
        base = self.base_url.rstrip("/")
        if path.startswith("/"):
            return f"{base}{path}"
        return f"{base}/{path}"


@dataclass
class UIState:
    root: Path
    current: Path
    cfg_path: Path
    remotes: list[RemoteConfig] = field(default_factory=list)
    lock: threading.RLock = field(default_factory=threading.RLock)

    def list_runs(self) -> list[Path]:
        runs = _discover_runs(self.root)
        if self.current not in runs:
            runs.append(self.current)
        unique: list[Path] = []
        seen: set[Path] = set()
        for path in runs:
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                unique.append(resolved)
        unique.sort(key=_run_sort_key, reverse=True)
        return unique

    def alias_for(self, path: Path) -> str:
        path = path.resolve()
        try:
            rel = path.relative_to(self.root)
        except ValueError:
            return path.name or str(path)
        if rel == Path("."):
            return path.name or str(path)
        return rel.as_posix()

    def resolve_alias(self, value: str) -> Path | None:
        value = value.strip()
        if not value:
            return None
        candidates = self.list_runs()
        for candidate in candidates:
            if value == self.alias_for(candidate):
                return candidate
        maybe = (self.root / value).resolve()
        for candidate in candidates:
            if candidate == maybe:
                return candidate
        try:
            direct = Path(value).resolve()
        except Exception:
            return None
        for candidate in candidates:
            if candidate == direct:
                return candidate
        return None

    def set_current(self, alias: str) -> bool:
        target = self.resolve_alias(alias)
        if target is None:
            return False
        with self.lock:
            self.current = target
        return True

    def current_alias(self) -> str:
        return self.alias_for(self.current)


def _looks_like_run(path: Path) -> bool:
    try:
        if not path.exists() or not path.is_dir():
            return False
    except OSError:
        return False
    for name in (*RANKED_FILES, *METRIC_FILES, *EVENT_FILES):
        if (path / name).exists():
            return True
    discovery_dir = path / "discovery"
    try:
        if discovery_dir.exists() and any(discovery_dir.iterdir()):
            return True
    except OSError:
        return False
    return False


def _discover_runs(root: Path) -> list[Path]:
    try:
        root.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    runs: list[Path] = []
    if _looks_like_run(root):
        runs.append(root)
    try:
        for entry in root.iterdir():
            if not entry.is_dir() or entry.name.startswith("."):
                continue
            if _looks_like_run(entry):
                runs.append(entry)
    except FileNotFoundError:
        return runs
    except OSError as exc:
        logger.debug("run discovery failed for %s: %s", root, exc)
    deduped: list[Path] = []
    seen: set[Path] = set()
    for entry in runs:
        resolved = entry.resolve()
        if resolved not in seen:
            seen.add(resolved)
            deduped.append(resolved)
    deduped.sort(key=_run_sort_key, reverse=True)
    return deduped


def _run_sort_key(path: Path) -> tuple[float, str]:
    try:
        mtime = path.stat().st_mtime
    except OSError:
        mtime = 0.0
    return mtime, path.name


def _initialise_state(workdir: Path, cfg_path: Path) -> UIState:
    resolved_workdir = workdir.resolve()
    resolved_cfg = cfg_path.resolve()
    if _looks_like_run(resolved_workdir):
        root = resolved_workdir.parent if resolved_workdir.parent else resolved_workdir
        current = resolved_workdir
    else:
        root = resolved_workdir
        candidates = _discover_runs(root)
        current = candidates[0] if candidates else resolved_workdir
    try:
        current.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    state = UIState(root=root.resolve(), current=current.resolve(), cfg_path=resolved_cfg)
    state.remotes = _load_remotes(resolved_cfg, state.root)
    return state


def _load_remotes(cfg_path: Path, root: Path) -> list[RemoteConfig]:
    remotes: list[RemoteConfig] = []
    seen: set[str] = set()
    candidates = {
        Path.cwd() / "ui-remotes.json",
        cfg_path.parent / "ui-remotes.json",
        root / "ui-remotes.json",
    }
    for path in candidates:
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning("failed to load remote config %s: %s", path, exc)
            continue
        if not isinstance(payload, list):
            continue
        for entry in payload:
            if not isinstance(entry, dict):
                continue
            url = entry.get("url") or entry.get("base_url") or entry.get("endpoint")
            if not isinstance(url, str) or not url.strip():
                continue
            key = url.strip()
            if key in seen:
                continue
            seen.add(key)
            name = entry.get("name") or entry.get("label") or key
            token = entry.get("token") or entry.get("auth_token")
            remotes.append(RemoteConfig(name=name, base_url=key, token=token))
    return remotes


def _ranked_path(workdir: Path) -> Path | None:
    for name in RANKED_FILES:
        candidate = workdir / name
        if candidate.exists():
            return candidate
    return None


def _load_ranked(workdir: Path) -> list[dict[str, Any]]:
    path = _ranked_path(workdir)
    if not path:
        return []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("failed to read ranked %s: %s", path, exc)
        return []
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.warning("failed to parse ranked %s: %s", path, exc)
        return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        return list(data["items"])
    return []


def _load_metrics(workdir: Path) -> dict[str, Any]:
    for name in METRIC_FILES:
        candidate = workdir / name
        if not candidate.exists():
            continue
        try:
            text = candidate.read_text(encoding="utf-8")
        except OSError:
            continue
        if candidate.suffix == ".jsonl":
            lines = [ln for ln in text.splitlines() if ln.strip()]
            if not lines:
                continue
            text = lines[-1]
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            return data
    return {}


def _load_events(workdir: Path, limit: int = EVENT_LIMIT) -> list[dict[str, Any]]:
    for name in EVENT_FILES:
        candidate = workdir / name
        if not candidate.exists():
            continue
        try:
            lines = [ln for ln in candidate.read_text(encoding="utf-8").splitlines() if ln.strip()]
        except OSError:
            continue
        events: list[dict[str, Any]] = []
        for raw in lines[-limit:]:
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                payload = {"ts": None, "type": "log", "message": raw}
            if isinstance(payload, dict):
                events.append(payload)
        return events
    return []


def _load_targets(workdir: Path) -> dict[str, Any]:
    targets_file = workdir / "targets.txt"
    discovery_file = workdir / "discovery" / "targets.json"
    try:
        targets = (
            targets_file.read_text(encoding="utf-8").splitlines()
            if targets_file.exists()
            else []
        )
    except OSError:
        targets = []
    try:
        discovery = (
            json.loads(discovery_file.read_text(encoding="utf-8"))
            if discovery_file.exists()
            else {"targets": []}
        )
    except Exception:
        discovery = {"targets": []}
    return {"targets": targets, "discovery": discovery}


def _load_discovery(workdir: Path) -> dict[str, Any]:
    result: dict[str, Any] = {}
    discovery_dir = workdir / "discovery"
    for name in DISCOVERY_FILES:
        path = discovery_dir / name
        if not path.exists():
            continue
        try:
            result[name] = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            result[name] = None
    return result


def _load_oob(workdir: Path) -> dict[str, Any]:
    path = workdir / "oob" / "events.json"
    if not path.exists():
        return {"count": 0, "events": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"count": 0, "events": []}
    events = data.get("events") if isinstance(data, dict) else []
    if not isinstance(events, list):
        events = []
    return {"count": len(events), "events": events}


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _safe_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _safe_mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def _precision_at(items: Sequence[dict[str, Any]], depth: int) -> float:
    if depth <= 0 or not items:
        return 0.0
    top = items[:depth]
    denom = min(depth, len(top))
    if denom == 0:
        return 0.0
    hits = 0
    for item in top:
        if not isinstance(item, dict):
            continue
        if item.get("_confirmed"):
            hits += 1
            continue
        evidence = item.get("evidence")
        if isinstance(evidence, dict) and evidence.get("sequence_hit"):
            hits += 1
    return round(hits / denom, 3)


def _count_poc(workdir: Path) -> int:
    poc_dir = workdir / "poc"
    if not poc_dir.exists():
        return 0
    stems: set[str] = set()
    try:
        for entry in poc_dir.glob("poc_*.*"):
            if entry.is_file():
                stems.add(entry.stem)
    except OSError:
        return 0
    return len(stems)


def _extract_field(payload: dict[str, Any], field: str) -> Any:
    node: Any = payload
    for part in field.split("."):
        if isinstance(node, dict):
            node = node.get(part)
        else:
            return None
    return node


def _generate_csv(items: Sequence[dict[str, Any]], fields: Sequence[str]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(fields)
    for item in items:
        row: list[str] = []
        for column in fields:
            value = _extract_field(item, column)
            if isinstance(value, (dict, list)):
                row.append(json.dumps(value, ensure_ascii=False))
            elif value is None:
                row.append("")
            else:
                row.append(str(value))
        writer.writerow(row)
    return buffer.getvalue()


def _collect_files(root: Path, groups: Iterable[str]) -> list[Path]:
    patterns: list[str] = []
    for group in groups:
        patterns.extend(EXPORT_GROUPS.get(group, []))
    if not patterns:
        for pats in EXPORT_GROUPS.values():
            patterns.extend(pats)
    seen: set[Path] = set()
    files: list[Path] = []
    for pattern in patterns:
        for candidate in root.glob(pattern):
            if candidate.is_file():
                resolved = candidate.resolve()
                if resolved not in seen:
                    seen.add(resolved)
                    files.append(resolved)
    files.sort()
    return files


def _build_metrics_response(metrics: dict[str, Any]) -> dict[str, Any]:
    response = dict(metrics)
    for key in ("ttfp_seconds", "duration_seconds"):
        response[key] = _safe_float(response.get(key))
    for key in ("hits", "confirmed_hits"):
        response[key] = _safe_int(response.get(key))
    return response


def _build_run_summary(state: UIState, path: Path) -> dict[str, Any]:
    metrics = _load_metrics(path)
    ranked = _load_ranked(path)
    summary = {
        "workdir": state.alias_for(path),
        "path": str(path),
        "ttfp": _safe_float(metrics.get("ttfp_seconds")),
        "duration": _safe_float(metrics.get("duration_seconds")),
        "hits": _safe_int(metrics.get("hits")),
        "confirmed_hits": _safe_int(metrics.get("confirmed_hits")),
        "p10": _precision_at(ranked, 10),
        "p20": _precision_at(ranked, 20),
        "poc": _count_poc(path),
        "updated": _safe_mtime(path),
    }
    return summary


def _local_runs_payload(state: UIState) -> dict[str, Any]:
    runs = [_build_run_summary(state, path) for path in state.list_runs()][:RUN_LIMIT]
    runs.sort(key=lambda item: item.get("updated") or 0, reverse=True)
    return {
        "node": socket.gethostname(),
        "runs": runs,
        "current": state.current_alias(),
    }


def _fetch_remote_runs(remote: RemoteConfig) -> dict[str, Any] | None:
    if httpx is None:
        return None
    url = remote.api_url("/api/runs")
    headers: dict[str, str] = {}
    if remote.token:
        headers["Authorization"] = f"Bearer {remote.token}"
    try:
        response = httpx.get(url, headers=headers, timeout=5.0)
        response.raise_for_status()
        data = response.json()
    except Exception as exc:
        logger.warning("remote runs fetch failed for %s: %s", remote.base_url, exc)
        return None
    if isinstance(data, dict):
        data.setdefault("node", remote.name)
        return data
    return None


def create_app(
    workdir: Path,
    cfg_path: Path,
    *,
    auth_tokens: Sequence[str] | None = None,
) -> Flask:
    app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="/static")
    configure_auth(app, tokens=auth_tokens)
    state = _initialise_state(workdir, cfg_path)

    @app.get("/healthz")
    def healthz() -> Response:
        return jsonify({"ok": True, "workdir": state.current_alias()})

    @app.get("/")
    def home() -> Response:
        index = STATIC_DIR / "index.html"
        if index.exists():
            return send_from_directory(STATIC_DIR, "index.html")
        return Response(
            "<p>UI assets are unavailable.</p>",
            mimetype="text/html; charset=utf-8",
        )

    @app.get("/api/metrics")
    def metrics() -> Response:
        data = _build_metrics_response(_load_metrics(state.current))
        return jsonify(data)

    @app.get("/api/ranked")
    def ranked() -> Response:
        return jsonify(_load_ranked(state.current))

    @app.get("/api/events")
    def events() -> Response:
        return jsonify(_load_events(state.current))

    @app.get("/api/workdirs")
    def workdirs() -> Response:
        items = [state.alias_for(path) for path in state.list_runs()]
        if not items:
            items = [state.current_alias()]
        return jsonify({"items": items, "current": state.current_alias()})

    @app.get("/api/use")
    def use_workdir() -> Response:
        target = request.args.get("dir", "")
        if not state.set_current(target):
            return jsonify({"error": "unknown workdir"}), 404
        return jsonify({"current": state.current_alias()})

    @app.get("/api/evidence")
    def evidence() -> Response:
        idx_raw = request.args.get("i")
        try:
            index = int(idx_raw) if idx_raw is not None else -1
        except ValueError:
            return jsonify({"error": "invalid index"}), 400
        items = _load_ranked(state.current)
        if index < 0 or index >= len(items):
            return jsonify({"error": "index out of range"}), 404
        return jsonify(items[index])

    @app.get("/api/poc_snippet")
    def poc_snippet() -> Response:
        idx_raw = request.args.get("i")
        try:
            index = int(idx_raw) if idx_raw is not None else -1
        except ValueError:
            return Response(
                "invalid index\n",
                status=400,
                mimetype="text/plain; charset=utf-8",
            )
        items = _load_ranked(state.current)
        if index < 0 or index >= len(items):
            return Response(
                "not found\n",
                status=404,
                mimetype="text/plain; charset=utf-8",
            )
        snippet = make_curl(items[index])
        return Response(snippet + "\n", mimetype="text/plain; charset=utf-8")

    @app.get("/api/csv")
    def download_csv() -> Response:
        fields_param = request.args.get("fields", "")
        fields = [field.strip() for field in fields_param.split(",") if field.strip()]
        if not fields:
            fields = list(DEFAULT_CSV_FIELDS)
        items = _load_ranked(state.current)
        csv_data = _generate_csv(items, fields)
        filename = f"ranked-{int(time.time())}.csv"
        return Response(
            csv_data,
            mimetype="text/csv; charset=utf-8",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    @app.get("/api/export_zip")
    def export_zip() -> Response:
        include_param = request.args.get("include", "")
        groups = [part.strip() for part in include_param.split(",") if part.strip()]
        files = _collect_files(state.current, groups)
        if not files:
            return jsonify({"error": "no files matched"}), 404
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            for file_path in files:
                try:
                    arcname = file_path.relative_to(state.current)
                except ValueError:
                    continue
                archive.write(file_path, arcname.as_posix())
        buffer.seek(0)
        filename = f"warprecon-export-{int(time.time())}.zip"
        return send_file(
            buffer,
            mimetype="application/zip",
            as_attachment=True,
            download_name=filename,
        )

    @app.get("/poc/")
    def poc_index() -> Response:
        poc_dir = state.current / "poc"
        entries: list[str] = []
        if poc_dir.exists():
            for file_path in sorted(poc_dir.glob("*")):
                if file_path.is_file():
                    name = file_path.name
                    entries.append(f'<li><a href="{name}" download>{name}</a></li>')
        if not entries:
            entries.append("<li>No PoC artifacts available.</li>")
        html = (
            "<!doctype html><meta charset='utf-8'><title>PoC artifacts</title>"
            "<body><h1>PoC artifacts</h1><ul>"
            + "".join(entries)
            + "</ul></body>"
        )
        return Response(html, mimetype="text/html; charset=utf-8")

    @app.get("/poc/<path:filename>")
    def poc_file(filename: str):
        poc_dir = state.current / "poc"
        if not poc_dir.exists():
            return Response(
                "not found\n",
                status=404,
                mimetype="text/plain; charset=utf-8",
            )
        return send_from_directory(poc_dir, filename)

    @app.get("/api/runs")
    def runs() -> Response:
        return jsonify(_local_runs_payload(state))

    @app.get("/api/runs_all")
    def runs_all() -> Response:
        items: list[dict[str, Any]] = []
        items.append(_local_runs_payload(state))
        for remote in state.remotes:
            payload = _fetch_remote_runs(remote)
            if payload and isinstance(payload.get("runs"), list):
                items.append(payload)
        return jsonify({"items": items})

    @app.post("/api/run")
    def run_now() -> Response:
        data = request.get_json(force=True, silent=True) or {}
        domain = (data.get("domain") or "").strip()
        if not domain:
            return jsonify({"error": "domain required"}), 400
        max_concurrency = data.get("max_concurrency")
        try:
            max_concurrency_val = (
                int(max_concurrency) if max_concurrency is not None else None
            )
        except (TypeError, ValueError):
            max_concurrency_val = None
        profile_value = data.get("profile")
        profile_path = None
        if isinstance(profile_value, str) and profile_value.strip():
            profile_path = Path(profile_value).expanduser()
            if not profile_path.is_absolute():
                profile_path = (state.cfg_path.parent / profile_path).resolve()
        capture = bool(data.get("capture"))
        dom_crawl = bool(data.get("dom_crawl"))
        poc_top = data.get("poc_top")
        try:
            poc_top_val = int(poc_top) if poc_top is not None else None
        except (TypeError, ValueError):
            poc_top_val = None
        history_ttl = data.get("history_ttl")
        try:
            history_ttl_val = int(history_ttl) if history_ttl is not None else None
        except (TypeError, ValueError):
            history_ttl_val = None
        ultra = bool(data.get("ultra"))
        resume = bool(data.get("resume"))

        gate_threshold_present = "gate_threshold" in data
        gate_topn_present = "gate_topn" in data
        gate_labels_present = "gate_labels" in data
        try:
            gate_threshold_val = (
                float(data.get("gate_threshold")) if gate_threshold_present else None
            )
        except (TypeError, ValueError):
            gate_threshold_val = None
        try:
            gate_topn_val = (
                int(data.get("gate_topn")) if gate_topn_present else None
            )
        except (TypeError, ValueError):
            gate_topn_val = None

        gate_labels_path: Path | None = None
        if gate_labels_present:
            labels_value = data.get("gate_labels")
            if isinstance(labels_value, str) and labels_value.strip():
                gate_labels_path = Path(labels_value).expanduser()
                if not gate_labels_path.is_absolute():
                    gate_labels_path = (state.cfg_path.parent / gate_labels_path).resolve()

        with state.lock:
            target_dir = state.current

        def runner() -> None:
            try:
                kwargs: dict[str, Any] = {
                    "max_concurrency": max_concurrency_val,
                    "profile": profile_path,
                    "capture": capture,
                    "dom_crawl": dom_crawl,
                    "poc_top": poc_top_val,
                    "history_ttl": history_ttl_val,
                    "ultra": ultra,
                    "resume": resume,
                }
                if gate_threshold_present:
                    kwargs["gate_threshold"] = gate_threshold_val
                if gate_topn_present:
                    kwargs["gate_topn"] = gate_topn_val
                if gate_labels_path is not None:
                    kwargs["gate_labels"] = gate_labels_path

                run_pipeline(
                    domain,
                    state.cfg_path,
                    target_dir,
                    **kwargs,
                )
            except Exception as exc:  # pragma: no cover - background logging
                logger.exception("pipeline run failed: %s", exc)

        threading.Thread(target=runner, daemon=True).start()
        return jsonify(
            {
                "accepted": True,
                "domain": domain,
                "workdir": state.alias_for(target_dir),
                "capture": capture,
                "dom_crawl": dom_crawl,
                "max_concurrency": max_concurrency_val,
                "profile": str(profile_path) if profile_path else None,
                "poc_top": poc_top_val,
                "history_ttl": history_ttl_val,
                "ultra": ultra,
                "resume": resume,
                "gate_threshold": gate_threshold_val if gate_threshold_present else None,
                "gate_topn": gate_topn_val if gate_topn_present else None,
                "gate_labels": str(gate_labels_path) if gate_labels_path else None,
            }
        )

    @app.post("/api/queue/add")
    def queue_add() -> Response:
        data = request.get_json(force=True, silent=True) or {}
        domain = (data.get("domain") or "").strip()
        if not domain:
            return jsonify({"error": "domain required"}), 400
        with state.lock:
            queue_dir = state.current / "queue"
        try:
            queue_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return jsonify({"error": str(exc)}), 500
        queue = FSQueue(queue_dir)
        tid = queue.enqueue(domain, str(state.cfg_path))
        return jsonify({"queued": tid, "domain": domain})

    @app.get("/api/deliver")
    def deliver() -> Response:
        archive = make_deliverable_zip(state.current)
        return send_file(
            archive,
            as_attachment=True,
            download_name=Path(archive).name,
        )

    @app.get("/api/findings")
    def findings() -> Response:
        items = _load_ranked(state.current)
        return jsonify({"items": items, "count": len(items)})

    @app.get("/api/targets")
    def targets() -> Response:
        return jsonify(_load_targets(state.current))

    @app.get("/api/discovery")
    def discovery() -> Response:
        return jsonify(_load_discovery(state.current))

    @app.get("/api/oob")
    def oob() -> Response:
        return jsonify(_load_oob(state.current))

    @app.get("/api/chain")
    def chain() -> Response:
        try:
            graph = build_graph(_load_ranked(state.current))
            paths = suggest_paths(graph)
        except Exception as exc:
            logger.warning("chain build failed: %s", exc)
            paths = []
        return jsonify({"paths": paths})

    @app.get("/api/control")
    def control() -> Response:
        pause_raw = request.args.get("pause")
        if pause_raw is None:
            pause = True
        else:
            pause = str(pause_raw).lower() in {"1", "true", "yes", "on"}
        control_path = state.current / "control.json"
        payload = {"pause": pause}
        try:
            control_path.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            return jsonify({"error": str(exc)}), 500
        return jsonify(payload)

    return app


__all__ = ["create_app"]

