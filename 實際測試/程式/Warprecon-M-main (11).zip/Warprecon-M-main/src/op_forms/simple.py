from __future__ import annotations
import re
from typing import List, Dict, Any
from urllib.parse import urljoin

# Capture form tag attributes and inner HTML
_FORM_RE = re.compile(r"(?is)<form\b([^>]*)>(.*?)</form>")
_INPUT_RE = re.compile(r'(?is)<input\b([^>]+)>')
_TEXTAREA_RE = re.compile(r'(?is)<textarea\b([^>]+)>(.*?)</textarea>')
_ATTR_RE = re.compile(r'([a-zA-Z:_-]+)\s*=\s*["\']([^"\']*)["\']')

CSRF_NAMES = {"csrf","_csrf","csrf-token","authenticity_token","__RequestVerificationToken"}

def _attrs(s: str) -> dict:
    return {k.lower(): v for k,v in _ATTR_RE.findall(s)}

def extract_forms(base_url: str, html: str) -> List[Dict[str, Any]]:
    out: List[Dict[str,Any]] = []
    for attrs_str, inner in _FORM_RE.findall(html or ""):
        attrs = _attrs(attrs_str)
        action = attrs.get("action", "")
        method_attr = (attrs.get("method") or "").lower()
        inputs: List[Dict[str,str]] = []
        for t, name in (("input", _INPUT_RE), ("textarea", _TEXTAREA_RE)):
            for im in name.findall(inner):
                if isinstance(im, tuple):
                    attrs = _attrs(im[0])
                    val = ""
                    if t=="textarea":
                        val = im[1]
                else:
                    attrs = _attrs(im)
                    val = ""
                nm = attrs.get("name") or attrs.get("id")
                if not nm: continue
                itype = attrs.get("type","text").lower()
                value = attrs.get("value", val)
                inputs.append({"name": nm, "type": itype, "value": value})
        method = "post" if method_attr == "post" else "get"
        out.append({"action": urljoin(base_url, action), "method": method, "inputs": inputs})
    return out

def choose_form_fields(forms: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    """
    Pick a small subset of fields from forms to fuzz: 1-2 text-like inputs per form.
    """
    picks: List[Dict[str,Any]] = []
    for f in forms:
        text_like = [i for i in f["inputs"] if i["type"] in ("text","search","email","password","url","number") or i["type"]=="" ]
        other = [i for i in f["inputs"] if i["type"] not in ("submit","button","hidden")]
        cand = text_like or other
        if not cand: continue
        for i in cand[:2]:
            picks.append({"action": f["action"], "method": f["method"], "target_param": i["name"], "ctx": f})
    return picks

def extract_csrf_tokens(inputs: List[Dict[str,str]]) -> Dict[str,str]:
    out={}
    for it in inputs:
        if it.get("name","").lower() in CSRF_NAMES or it.get("type","").lower()=="hidden" and "csrf" in it.get("name","").lower():
            out[it["name"]] = it.get("value","")
    return out
