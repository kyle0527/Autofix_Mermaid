from __future__ import annotations
"""
op_output.sanitize — redact sensitive data in findings/evidence/headers/PoC.
CLI:
  python -m op_output.sanitize --in ranked.json --out ranked.sanitized.json --html report_v3.html
"""
import argparse, json, re
from pathlib import Path
from typing import Any, Dict, List

SENSITIVE_KEYS = {
    "authorization","cookie","set-cookie","x-api-key","api-key","x-api-token",
    "x-auth-token","token","password","secret","access_key","secret_key",
    "aws_access_key_id","aws_secret_access_key","x-credentials"
}

# Regex patterns for strings
RE_JWT = re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b")
RE_BEARER = re.compile(r"\b[Bb]earer\s+([A-Za-z0-9\-._~+/]+=*)")
RE_BASIC = re.compile(r"\b[Bb]asic\s+([A-Za-z0-9+/=]{10,})")
RE_APIKEY = re.compile(r"(?i)(api[-_ ]?key|x[-_ ]?api[-_ ]?key)\s*[:=]\s*([A-Za-z0-9\-._]{16,})")
RE_EMAIL = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")
RE_COOKIE = re.compile(r"(?im)^(set-cookie|cookie)\s*:\s*.+$", re.MULTILINE)
RE_AUTH = re.compile(r"(?im)^authorization\s*:\s*.+$", re.MULTILINE)

def _mask_middle(s: str, keep: int=4) -> str:
    if not s: return s
    if len(s) <= keep*2: return "*" * len(s)
    return s[:keep] + "*"*(len(s)-keep*2) + s[-keep:]

def redact_string(s: str) -> str:
    if not isinstance(s, str): return s
    s = RE_JWT.sub(lambda m: _mask_middle(m.group(0), 6), s)
    s = RE_BEARER.sub(lambda m: "Bearer " + _mask_middle(m.group(1), 3), s)
    s = RE_BASIC.sub(lambda m: "Basic " + _mask_middle(m.group(1), 4), s)
    s = RE_APIKEY.sub(lambda m: f"{m.group(1)}: " + _mask_middle(m.group(2), 4), s)
    s = RE_EMAIL.sub(lambda m: _mask_middle(m.group(0), 2), s)
    s = RE_COOKIE.sub(lambda m: m.group(1) + ": <redacted>", s)
    s = RE_AUTH.sub(lambda m: "authorization: <redacted>", s)
    return s

def redact_value(v: Any) -> Any:
    if isinstance(v, str):
        return redact_string(v)
    if isinstance(v, list):
        return [redact_value(x) for x in v]
    if isinstance(v, dict):
        return redact_dict(v)
    return v

def redact_dict(d: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in d.items():
        kl = str(k).lower()
        if kl in SENSITIVE_KEYS:
            if isinstance(v, str):
                out[k] = _mask_middle(v, 4)
            else:
                out[k] = "<redacted>"
        else:
            out[k] = redact_value(v)
    return out

def sanitize_findings(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for it in items:
        it2 = dict(it)
        # typical fields
        for fld in ("headers","request","response","evidence","poc"):
            if fld in it2:
                it2[fld] = redact_value(it2[fld])
        out.append(it2)
    return out

HTML_TMPL = """<html><head><meta charset='utf-8'><title>Warprecon-M Report v3 (Sanitized)</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:24px}
.card{border:1px solid #ddd;border-radius:8px;padding:16px;margin-bottom:12px}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#eee;margin-right:6px;font-size:12px}
.evidence{background:#fafafa;border:1px dashed #ccc;padding:8px;margin-top:8px;white-space:pre-wrap;font-family:ui-monospace,Menlo,Consolas,monospace}
small.mono{font-family:ui-monospace,Menlo,Consolas,monospace;color:#555}
#toolbar{position:sticky;top:0;background:#fff;padding:8px 0}
</style></head><body>
<h1>Warprecon-M Report v3 <small>(Sanitized)</small></h1>
<div id="toolbar">
  <label>Severity:
    <select id="sev"><option value="">All</option><option>critical</option><option>high</option><option>medium</option><option>low</option><option>info</option></select>
  </label>
  <label>Search: <input id="q" placeholder="type / fingerprint / evidence"/></label>
  <button onclick="render()">Apply</button>
</div>
<div id="root"></div>
<script>
const DATA = __DATA__;
function htmlEscape(s){return s.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){
  const root = document.getElementById('root'); root.innerHTML='';
  const q = (document.getElementById('q').value||'').toLowerCase();
  const sev = (document.getElementById('sev').value||'').toLowerCase();
  DATA.filter(x=>!sev || (String(x.severity||'').toLowerCase()==sev))
      .filter(x=>!q || JSON.stringify(x).toLowerCase().includes(q))
      .sort((a,b)=> (b._score||0)-(a._score||0))
      .forEach(x=>{
        const card = document.createElement('div'); card.className='card';
        const sev = String(x.severity||'info'); const score = (x._score||0).toFixed(3);
        const src = String(x.source||'core'); const fp = String(x.fingerprint||x.fp||'');
        card.innerHTML = `<div><span class='badge'>${sev}</span><span class='badge'>score:${score}</span><span class='badge'>${src}</span></div>
                          <div><b>${htmlEscape(String(x.type||'finding'))}</b> <small class='mono'>${htmlEscape(fp)}</small></div>`;
        if (x.evidence){
          const det = document.createElement('details'); det.innerHTML=`<summary>evidence</summary><div class='evidence'>${htmlEscape(typeof x.evidence==='string'?x.evidence:JSON.stringify(x.evidence,null,2))}</div>`;
          card.appendChild(det);
        }
        root.appendChild(card);
      });
}
render();
</script>
</body></html>"""

def _cli():
    ap = argparse.ArgumentParser(description="Sanitize findings and emit HTML v3")
    ap.add_argument("--in", dest="infile", required=True)
    ap.add_argument("--out", required=True, help="sanitized JSON output")
    ap.add_argument("--html", required=False, help="optional HTML v3 output path")
    args = ap.parse_args()
    items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
    sanitized = sanitize_findings(items)
    Path(args.out).write_text(json.dumps(sanitized, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.html:
        data_json = json.dumps(sanitized, ensure_ascii=False).replace("</", "<\\/")
        html = HTML_TMPL.replace("__DATA__", data_json)
        Path(args.html).write_text(html, encoding="utf-8")
    print(json.dumps({"in": args.infile, "out": args.out, "count": len(sanitized)}, ensure_ascii=False))

if __name__=="__main__":
    _cli()
