from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping

from op_core.finding_contract import Finding


def _coerce_items(items: Iterable[Finding | Mapping[str, Any]]) -> list[Dict[str, Any]]:
    """Convert heterogeneous findings to plain dictionaries."""

    normalised: list[Dict[str, Any]] = []
    for item in items:
        if isinstance(item, Finding):
            normalised.append(item.to_dict())
        elif isinstance(item, dict):
            normalised.append(dict(item))
        elif hasattr(item, "to_dict"):
            normalised.append(item.to_dict())  # type: ignore[call-arg]
        else:
            normalised.append(dict(item))
    return normalised


def _build_properties(finding: Mapping[str, Any]) -> Dict[str, Any]:
    properties: Dict[str, Any] = {
        "payload": finding.get("payload"),
        "protocol": (finding.get("vector") or {}).get("protocol")
        if isinstance(finding.get("vector"), Mapping)
        else None,
    }

    cwe = finding.get("cwe")
    if cwe:
        properties["cwe"] = cwe

    cvss = finding.get("cvss") or {}
    if isinstance(cvss, Mapping):
        base = cvss.get("base_score")
        if base is not None:
            properties["cvssBaseScore"] = base
        vector = cvss.get("vector")
        if vector:
            properties["cvssVector"] = vector
        severity = cvss.get("severity")
        if severity:
            properties["cvssSeverity"] = severity
        metrics = cvss.get("metrics")
        if metrics:
            properties["cvssMetrics"] = metrics

    return {k: v for k, v in properties.items() if v is not None}


def to_sarif(items: Iterable[Finding | Mapping[str, Any]]) -> str:
    """Return a SARIF JSON document for *items*."""

    normalised = _coerce_items(items)
    results = []
    for finding in normalised:
        evidence = finding.get("evidence") or {}
        if not isinstance(evidence, Mapping):
            evidence = {}
        message = evidence.get("snippet") or finding.get("detail") or "finding"

        severity = (finding.get("severity") or "").lower()
        level = "warning"
        if severity in {"high", "critical"}:
            level = "error"

        locations = [
            {
                "physicalLocation": {
                    "artifactLocation": {"uri": finding.get("url", "")},
                }
            }
        ]

        results.append(
            {
                "ruleId": finding.get("rule_id", "OPR"),
                "level": level,
                "message": {"text": message},
                "locations": locations,
                "properties": _build_properties(finding),
            }
        )

    sarif = {
        "version": "2.1.0",
        "runs": [
            {
                "tool": {"driver": {"name": "warprecon-m"}},
                "results": results,
            }
        ],
    }
    return json.dumps(sarif, ensure_ascii=False, indent=2)


def export_sarif(workdir: Path, items: Iterable[Finding | Mapping[str, Any]]) -> str:
    """Write *items* to ``out.sarif`` inside ``workdir`` and return the path."""

    out_path = Path(workdir) / "out.sarif"
    out_path.write_text(to_sarif(items), encoding="utf-8")
    return str(out_path)


__all__ = ["to_sarif", "export_sarif"]
