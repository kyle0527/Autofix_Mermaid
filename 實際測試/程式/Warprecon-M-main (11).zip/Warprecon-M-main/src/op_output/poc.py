from __future__ import annotations
from pathlib import Path
from typing import Dict, Tuple
import json, shlex
def make_curl(f: Dict) -> str:
    url = shlex.quote(f.get("url") or f.get("target", ""))
    vec = f.get("vector", {}) or {}
    loc = vec.get("location")
    param = vec.get("param") or "q"
    payload = f.get("payload", "")
    if loc in {"form", "json"}:
        if loc == "form":
            field = shlex.quote(f"{param}={payload}")
            return f"curl -i -X POST --data-urlencode {field} {url}"
        else:
            data = shlex.quote(json.dumps({param: payload}))
            return f"curl -i -X POST -H 'Content-Type: application/json' --data {data} {url}"
    elif loc in {"header", "cookie"}:
        if loc == "header":
            hdr = shlex.quote(f"{param}: {payload}")
            return f"curl -i -H {hdr} {url}"
        else:
            ck = shlex.quote(f"Cookie: {param}={payload}")
            return f"curl -i -H {ck} {url}"
    else:
        return f"curl -i {url}"
def make_requests_py(f: Dict) -> str:
    url = f.get("url") or f.get("target",""); vec = f.get("vector",{}) or {}
    loc = vec.get("location"); param = vec.get("param") or "q"; payload = f.get("payload","")
    if loc=="form": body = f"res = s.post(url, data={{'{param}': payload}}, timeout=15)"
    elif loc=="json": body = f"res = s.post(url, json={{'{param}': payload}}, timeout=15)"
    elif loc=="header": body = f"res = s.get(url, headers={{'{param}': payload}}, timeout=15)"
    elif loc=="cookie": body = f"res = s.get(url, cookies={{'{param}': payload}}, timeout=15)"
    else: body = "res = s.get(url, timeout=15)"
    return f'''import requests
url = {url!r}
payload = {payload!r}
with requests.Session() as s:
    {body}
    print(res.status_code)
    print(res.text[:400])
'''
def write_poc_files(workdir: Path, f: Dict, idx: int) -> Tuple[str,str]:
    pocdir = workdir/"poc"; pocdir.mkdir(parents=True, exist_ok=True)
    ps1 = pocdir/f"poc_{idx:02d}.ps1"; py  = pocdir/f"poc_{idx:02d}.py"
    ps1.write_text(make_curl(f)+"\n", encoding="utf-8")
    py.write_text(make_requests_py(f), encoding="utf-8")
    return str(ps1), str(py)
