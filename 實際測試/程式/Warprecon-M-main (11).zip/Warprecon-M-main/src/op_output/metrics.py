from __future__ import annotations
from pathlib import Path
import json

def export_metrics_html(workdir: Path) -> str:
    mpath = None
    for name in ("metrics.jsonl", "metrics.json"):
        candidate = workdir / name
        if candidate.exists():
            mpath = candidate
            break
    if mpath is None:
        return ""
    if mpath.suffix == ".jsonl":
        lines = [ln for ln in mpath.read_text(encoding="utf-8").splitlines() if ln.strip()]
        if not lines:
            return ""
        m = json.loads(lines[-1])
    else:
        m = json.loads(mpath.read_text(encoding="utf-8"))
    def _fmt(v):
        return "-" if v is None else (str(round(float(v),3)) if isinstance(v,(int,float)) else str(v))
    html = (
        "<!doctype html><meta charset=\"utf-8\"><title>Metrics</title>"
        "<style>body{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:20px} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px} th{background:#f6f6f6}</style>"
        "<h1>Run Metrics</h1>"
        "<table>"
        "<tr><th>Start</th><td>"+_fmt(m.get("start_ts"))+"</td></tr>"
        "<tr><th>First Hit (s)</th><td>"+_fmt((m.get("first_hit_ts") or 0) - (m.get("start_ts") or 0))+"</td></tr>"
        "<tr><th>TTFP (s)</th><td>"+_fmt(m.get("ttfp_seconds"))+"</td></tr>"
        "<tr><th>Duration (s)</th><td>"+_fmt(m.get("duration_seconds"))+"</td></tr>"
        "<tr><th>Total Hits</th><td>"+_fmt(m.get("hits"))+"</td></tr>"
        "<tr><th>Confirmed Hits</th><td>"+_fmt(m.get("confirmed_hits"))+"</td></tr>"
        "</table>"
    )
    out = workdir / "report_metrics.html"
    out.write_text(html, encoding="utf-8")
    return str(out)
