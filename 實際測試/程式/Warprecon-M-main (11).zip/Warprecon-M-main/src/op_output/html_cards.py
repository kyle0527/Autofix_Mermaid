from __future__ import annotations
from typing import List, Dict
from pathlib import Path
import html, json


def _chip(txt: str) -> str:
    return f'<span class="chip">{html.escape(str(txt))}</span>'


def _card(i: int, f: Dict) -> str:
    sev = str(f.get("severity", "info")).upper()
    tgt = str(f.get("url") or f.get("target") or "")
    payload = (f.get("payload") or "")[:240]
    score = str(round(float(f.get("_score", 0)), 2))
    cf = "✅" if f.get("_confirmed") else ""
    proto = (f.get("vector", {}) or {}).get("protocol", "")
    tool = str(f.get("tool", ""))
    tags = "".join([_chip(sev), _chip(proto), _chip(tool)])
    ev = f.get("evidence", {}) or {}
    snippet = str(
        ev.get("snippet")
        or ev.get("details")
        or ev.get("confirm_status_5xx")
        or ""
    )[:240]
    j = html.escape(json.dumps(ev, ensure_ascii=False)[:2000])
    ev_html = (
        f'<details class="ev"><summary>Evidence</summary><pre>{j}</pre></details>'
        if j
        else ""
    )
    parts = [
        f'<div class="card" data-sev="{html.escape(sev)}" data-proto="{html.escape(str(proto))}">',
        f'<div class="head"><span class="rank">{i}</span>'
        f'<span class="sev {html.escape(sev)}">{html.escape(sev)}</span>'
        f'<span class="score">Score {score}</span><span class="cf">{cf}</span></div>',
        f'<div class="tags">{tags}</div>',
        f'<div class="payload"><code>{html.escape(payload)}</code></div>',
        f'<div class="target"><a href="{html.escape(tgt)}" target="_blank">{html.escape(tgt)}</a></div>',
        ev_html,
        f'<div class="snippet">{html.escape(snippet)}</div>',
        "</div>",
    ]
    return "".join(parts)


def export_html_cards(
    workdir: Path,
    ranked: List[Dict],
    group_by: str = "severity",
    limit_per_group: int = 50,
) -> str:
    out = workdir / "report_cards.html"
    groups: Dict[str, List[Dict]] = {}
    for f in ranked:
        key = str(f.get(group_by, f.get("severity", "info")))
        groups.setdefault(key, []).append(f)
    sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    ordered_keys = sorted(
        groups.keys(), key=lambda k: sev_order.get(str(k).upper(), 99)
    )
    sections: List[str] = []
    idx = 1
    for k in ordered_keys:
        items = sorted(
            groups[k], key=lambda x: float(x.get("_score", 0)), reverse=True
        )[:limit_per_group]
        cards = "".join(_card(i, f) for i, f in enumerate(items, start=idx))
        idx += len(items)
        sections.append(
            f'<details class="sec" open><summary>Group: {html.escape(str(k)).upper()} ({len(items)})</summary><div class="grid">'
            + cards
            + "</div></details>"
        )
    css = (
        "body{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px}"
        ".toolbar{display:flex;gap:8px;margin-bottom:12px}"
        "input[type=search]{flex:1;padding:6px 10px;border:1px solid #e5e7eb;border-radius:6px}"
        "select{padding:6px 10px;border:1px solid #e5e7eb;border-radius:6px}"
        ".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px}"
        ".card{border:1px solid #e5e7eb;border-radius:8px;padding:12px;background:#fff}"
        ".head{display:flex;gap:8px;align-items:center;margin-bottom:6px}"
        ".rank{font-weight:600}"
        ".sev{padding:2px 6px;border-radius:4px;background:#f3f4f6;font-size:12px}"
        ".sev.CRITICAL,.sev.HIGH{background:#fee2e2}"
        ".sev.MEDIUM{background:#fffbeb}"
        ".sev.LOW{background:#ecfeff}"
        ".score{margin-left:auto;font-size:12px;color:#6b7280}"
        ".cf{margin-left:8px}"
        ".tags{margin:6px 0}"
        ".chip{display:inline-block;margin-right:6px;padding:2px 6px;border-radius:999px;background:#f1f5f9;font-size:12px}"
        ".payload code{white-space:pre-wrap}"
        ".snippet{color:#6b7280;font-size:12px;margin-top:6px}"
        "a{text-decoration:none}"
        "summary{cursor:pointer;padding:4px 0}"
        "details.ev{margin-top:6px}"
    )
    js = (
        "const q=document.getElementById('q');const sev=document.getElementById('sev');"
        "function filt(){const t=(q.value||'').toLowerCase();const s=sev.value;document.querySelectorAll('.card').forEach(c=>{"
        "  const txt=c.innerText.toLowerCase(); const okT = t=='' || txt.includes(t);"
        "  const okS = s=='ALL' || (c.dataset.sev||'')===s; c.style.display=(okT&&okS)?'':'none';});}"
        "q.addEventListener('input',filt); sev.addEventListener('change',filt);"
    )
    toolbar = (
        "<div class=\"toolbar\"><input id=\"q\" type=\"search\" placeholder=\"Search payload/target/evidence\">"
        "<select id=\"sev\"><option>ALL</option><option>CRITICAL</option><option>HIGH</option>"
        "<option>MEDIUM</option><option>LOW</option><option>INFO</option></select></div>"
    )
    html_doc = (
        "<!doctype html><meta charset=\"utf-8\"><title>Warprecon-M Cards</title>"
        + f"<style>{css}</style>"
        + toolbar
        + "".join(sections)
        + f"<script>{js}</script>"
    )
    out.write_text(html_doc, encoding="utf-8")
    return str(out)

