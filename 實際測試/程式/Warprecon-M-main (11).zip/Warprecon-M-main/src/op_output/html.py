from __future__ import annotations
from typing import List, Dict
from pathlib import Path
import html

def _row(i: int, f: Dict) -> str:
    sev = html.escape(str(f.get("severity","info")).upper())
    tgt = html.escape(str(f.get("url") or f.get("target") or ""))
    payload = html.escape((f.get("payload") or "")[:180])
    score = str(round(float(f.get("_score",0)),2))
    rank = str(f.get("_rank", i))
    cf = "✅" if f.get("_confirmed") else ""
    return "<tr><td>"+rank+"</td><td>"+sev+"</td><td>"+score+"</td><td>"+cf+"</td><td><code>"+payload+"</code></td><td><a href=\""+tgt+"\" target=\"_blank\">"+tgt+"</a></td></tr>"

def export_html(workdir: Path, ranked: List[Dict], top_n: int = 50) -> str:
    out = workdir / "report.html"
    rows = []
    for i, f in enumerate(ranked[:top_n], start=1):
        rows.append(_row(i, f))
    pocdir = workdir / "poc"
    pocnote = ""
    if pocdir.exists():
        pocfiles = sorted([p.name for p in pocdir.glob("poc_*.*")])
        if pocfiles:
            links = "".join("<li><a href=\"poc/"+html.escape(n)+"\" download>"+html.escape(n)+"</a></li>" for n in pocfiles)
            pocnote = "<h3>PoC Files</h3><ul>"+links+"</ul>"
    tpl = (
        "<!doctype html>\n"
        "<meta charset=\"utf-8\">\n"
        "<title>Warprecon-M Report</title>\n"
        "<style>body{font-family:system-ui,Segoe UI,Arial,sans-serif} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:6px} th{background:#f6f6f6} code{white-space:pre-wrap}</style>\n"
        "<h1>Warprecon-M Report</h1>\n"
        "<p>Top Findings</p>\n"
        "<table>\n"
        "<thead><tr><th>#</th><th>SEV</th><th>SCORE</th><th>CONF</th><th>PAYLOAD</th><th>TARGET</th></tr></thead>\n"
        "<tbody>"+("".join(rows))+"</tbody>\n"
        "</table>\n"
        + pocnote
    )
    out.write_text(tpl, encoding="utf-8")
    return str(out)
