from __future__ import annotations

from pathlib import Path
from typing import Iterable
import zipfile


INCLUDE_PATTERNS: list[str] = [
    "ranked.json",
    "ranked.merged.json",
    "ranked.final.json",
    "findings.misconfig.json",
    "findings.grpc.json",
    "out.sarif",
    "report.html",
    "metrics.json",
    "metrics.jsonl",
    "events.log",
    "poc/poc_*.ps1",
    "poc/poc_*.py",
    "artifacts/**/screenshot.png",
    "artifacts/**/capture.har",
    "targets.txt",
    "history.sqlite3",
    "discovery/**",
    "schema/**",
    "oob/**",
]


def _iter_include_files(root: Path) -> Iterable[Path]:
    for pattern in INCLUDE_PATTERNS:
        for candidate in root.glob(pattern):
            if candidate.is_file():
                yield candidate


def make_deliverable_zip(workdir: Path, out_zip: Path | None = None) -> str:
    """Create a ZIP archive containing pipeline deliverables."""

    destination = out_zip or (workdir / "deliverable.zip")
    destination.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for item in _iter_include_files(workdir):
            archive.write(item, item.relative_to(workdir).as_posix())

    return str(destination)
