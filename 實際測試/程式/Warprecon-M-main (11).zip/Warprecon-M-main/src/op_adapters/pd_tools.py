from __future__ import annotations
from typing import List, Dict, Any
import re, os
from urllib.parse import urljoin, urlparse

from op_core.endpoint_heuristics import (
    extract_request_matches,
    extract_text_matches,
    is_likely_endpoint,
)

try:
    import httpx
except Exception:  # pragma: no cover
    httpx = None  # type: ignore

def _same_host(u: str, host: str) -> bool:
    try:
        return urlparse(u).netloc.split(':')[0].lower() == host.lower()
    except Exception:
        return False

def _fetch_text(url: str, client, limit: int = 800_000) -> str:
    try:
        r = client.get(url)
        return (r.text or "")[:limit]
    except Exception:
        return ""

def _discover_from_html(base: str, html: str, host: str) -> Dict[str, List[str]]:
    cand: List[str] = []
    scripts: List[str] = []
    for m in re.findall(r'(?is)<(a|script|link|form)\b[^>]+?(href|src|action)\s*=\s*["\']([^"\']+)["\']', html):
        u = urljoin(base, m[2])
        if _same_host(u, host):
            if u.lower().endswith(".js"):
                scripts.append(u)
            if is_likely_endpoint(u):
                cand.append(u)
    text = re.sub(r"(?is)<script[^>]*>.*?</script>", " ", html)
    for raw in extract_text_matches(text):
        u = urljoin(base, raw)
        if _same_host(u, host):
            cand.append(u)
    return {"candidates": list(dict.fromkeys(cand)), "scripts": list(dict.fromkeys(scripts))}

_BASEURL_PATS = [
    r'axios\.defaults\.baseURL\s*=\s*["\']([^"\']+)["\']',
    r'baseURL\s*:\s*["\']([^"\']+)["\']',
    r'window\.__env__\.(?:API_BASE|BASE_URL)\s*=\s*["\']([^"\']+)["\']',
    r'window\.__env\.(?:API_BASE|BASE_URL)\s*=\s*["\']([^"\']+)["\']',
    r'const\s+BASE_URL\s*=\s*["\']([^"\']+)["\']',
    r'process\.env\.(?:API_BASE|BASE_URL)\s*=\s*["\']([^"\']+)["\']',
]

def _parse_baseurls(js: str, base: str, host: str) -> List[str]:
    outs: List[str] = []
    for pat in _BASEURL_PATS:
        for m in re.findall(pat, js):
            u = urljoin(base, m)
            if _same_host(u, host): outs.append(u.rstrip("/"))
    return list(dict.fromkeys(outs))

def _discover_from_js(base: str, js: str, host: str, baseurls: List[str]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for raw in extract_request_matches(js):
        resolved = urljoin(base, raw)
        if not _same_host(resolved, host):
            for bu in baseurls:
                test = urljoin(bu + "/", raw.lstrip("/"))
                if _same_host(test, host):
                    resolved = test
                    break
        if _same_host(resolved, host):
            out.append({"raw": raw, "resolved": resolved})
    seen=set(); uniq=[]
    for e in out:
        k=(e["raw"], e["resolved"])
        if k not in seen:
            seen.add(k); uniq.append(e)
    return uniq

def recon_plus(domain: str):
    if httpx is None:
        roots = [f"https://{domain}", f"http://{domain}"]
        return roots, {"note":"httpx missing, roots only"}
    roots = [f"https://{domain}", f"http://{domain}"]
    alive: List[str] = []; html_cand: List[str] = []; js_cand: List[str] = []; scripts_seen: List[str] = []
    js_endpoints: List[Dict[str, Any]] = []; baseurls_all: List[str] = []
    details: Dict[str, Any] = {"roots": roots, "html_candidates": [], "js_candidates": [], "scripts": [], "baseurls": [], "js_endpoints": []}
    from urllib.parse import urlparse
    # env caps
    try: js_cap = int(os.environ.get("OP_JS_MAX_SCRIPTS","20"))
    except Exception: js_cap = 20

    with httpx.Client(follow_redirects=True, timeout=6.0) as s:
        for base in roots:
            try:
                r = s.get(base)
                if r.status_code < 500:
                    alive.append(base)
                    host = urlparse(r.url).netloc.split(':')[0]
                    html = r.text or ""
                    d = _discover_from_html(str(r.url), html, host)
                    html_cand += d["candidates"]; scripts_seen += d["scripts"]
                    for su in d["scripts"][:js_cap]:
                        try:
                            js = _fetch_text(su, s)
                            bus = _parse_baseurls(js, str(r.url), host)
                            baseurls_all += bus
                            items = _discover_from_js(str(r.url), js, host, baseurls_all)
                            for it in items:
                                it["from_script"] = su
                            js_endpoints += items
                            js_cand += [it["resolved"] for it in items]
                        except Exception:
                            pass
            except Exception:
                continue
    targets = list(dict.fromkeys(alive + html_cand + js_cand))
    details["html_candidates"] = list(dict.fromkeys(html_cand))
    details["js_candidates"] = list(dict.fromkeys(js_cand))
    details["scripts"] = list(dict.fromkeys(scripts_seen))
    details["baseurls"] = list(dict.fromkeys(baseurls_all))
    details["js_endpoints"] = js_endpoints
    return (targets or roots), details
