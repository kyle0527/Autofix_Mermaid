from __future__ import annotations
"""
op_adapters.pd_wrappers
A thin, optional wrapper around ProjectDiscovery tools (subfinder/naabu/httpx).
- Auto-detects availability (shutil.which).
- Falls back gracefully when tools are not installed.
- Emits discovery artifacts under: {workdir}/discovery/
- Produces: targets.txt (one URL per line) and pd.jsonl (ndjson of intermediate steps).
"""
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import subprocess, shutil, json, sys, os

def _run(cmd: List[str], input_data: Optional[bytes]=None, timeout: int=120) -> Tuple[int, bytes, bytes]:
    try:
        p = subprocess.run(cmd, input=input_data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, check=False)
        return p.returncode, p.stdout, p.stderr
    except Exception as e:
        return 1, b"", str(e).encode("utf-8", errors="ignore")

def _which(name: str) -> Optional[str]:
    return shutil.which(name)

def run_subfinder(domain: str) -> List[str]:
    exe = _which("subfinder")
    if not exe:
        return []
    code, out, err = _run([exe, "-silent", "-d", domain], timeout=180)
    if code != 0:
        return []
    subs = [ln.strip() for ln in out.decode("utf-8", errors="ignore").splitlines() if ln.strip()]
    return subs

def run_naabu(hosts: List[str]) -> Dict[str, List[int]]:
    exe = _which("naabu")
    if not exe or not hosts:
        return {}
    inp = ("\n".join(hosts) + "\n").encode("utf-8")
    code, out, err = _run([exe, "-silent", "-nc"], input_data=inp, timeout=240)
    if code != 0:
        return {}
    d: Dict[str, List[int]] = {}
    for ln in out.decode("utf-8", errors="ignore").splitlines():
        ln = ln.strip()
        if not ln: continue
        # format: host:port
        if ":" in ln:
            h, p = ln.rsplit(":", 1)
            try:
                port = int(p)
            except ValueError:
                continue
            d.setdefault(h, []).append(port)
    return d

def run_httpx(hostports: Dict[str, List[int]]) -> List[str]:
    exe = _which("httpx")
    urls: List[str] = []
    if not hostports:
        return urls
    lines = []
    for h, ports in hostports.items():
        for p in ports:
            # let httpx decide scheme
            lines.append(f"{h}:{p}")
    inp = ("\n".join(lines) + "\n").encode("utf-8")
    if exe:
        code, out, err = _run([exe, "-silent", "-probe", "-no-color", "-status-code", "-follow-redirects"], input_data=inp, timeout=300)
        if code == 0:
            for ln in out.decode("utf-8", errors="ignore").splitlines():
                # httpx prints URL [code]; keep the URL part
                u = ln.split(" ", 1)[0].strip()
                if u.startswith("http://") or u.startswith("https://"):
                    urls.append(u)
            return list(dict.fromkeys(urls))
    # fallback: naive URLs if httpx is missing
    for h, ports in hostports.items():
        for p in ports:
            if p == 443:
                urls.append(f"https://{h}")
            elif p == 80:
                urls.append(f"http://{h}")
            else:
                urls.append(f"http://{h}:{p}")
    return list(dict.fromkeys(urls))

def recon_pd(domain: str, workdir: Path) -> Tuple[List[str], Path]:
    workdir.mkdir(parents=True, exist_ok=True)
    disc_dir = workdir / "discovery"
    disc_dir.mkdir(parents=True, exist_ok=True)
    ndjson_path = disc_dir / "pd.jsonl"
    with ndjson_path.open("w", encoding="utf-8") as w:
        # 1. subfinder
        subs = run_subfinder(domain)
        w.write(json.dumps({"step":"subfinder","count":len(subs)}) + "\n")
        # 2. naabu
        hp = run_naabu(subs or [domain])
        w.write(json.dumps({"step":"naabu","hosts":len(hp),"pairs":sum(len(v) for v in hp.values())}) + "\n")
        # 3. httpx
        urls = run_httpx(hp or {domain:[80,443]})
        w.write(json.dumps({"step":"httpx","urls":len(urls)}) + "\n")
    targets = workdir / "targets.txt"
    targets.write_text("\n".join(urls) + ("\n" if urls else ""), encoding="utf-8")
    return urls, targets

def _cli() -> None:
    import argparse
    ap = argparse.ArgumentParser(description="ProjectDiscovery wrappers → targets.txt")
    ap.add_argument("--domain", required=True)
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()
    urls, t = recon_pd(args.domain, Path(args.workdir))
    sys.stdout.write(json.dumps({"urls": len(urls), "targets": str(t)}, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    _cli()
