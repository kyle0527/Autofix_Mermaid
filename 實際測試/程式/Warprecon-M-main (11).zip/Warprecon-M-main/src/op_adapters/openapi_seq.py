from __future__ import annotations

import json
from pathlib import Path
from typing import List

try:  # pragma: no cover - optional dependency
    import yaml
except Exception:  # pragma: no cover
    yaml = None  # type: ignore


def _extract_paths(text: str) -> List[str]:
    paths: List[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("/") and stripped.endswith(":"):
            paths.append(stripped[:-1])
    return paths


def _extract_paths_yaml(doc: dict) -> List[str]:
    paths: List[str] = []
    try:
        paths = list(doc.get("paths", {}).keys())
    except Exception:
        pass
    return paths


def process_openapi(
    spec_path: Path,
    workdir: Path,
    server_override: str | None = None,
) -> List[str]:
    """Parse an OpenAPI spec and return request targets.

    The parser attempts to use :mod:`yaml` for full YAML support when the
    dependency is installed.  It falls back to a lightweight textual scan, which
    handles the tiny subset needed by the unit tests.
    """
    text = Path(spec_path).read_text(encoding="utf-8")
    paths: List[str] = []
    servers: List[str] = []
    if yaml is not None:
        try:  # pragma: no cover - simple parse
            doc = yaml.safe_load(text)
            paths = _extract_paths_yaml(doc)
            if server_override:
                servers = [server_override]
            else:
                servers = [s.get("url", "") for s in doc.get("servers", [])]
        except Exception:
            paths = []
            servers = []
    if not paths:
        paths = _extract_paths(text)
    if not servers:
        servers = [server_override or ""]
    targets: List[str] = []
    for srv in servers:
        for p in paths:
            targets.append(f"{srv}{p}")
    return targets


def execute_sequences(
    spec_path: Path,
    workdir: Path,
    server_override: str | None = None,
) -> None:
    """Write a discovery file describing the sequences that would be executed."""
    workdir = Path(workdir)
    disc = workdir / "discovery"
    disc.mkdir(parents=True, exist_ok=True)
    targets = process_openapi(spec_path, workdir, server_override)
    content = json.dumps({"targets": targets}, ensure_ascii=False, indent=2)
    (disc / "openapi-seqs.json").write_text(content, encoding="utf-8")
