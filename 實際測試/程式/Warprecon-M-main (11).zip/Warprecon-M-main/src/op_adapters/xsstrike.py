from __future__ import annotations

import re
import subprocess
from typing import Dict, List

from op_adapters.errors import ExternalToolNotInstalledError

def run_xsstrike(url: str, timeout: int = 120) -> List[Dict]:
    cmd = ["xsstrike", "-u", url, "--crawl", "--skip-dom"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        output = (res.stdout or "") + (res.stderr or "")
    except FileNotFoundError as exc:
        raise ExternalToolNotInstalledError("xsstrike") from exc
    except subprocess.TimeoutExpired as e:
        snippet = ((e.stdout or "") + (e.stderr or ""))[-800:]
        if not snippet:
            snippet = f"xsstrike timed out after {timeout}s"

        return [{
            "target": url,
            "vector": {"protocol":"http","location":"query","param":None},
            "payload": "xsstrike-auto",
            "tool": "xsstrike",
            "evidence": {"error":"timeout"},
            "severity": "info",
            "url": url
        }]
    
    hits = bool(re.search(r"Reflected|Stored", output, re.I))
    
    if hits:
        return [{
            "target": url,
            "vector": {"protocol":"http","location":"query","param":None},
            "payload": "xsstrike-auto",
            "tool": "xsstrike",
            "evidence": {"snippet": output[-800:]},
            "severity": "medium",
            "url": url
        }]
    return []
