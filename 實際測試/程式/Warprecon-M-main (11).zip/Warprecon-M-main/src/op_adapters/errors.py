"""Common exceptions for adapter modules."""

from __future__ import annotations


class ExternalToolNotInstalledError(RuntimeError):
    """Raised when an external scanning utility is missing."""

    def __init__(self, tool: str, message: str | None = None) -> None:
        msg = message or f"{tool} executable not found"
        super().__init__(msg)
        self.tool = tool


__all__ = ["ExternalToolNotInstalledError"]
