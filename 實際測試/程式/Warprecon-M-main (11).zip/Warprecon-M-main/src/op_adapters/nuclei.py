from __future__ import annotations

import json
import logging
import subprocess
from typing import Any, Dict, List, Optional

from op_adapters.errors import ExternalToolNotInstalledError

logger = logging.getLogger(__name__)

_NUCLEI_VECTOR = {"protocol": "http", "location": "nuclei", "param": None}


def _build_nuclei_command(targets_file: str, templates_dir: Optional[str] = None) -> List[str]:
    """Return the command line used to invoke nuclei."""

    command = ["nuclei", "-l", targets_file, "-jsonl"]
    if templates_dir:
        command.extend(["-t", templates_dir])
    return command


def _parse_nuclei_record(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Convert a nuclei JSON line into the internal finding schema."""

    target = payload.get("host") or payload.get("matched-at")
    if not target:
        return None

    info = payload.get("info") or {}
    vector = dict(_NUCLEI_VECTOR)
    return {
        "target": target,
        "vector": vector,
        "payload": info.get("name"),
        "tool": "nuclei",
        "evidence": {
            "matcher": payload.get("matcher-name"),
            "template": payload.get("template-id"),
        },
        "severity": info.get("severity") or "medium",
        "url": payload.get("matched-at") or target,
    }


def run_nuclei(targets_file: str, templates_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    """Execute nuclei and return parsed findings."""

    command = _build_nuclei_command(targets_file, templates_dir)
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except FileNotFoundError as exc:
        raise ExternalToolNotInstalledError("nuclei") from exc

    if process.stdout is None:  # pragma: no cover - defensive guard
        process.kill()
        raise RuntimeError("nuclei stdout not available")

    results: List[Dict[str, Any]] = []
    diagnostics: List[str] = []

    for raw_line in process.stdout:
        line = raw_line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            diagnostics.append(line)
            continue

        record = _parse_nuclei_record(payload)
        if record:
            results.append(record)

    returncode = process.wait()
    if returncode != 0:
        message = f"nuclei exited with status {returncode}"
        if diagnostics:
            message = f"{message}; last output: {diagnostics[-1]}"
        logger.warning(message)
        raise RuntimeError(message)

    return results


__all__ = ["run_nuclei"]
