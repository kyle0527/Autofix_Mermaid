from __future__ import annotations

import re
from typing import Dict

try:  # pragma: no cover - optional dependency
    import httpx
except Exception:  # pragma: no cover
    httpx = None  # type: ignore


def extract_hints_with_playwright(
    url: str,
    timeout: float = 1.0,
) -> Dict[str, str]:
    """Retrieve simple DOM hints from *url* without requiring Playwright.

    The helper fetches the page using :mod:`httpx` when available and extracts
    the ``<title>`` element.  It gracefully degrades to returning just the URL
    if dependencies are missing or network errors occur.
    """
    hints: Dict[str, str] = {"url": url}
    if httpx is None:
        hints["error"] = "httpx not installed"
        return hints
    try:
        r = httpx.get(url, timeout=timeout)
        m = re.search(r"<title>(.*?)</title>", r.text, re.I | re.S)
        if m:
            hints["title"] = m.group(1).strip()
    except Exception as e:  # pragma: no cover - network dependent
        hints["error"] = str(e)
    return hints
