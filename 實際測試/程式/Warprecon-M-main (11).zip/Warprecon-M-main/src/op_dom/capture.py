from __future__ import annotations

import base64
import os
from typing import Any, Dict, List
from urllib.parse import urljoin, urlparse

from op_core.endpoint_heuristics import (
    extract_request_matches,
    extract_text_matches,
    is_likely_endpoint,
)


def _same_host(url: str, host: str) -> bool:
    try:
        return urlparse(url).netloc.split(":")[0].lower() == host.lower()
    except Exception:
        return False

async def crawl_and_capture(
    domain: str,
    max_pages: int | None = None,
    max_requests: int | None = None,
) -> Dict[str, Any]:
    """Render ``domain`` with Playwright, collecting network traffic and snapshots."""

    result: Dict[str, Any] = {"requests": [], "endpoints": [], "pages": []}
    try:
        from playwright.async_api import async_playwright  # type: ignore
    except Exception:
        return result

    if max_pages is None:
        try:
            max_pages = int(os.environ.get("OP_DOM_MAX_PAGES", "5"))
        except Exception:
            max_pages = 5
    if max_requests is None:
        try:
            max_requests = int(os.environ.get("OP_DOM_MAX_REQ", "200"))
        except Exception:
            max_requests = 200

    start = f"https://{domain}"
    host = domain.split(":")[0].lower()
    seen_pages: set[str] = set()
    requests: List[Dict[str, Any]] = []
    endpoints: List[str] = []
    pages: List[Dict[str, Any]] = []

    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        def on_request(request: Any) -> None:  # pragma: no cover - depends on playwright
            try:
                url = request.url
                if len(requests) >= max_requests:
                    return
                if _same_host(url, host):
                    entry = {
                        "method": getattr(request, "method", ""),
                        "url": url,
                        "headers": getattr(request, "headers", {}),
                    }
                    try:
                        body = getattr(request, "post_data")
                        if body:
                            entry["body"] = body
                    except Exception:
                        pass
                    requests.append(entry)
                    if is_likely_endpoint(url):
                        endpoints.append(url)
            except Exception:
                return

        page.on("request", on_request)

        async def capture_page_snapshot() -> None:
            url = str(getattr(page, "url", start)) or start
            record: Dict[str, Any] = {"url": url}
            try:
                html = await page.content()
            except Exception:
                html = ""
            if html:
                record["html"] = html
                extracted = list(extract_request_matches(html)) + list(
                    extract_text_matches(html)
                )
                for raw in extracted:
                    resolved = urljoin(url, raw)
                    if _same_host(resolved, host):
                        endpoints.append(resolved)
                        record.setdefault("endpoints", []).append(resolved)
            try:
                shot = await page.screenshot(full_page=True)
            except Exception:
                shot = None
            if isinstance(shot, (bytes, bytearray)) and shot:
                record["screenshot"] = base64.b64encode(shot).decode("ascii")
            if "endpoints" in record:
                record["endpoints"] = list(dict.fromkeys(record["endpoints"]))
            pages.append(record)

        try:
            await page.goto(start, wait_until="domcontentloaded", timeout=20000)
            seen_pages.add(start)
            await capture_page_snapshot()
        except Exception:
            await browser.close()
            result["requests"] = requests
            result["endpoints"] = list(dict.fromkeys(endpoints))
            result["pages"] = pages
            return result

        try:
            hrefs = await page.eval_on_selector_all(
                "a[href]", "els => els.map(e => e.href)"
            )
            hrefs = [h for h in hrefs if isinstance(h, str) and _same_host(h, host)]
        except Exception:
            hrefs = []

        for href in hrefs:
            if len(pages) >= max_pages:
                break
            try:
                if href in seen_pages:
                    continue
                await page.goto(href, wait_until="domcontentloaded", timeout=15000)
                seen_pages.add(href)
                await capture_page_snapshot()
            except Exception:
                continue

        await context.close()
        await browser.close()

    result["requests"] = requests
    result["endpoints"] = list(dict.fromkeys(endpoints))
    result["pages"] = pages
    return result
