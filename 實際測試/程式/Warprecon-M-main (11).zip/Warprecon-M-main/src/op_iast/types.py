from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from op_core.finding_contract import Finding


def _coerce_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    if value is None:
        return {}
    try:
        return dict(value)
    except Exception:
        return {"value": value}


@dataclass
class IastFinding:
    """Structured payload emitted by an IAST agent."""

    check: str = "iast.agent"
    target: str = ""
    severity: str = "info"
    title: str = ""
    detail: str = ""
    fingerprint: str | None = None
    evidence: dict[str, Any] = field(default_factory=dict)
    location: dict[str, Any] = field(default_factory=dict)
    source: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)
    ts: float | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "IastFinding":
        data = dict(payload)
        evidence = _coerce_mapping(data.get("evidence"))
        location = _coerce_mapping(data.get("location"))
        meta = _coerce_mapping(data.get("meta"))

        detail = data.get("detail") or data.get("description") or data.get("message") or ""
        title = data.get("title") or data.get("message") or data.get("issue") or detail

        target = data.get("target") or data.get("url") or data.get("sink") or ""
        severity = str(data.get("severity", "info"))
        check = str(data.get("check") or data.get("type") or "iast.agent")

        fingerprint = data.get("fingerprint") or data.get("id") or data.get("hash")
        source = data.get("source") or data.get("agent") or data.get("module")

        ts_raw = data.get("ts") or data.get("timestamp")
        try:
            ts = float(ts_raw) if ts_raw is not None else None
        except (TypeError, ValueError):
            ts = None

        raw = dict(data)
        raw.setdefault("check", check)
        raw.setdefault("target", target)
        raw.setdefault("severity", severity)
        raw.setdefault("title", title or detail)
        raw.setdefault("detail", detail)

        return cls(
            check=str(check),
            target=str(target),
            severity=str(severity),
            title=str(title or detail),
            detail=str(detail),
            fingerprint=fingerprint if fingerprint is None else str(fingerprint),
            evidence=evidence,
            location=location,
            source=str(source) if source else None,
            meta=meta,
            ts=ts,
            raw=raw,
        )

    def to_finding(self) -> Finding:
        meta = dict(self.meta or {})
        iast_meta = dict(meta.get("iast") or {})
        if self.fingerprint:
            iast_meta["fingerprint"] = self.fingerprint
        if self.evidence:
            iast_meta["evidence"] = self.evidence
        if self.location:
            iast_meta["location"] = self.location
        if self.source:
            iast_meta["source"] = self.source
        if self.raw:
            iast_meta.setdefault("raw", self.raw)
        meta["iast"] = iast_meta

        payload: dict[str, Any] = {
            "check": self.check or "iast.agent",
            "target": self.target or "",
            "severity": (self.severity or "info").lower(),
            "title": self.title or self.detail or "IAST finding",
            "detail": self.detail or self.title or "",
            "meta": meta,
        }
        if self.ts:
            payload["ts"] = self.ts

        base_fields = {"check", "target", "severity", "title", "detail", "meta", "ts"}
        for key, value in self.raw.items():
            if key in base_fields:
                continue
            payload.setdefault(key, value)

        return Finding.from_dict(payload)


__all__ = ["IastFinding"]
