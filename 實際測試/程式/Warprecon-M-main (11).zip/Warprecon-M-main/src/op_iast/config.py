from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass
class IastConfig:
    """Normalised configuration for IAST agent orchestration."""

    enabled: bool = False
    transport: str = "embedded"
    endpoint: str | None = None
    api_key: str | None = None
    artifact_dir: str | None = None
    buffer_path: str | None = None
    startup_timeout: float = 5.0
    environment: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_obj(cls, obj: Any) -> "IastConfig":
        """Create an :class:`IastConfig` from campaign or mapping objects."""

        if isinstance(obj, cls):
            config = cls()
            config.__dict__.update(obj.__dict__)
            return config

        if obj is None:
            return cls()

        if hasattr(obj, "model_dump"):
            raw = obj.model_dump(mode="python")  # type: ignore[assignment]
        elif isinstance(obj, Mapping):
            raw = dict(obj)
        else:
            raw = {name: getattr(obj, name, None) for name in cls.__dataclass_fields__}

        config = cls()
        for name in config.__dataclass_fields__:
            if name in raw and raw[name] is not None:
                setattr(config, name, raw[name])

        config.transport = (config.transport or "embedded").lower()
        if config.environment is None:
            config.environment = {}
        return config


__all__ = ["IastConfig"]
