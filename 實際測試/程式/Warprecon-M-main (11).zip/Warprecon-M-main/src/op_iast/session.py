from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Iterable, List, Mapping, Sequence
from urllib import error as url_error
from urllib import request

from .config import IastConfig
from .types import IastFinding

logger = logging.getLogger(__name__)


class AgentTransport:
    """Minimal transport interface for retrieving IAST findings."""

    def start(self) -> None:  # pragma: no cover - interface default
        return None

    def stop(self) -> None:  # pragma: no cover - interface default
        return None

    def collect(self) -> Sequence[Mapping[str, Any]]:
        return []


class NullTransport(AgentTransport):
    pass


class EmbeddedTransport(AgentTransport):
    """Read findings from a file buffered by an embedded agent."""

    def __init__(self, config: IastConfig, workdir: Path):
        self._config = config
        self._workdir = Path(workdir)
        base_dir = Path(config.artifact_dir) if config.artifact_dir else Path("iast")
        if not base_dir.is_absolute():
            base_dir = self._workdir / base_dir
        self._base_dir = base_dir

        buffer_path = Path(config.buffer_path) if config.buffer_path else Path("findings.jsonl")
        if not buffer_path.is_absolute():
            buffer_path = self._base_dir / buffer_path
        self._buffer_path = buffer_path

    def start(self) -> None:
        try:
            self._base_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:  # pragma: no cover - filesystem failure
            logger.warning("Unable to prepare IAST buffer directory %s: %s", self._base_dir, exc)
        try:
            self._buffer_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:  # pragma: no cover - filesystem failure
            logger.warning("Unable to prepare IAST buffer path %s: %s", self._buffer_path, exc)

    def collect(self) -> Sequence[Mapping[str, Any]]:
        if not self._buffer_path.exists():
            return []
        try:
            content = self._buffer_path.read_text(encoding="utf-8")
        except OSError as exc:  # pragma: no cover - best effort
            logger.warning("Failed to read IAST buffer %s: %s", self._buffer_path, exc)
            return []

        content = content.strip()
        if not content:
            return []

        try:
            payload = json.loads(content)
        except json.JSONDecodeError:
            items: list[Mapping[str, Any]] = []
            for line in content.splitlines():
                text = line.strip()
                if not text:
                    continue
                try:
                    parsed = json.loads(text)
                except json.JSONDecodeError:
                    logger.debug("Skipping invalid IAST line: %s", text)
                    continue
                if isinstance(parsed, Mapping):
                    items.append(dict(parsed))
            return items

        if isinstance(payload, list):
            return [dict(item) for item in payload if isinstance(item, Mapping)]
        if isinstance(payload, Mapping):
            return [dict(payload)]
        return []


class HttpTransport(AgentTransport):
    """Fetch findings from a remote agent over HTTP."""

    def __init__(self, config: IastConfig):
        self._endpoint = (config.endpoint or "").rstrip("/")
        self._api_key = config.api_key
        self._timeout = max(float(config.startup_timeout or 5.0), 1.0)

    def collect(self) -> Sequence[Mapping[str, Any]]:
        if not self._endpoint:
            return []

        url = f"{self._endpoint}/findings"
        req = request.Request(url, method="GET")
        if self._api_key:
            req.add_header("Authorization", f"Bearer {self._api_key}")

        try:
            with request.urlopen(req, timeout=self._timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except (url_error.URLError, json.JSONDecodeError, OSError) as exc:
            logger.warning("IAST HTTP fetch failed for %s: %s", url, exc)
            return []

        if isinstance(payload, Mapping) and "findings" in payload:
            payload = payload["findings"]

        if isinstance(payload, list):
            return [dict(item) for item in payload if isinstance(item, Mapping)]
        if isinstance(payload, Mapping):
            return [dict(payload)]
        return []


class IastSession:
    """Lifecycle wrapper coordinating agent transports."""

    def __init__(self, config: IastConfig, transport: AgentTransport):
        self.config = config
        self._transport = transport
        self._started = False

    def __enter__(self) -> "IastSession":
        self._transport.start()
        self._started = True
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # type: ignore[override]
        try:
            self._transport.stop()
        finally:
            self._started = False

    def collect(self) -> List[IastFinding]:
        if not self._started:
            self._transport.start()
            self._started = True

        raw_items: Iterable[Mapping[str, Any]] = self._transport.collect()
        findings: List[IastFinding] = []
        for item in raw_items:
            try:
                findings.append(IastFinding.from_dict(item))
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning("Invalid IAST finding payload skipped: %s", exc)
        return findings


def create_session(config_obj: Any, workdir: Path) -> IastSession:
    """Instantiate a session for the provided configuration."""

    config = IastConfig.from_obj(config_obj)
    workdir = Path(workdir)

    if not config.enabled:
        return IastSession(config, NullTransport())

    if config.transport in {"embedded", "file"}:
        transport = EmbeddedTransport(config, workdir)
    elif config.transport in {"http", "https", "rest"}:
        transport = HttpTransport(config)
    else:
        logger.warning("Unknown IAST transport '%s', falling back to no-op", config.transport)
        transport = NullTransport()

    return IastSession(config, transport)


__all__ = ["IastSession", "create_session"]
