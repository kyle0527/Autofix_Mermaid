from __future__ import annotations
import networkx as nx
from typing import List, Dict, Tuple
IMPACTS = {
    "ssrf": "Internal Access",
    "sqli": "DB Read/Write",
    "xss": "Account Impersonation",
    "graphql": "Schema/Info Leak",
    "ws": "Realtime Abuse",
    "grpc": "Service Abuse",
}
def _mode(f: Dict) -> str:
    v = (f.get("vector",{}) or {}).get("protocol","http").lower()
    p = (f.get("payload") or "").lower()
    ev = f.get("evidence",{}) or {}
    if ev.get("oob_token"): return "ssrf"
    if "union select" in p or " or 1=1" in p: return "sqli"
    if "<script>" in p or "onload=" in p: return "xss"
    if v == "graphql": return "graphql"
    if v == "ws": return "ws"
    return v
def build_graph(findings: List[Dict]) -> nx.DiGraph:
    G = nx.DiGraph()
    for i,f in enumerate(findings, start=1):
        url = f.get("url") or f.get("target","")
        m = _mode(f); vuln = f"V{i}:{m}"
        G.add_node(url, type="asset")
        G.add_node(vuln, type="vuln", severity=f.get("severity","medium"), score=f.get("_score",0))
        G.add_edge(url, vuln, weight=max(1, 100-(f.get("_score",0))))
        impact = IMPACTS.get(m, "Impact")
        G.add_node(impact, type="impact"); G.add_edge(vuln, impact, weight=1)
    return G
def suggest_paths(G: nx.DiGraph, top_k: int = 5) -> List[Tuple[List[str], float]]:
    paths = []; assets = [n for n,d in G.nodes(data=True) if d.get("type")=="asset"]
    impacts = [n for n,d in G.nodes(data=True) if d.get("type")=="impact"]
    for a in assets:
        for b in impacts:
            try:
                p = nx.shortest_path(G, a, b, weight="weight"); w = nx.path_weight(G, p, weight="weight")
                paths.append((p, w))
            except Exception: continue
    paths.sort(key=lambda x: x[1]); return paths[:top_k]
