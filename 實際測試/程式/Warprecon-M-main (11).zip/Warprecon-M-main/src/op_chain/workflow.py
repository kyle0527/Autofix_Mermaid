from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

import httpx

from op_core.finding_contract import Finding


_TEMPLATE = re.compile(r"\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}")
_MAX_BODY_CHARS = 2048


class WorkflowError(RuntimeError):
    """Raised when a workflow manifest cannot be executed."""


@dataclass
class WorkflowStep:
    kind: str
    config: Dict[str, Any]
    name: Optional[str] = None


@dataclass
class Transition:
    target: Optional[str]
    condition: Optional[Dict[str, Any]] = None


@dataclass
class WorkflowState:
    name: str
    steps: List[WorkflowStep] = field(default_factory=list)
    transitions: List[Transition] = field(default_factory=list)


@dataclass
class Workflow:
    id: str
    entry: str
    states: Dict[str, WorkflowState]
    check: str = "chain.workflow"
    severity: str = "medium"
    description: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    default_target: Optional[str] = None
    default_finding: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    max_steps: int = 20

    @classmethod
    def from_mapping(
        cls,
        payload: Mapping[str, Any],
        *,
        source: Optional[Path] = None,
        overrides: Optional[Mapping[str, Any]] = None,
    ) -> "Workflow":
        if not isinstance(payload, Mapping):
            raise WorkflowError("workflow payload must be a mapping")

        overrides = dict(overrides or {})
        states_payload = payload.get("states") or {}
        if not isinstance(states_payload, Mapping):
            raise WorkflowError("workflow states must be a mapping")

        states: Dict[str, WorkflowState] = {}
        for state_name, raw_state in states_payload.items():
            if not isinstance(raw_state, Mapping):
                raise WorkflowError(f"state {state_name!r} must be a mapping")
            steps = _normalise_steps(raw_state.get("steps", []))
            emit_payload = raw_state.get("emit")
            if emit_payload:
                steps.append(WorkflowStep("emit", _normalise_emit(emit_payload)))
            transitions = _normalise_transitions(raw_state.get("transitions", []))
            states[state_name] = WorkflowState(state_name, steps, transitions)

        workflow_id = overrides.get("id") or payload.get("id") or payload.get("name")
        if not workflow_id:
            raise WorkflowError("workflow requires an id or name")

        entry = overrides.get("entry") or payload.get("entry") or "start"
        if entry not in states:
            raise WorkflowError(f"entry state {entry!r} is not defined")

        max_steps = overrides.get("max_steps") or payload.get("max_steps") or 20
        try:
            max_steps_int = int(max_steps)
        except (TypeError, ValueError) as exc:
            raise WorkflowError(f"invalid max_steps value {max_steps!r}") from exc
        if max_steps_int <= 0:
            raise WorkflowError("max_steps must be positive")

        metadata = {
            "source": str(source) if source else None,
            "name": payload.get("name") or overrides.get("name"),
        }

        context = {}
        context_payload = payload.get("context") or {}
        if isinstance(context_payload, Mapping):
            context.update(context_payload)
        variables_override = overrides.get("variables")
        if isinstance(variables_override, Mapping):
            context.update(variables_override)

        default_finding = {}
        finding_payload = payload.get("finding")
        if isinstance(finding_payload, Mapping):
            default_finding.update(finding_payload)

        check = overrides.get("check") or payload.get("check") or "chain.workflow"
        severity = overrides.get("severity") or payload.get("severity") or "medium"
        default_target = overrides.get("target") or payload.get("target")

        return cls(
            id=str(workflow_id),
            entry=str(entry),
            states=states,
            check=str(check),
            severity=str(severity),
            description=payload.get("description"),
            context=context,
            default_target=str(default_target) if default_target else None,
            default_finding=default_finding,
            metadata=metadata,
            max_steps=max_steps_int,
        )


@dataclass
class WorkflowRun:
    workflow: Workflow
    success: bool
    findings: List[Finding]
    trace: List[Dict[str, Any]]
    variables: Dict[str, Any]
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "workflow": {
                "id": self.workflow.id,
                "name": self.workflow.metadata.get("name"),
                "source": self.workflow.metadata.get("source"),
            },
            "success": bool(self.success),
            "variables": _serialise_json(self.variables),
            "findings": [finding.to_dict() for finding in self.findings],
            "trace": _serialise_json(self.trace),
        }
        if self.error:
            data["error"] = self.error
        return data


class WorkflowExecutor:
    """Execute workflow manifests and produce findings."""

    def __init__(
        self,
        workflow: Workflow,
        *,
        base_context: Optional[Mapping[str, Any]] = None,
        max_steps: Optional[int] = None,
    ) -> None:
        self.workflow = workflow
        self.base_context = dict(base_context or {})
        self.variables: Dict[str, Any] = dict(workflow.context)
        self.trace: List[Dict[str, Any]] = []
        self.last_result: Dict[str, Any] = {}
        self.state_success: bool = True
        self.max_steps = max_steps or workflow.max_steps
        self.findings: List[Finding] = []
        self._step_counter = 0

    async def run(self, client: httpx.AsyncClient) -> WorkflowRun:
        state_name = self.workflow.entry
        visited_states = 0
        error: Optional[str] = None
        success = False

        while state_name:
            state = self.workflow.states.get(state_name)
            if state is None:
                error = f"unknown_state:{state_name}"
                success = False
                break

            await self._execute_state(state, client)
            if self._step_counter >= self.max_steps:
                error = "max_steps_exceeded"
                success = False
                break

            if not state.transitions:
                success = self.state_success
                break

            next_state = None
            for transition in state.transitions:
                if self._evaluate_condition(transition.condition):
                    next_state = transition.target
                    break

            if not next_state:
                success = self.state_success
                break

            visited_states += 1
            if visited_states >= self.max_steps:
                error = "max_steps_exceeded"
                success = False
                break

            state_name = next_state

        return WorkflowRun(
            workflow=self.workflow,
            success=success,
            findings=list(self.findings),
            trace=list(self.trace),
            variables=dict(self.variables),
            error=error,
        )

    async def _execute_state(self, state: WorkflowState, client: httpx.AsyncClient) -> None:
        self.state_success = True
        for step in state.steps:
            result = await self._execute_step(step, client)
            self.trace.append({"state": state.name, **_serialise_json(result)})
            self.last_result = result
            self._step_counter += 1
            if not result.get("success", True):
                self.state_success = False
                break

    async def _execute_step(
        self, step: WorkflowStep, client: httpx.AsyncClient
    ) -> Dict[str, Any]:
        if step.kind == "http":
            return await self._execute_http(step, client)
        if step.kind == "assert":
            return self._execute_assert(step)
        if step.kind == "store":
            return self._execute_store(step)
        if step.kind == "emit":
            return self._execute_emit(step)
        raise WorkflowError(f"unsupported step type {step.kind!r}")

    async def _execute_http(
        self, step: WorkflowStep, client: httpx.AsyncClient
    ) -> Dict[str, Any]:
        request_cfg = step.config.get("request") or step.config
        method = str(request_cfg.get("method", "GET")).upper()
        url = self._render(request_cfg.get("url"))
        if not url:
            raise WorkflowError("http step requires a url")

        request_kwargs: Dict[str, Any] = {}
        for key in ("params", "headers", "json", "data", "content"):
            if key in request_cfg:
                request_kwargs[key] = self._render(request_cfg[key])
        timeout = request_cfg.get("timeout")
        if timeout is not None:
            request_kwargs["timeout"] = timeout

        try:
            response = await client.request(method, url, **request_kwargs)
        except httpx.HTTPError as exc:
            return {
                "action": "http",
                "name": step.name,
                "request": {"method": method, "url": url},
                "success": False,
                "reason": str(exc),
                "error": {"type": exc.__class__.__name__, "message": str(exc)},
            }

        try:
            body_text = response.text
        except Exception:
            body_text = ""
        summary: Dict[str, Any] = {
            "action": "http",
            "name": step.name,
            "request": {"method": method, "url": str(response.request.url)},
            "response": {
                "status": response.status_code,
                "headers": dict(response.headers),
                "body": body_text[:_MAX_BODY_CHARS],
            },
        }

        json_payload: Any
        try:
            json_payload = response.json()
        except Exception:
            json_payload = None
        summary["response"]["json"] = json_payload

        expect_cfg = step.config.get("expect")
        success = True
        reason: Optional[str] = None
        if isinstance(expect_cfg, Mapping):
            success, reason = self._evaluate_expect(expect_cfg, summary)

        capture_cfg = step.config.get("capture")
        captures: Dict[str, Any] = {}
        if isinstance(capture_cfg, Mapping):
            for key, expr in capture_cfg.items():
                captures[key] = self._capture(expr, summary)
            self.variables.update({k: v for k, v in captures.items() if v is not None})

        summary["success"] = success
        if reason:
            summary["reason"] = reason
        if captures:
            summary["captures"] = captures

        return summary

    def _execute_assert(self, step: WorkflowStep) -> Dict[str, Any]:
        expect_cfg = step.config.get("expect") or step.config
        if not isinstance(expect_cfg, Mapping):
            raise WorkflowError("assert step requires an expect mapping")
        success, reason = self._evaluate_expect(expect_cfg, self.last_result)
        result = {"action": "assert", "name": step.name, "success": success}
        if reason:
            result["reason"] = reason
        return result

    def _execute_store(self, step: WorkflowStep) -> Dict[str, Any]:
        assignments = step.config.get("values") or step.config
        if not isinstance(assignments, Mapping):
            raise WorkflowError("store step requires a mapping")
        stored: Dict[str, Any] = {}
        for key, value in assignments.items():
            stored[key] = self._render(value)
        self.variables.update(stored)
        return {"action": "store", "name": step.name, "success": True, "values": stored}

    def _execute_emit(self, step: WorkflowStep) -> Dict[str, Any]:
        finding_cfg = dict(self.workflow.default_finding)
        finding_cfg.update(step.config)
        payload = {
            "check": finding_cfg.get("check") or self.workflow.check,
            "severity": finding_cfg.get("severity") or self.workflow.severity,
            "title": self._render(finding_cfg.get("title")),
            "detail": self._render(finding_cfg.get("detail")),
        }
        meta_payload = finding_cfg.get("meta") or {}
        if isinstance(meta_payload, Mapping):
            payload["meta"] = _serialise_json(self._render(meta_payload))
        target_candidate = (
            finding_cfg.get("target")
            or self.workflow.default_target
            or self.base_context.get("target")
            or self.base_context.get("base_url")
        )
        if target_candidate is not None:
            payload["target"] = self._render(target_candidate)
        
        finding = Finding(**{k: v for k, v in payload.items() if v is not None})
        finding.meta.setdefault("workflow", {})
        finding.meta["workflow"].update(
            {
                "id": self.workflow.id,
                "name": self.workflow.metadata.get("name"),
            }
        )
        finding.meta.setdefault("trace", list(self.trace))
        self.findings.append(finding)
        return {"action": "emit", "name": step.name, "success": True}

    def _evaluate_expect(
        self, expect_cfg: Mapping[str, Any], result: Mapping[str, Any]
    ) -> tuple[bool, Optional[str]]:
        success = True
        reasons: List[str] = []
        response = result.get("response") if isinstance(result, Mapping) else None

        if "status" in expect_cfg and response:
            expected_status = expect_cfg["status"]
            statuses = _ensure_iterable(expected_status)
            status_values = [int(self._render(item)) for item in statuses]
            actual_status = int(response.get("status", 0)) if isinstance(response, Mapping) else 0
            if actual_status not in status_values:
                success = False
                reasons.append(f"status:{actual_status}")

        if "contains" in expect_cfg and response:
            haystack = ""
            if isinstance(response, Mapping):
                haystack = str(response.get("body") or "")
            for needle in _ensure_iterable(expect_cfg["contains"]):
                rendered = str(self._render(needle))
                if rendered not in haystack:
                    success = False
                    reasons.append(f"missing:{rendered}")

        if "absent" in expect_cfg and response:
            haystack = ""
            if isinstance(response, Mapping):
                haystack = str(response.get("body") or "")
            for text in _ensure_iterable(expect_cfg["absent"]):
                rendered = str(self._render(text))
                if rendered in haystack:
                    success = False
                    reasons.append(f"present:{rendered}")

        if "json" in expect_cfg and response:
            response_json = response.get("json") if isinstance(response, Mapping) else None
            if response_json is None:
                success = False
                reasons.append("json:none")
            else:
                json_expect = expect_cfg["json"]
                if isinstance(json_expect, Mapping):
                    for path, expected in json_expect.items():
                        actual = _resolve_path(response_json, str(path))
                        rendered = self._render(expected)
                        if actual != rendered:
                            success = False
                            reasons.append(f"json:{path}")

        if "success" in expect_cfg:
            desired = bool(expect_cfg["success"])
            current = bool(result.get("success", False)) if isinstance(result, Mapping) else False
            if desired != current:
                success = False
                reasons.append("success-state")

        reason = ",".join(reasons) if reasons else None
        return success, reason

    def _capture(self, expr: Any, summary: Mapping[str, Any]) -> Any:
        if isinstance(expr, Mapping):
            if "regex" in expr:
                pattern = str(expr["regex"])
                body = ""
                response = summary.get("response")
                if isinstance(response, Mapping):
                    body = str(response.get("body") or "")
                match = re.search(pattern, body)
                if not match:
                    return None
                group = expr.get("group", 1)
                try:
                    return match.group(int(group))
                except (IndexError, ValueError):
                    return match.group(0)
            if "path" in expr:
                payload = summary.get(expr.get("source", "response"))
                return _resolve_path(payload, expr["path"])
        if isinstance(expr, str):
            if expr.startswith("json."):
                response = summary.get("response")
                if isinstance(response, Mapping):
                    return _resolve_path(response.get("json"), expr[5:])
            if expr.startswith("headers."):
                response = summary.get("response")
                if isinstance(response, Mapping):
                    headers = response.get("headers")
                    if isinstance(headers, Mapping):
                        return headers.get(expr[8:])
            if expr in {"status", "url", "body"}:
                response = summary.get("response")
                if isinstance(response, Mapping):
                    return response.get(expr)
            if expr.startswith("last."):
                return _resolve_path(self.last_result, expr[5:])
            return self._render(expr)
        return expr

    def _evaluate_condition(self, condition: Optional[Mapping[str, Any]]) -> bool:
        if not condition:
            return True
        if condition.get("success") is True and not self.state_success:
            return False
        if condition.get("failure") is True and self.state_success:
            return False

        for item in _ensure_iterable(condition.get("equals", [])):
            if not isinstance(item, Mapping):
                continue
            var_name = str(item.get("var"))
            expected = self._render(item.get("value"))
            if self._resolve(var_name) != expected:
                return False

        for item in _ensure_iterable(condition.get("contains", [])):
            if not isinstance(item, Mapping):
                continue
            var_name = str(item.get("var"))
            needle = str(self._render(item.get("value")))
            haystack = self._resolve(var_name)
            if needle not in str(haystack or ""):
                return False

        for var_name in _ensure_iterable(condition.get("exists", [])):
            if self._resolve(str(var_name)) in (None, "", [], {}):
                return False

        for var_name in _ensure_iterable(condition.get("not_exists", [])):
            value = self._resolve(str(var_name))
            if value not in (None, "", [], {}):
                return False

        all_conditions = condition.get("all", [])
        for child in _ensure_iterable(all_conditions):
            if not isinstance(child, Mapping):
                continue
            if not self._evaluate_condition(child):
                return False

        any_conditions = condition.get("any")
        if any_conditions:
            matched = False
            for child in _ensure_iterable(any_conditions):
                if isinstance(child, Mapping) and self._evaluate_condition(child):
                    matched = True
                    break
            if not matched:
                return False

        return True

    def _render(self, value: Any) -> Any:
        if isinstance(value, str):
            return _render_template(value, self._env())
        if isinstance(value, Mapping):
            return {k: self._render(v) for k, v in value.items()}
        if isinstance(value, (list, tuple, set)):
            return type(value)(self._render(v) for v in value)
        return value

    def _env(self) -> Dict[str, Any]:
        env: Dict[str, Any] = {
            **self.base_context,
            **self.variables,
            "vars": self.variables,
            "workflow": {
                "id": self.workflow.id,
                "name": self.workflow.metadata.get("name"),
            },
            "last": self.last_result,
        }
        return env

    def _resolve(self, path: str) -> Any:
        if not path:
            return None
        env = self._env()
        return _resolve_path(env, path)


def _normalise_steps(raw_steps: Any) -> List[WorkflowStep]:
    steps: List[WorkflowStep] = []
    if not raw_steps:
        return steps
    if not isinstance(raw_steps, Sequence):
        raise WorkflowError("state steps must be a sequence")
    for item in raw_steps:
        if isinstance(item, WorkflowStep):
            steps.append(item)
            continue
        if not isinstance(item, Mapping):
            raise WorkflowError("step entries must be mappings")
        if "http" in item:
            cfg = item["http"]
            if not isinstance(cfg, Mapping):
                raise WorkflowError("http step requires a mapping")
            steps.append(WorkflowStep("http", dict(cfg), name=str(cfg.get("name")) if cfg.get("name") else None))
            continue
        if "assert" in item:
            cfg = item["assert"]
            if not isinstance(cfg, Mapping):
                raise WorkflowError("assert step requires a mapping")
            steps.append(WorkflowStep("assert", dict(cfg), name=str(cfg.get("name")) if cfg.get("name") else None))
            continue
        if "store" in item:
            cfg = item["store"]
            if not isinstance(cfg, Mapping):
                raise WorkflowError("store step requires a mapping")
            steps.append(WorkflowStep("store", dict(cfg), name=str(cfg.get("name")) if cfg.get("name") else None))
            continue
        if "emit" in item:
            cfg = item["emit"]
            if not isinstance(cfg, Mapping):
                raise WorkflowError("emit step requires a mapping")
            steps.append(WorkflowStep("emit", dict(cfg), name=str(cfg.get("name")) if cfg.get("name") else None))
            continue
        step_type = item.get("type")
        if step_type:
            cfg = dict(item)
            cfg.pop("type", None)
            steps.append(WorkflowStep(str(step_type), cfg, name=str(cfg.get("name")) if cfg.get("name") else None))
            continue
        raise WorkflowError("unable to determine step type")
    return steps


def _normalise_emit(payload: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise WorkflowError("emit payload must be a mapping")
    return dict(payload)


def _normalise_transitions(raw: Any) -> List[Transition]:
    transitions: List[Transition] = []
    if not raw:
        return transitions
    if not isinstance(raw, Sequence):
        raise WorkflowError("transitions must be a sequence")
    for item in raw:
        if isinstance(item, Transition):
            transitions.append(item)
            continue
        if not isinstance(item, Mapping):
            raise WorkflowError("transition entries must be mappings")
        target = item.get("target")
        if target is not None:
            target = str(target)
        condition = item.get("when")
        if isinstance(condition, str):
            condition = {condition: True}
        elif condition is not None and not isinstance(condition, Mapping):
            raise WorkflowError("transition condition must be mapping or string")
        transitions.append(Transition(target=target, condition=dict(condition) if condition else None))
    return transitions


def _render_template(value: str, env: Mapping[str, Any]) -> str:
    def replace(match: re.Match[str]) -> str:
        key = match.group(1)
        resolved = _resolve_path(env, key)
        if resolved is None:
            return ""
        if isinstance(resolved, (dict, list)):
            return json.dumps(resolved, ensure_ascii=False)
        return str(resolved)

    return _TEMPLATE.sub(replace, value)


def _resolve_path(data: Any, path: str) -> Any:
    if not path:
        return data
    parts = [part for part in str(path).split(".") if part]
    current: Any = data
    for part in parts:
        if isinstance(current, Mapping):
            current = current.get(part)
        elif isinstance(current, Sequence) and not isinstance(current, (str, bytes)):
            try:
                index = int(part)
            except ValueError:
                return None
            if index < 0 or index >= len(current):
                return None
            current = current[index]
        else:
            return None
    return current


def _ensure_iterable(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return [value]


def _serialise_json(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {k: _serialise_json(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_serialise_json(v) for v in value]
    if isinstance(value, tuple):
        return [_serialise_json(v) for v in value]
    if isinstance(value, set):
        return [_serialise_json(v) for v in value]
    return value


async def execute_workflow(
    workflow: Workflow,
    *,
    client: Optional[httpx.AsyncClient] = None,
    base_context: Optional[Mapping[str, Any]] = None,
    max_steps: Optional[int] = None,
) -> WorkflowRun:
    owns_client = client is None
    if owns_client:
        client = httpx.AsyncClient(follow_redirects=True)
    assert client is not None
    try:
        executor = WorkflowExecutor(workflow, base_context=base_context, max_steps=max_steps)
        return await executor.run(client)
    finally:
        if owns_client:
            await client.aclose()


def load_workflow_file(path: Path, *, overrides: Optional[Mapping[str, Any]] = None) -> Workflow:
    text = path.read_text(encoding="utf-8")
    data: Any
    if path.suffix.lower() in {".yaml", ".yml"}:
        import yaml  # type: ignore

        data = yaml.safe_load(text) or {}
    else:
        data = json.loads(text)
    if not isinstance(data, Mapping):
        raise WorkflowError("workflow file must contain a mapping")
    return Workflow.from_mapping(data, source=path, overrides=overrides)


__all__ = [
    "Workflow",
    "WorkflowState",
    "WorkflowStep",
    "WorkflowRun",
    "WorkflowExecutor",
    "WorkflowError",
    "execute_workflow",
    "load_workflow_file",
]
