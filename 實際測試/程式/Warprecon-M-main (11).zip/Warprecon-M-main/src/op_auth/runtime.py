from __future__ import annotations

"""Runtime helpers for translating account pools into auth strategies."""

import base64
import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, MutableMapping, Optional

import httpx

from . import AuthStrategy
from .accounts import (
    AccountEntry,
    AccountPool,
    AccountProfile,
    LoginFlow,
    RefreshPolicy,
    SessionArtifacts,
    load_account_sources,
)

logger = logging.getLogger(__name__)


def _token_expiry_from_jwt(token: str | None) -> float | None:
    if not token or token.count(".") != 2:
        return None
    header, payload, _ = token.split(".", 2)
    if not payload:
        return None
    padding = "=" * (-len(payload) % 4)
    try:
        decoded = base64.urlsafe_b64decode(payload + padding)
        data = json.loads(decoded.decode("utf-8"))
    except Exception:  # pragma: no cover - malformed token
        return None
    exp = data.get("exp")
    if isinstance(exp, (int, float)):
        return float(exp)
    return None


def _extract_json_path(data: Any, path: str | None) -> Any:
    if not path:
        return None
    current = data
    for element in path.split("."):
        if isinstance(current, Mapping):
            current = current.get(element)
        else:
            return None
    return current


def _coerce_headers(headers: Mapping[str, str] | None) -> Dict[str, str]:
    result: Dict[str, str] = {}
    if not headers:
        return result
    for key, value in headers.items():
        if value is None:
            continue
        result[str(key)] = str(value)
    return result


def _merge_artifacts(
    base: SessionArtifacts,
    *,
    headers: Mapping[str, str] | None = None,
    cookies: Mapping[str, Any] | None = None,
    token: str | None = None,
) -> None:
    if headers:
        base.headers.update({str(k): str(v) for k, v in headers.items()})
    if cookies:
        base.cookies.update({str(k): str(v) for k, v in cookies.items()})
    if token is not None:
        base.token = token


class AccountStrategy(AuthStrategy):
    """Auth strategy backed by :class:`AccountEntry` definitions."""

    def __init__(
        self,
        entry: AccountEntry,
        *,
        workdir: Path,
        request_timeout: float = 10.0,
    ) -> None:
        self.entry = entry
        self.workdir = Path(workdir)
        self.request_timeout = float(request_timeout)
        self.artifacts = SessionArtifacts(
            headers=dict(entry.artifacts.headers),
            cookies=dict(entry.artifacts.cookies),
            query=dict(entry.artifacts.query),
            body=dict(entry.artifacts.body),
            token=entry.artifacts.token,
        )
        self._token_expiry: float | None = _token_expiry_from_jwt(self.artifacts.token)
        self._last_refresh: float | None = time.time() if self.artifacts.token else None
        self._last_login: float | None = None
        self._force_refresh = False

    @staticmethod
    def _format_timestamp(value: float | None) -> str | None:
        if value is None:
            return None
        try:
            return datetime.fromtimestamp(value, tz=timezone.utc).isoformat()
        except (OSError, OverflowError, ValueError):  # pragma: no cover - defensive
            return None

    def _auth_headers(self) -> Dict[str, str]:
        headers = dict(self.artifacts.headers)
        token = self.artifacts.token
        has_auth_header = any(k.lower() == "authorization" for k in headers)
        if token and not has_auth_header:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _apply_client_defaults(self, client: Any) -> None:
        headers = self._auth_headers()
        if headers and hasattr(client, "headers"):
            try:
                client.headers.update(headers)
            except Exception:  # pragma: no cover - best effort
                for key, value in headers.items():
                    try:
                        client.headers[key] = value  # type: ignore[index]
                    except Exception:
                        continue

        if self.artifacts.cookies and hasattr(client, "cookies"):
            try:
                client.cookies.update(self.artifacts.cookies)  # type: ignore[arg-type]
            except Exception:  # pragma: no cover - best effort
                for key, value in self.artifacts.cookies.items():
                    try:
                        client.cookies.set(key, value)  # type: ignore[attr-defined]
                    except Exception:
                        continue

        if self.artifacts.query and hasattr(client, "params"):
            try:
                params: MutableMapping[str, Any] = getattr(client, "params")
                params.update(self.artifacts.query)
            except Exception:
                pass

    async def login(self, client: Any) -> None:
        self._apply_client_defaults(client)
        flow = self.entry.login
        if flow and flow.url:
            await self._execute_flow(client, flow, allow_token=True)
        else:
            token = self.artifacts.token
            self._token_expiry = _token_expiry_from_jwt(token)
        self._last_login = time.time()
        self._force_refresh = False

    async def ensure_session(self, client: Any) -> None:
        self._apply_client_defaults(client)

    def needs_refresh(self, client: Any) -> bool:  # noqa: ARG002 - signature contract
        policy = self.entry.refresh
        if not policy:
            return False
        grace = max(0, int(policy.grace_seconds))
        now = time.time()
        if self._force_refresh:
            return True
        if self._token_expiry is not None:
            return now >= (self._token_expiry - grace)
        if self._last_refresh is None:
            return False
        return (now - self._last_refresh) >= max(grace, 60)

    async def refresh(self, client: Any) -> None:
        policy = self.entry.refresh
        if not policy or not policy.url:
            await self.login(client)
            return
        await self._execute_flow(client, policy, allow_token=True)
        self._last_refresh = time.time()
        self._force_refresh = False

    def refresh_backoff_seconds(self, attempt: int) -> float:
        policy = self.entry.refresh
        if not policy:
            return 0.0
        return max(0.0, float(policy.retry_backoff_seconds or 0.0)) * max(1, attempt - 1)

    def max_refresh_attempts(self) -> int:
        policy = self.entry.refresh
        if not policy:
            return 1
        return 3 if policy.retry_backoff_seconds else 1

    def refresh_error_is_retryable(self, error: BaseException) -> bool:  # noqa: D401
        return bool(self.entry.refresh and self.entry.refresh.retry_backoff_seconds)

    def mark_for_refresh(self) -> None:
        self._force_refresh = True

    def export_state(self) -> Dict[str, Any]:
        """Return a serialisable snapshot of the strategy state."""

        if hasattr(self.artifacts, "model_dump"):
            artifacts = self.artifacts.model_dump(mode="python")  # type: ignore[call-arg]
        else:  # pragma: no cover - fallback for simple dataclasses
            artifacts = {
                "headers": dict(getattr(self.artifacts, "headers", {})),
                "cookies": dict(getattr(self.artifacts, "cookies", {})),
                "query": dict(getattr(self.artifacts, "query", {})),
                "body": dict(getattr(self.artifacts, "body", {})),
                "token": getattr(self.artifacts, "token", None),
            }

        metadata = {
            "name": self.entry.name,
            "role": self.entry.role,
            "strategy": self.entry.strategy,
            "tags": dict(self.entry.tags),
            "has_refresh": bool(self.entry.refresh),
            "last_login": self._format_timestamp(self._last_login),
            "last_refresh": self._format_timestamp(self._last_refresh),
            "token_expiry": self._format_timestamp(self._token_expiry),
            "force_refresh": bool(self._force_refresh),
        }

        return {"artifacts": artifacts, "meta": metadata}

    async def _execute_flow(
        self,
        client: httpx.AsyncClient,
        flow: LoginFlow | RefreshPolicy,
        *,
        allow_token: bool,
    ) -> None:
        request_headers = self._auth_headers()
        request_headers.update(_coerce_headers(getattr(flow, "headers", None)))
        payload = getattr(flow, "payload", None) or None

        request_callable = getattr(client, "request", None)
        if not callable(request_callable):
            logger.debug(
                "authentication flow skipped for %s: client %s lacks request()",
                flow.url,
                type(client).__name__,
            )
            self._force_refresh = False
            return
        try:
            response = await request_callable(
                getattr(flow, "method", "POST"),
                flow.url,
                json=payload if isinstance(payload, Mapping) else None,
                data=None if isinstance(payload, Mapping) else payload,
                headers=request_headers or None,
                timeout=self.request_timeout,
            )
        except Exception as exc:  # pragma: no cover - network failures
            self._force_refresh = True
            raise RuntimeError(f"authentication flow failed: {exc}") from exc

        success_codes = getattr(flow, "success_status", None) or [200, 201, 202, 204, 302]
        if response.status_code not in success_codes:
            self._force_refresh = True
            raise RuntimeError(
                f"authentication flow returned {response.status_code} for {flow.url}"
            )

        cookies = dict(response.cookies)
        if cookies:
            _merge_artifacts(self.artifacts, cookies=cookies)

        token: str | None = None
        json_payload: Any = None
        if allow_token:
            try:
                json_payload = response.json()
            except ValueError:
                json_payload = None
            token = _extract_json_path(json_payload or {}, getattr(flow, "token_path", None))
            if token is None and isinstance(json_payload, Mapping):
                token = json_payload.get("token") or json_payload.get("access_token")
        if allow_token:
            _merge_artifacts(self.artifacts, token=token)
            self._token_expiry = _token_expiry_from_jwt(token)

        self._apply_client_defaults(client)


@dataclass
class AccountContext:
    strategies: Dict[str, AuthStrategy]
    profile: AccountProfile | None
    default_role: str | None


def _resolve_profile(pool: AccountPool, profile_name: str | None) -> AccountProfile:
    try:
        return pool.profile(profile_name)
    except KeyError as exc:
        available = ", ".join(sorted(pool.profiles)) or "<none>"
        raise KeyError(
            f"profile '{profile_name}' not available; configured profiles: {available}"
        ) from exc


def build_account_context(
    pool: AccountPool | None,
    *,
    profile_name: str | None = None,
    prefer_roles: Iterable[str] | None = None,
    workdir: Path,
    request_timeout: float = 10.0,
) -> AccountContext:
    if pool is None:
        return AccountContext(strategies={}, profile=None, default_role=None)

    profile = _resolve_profile(pool, profile_name)
    prefer = [r.lower() for r in (prefer_roles or []) if r]

    strategies: Dict[str, AuthStrategy] = {}
    for entry in profile.accounts:
        strategies[entry.role.lower()] = AccountStrategy(
            entry,
            workdir=workdir,
            request_timeout=request_timeout,
        )

    default_role: str | None = None
    for candidate in prefer:
        if candidate in strategies:
            default_role = candidate
            break
    if default_role is None and profile.accounts:
        default_role = profile.accounts[0].role.lower()

    return AccountContext(strategies=strategies, profile=profile, default_role=default_role)


def _iter_source_paths(source: str, base_dir: Path) -> Iterable[Path]:
    path = Path(source)
    if path.is_absolute():
        yield path
    else:
        yield base_dir / path
        yield Path.cwd() / path


def load_pool_from_config(
    *,
    sources: Iterable[str] | None,
    inline_profiles: Mapping[str, Any] | None,
    default_profile: str | None,
    base_dir: Path,
) -> AccountPool | None:
    aggregate = AccountPool()
    found = False

    path_candidates: list[Path] = []
    for source in sources or []:
        for candidate in _iter_source_paths(source, base_dir):
            if candidate.exists():
                path_candidates.append(candidate)
                break
        else:
            logger.warning("account source not found: %s", source)

    if path_candidates:
        aggregate = load_account_sources(path_candidates)
        found = True

    if inline_profiles:
        inline_payload = {
            "default_profile": default_profile,
            "profiles": inline_profiles,
        }
        inline_pool = AccountPool(**inline_payload)
        aggregate.merge(inline_pool, override=True)
        found = True

    if not found:
        return None

    if default_profile:
        aggregate.default_profile = default_profile
    aggregate.normalise()
    return aggregate

