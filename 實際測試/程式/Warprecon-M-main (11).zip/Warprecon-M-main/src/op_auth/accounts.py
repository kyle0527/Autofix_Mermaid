from __future__ import annotations

"""Account pool loader for multi-identity authentication workflows."""

import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional

import yaml

try:  # pragma: no cover - exercised in main environments with pydantic
    from pydantic import BaseModel, Field
except Exception:  # pragma: no cover - fallback for constrained test envs

    class BaseModel:  # type: ignore[override]
        def __init__(self, **kwargs: Any) -> None:
            for key, value in kwargs.items():
                setattr(self, key, value)

        def model_dump(self, **_: Any) -> Dict[str, Any]:
            return dict(self.__dict__)

    def Field(*, default: Any = None, default_factory: Any | None = None):  # type: ignore[override]
        if default_factory is not None:
            return default_factory()
        return default

logger = logging.getLogger(__name__)

_ENV_PATTERN = re.compile(r"\$\{([^}:]+)(?::([^}]*))?\}")


class SessionArtifacts(BaseModel):
    """Static material used to prime an HTTP client session."""

    headers: Dict[str, str] = Field(default_factory=dict)
    cookies: Dict[str, str] = Field(default_factory=dict)
    query: Dict[str, Any] = Field(default_factory=dict)
    body: Dict[str, Any] = Field(default_factory=dict)
    token: Optional[str] = None


class LoginFlow(BaseModel):
    """Declarative login sequence executed before issuing requests."""

    method: str = "POST"
    url: Optional[str] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
    headers: Dict[str, str] = Field(default_factory=dict)
    success_status: List[int] = Field(default_factory=lambda: [200, 201, 204, 302])


class RefreshPolicy(BaseModel):
    """Automatic session refresh procedure."""

    method: str = "POST"
    url: Optional[str] = None
    grace_seconds: int = 30
    retry_backoff_seconds: float = 0.0
    headers: Dict[str, str] = Field(default_factory=dict)
    payload: Dict[str, Any] = Field(default_factory=dict)
    token_path: Optional[str] = None


class AccountEntry(BaseModel):
    """Single account definition within a profile."""

    name: str
    role: str
    strategy: str = "none"
    login: Optional[LoginFlow] = None
    refresh: Optional[RefreshPolicy] = None
    artifacts: SessionArtifacts = Field(default_factory=SessionArtifacts)
    tags: Dict[str, str] = Field(default_factory=dict)

    def has_refresh(self) -> bool:
        return self.refresh is not None


class AccountProfile(BaseModel):
    """Grouping of account entries used together during a campaign."""

    name: Optional[str] = None
    description: Optional[str] = None
    accounts: List[AccountEntry] = Field(default_factory=list)

    def normalise(self, fallback_name: str) -> None:
        if not self.name:
            self.name = fallback_name
        seen_roles: set[str] = set()
        for entry in self.accounts:
            if not entry.role:
                raise ValueError(f"account '{entry.name}' is missing a role assignment")
            role_key = entry.role.lower()
            if role_key in seen_roles:
                raise ValueError(
                    f"duplicate role '{entry.role}' detected in profile '{self.name}'"
                )
            seen_roles.add(role_key)

    def role_map(self) -> Dict[str, AccountEntry]:
        return {entry.role.lower(): entry for entry in self.accounts}


class AccountPool(BaseModel):
    """Complete account catalogue available to the scanner."""

    default_profile: Optional[str] = None
    profiles: Dict[str, AccountProfile] = Field(default_factory=dict)

    def normalise(self) -> None:
        for name, profile in list(self.profiles.items()):
            profile.normalise(name)
        if self.default_profile and self.default_profile not in self.profiles:
            raise ValueError(
                f"default profile '{self.default_profile}' not present in account pool"
            )

    def profile(self, name: Optional[str] = None) -> AccountProfile:
        key = name or self.default_profile
        if not key:
            raise KeyError("no profile specified and no default configured")
        try:
            return self.profiles[key]
        except KeyError as exc:  # pragma: no cover - defensive
            raise KeyError(f"profile '{key}' not found") from exc

    def list_roles(self, profile: Optional[str] = None) -> Dict[str, AccountEntry]:
        return self.profile(profile).role_map()

    def merge(self, other: "AccountPool", *, override: bool = False) -> None:
        for name, profile in other.profiles.items():
            if name in self.profiles and not override:
                raise ValueError(f"profile '{name}' already defined")
            self.profiles[name] = profile
        if other.default_profile and (override or not self.default_profile):
            self.default_profile = other.default_profile
        self.normalise()

    def to_dict(self) -> Dict[str, Any]:  # pragma: no cover - serialisation helper
        return self.model_dump(mode="python")


def _expand_env_placeholders(value: str) -> str:
    """Expand ``${VARNAME[:default]}`` style placeholders in ``value``."""

    def _replacement(match: re.Match[str]) -> str:
        name = match.group(1)
        default = match.group(2)
        env_value = os.environ.get(name)
        if env_value is not None:
            return env_value
        if default is not None:
            return default
        raise KeyError(name)

    if "${" not in value:
        return value
    return _ENV_PATTERN.sub(_replacement, value)


def _resolve_env(data: Any) -> Any:
    """Recursively resolve environment placeholders within ``data``."""

    if isinstance(data, str):
        return _expand_env_placeholders(data)
    if isinstance(data, list):
        return [_resolve_env(item) for item in data]
    if isinstance(data, tuple):  # pragma: no cover - defensive tuple handling
        return tuple(_resolve_env(item) for item in data)
    if isinstance(data, dict):
        return {key: _resolve_env(value) for key, value in data.items()}
    return data


def _load_yaml(path: Path) -> Mapping[str, Any]:
    if not path.exists():
        raise FileNotFoundError(path)
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def load_account_pool(path: Path | str) -> AccountPool:
    """Load a single account pool file."""

    source = Path(path)
    data = _load_yaml(source)
    try:
        data = _resolve_env(data)
    except KeyError as exc:
        missing = exc.args[0]
        raise ValueError(
            f"environment variable '{missing}' required by account source {source}"
        ) from None
    pool = AccountPool(**data)
    pool.normalise()
    return pool


def load_account_sources(paths: Iterable[Path | str]) -> AccountPool:
    """Merge multiple account sources into a single :class:`AccountPool`."""

    aggregate = AccountPool()
    for path in paths:
        source = Path(path)
        if not source.exists():
            logger.warning("account source missing: %s", source)
            continue
        pool = load_account_pool(source)
        aggregate.merge(pool, override=True)
    aggregate.normalise()
    return aggregate


@dataclass(slots=True)
class RoleAccount:
    """Convenience container returned by :func:`resolve_role`."""

    profile: str
    account: AccountEntry


def resolve_role(pool: AccountPool, role: str, profile: Optional[str] = None) -> RoleAccount:
    """Locate an account by ``role`` within ``profile`` (defaults to pool default)."""

    prof = pool.profile(profile)
    mapping = prof.role_map()
    try:
        entry = mapping[role.lower()]
    except KeyError as exc:
        raise KeyError(f"role '{role}' not available in profile '{prof.name}'") from exc
    return RoleAccount(profile=prof.name or "", account=entry)


__all__ = [
    "AccountEntry",
    "AccountPool",
    "AccountProfile",
    "LoginFlow",
    "RefreshPolicy",
    "RoleAccount",
    "SessionArtifacts",
    "load_account_pool",
    "load_account_sources",
    "resolve_role",
]
