from __future__ import annotations

import asyncio
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, MutableMapping, Sequence

import typer

from op_auth.accounts import AccountEntry, AccountPool, load_account_sources
from op_auth.manager import AuthManager
from op_auth.runtime import AccountContext, build_account_context
from op_core.httpclient import make_async_client


auth_app = typer.Typer(
    add_completion=False,
    help="Authentication utilities for managing account pools and sessions.",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _default_account_path() -> Path:
    return Path("config") / "accounts.yaml"


def _resolve_account_sources(sources: Sequence[Path]) -> list[Path]:
    if sources:
        resolved = []
        for source in sources:
            if not source.exists():
                raise typer.BadParameter(
                    f"Account source not found: {source}", param_hint="--accounts"
                )
            resolved.append(source)
        return resolved

    default_path = _default_account_path()
    if default_path.exists():
        return [default_path]

    raise typer.BadParameter(
        "No account sources provided and config/accounts.yaml is missing",
        param_hint="--accounts",
    )


def _load_pool(sources: Iterable[Path]) -> AccountPool:
    pool = load_account_sources(sources)
    if not pool.profiles:
        raise typer.BadParameter(
            "The provided account sources did not define any profiles",
            param_hint="--accounts",
        )
    return pool


def _collect_role_states(
    context: AccountContext,
    allowed_roles: set[str] | None,
) -> tuple[MutableMapping[str, Any], list[str]]:
    profile = context.profile
    if profile is None:
        return {}, sorted(allowed_roles or [])

    entries: dict[str, AccountEntry] = {
        entry.role.lower(): entry for entry in profile.accounts
    }

    states: MutableMapping[str, Any] = {}
    for canonical_role, strategy in context.strategies.items():
        if allowed_roles and canonical_role not in allowed_roles:
            continue
        entry = entries.get(canonical_role)
        label = entry.role if entry else canonical_role
        state = strategy.export_state()
        meta = state.setdefault("meta", {})
        meta.setdefault("canonical_role", canonical_role)
        if entry is not None:
            meta.setdefault("name", entry.name)
            meta.setdefault("role", entry.role)
            meta.setdefault("strategy", entry.strategy)
            if entry.tags:
                meta.setdefault("tags", dict(entry.tags))
        states[label] = state

    missing: list[str] = []
    if allowed_roles:
        available = set(context.strategies.keys())
        missing = sorted(role for role in allowed_roles if role not in available)

    return states, missing


def _slugify_role(label: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", label).strip("_")
    if not slug:
        return "role"
    return slug


def _write_role_snapshots(directory: Path, states: Mapping[str, Any]) -> list[Path]:
    directory.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for label, payload in states.items():
        target = directory / f"{_slugify_role(label)}.json"
        target.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        written.append(target)
    return written


@auth_app.command("sync")
def sync_accounts(
    accounts: list[Path] = typer.Option(
        [],
        "--accounts",
        "-a",
        help="Account pool YAML sources (defaults to config/accounts.yaml).",
    ),
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Profile to load (defaults to the pool's configured default).",
    ),
    prefer_role: list[str] = typer.Option(
        [],
        "--prefer-role",
        help="Preferred roles to treat as default when multiple are available.",
    ),
    role: list[str] = typer.Option(
        [],
        "--role",
        help="Restrict sync to specific roles (repeat for multiple roles).",
    ),
    workdir: Path = typer.Option(
        Path("."),
        "--workdir",
        help="Working directory for session material and HTTP client config.",
    ),
    timeout: float = typer.Option(
        10.0,
        "--timeout",
        help="HTTP timeout (seconds) applied to login/refresh requests.",
    ),
    out: Path | None = typer.Option(
        None,
        "--out",
        help="Optional JSON output path for aggregated session material.",
    ),
    dump_dir: Path | None = typer.Option(
        None,
        "--dump-dir",
        help="Directory to write per-role session snapshots as JSON files.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit the aggregated session payload to stdout in JSON format.",
    ),
) -> None:
    """Prime account sessions and optionally export material to disk."""

    sources = _resolve_account_sources(accounts)
    pool = _load_pool(sources)

    prefer = [item.strip() for item in prefer_role if item.strip()]
    context = build_account_context(
        pool,
        profile_name=profile,
        prefer_roles=prefer or None,
        workdir=workdir,
        request_timeout=float(timeout),
    )

    if not context.strategies:
        typer.secho(
            "No authentication strategies were constructed from the selected profile.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=1)

    raw_roles = [item.strip() for item in role if item.strip()]
    canonical_roles = list(dict.fromkeys(r.lower() for r in raw_roles))
    allowed_roles = set(canonical_roles) if canonical_roles else None
    prime_roles: list[str] | None = canonical_roles or None

    auth = AuthManager(
        dict(context.strategies),
        lambda: make_async_client(workdir, timeout=timeout),
        default_role=context.default_role,
    )

    async def _prime() -> tuple[MutableMapping[str, Any], list[str]]:
        try:
            await auth.prime(prime_roles)
        finally:
            states, missing = _collect_role_states(context, allowed_roles)
            await auth.close_all()
        return states, missing

    try:
        states, missing = asyncio.run(_prime())
    except Exception as exc:  # pragma: no cover - network/auth failures bubble up
        typer.secho(f"Authentication sync failed: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=2) from exc

    if not states:
        message = "No roles matched the provided criteria." if not missing else (
            "Requested roles were not available in the selected profile."
        )
        typer.secho(message, fg=typer.colors.RED, err=True)
        if missing:
            typer.secho(
                f"Missing roles: {', '.join(missing)}",
                fg=typer.colors.YELLOW,
                err=True,
            )
        raise typer.Exit(code=3)

    profile_name = (
        context.profile.name
        if context.profile and context.profile.name
        else pool.default_profile
    ) or ""

    timestamp = datetime.now(timezone.utc).isoformat()
    output: dict[str, Any] = {
        "profile": profile_name,
        "default_role": auth.default_role,
        "requested_roles": raw_roles or None,
        "sources": [str(path) for path in sources],
        "synced_at": timestamp,
        "roles": dict(states),
    }

    if prefer:
        output["preferred_roles"] = prefer
    if missing:
        output["missing_roles"] = missing
    if not raw_roles:
        output.pop("requested_roles", None)

    typer.secho(
        f"Primed {len(states)} role(s) for profile '{profile_name}' (default: {auth.default_role}).",
        fg=typer.colors.GREEN,
        err=True,
    )
    for label, payload in states.items():
        artifacts = payload.get("artifacts", {}) if isinstance(payload, Mapping) else {}
        cookies = artifacts.get("cookies") if isinstance(artifacts, Mapping) else {}
        headers = artifacts.get("headers") if isinstance(artifacts, Mapping) else {}
        token = artifacts.get("token") if isinstance(artifacts, Mapping) else None
        typer.secho(
            "  - {label}: cookies={cookies_count} headers={headers_count} token={token_state}".format(
                label=label,
                cookies_count=len(cookies) if isinstance(cookies, Mapping) else 0,
                headers_count=len(headers) if isinstance(headers, Mapping) else 0,
                token_state="yes" if token else "no",
            ),
            err=True,
        )

    written_files: list[Path] = []
    if dump_dir is not None:
        written_files = _write_role_snapshots(dump_dir, states)
        output["dump_dir"] = str(dump_dir)
        output["dump_files"] = [str(path) for path in written_files]
        typer.secho(
            f"Wrote {len(written_files)} session file(s) to {dump_dir}",
            fg=typer.colors.BLUE,
            err=True,
        )

    if out is not None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
        typer.secho(f"Aggregated session material written to {out}", err=True)

    if json_output:
        typer.echo(json.dumps(output, ensure_ascii=False, indent=2))


__all__ = ["auth_app"]

