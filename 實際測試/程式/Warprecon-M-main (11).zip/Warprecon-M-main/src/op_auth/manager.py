from __future__ import annotations

"""Authentication session manager supporting multiple user roles."""

import asyncio
import inspect
import logging
import time
from collections.abc import Iterable
from typing import Any, Callable, Dict, List, Optional, Mapping

from . import AuthStrategy, NoAuthStrategy
from op_core.telemetry import Telemetry

logger = logging.getLogger(__name__)


class AuthManager:
    """Manage authenticated clients for multiple user roles.

    Parameters
    ----------
    strategies:
        Mapping of role name to :class:`AuthStrategy` instances.
    client_factory:
        Callable that returns a new HTTP client when a role is first used.
    """

    REFRESH_STATUS_CODES = frozenset({401, 403, 419, 440})

    def __init__(
        self,
        strategies: Dict[str, AuthStrategy],
        client_factory: Callable[[], Any],
        *,
        default_role: Optional[str] = None,
    ) -> None:
        self._strategies = {key.lower(): value for key, value in strategies.items()}
        self._client_factory = client_factory
        self._clients: Dict[str, Any] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._default_role = default_role.lower() if default_role else None
        self._instrumented_clients: set[int] = set()

    @property
    def default_role(self) -> str:
        """Return the canonical default role name."""

        return self._default_role or "default"

    def roles(self) -> List[str]:
        """Return the known authentication roles."""

        return sorted(self._strategies.keys())

    async def client_for(self, role: str) -> Any:
        """Return an authenticated client for ``role``."""

        resolved_role = self._resolve_role(role)
        lock = self._locks.setdefault(resolved_role, asyncio.Lock())
        async with lock:
            client = self._clients.get(resolved_role)
            strategy = self._strategies.get(resolved_role, NoAuthStrategy())
            created = False
            if client is None:
                client = self._client_factory()
                self._clients[resolved_role] = client
                created = True

            self._instrument_client(resolved_role, client, strategy)

            action = "login" if created else "ensure"
            started = time.perf_counter()
            outcome = "success"
            error_payload: Optional[Dict[str, Any]] = None

            try:
                if created:
                    await self._awaitable(strategy.login(client))
                else:
                    if strategy.needs_refresh(client):
                        await self._refresh(resolved_role, strategy, client)
                    await self._awaitable(strategy.ensure_session(client))
                return client
            except Exception as exc:
                outcome = "error"
                error_payload = {
                    "type": exc.__class__.__name__,
                    "message": str(exc),
                }
                raise
            finally:
                elapsed_ms = (time.perf_counter() - started) * 1000.0
                Telemetry.record_auth_switch(
                    role=resolved_role,
                    action=action,
                    elapsed_ms=elapsed_ms,
                    outcome=outcome,
                    error=error_payload,
                )

    async def prime(self, roles: Optional[Iterable[str]] = None) -> None:
        """Ensure the provided roles are logged in and ready for use."""

        targets: List[str]
        if roles is None:
            targets = self.roles()
        else:
            targets = [self._resolve_role(role) for role in roles]

        if not targets:
            # When the manager only has the implicit default role ensure at
            # least one login takes place so downstream consumers have a
            # hydrated session artifact to work with.
            targets = [self.default_role]

        seen: set[str] = set()
        for role in targets:
            resolved = self._resolve_role(role)
            if resolved in seen:
                continue
            seen.add(resolved)
            await self.client_for(resolved)

    async def renew(self, role: str) -> None:
        """Force re-login for the given ``role`` if it exists."""

        resolved_role = self._resolve_role(role)
        lock = self._locks.setdefault(resolved_role, asyncio.Lock())
        async with lock:
            client = self._clients.get(resolved_role)
            strategy = self._strategies.get(resolved_role)
            if client is not None and strategy is not None:
                await self._awaitable(strategy.login(client))

    async def renew_all(self) -> None:
        """Force re-login for all cached clients."""

        for role in list(self._clients.keys()):
            await self.renew(role)

    async def close_all(self) -> None:
        """Close all underlying clients and clear cache."""

        for client in self._clients.values():
            close = getattr(client, "aclose", None)
            self._instrumented_clients.discard(id(client))
            if callable(close):
                result = close()
                if inspect.isawaitable(result):
                    await result
        self._clients.clear()
        self._locks.clear()
        self._instrumented_clients.clear()

    async def _awaitable(self, result: Any) -> Any:
        if inspect.isawaitable(result):
            return await result
        return result

    def session_artifacts(self, role: str) -> Dict[str, Any]:
        """Return session material (headers/cookies/query/body/token) for ``role``."""

        resolved_role = self._resolve_role(role)
        strategy = self._strategies.get(resolved_role)
        if strategy is None:
            return {}

        artifacts = self._extract_strategy_artifacts(strategy)
        if not artifacts:
            return {}

        result: Dict[str, Any] = {}
        headers = artifacts.get("headers")
        if isinstance(headers, Mapping):
            normalised_headers = {
                str(key): str(value)
                for key, value in headers.items()
                if value is not None
            }
            if normalised_headers:
                result["headers"] = normalised_headers

        cookies = artifacts.get("cookies")
        if isinstance(cookies, Mapping):
            normalised_cookies = {
                str(key): str(value)
                for key, value in cookies.items()
                if value is not None
            }
            if normalised_cookies:
                result["cookies"] = normalised_cookies

        query = artifacts.get("query")
        if isinstance(query, Mapping):
            result["query"] = dict(query)

        body = artifacts.get("body")
        if isinstance(body, Mapping):
            result["body"] = dict(body)

        token = artifacts.get("token")
        if token is not None:
            if isinstance(token, bytes):
                try:
                    result["token"] = token.decode()
                except Exception:
                    result["token"] = token.hex()
            else:
                result["token"] = str(token)

        return result

    def _extract_strategy_artifacts(self, strategy: AuthStrategy) -> Dict[str, Any]:
        """Best-effort extraction of artifact payloads from *strategy*."""

        exporter = getattr(strategy, "export_state", None)
        if callable(exporter):
            try:
                state = exporter()
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("export_state failed for %s: %s", strategy, exc)
            else:
                if isinstance(state, Mapping):
                    artifacts = state.get("artifacts")
                    if isinstance(artifacts, Mapping):
                        return dict(artifacts)

        direct = getattr(strategy, "artifacts", None)
        if direct is not None:
            if hasattr(direct, "model_dump"):
                try:
                    dumped = direct.model_dump(mode="python")
                except Exception as exc:  # pragma: no cover - defensive
                    logger.debug("model_dump failed for %s artifacts: %s", strategy, exc)
                else:
                    if isinstance(dumped, Mapping):
                        return dict(dumped)
            elif isinstance(direct, Mapping):
                return dict(direct)
            else:
                payload: Dict[str, Any] = {}
                for key in ("headers", "cookies", "query", "body", "token"):
                    if hasattr(direct, key):
                        payload[key] = getattr(direct, key)
                if payload:
                    return payload

        return {}

    def _resolve_role(self, role: str) -> str:
        key = role.lower()
        if key == "default" and self._default_role:
            return self._default_role
        return key

    async def _refresh(
        self,
        role: str,
        strategy: AuthStrategy,
        client: Any,
    ) -> None:
        attempts = 0
        started = time.perf_counter()
        outcome = "success"
        error_payload: Optional[Dict[str, Any]] = None
        max_attempts = max(1, int(strategy.max_refresh_attempts()))

        try:
            while True:
                attempts += 1
                try:
                    await self._awaitable(strategy.refresh(client))
                    break
                except Exception as exc:
                    error_payload = {
                        "type": exc.__class__.__name__,
                        "message": str(exc),
                    }
                    outcome = "error"
                    if attempts >= max_attempts or not strategy.refresh_error_is_retryable(exc):
                        raise
                    backoff = float(strategy.refresh_backoff_seconds(attempts) or 0.0)
                    if backoff > 0:
                        await asyncio.sleep(backoff)
        finally:
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            Telemetry.record_auth_refresh(
                role=role,
                elapsed_ms=elapsed_ms,
                outcome=outcome,
                attempts=max(1, attempts),
                error=error_payload,
            )

    def _instrument_client(
        self,
        role: str,
        client: Any,
        strategy: AuthStrategy,
    ) -> None:
        client_id = id(client)
        if client_id in self._instrumented_clients:
            return

        hooks = getattr(client, "event_hooks", None)
        if not isinstance(hooks, dict):
            self._instrumented_clients.add(client_id)
            return

        try:
            response_hooks = hooks.setdefault("response", [])
        except Exception:
            self._instrumented_clients.add(client_id)
            return

        if isinstance(response_hooks, tuple):
            response_hooks = list(response_hooks)
            hooks["response"] = response_hooks

        async def _hook(
            response: Any,
            _role: str = role,
            _strategy: AuthStrategy = strategy,
            _manager: "AuthManager" = self,
        ) -> None:
            await _manager._handle_response_hook(_role, _strategy, response)

        response_hooks.append(_hook)
        self._instrumented_clients.add(client_id)

    async def _handle_response_hook(
        self,
        role: str,
        strategy: AuthStrategy,
        response: Any,
    ) -> None:
        status = self._normalise_status(response)
        if status is None or status not in self.REFRESH_STATUS_CODES:
            return

        marker = getattr(strategy, "mark_for_refresh", None)
        if callable(marker):
            marker()
        url = self._response_url(response)
        logger.debug(
            "Auth incident for role=%s status=%s url=%s", role, status, url or "<unknown>"
        )
        Telemetry.record_auth_incident(
            role=role,
            status_code=status,
            reason="http_response",
            url=url,
        )

    @staticmethod
    def _normalise_status(response: Any) -> Optional[int]:
        raw = getattr(response, "status_code", None)
        if isinstance(raw, bool):
            return None
        try:
            if raw is None:
                return None
            value = int(raw)
        except (TypeError, ValueError):
            return None
        if value <= 0:
            return None
        return value

    @staticmethod
    def _response_url(response: Any) -> Optional[str]:
        request = getattr(response, "request", None)
        if request is None:
            return None
        url = getattr(request, "url", None)
        if url is None:
            return None
        try:
            return str(url)
        except Exception:
            return None
