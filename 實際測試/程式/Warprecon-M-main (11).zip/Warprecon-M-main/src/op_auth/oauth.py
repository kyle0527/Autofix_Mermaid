from __future__ import annotations

"""OAuth 2.0 client credentials authentication strategy."""

import json
from typing import Any
from urllib import parse, request

from . import AuthStrategy


class OAuthAuthStrategy(AuthStrategy):
    """Fetch a token via client credentials and set it as a Bearer token."""

    def __init__(
        self,
        token_url: str,
        client_id: str,
        client_secret: str,
    ) -> None:
        self.token_url = token_url
        self.client_id = client_id
        self.client_secret = client_secret
        self._token: str | None = None

    def _fetch_token(self) -> str:
        data = parse.urlencode(
            {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
        ).encode()
        with request.urlopen(self.token_url, data=data) as resp:  # nosec B310
            payload = json.loads(resp.read().decode())
        return payload["access_token"]

    def login(self, client: Any) -> None:
        self._token = self._fetch_token()
        if hasattr(client, "headers"):
            client.headers["Authorization"] = f"Bearer {self._token}"

    def ensure_session(self, client: Any) -> None:
        headers = getattr(client, "headers", {})
        if not getattr(headers, "get", lambda _: None)("Authorization"):
            self.login(client)
