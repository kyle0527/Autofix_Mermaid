from __future__ import annotations

"""JWT-based authentication strategy."""

from typing import Any

from . import AuthStrategy


class JWTAuthStrategy(AuthStrategy):
    """Inject a static Bearer token into outgoing requests."""

    def __init__(self, token: str):
        self.token = token

    def login(self, client: Any) -> None:
        if hasattr(client, "headers"):
            client.headers["Authorization"] = f"Bearer {self.token}"

    def ensure_session(self, client: Any) -> None:
        if not getattr(getattr(client, "headers", {}), "get", lambda k: None)(
            "Authorization"
        ):
            self.login(client)
