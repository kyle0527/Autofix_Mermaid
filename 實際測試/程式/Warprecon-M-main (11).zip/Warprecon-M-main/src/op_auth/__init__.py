from __future__ import annotations

"""Pluggable authentication strategies for Warprecon-M."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Type


class AuthStrategy(ABC):
    """Interface for authentication and session maintenance."""

    @abstractmethod
    def login(self, client: Any) -> Any:
        """Perform an initial login using the provided HTTP client."""

    @abstractmethod
    def ensure_session(self, client: Any) -> Any:
        """Validate the current session and re-login if necessary."""

    def needs_refresh(self, client: Any) -> bool:
        """Return ``True`` when the underlying session should be refreshed."""

        return False

    def refresh(self, client: Any) -> Any:
        """Refresh the session material for ``client``.

        Implementations may override this to perform token renewal or other
        bookkeeping. The default behaviour simply performs another login.
        """

        return self.login(client)

    def refresh_backoff_seconds(self, attempt: int) -> float:
        """Return the delay before attempting another refresh."""

        return 0.0

    def max_refresh_attempts(self) -> int:
        """Number of attempts made when refreshing a session."""

        return 1

    def refresh_error_is_retryable(self, error: BaseException) -> bool:
        """Return ``True`` when ``error`` warrants another refresh attempt."""

        return False

    def mark_for_refresh(self) -> None:
        """Flag the strategy so the next client usage refreshes credentials."""

        return None


class NoAuthStrategy(AuthStrategy):
    """Default strategy that performs no authentication."""

    def login(self, client: Any) -> None:  # pragma: no cover
        return None

    def ensure_session(self, client: Any) -> None:  # pragma: no cover
        return None


from .accounts import (  # noqa: E402
    AccountEntry,
    AccountPool,
    AccountProfile,
    LoginFlow,
    RefreshPolicy,
    RoleAccount,
    SessionArtifacts,
    load_account_pool,
    load_account_sources,
    resolve_role,
)
from .cookie import CookieAuthStrategy  # noqa: E402
from .jwt import JWTAuthStrategy  # noqa: E402
from .manager import AuthManager  # noqa: E402
from .oauth import OAuthAuthStrategy  # noqa: E402
from .runtime import (  # noqa: E402
    AccountContext,
    AccountStrategy,
    build_account_context,
    load_pool_from_config,
)

_STRATEGIES: Dict[str, Type[AuthStrategy]] = {
    "none": NoAuthStrategy,
    "cookie": CookieAuthStrategy,
    "jwt": JWTAuthStrategy,
    "oauth": OAuthAuthStrategy,
}


def load_strategy(name: str, **kwargs: Any) -> AuthStrategy:
    """Factory helper to construct an authentication strategy.

    Unknown names fall back to :class:`NoAuthStrategy` to preserve
    backwards compatibility.
    """

    cls = _STRATEGIES.get(name.lower(), NoAuthStrategy)
    return cls(**kwargs)  # type: ignore[call-arg]


__all__ = [
    "AuthStrategy",
    "NoAuthStrategy",
    "CookieAuthStrategy",
    "JWTAuthStrategy",
    "OAuthAuthStrategy",
    "AuthManager",
    "load_strategy",
    "AccountEntry",
    "AccountPool",
    "AccountProfile",
    "SessionArtifacts",
    "LoginFlow",
    "RefreshPolicy",
    "RoleAccount",
    "load_account_pool",
    "load_account_sources",
    "resolve_role",
    "AccountStrategy",
    "AccountContext",
    "build_account_context",
    "load_pool_from_config",
]
