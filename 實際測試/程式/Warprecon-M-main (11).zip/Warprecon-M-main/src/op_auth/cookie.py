from __future__ import annotations

from pathlib import Path
import logging
from typing import Any

from op_core.session import CookieError, load_cookies

from . import AuthStrategy


logger = logging.getLogger(__name__)


class CookieAuthStrategy(AuthStrategy):
    """Reuse cookies from ``<workdir>/session/cookies.json``."""

    def __init__(self, workdir: Path):
        self.workdir = Path(workdir)

    def login(self, client: Any) -> None:
        try:
            jar = load_cookies(self.workdir)
        except (OSError, CookieError) as exc:
            logger.warning("Cookie authentication skipped due to load failure: %s", exc)
            return
        if not jar:
            logger.debug("No cookies found for cookie authentication")
            return
        if hasattr(client, "cookies"):
            try:
                client.cookies.update(jar)  # type: ignore[arg-type]
            except (AttributeError, TypeError, ValueError):
                for k, v in getattr(jar, "items", lambda: [])():
                    try:
                        client.cookies[k] = v  # type: ignore[index]
                    except (AttributeError, TypeError, ValueError):
                        continue

    def ensure_session(self, client: Any) -> None:
        if (
            hasattr(client, "cookies")
            and not client.cookies  # type: ignore[truthy-function]
        ):
            self.login(client)
