from __future__ import annotations
"""
op_bandit.contextual — Plan A++ (backward-compatible + gated UCB sort)

Goals
-----
1) Keep full LinUCB (choose/update with context x).
2) Preserve legacy API for main runner:
   - __init__(arms, state_file=None, **extras)
   - order(ctx) -> legacy default: **no sorting**
   - update(idx, reward)  # moving-average + optional state_file persistence
   - choose(x=None)       # legacy fallback when x is None
3) Gated UCB sorting:
   - If env BANDIT_ENABLE_UCB_SORT is truthy AND per-arm context x can be parsed from `ctx`,
     then `order(ctx)` returns arms sorted by UCB score (desc).
   - Otherwise, `order(ctx)` returns the original order (legacy behavior).
4) Robustness:
   - Missing/invalid context → legacy order
   - Dimension drift → rebuild A,b to the new d (Plan A policy)
   - Persistence failures are ignored (never break pipeline)

Environment
-----------
- BANDIT_ENABLE_UCB_SORT = 1|true|yes   # default: off
- BANDIT_UCB_ALPHA       = float        # optional override
- BANDIT_DIM             = int          # optional initial dimensionality
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, Union
from pathlib import Path
import json, math, os

# ----------------------------
# Linear algebra helpers
# ----------------------------
def _matvec(A: List[List[float]], x: List[float]) -> List[float]:
    return [sum(A[i][j]*x[j] for j in range(len(x))) for i in range(len(A))]

def _vecadd(a: List[float], b: List[float]) -> List[float]:
    return [a[i] + b[i] for i in range(len(a))]

def _outer(x: List[float]) -> List[List[float]]:
    n = len(x)
    return [[x[i]*x[j] for j in range(n)] for i in range(n)]

def _eye(n: int) -> List[List[float]]:
    return [[1.0 if i==j else 0.0 for j in range(n)] for i in range(n)]

def _matadd(A: List[List[float]], B: List[List[float]]) -> List[List[float]]:
    n = len(A); m = len(A[0])
    return [[A[i][j]+B[i][j] for j in range(m)] for i in range(n)]

def _linsolve(A: List[List[float]], b: List[float]) -> List[float]:
    """Naive Gaussian elimination (sufficient for small d)."""
    n = len(A)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for i in range(n):
        pivot = M[i][i]
        if abs(pivot) < 1e-12:
            for k in range(i+1, n):
                if abs(M[k][i]) > 1e-12:
                    M[i], M[k] = M[k], M[i]
                    pivot = M[i][i]
                    break
        if abs(pivot) < 1e-12:
            pivot = 1e-8
            M[i][i] = pivot
        for j in range(i, n+1):
            M[i][j] /= pivot
        for k in range(i+1, n):
            factor = M[k][i]
            for j in range(i, n+1):
                M[k][j] -= factor * M[i][j]
    x = [0.0]*n
    for i in range(n-1, -1, -1):
        x[i] = M[i][n] - sum(M[i][j]*x[j] for j in range(i+1, n))
    return x

# ----------------------------
# Data structures
# ----------------------------
@dataclass
class Arm:
    name: str
    d: int
    alpha: float = 0.8
    A: List[List[float]] = field(default_factory=list)
    b: List[float] = field(default_factory=list)

    def __post_init__(self):
        if not self.A or not self.b:
            self.A = _eye(self.d)
            self.b = [0.0]*self.d

@dataclass
class LinUCB:
    arms: List[Arm] = field(default_factory=list)
    _legacy_scores: List[float] = field(default_factory=list)
    _legacy_counts: List[int] = field(default_factory=list)
    state_file: Optional[Path] = None
    default_alpha: float = 0.8
    _last_order_debug: Dict[str, Any] = field(default_factory=dict)

    def __init__(self,
                 arms: Union[List[Arm], List[Dict[str, Any]], List[str]],
                 state_file: Optional[Union[str, Path]] = None,
                 alpha: float = 0.8,
                 dim: Optional[int] = None):
        self.default_alpha = alpha
        self.state_file = Path(state_file) if state_file is not None else None

        # Normalize arms input to List[Arm]
        self.arms = []
        if arms and isinstance(arms[0], Arm):
            self.arms = list(arms)
        else:
            names: List[str] = []
            for a in arms:
                if isinstance(a, str):
                    names.append(a)
                elif isinstance(a, dict) and "name" in a:
                    names.append(str(a["name"]))
                else:
                    names.append(str(a))
            if dim is None:
                dim_env = os.environ.get("BANDIT_DIM")
                dim = int(dim_env) if dim_env and dim_env.isdigit() else 1
            self.arms = [Arm(name=n, d=dim, alpha=alpha) for n in names]

        n = len(self.arms)
        self._legacy_scores = [0.0]*n
        self._legacy_counts = [0]*n
        self._last_order_debug = {}
        self._load_if_exists()

    @staticmethod
    def from_spec(names: List[str], dim: int, alpha: float = 0.8) -> "LinUCB":
        return LinUCB(arms=[Arm(name=n, d=dim, alpha=alpha) for n in names], alpha=alpha, dim=dim)

    # -------------- Backward compatible surface --------------
    def order(self, ctx: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Legacy default: return original order.
        If BANDIT_ENABLE_UCB_SORT is truthy AND we can parse per-arm x from ctx,
        return arms ordered by UCB score (desc). Any error → fall back to legacy order.
        """
        try:
            if not _env_truthy(os.environ.get("BANDIT_ENABLE_UCB_SORT", "")):
                return [{"name": a.name} for a in self.arms]

            parsed = _parse_ctx_x(ctx, [a.name for a in self.arms])
            if parsed is None:
                self._last_order_debug = {"mode": "legacy-no-ctx"}
                return [{"name": a.name} for a in self.arms]

            x_list: List[List[float]] = parsed
            if not x_list or any(not isinstance(v, list) or len(v)==0 for v in x_list):
                self._last_order_debug = {"mode": "legacy-bad-ctx"}
                return [{"name": a.name} for a in self.arms]

            d = len(x_list[0])
            self._ensure_dim(d)

            alpha_override = os.environ.get("BANDIT_UCB_ALPHA")
            alpha_val = None
            try:
                if alpha_override is not None:
                    alpha_val = float(alpha_override)
            except Exception:
                alpha_val = None

            scores = []
            for i, a in enumerate(self.arms):
                x = _pad_or_trunc(x_list[i], a.d)
                theta = _linsolve(a.A, a.b)
                y = _linsolve(a.A, x)
                alpha_use = a.alpha if alpha_val is None else alpha_val
                ucb = sum(theta[j]*x[j] for j in range(len(x))) + alpha_use * math.sqrt(max(0.0, sum(x[j]*y[j] for j in range(len(x)))))
                scores.append((i, ucb))

            order_idx = [i for i, _ in sorted(scores, key=lambda t: t[1], reverse=True)]
            self._last_order_debug = {
                "mode": "ucb-sort",
                "scores": [{"name": self.arms[i].name, "score": s} for i, s in sorted(scores, key=lambda t: t[1], reverse=True)]
            }
            return [{"name": self.arms[i].name} for i in order_idx]
        except Exception as e:
            self._last_order_debug = {"mode": "legacy-exception", "error": str(e)}
            return [{"name": a.name} for a in self.arms]

    def update(self, arm_idx: int, *args) -> None:
        if len(args) == 1:
            reward = float(args[0])
            self._legacy_counts[arm_idx] += 1
            c = self._legacy_counts[arm_idx]
            self._legacy_scores[arm_idx] += (reward - self._legacy_scores[arm_idx]) / max(1, c)
            self._persist_safe()
        elif len(args) == 2:
            x, reward = args
            x = list(map(float, x))
            reward = float(reward)
            self._ensure_dim(len(x))
            arm = self.arms[arm_idx]
            arm.A = _matadd(arm.A, _outer(x))
            arm.b = _vecadd(arm.b, [reward * xi for xi in x])
            self._persist_safe()
        else:
            raise TypeError("update expects (idx, reward) or (idx, x, reward)")

    def choose(self, x: Optional[List[float]] = None) -> int:
        if x is None:
            best_idx = 0
            best_val = self._legacy_scores[0] if self._legacy_scores else 0.0
            for i, val in enumerate(self._legacy_scores):
                if val > best_val:
                    best_val = val
                    best_idx = i
            return best_idx

        x = list(map(float, x))
        self._ensure_dim(len(x))
        best_idx = 0
        best_score = -1e30
        for i, arm in enumerate(self.arms):
            theta = _linsolve(arm.A, arm.b)
            y = _linsolve(arm.A, x)
            ucb = sum(theta[j]*x[j] for j in range(len(x))) + arm.alpha * math.sqrt(max(0.0, sum(x[j]*y[j] for j in range(len(x)))))
            if ucb > best_score:
                best_score = ucb
                best_idx = i
        return best_idx

    def to_json(self) -> str:
        j = {
            "arms": [{
                "name": a.name, "d": a.d, "alpha": a.alpha, "A": a.A, "b": a.b
            } for a in self.arms],
            "legacy_scores": self._legacy_scores,
            "legacy_counts": self._legacy_counts,
            "meta": {"format": "planA.v2", "note": "LinUCB + legacy scores + gated sort"}
        }
        return json.dumps(j)

    @staticmethod
    def from_json(s: str) -> "LinUCB":
        j = json.loads(s)
        arms = []
        for a in j.get("arms", []):
            arms.append(Arm(name=a["name"], d=a["d"], alpha=a.get("alpha", 0.8),
                            A=a.get("A"), b=a.get("b")))
        inst = LinUCB(arms=arms, alpha=0.0, dim=arms[0].d if arms else 1)
        inst._legacy_scores = list(j.get("legacy_scores", [0.0]*len(arms)))
        inst._legacy_counts = list(j.get("legacy_counts", [0]*len(arms)))
        return inst

    # ----------------------------
    # Helpers
    # ----------------------------
    def _ensure_dim(self, d: int) -> None:
        if not self.arms:
            return
        if self.arms[0].d == d:
            return
        for arm in self.arms:
            arm.d = d
            arm.A = _eye(d)
            arm.b = [0.0]*d

    def _persist_safe(self) -> None:
        if not self.state_file:
            return
        try:
            data = json.loads(self.to_json())
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.state_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except Exception:
            pass

    def _load_if_exists(self) -> None:
        if not self.state_file:
            return
        try:
            if Path(self.state_file).exists():
                with open(self.state_file, "r", encoding="utf-8") as f:
                    txt = f.read()
                loaded = LinUCB.from_json(txt)
                if len(loaded.arms) == len(self.arms):
                    self.arms = loaded.arms
                    self._legacy_scores = loaded._legacy_scores
                    self._legacy_counts = loaded._legacy_counts
        except Exception:
            pass

# ----------------------------
# Context parsing utilities
# ----------------------------
def _env_truthy(s: str) -> bool:
    return str(s).lower() in {"1", "true", "yes", "y", "on"}

def _looks_float_list(v: Any) -> bool:
    return isinstance(v, list) and all(isinstance(x, (int, float)) for x in v) and len(v) > 0

def _pad_or_trunc(x: List[float], d: int) -> List[float]:
    if len(x) == d:
        return x
    if len(x) > d:
        return x[:d]
    return x + [0.0]*(d - len(x))

def _parse_ctx_x(ctx: Any, names: List[str]) -> Optional[List[List[float]]]:
    """
    Try to extract per-arm x from ctx.

    Accepts:
      1) {'x_map': {name: [values], more}}
      2) {'features': {name: [values], more}}  # alias
      3) {'x': [[v1], [v2], etc]}  # list aligned with arms order
      4) [{'name': 'arm', 'x': [values]}, extra]
      5) [{'name': 'arm', 'features': [values]}, extra]
      6) {name: [values], more}  # direct mapping
    Returns list aligned with `names`, or None if cannot parse.
    """
    if ctx is None:
        return None

    # 1,2
    if isinstance(ctx, dict):
        for key in ("x_map", "features"):
            if key in ctx and isinstance(ctx[key], dict):
                m = ctx[key]
                arr = [m.get(n) for n in names]
                if all(_looks_float_list(v) for v in arr if v is not None) and all(v is not None for v in arr):
                    return arr
        # 3
        if "x" in ctx and isinstance(ctx["x"], list) and all(_looks_float_list(v) for v in ctx["x"]):
            arr = ctx["x"]
            if len(arr) == len(names):
                return arr
        # 6
        arr = [ctx.get(n) for n in names]
        if any(v is not None for v in arr) and all(_looks_float_list(v) for v in arr if v is not None):
            return arr if all(v is not None for v in arr) else None

    # 4,5
    if isinstance(ctx, list) and len(ctx) == len(names):
        if all(isinstance(it, dict) for it in ctx):
            alt = []
            for it in ctx:
                v = it.get("x") if "x" in it else it.get("features")
                if not _looks_float_list(v):
                    return None
                alt.append(v)
            return alt
        if all(_looks_float_list(v) for v in ctx):
            return ctx

    return None
