"""Cross-platform file locking utilities for filesystem queues."""

from __future__ import annotations

import errno
import os
import time
from contextlib import contextmanager
from pathlib import Path
from typing import IO, Iterator

try:  # pragma: no cover - imported conditionally
    import msvcrt  # type: ignore
except ImportError:  # pragma: no cover - non-Windows
    msvcrt = None  # type: ignore

try:  # pragma: no cover - imported conditionally
    import fcntl  # type: ignore
except ImportError:  # pragma: no cover - non-POSIX
    fcntl = None  # type: ignore

IS_WINDOWS = os.name == "nt"


class FileLock:
    """Simple exclusive lock built on top of OS-specific primitives."""

    def __init__(self, path: Path, *, retry_delay: float = 0.05) -> None:
        self.path = Path(path)
        self.retry_delay = max(0.01, float(retry_delay))
        self._handle: IO[str] | None = None

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+")
        try:
            if IS_WINDOWS:
                _lock_windows(handle, self.retry_delay)
            else:
                _lock_posix(handle)
        except Exception:
            handle.close()
            raise
        self._handle = handle

    def release(self) -> None:
        handle = self._handle
        if handle is None:
            return
        try:
            if IS_WINDOWS:
                _unlock_windows(handle)
            else:
                _unlock_posix(handle)
        finally:
            handle.close()
            self._handle = None

    @contextmanager
    def locked(self) -> Iterator[None]:
        self.acquire()
        try:
            yield
        finally:
            self.release()


def _lock_windows(handle: IO[str], retry_delay: float) -> None:
    if msvcrt is None:  # pragma: no cover - defensive
        raise RuntimeError("msvcrt is unavailable on this platform")
    while True:
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            return
        except OSError as exc:  # pragma: no cover - depends on timing
            if exc.errno not in (errno.EACCES, errno.EDEADLK):
                raise
            time.sleep(retry_delay)


def _unlock_windows(handle: IO[str]) -> None:
    if msvcrt is None:  # pragma: no cover - defensive
        raise RuntimeError("msvcrt is unavailable on this platform")
    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


def _lock_posix(handle: IO[str]) -> None:
    if fcntl is None:  # pragma: no cover - defensive
        raise RuntimeError("fcntl is unavailable on this platform")
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)


def _unlock_posix(handle: IO[str]) -> None:
    if fcntl is None:  # pragma: no cover - defensive
        raise RuntimeError("fcntl is unavailable on this platform")
    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


__all__ = ["FileLock", "IS_WINDOWS"]
