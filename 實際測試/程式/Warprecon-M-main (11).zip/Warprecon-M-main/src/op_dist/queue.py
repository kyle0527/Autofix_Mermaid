from __future__ import annotations
from pathlib import Path
import json, time, uuid, shutil, os
from typing import Optional, Dict, List, Tuple
import logging
from contextlib import contextmanager

from op_dist.locks import FileLock
logger = logging.getLogger(__name__)

class FSQueue:
    """Filesystem-backed queue persisted under ``root``.

    The queue organises tasks across ``pending``/``processing``/``done``
    directories and relies on ``fcntl`` advisory locks for coordination.
    Consequently it is intended for POSIX platforms where ``fcntl`` is
    available.
    """
    def __init__(self, root: Path, timeout: float | None = 300.0):
        self.root = root
        self.pending = self.root/"pending"
        self.processing = self.root/"processing"
        self.done = self.root/"done"
        self._lock = FileLock(self.root / ".lock")
        self.timeout = timeout
        for d in [self.pending, self.processing, self.done]:
            d.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def _locked(self):
        with self._lock.locked():
            yield
    def enqueue(self, domain: str, cfg: str) -> str:
        tid = f"{int(time.time())}-{uuid.uuid4().hex[:8]}"
        with self._locked():
            (self.pending / f"{tid}.json").write_text(
                json.dumps({"domain": domain, "cfg": cfg}, ensure_ascii=False), encoding="utf-8"
            )
        return tid
    def _list(self, d: Path) -> List[Path]:
        return sorted([p for p in d.glob("*.json")])
    def _mark_processing(self, path: Path):
        now = time.time()
        try:
            os.utime(path, (now, now))
        except OSError as exc:
            logger.warning("Failed updating mtime for processing task %s: %s", path, exc)

    def _requeue_stale_locked(self):
        if not self.timeout:
            return
        now = time.time()
        for p in self._list(self.processing):
            try:
                age = now - p.stat().st_mtime
            except OSError as exc:
                logger.warning("Failed stating processing task %s: %s", p, exc)
                continue
            if age >= self.timeout:
                dest = self.pending / p.name
                try:
                    shutil.move(str(p), str(dest))
                    logger.info("Re-queued stale task %s after %.2fs", p.stem, age)
                except (OSError, shutil.Error) as exc:
                    logger.error("Failed re-queuing stale task %s: %s", p, exc)

    def requeue_stale(self):
        with self._locked():
            self._requeue_stale_locked()

    def dequeue(self) -> Optional[Tuple[str, Path]]:
        with self._locked():
            self._requeue_stale_locked()
            for p in self._list(self.pending):
                dest = self.processing / p.name
                try:
                    shutil.move(str(p), str(dest))
                    self._mark_processing(dest)
                    return (p.stem, dest)
                except (OSError, shutil.Error) as exc:
                    logger.error("Failed moving task %s to processing: %s", p, exc)
                    continue
        return None
    def complete(self, tid: str, meta: Dict):
        with self._locked():
            (self.done / f"{tid}.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
            proc = self.processing / f"{tid}.json"
            if proc.exists():
                proc.unlink(missing_ok=True)
    def status(self) -> Dict[str,int]:
        return {"pending": len(self._list(self.pending)), "processing": len(self._list(self.processing)), "done": len(self._list(self.done))}
