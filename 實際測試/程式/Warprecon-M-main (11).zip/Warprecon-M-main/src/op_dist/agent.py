from __future__ import annotations

import json
import logging
import time
import traceback
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from op_core.pipeline import run_pipeline
from op_dist.queue import FSQueue

logger = logging.getLogger(__name__)


class QueueTaskError(RuntimeError):
    """Raised when a queue item cannot be converted into a runnable task."""


@dataclass(frozen=True)
class QueueTask:
    """Structured representation of a queued scan request."""

    task_id: str
    domain: str
    config_path: Path
    payload: Mapping[str, Any]

    @classmethod
    def from_file(cls, task_id: str, path: Path, default_cfg: Path) -> "QueueTask":
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:  # pragma: no cover - defensive guard
            raise QueueTaskError(f"invalid job payload: {exc}") from exc

        if not isinstance(payload, Mapping):  # pragma: no cover - JSON always dict
            raise QueueTaskError("job payload must be a mapping")

        domain = payload.get("domain")
        if not domain:
            raise QueueTaskError("job payload missing 'domain'")

        cfg_value = payload.get("cfg")
        config_path = Path(str(cfg_value)) if cfg_value else default_cfg

        return cls(task_id=task_id, domain=str(domain), config_path=config_path, payload=payload)


def _finalise_task(queue: FSQueue, task_id: str, meta: Mapping[str, Any], action: str) -> None:
    try:
        queue.complete(task_id, dict(meta))
    except Exception as exc:  # pragma: no cover - filesystem errors
        logger.exception("Failed to mark queue task %s as %s: %s", task_id, action, exc)


def _record_failure(
    queue: FSQueue,
    task_id: str,
    *,
    domain: str | None,
    error: BaseException,
    traceback_text: str | None = None,
) -> None:
    meta: dict[str, Any] = {
        "ok": False,
        "domain": domain,
        "error": {"message": str(error), "type": error.__class__.__name__},
    }
    if traceback_text:
        meta["error"]["traceback"] = traceback_text
    _finalise_task(queue, task_id, meta, "failed")


def _record_success(queue: FSQueue, task: QueueTask, output: Any) -> None:
    meta = {"ok": True, "domain": task.domain, "out": output}
    _finalise_task(queue, task.task_id, meta, "completed")


def _process_queue_item(
    queue: FSQueue,
    runs_dir: Path,
    default_cfg: Path,
    max_concurrency: int | None,
    item: tuple[str, Path],
) -> None:
    task_id, payload_path = item
    try:
        task = QueueTask.from_file(task_id, payload_path, default_cfg)
    except QueueTaskError as exc:
        logger.error("Discarding malformed queue task %s: %s", task_id, exc)
        _record_failure(queue, task_id, domain=None, error=exc)
        return
    except Exception as exc:  # pragma: no cover - unexpected loader failure
        logger.exception("Unexpected error loading queue task %s", task_id)
        _record_failure(
            queue,
            task_id,
            domain=None,
            error=exc,
            traceback_text=traceback.format_exc(),
        )
        return

    try:
        output = run_pipeline(
            task.domain,
            task.config_path,
            runs_dir / task.task_id,
            max_concurrency=max_concurrency,
        )
    except Exception as exc:  # pragma: no cover - depends on runtime failures
        logger.exception("Queue task %s failed during pipeline execution", task.task_id)
        _record_failure(
            queue,
            task.task_id,
            domain=task.domain,
            error=exc,
            traceback_text=traceback.format_exc(),
        )
        return

    _record_success(queue, task, output)


def run_agent(
    workdir: Path,
    cfg_path: Path,
    max_loops: int | None = None,
    sleep_sec: float = 1.0,
    max_concurrency: int | None = None,
) -> None:
    """Continuously pull jobs from the filesystem queue and execute scans."""

    queue = FSQueue(workdir / "queue")
    runs_dir = workdir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)

    loops = 0
    while True:
        item = queue.dequeue()
        if item is None:
            time.sleep(sleep_sec)
        else:
            _process_queue_item(queue, runs_dir, cfg_path, max_concurrency, item)

        loops += 1
        if max_loops is not None and loops >= max_loops:
            break
