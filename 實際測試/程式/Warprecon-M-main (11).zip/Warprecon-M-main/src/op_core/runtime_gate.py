from __future__ import annotations

import asyncio
import json
from pathlib import Path


async def wait_if_paused(workdir: Path | None, poll_interval: float = 0.5) -> None:
    """Block while a hunt workdir is paused.

    When *workdir* is ``None`` the pause gate is skipped entirely so CLI
    invocations that do not materialise a working directory keep operating.
    """

    if workdir is None:
        return

    workdir_path = workdir if isinstance(workdir, Path) else Path(workdir)
    control_file = workdir_path / "control.json"

    while True:
        try:
            payload = control_file.read_text(encoding="utf-8") if control_file.exists() else "{}"
            data = json.loads(payload) if payload else {}
        except asyncio.CancelledError:
            raise
        except Exception:
            data = {}

        if not data.get("pause"):
            break

        try:
            await asyncio.sleep(poll_interval)
        except asyncio.CancelledError:
            raise
