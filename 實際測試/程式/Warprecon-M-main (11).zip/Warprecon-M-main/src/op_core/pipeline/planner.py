from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Tuple

from op_control.campaign import Campaign, load_campaign
from op_control.config import merge_to_file


logger = logging.getLogger(__name__)


def prepare_campaign(
    campaign_path: Path,
    workdir: Path,
    profile: Optional[Path],
    max_concurrency: Optional[int],
    poc_top: Optional[int],
    capture: Optional[bool],
    history_ttl: Optional[int],
    ultra: bool,
    dom_crawl: bool,
) -> Tuple[Campaign, bool]:
    """Load and configure the campaign definition."""

    workdir.mkdir(parents=True, exist_ok=True)

    effective_cfg = campaign_path
    if profile and Path(profile).exists():
        tmp_cfg = workdir / "tmp" / f"merged-{Path(profile).stem}.yaml"
        merge_to_file(campaign_path, Path(profile), tmp_cfg)
        effective_cfg = tmp_cfg

    camp = load_campaign(effective_cfg)
    if max_concurrency:
        camp.limits.max_concurrency = max_concurrency
    if poc_top is not None:
        camp.output.poc_top = poc_top
    if capture is not None:
        camp.output.capture = capture
    if history_ttl is not None:
        camp.output.history_ttl_days = history_ttl

    if ultra:
        extras = [
            "double_encode",
            "unicode_confuse",
            "quote_flip",
            "split_keywords",
            "case_flip",
            "param_spread",
            "urlenc",
            "urlenc_all",
            "comment_break",
            "param_pollution",
            "html_entity",
        ]
        try:
            transforms = list(camp.synth.transforms or [])
        except AttributeError as exc:
            logger.warning("camp.synth.transforms missing: %s", exc)
            transforms = []
        transforms = list(dict.fromkeys(transforms + extras))
        try:
            camp.synth.transforms = transforms
        except AttributeError as exc:
            logger.warning("unable to set synth transforms: %s", exc)
        try:
            if getattr(camp.limits, "per_target_payloads", 0) < 18:
                camp.limits.per_target_payloads = 18
        except AttributeError as exc:
            logger.warning("unable to set payload budget: %s", exc)
        dom_crawl = True

    return camp, dom_crawl


__all__ = ["prepare_campaign"]
