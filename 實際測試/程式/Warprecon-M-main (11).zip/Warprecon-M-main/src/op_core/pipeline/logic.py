from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from op_chain.workflow import Workflow, WorkflowError, WorkflowExecutor
from op_control.campaign import Campaign
from op_core.finding_contract import Finding
from op_core.httpclient import make_async_client
from op_core.telemetry import Telemetry


def _get_attr(source: Any, name: str, default: Any = None) -> Any:
    if isinstance(source, Mapping):
        return source.get(name, default)
    return getattr(source, name, default)


def _resolve_workflow_path(workdir: Path, value: str) -> Optional[Path]:
    candidate = Path(value)
    candidates: List[Path] = []
    if candidate.is_absolute():
        candidates.append(candidate)
    else:
        candidates.extend(
            [
                workdir / candidate,
                workdir / "config" / candidate,
                Path("config") / candidate,
                candidate,
            ]
        )
    seen: set[Path] = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        if path.exists():
            return path
    return None


def _load_inline_manifest(manifest: Any) -> Optional[Mapping[str, Any]]:
    if manifest is None:
        return None
    if isinstance(manifest, Mapping):
        return manifest
    return None


def load_workflows(camp: Campaign, workdir: Path) -> List[Workflow]:
    cfg = getattr(camp, "logic", None)
    if not cfg or not _get_attr(cfg, "enabled", False):
        return []

    workflows: List[Workflow] = []
    max_steps = _get_attr(cfg, "max_steps", None)
    for entry in _get_attr(cfg, "workflows", []) or []:
        if not _get_attr(entry, "enabled", True):
            continue
        overrides: Dict[str, Any] = {}
        for key in ("id", "name", "check", "severity", "variables", "entry"):
            value = _get_attr(entry, key, None)
            if value is not None:
                overrides[key] = value
        if max_steps is not None:
            overrides.setdefault("max_steps", max_steps)

        manifest = _load_inline_manifest(_get_attr(entry, "manifest", None))
        path_value = _get_attr(entry, "path", None)

        try:
            if path_value:
                resolved = _resolve_workflow_path(workdir, str(path_value))
                if not resolved:
                    Telemetry.event(
                        "logic.workflow",
                        {
                            "id": overrides.get("id") or path_value,
                            "state": "missing",
                            "path": str(path_value),
                        },
                    )
                    continue
                workflow = Workflow.from_mapping(
                    _read_manifest(resolved),
                    source=resolved,
                    overrides=overrides,
                )
            elif manifest:
                workflow = Workflow.from_mapping(manifest, overrides=overrides)
            else:
                continue
        except WorkflowError as exc:
            Telemetry.event(
                "logic.workflow",
                {
                    "id": overrides.get("id") or path_value or "inline",
                    "state": "error",
                    "error": str(exc),
                },
            )
            continue

        workflows.append(workflow)
    return workflows


def _read_manifest(path: Path) -> Mapping[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        import yaml  # type: ignore

        data = yaml.safe_load(text) or {}
    else:
        data = json.loads(text)
    if not isinstance(data, Mapping):
        raise WorkflowError("workflow file must contain a mapping")
    return data


async def run_logic_workflows(
    camp: Campaign,
    workdir: Path,
    base_target: str,
) -> Tuple[List[Finding], Optional[Path]]:
    cfg = getattr(camp, "logic", None)
    if not cfg or not _get_attr(cfg, "enabled", False):
        return [], None

    workflows = load_workflows(camp, workdir)
    if not workflows:
        return [], None

    base_context: Dict[str, Any] = {
        "target": base_target,
        "base_url": _get_attr(cfg, "base_url", None) or base_target,
    }
    context_cfg = _get_attr(cfg, "context", None)
    if isinstance(context_cfg, Mapping):
        base_context.update(context_cfg)

    findings: List[Finding] = []
    runs: List[Dict[str, Any]] = []
    artifacts_dir = workdir / "logic"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = artifacts_dir / "findings.json"

    timeout = getattr(getattr(camp, "limits", None), "http_timeout", None)
    proxy = getattr(getattr(camp, "limits", None), "http_proxy", None)
    retries = getattr(getattr(camp, "limits", None), "retries", None)

    async with make_async_client(
        workdir,
        timeout=timeout,
        proxy=proxy,
        retries=retries,
    ) as client:
        for workflow in workflows:
            Telemetry.event(
                "logic.workflow",
                {"id": workflow.id, "state": "start"},
            )
            executor = WorkflowExecutor(
                workflow,
                base_context=base_context,
                max_steps=_get_attr(cfg, "max_steps", None),
            )
            try:
                run = await executor.run(client)
                runs.append(run.to_dict())
                findings.extend(run.findings)
                Telemetry.event(
                    "logic.workflow",
                    {
                        "id": workflow.id,
                        "state": "done",
                        "success": bool(run.success),
                        "findings": len(run.findings),
                    },
                )
            except Exception as exc:  # pragma: no cover - defensive guard
                Telemetry.event(
                    "logic.workflow",
                    {
                        "id": workflow.id,
                        "state": "error",
                        "error": str(exc),
                    },
                )
                runs.append(
                    {
                        "workflow": {"id": workflow.id, "source": workflow.metadata.get("source")},
                        "success": False,
                        "error": {
                            "type": exc.__class__.__name__,
                            "message": str(exc),
                        },
                    }
                )

    artifact_path.write_text(
        json.dumps(runs, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return findings, artifact_path


__all__ = ["load_workflows", "run_logic_workflows"]
