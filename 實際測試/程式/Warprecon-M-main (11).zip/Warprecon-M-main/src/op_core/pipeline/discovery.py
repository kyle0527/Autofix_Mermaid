from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
import json
import logging
import re
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple, TypeVar
from urllib.parse import urlparse

from op_core.runner import classify_target_protocols
from op_core.telemetry import Telemetry
from op_output.artifacts import try_capture
from op_proto.graphql.schema import try_introspect

logger = logging.getLogger(__name__)

T = TypeVar("T")

try:  # pragma: no cover - optional dependency
    from op_adapters.pd_tools import recon_plus as _recon
except ImportError as exc:  # pragma: no cover - optional dependency
    logger.warning("recon_plus import failed: %s", exc)
    _recon = None  # type: ignore[assignment]

try:  # pragma: no cover - optional dependency
    from op_adapters.pd_tools import recon_pipeline as _recon_basic
except ImportError as exc:  # pragma: no cover - optional dependency
    logger.warning("recon_pipeline import failed: %s", exc)
    _recon_basic = None  # type: ignore[assignment]

try:  # pragma: no cover - optional dependency
    from op_dom.capture import crawl_and_capture
except ImportError as exc:  # pragma: no cover - optional dependency
    logger.warning("DOM capture import failed: %s", exc)
    crawl_and_capture = None  # type: ignore[assignment]


@dataclass
class DiscoveryHooks:
    """Pluggable discovery-stage helpers used by :func:`collect_targets`."""

    run_recon: Callable[[str], Tuple[List[str], Dict[str, Any]]]
    crawl_and_capture: Optional[Callable[[str], Awaitable[Dict[str, Any]]]]
    try_capture: Callable[[str, Path], Any]
    try_introspect: Callable[[str], Any]
    classify_target_protocols: Callable[[str], Any]

    @classmethod
    def from_module(cls, module: ModuleType | None = None) -> "DiscoveryHooks":
        mod = module or sys.modules[__name__]
        return cls(
            run_recon=getattr(mod, "_run_recon"),
            crawl_and_capture=getattr(mod, "crawl_and_capture", None),
            try_capture=getattr(mod, "try_capture"),
            try_introspect=getattr(mod, "try_introspect"),
            classify_target_protocols=getattr(mod, "classify_target_protocols"),
        )


def _call_factory_in_thread(factory: Callable[[], Awaitable[T]]) -> T:
    outcome: Dict[str, Any] = {}

    def runner() -> None:
        try:
            outcome["result"] = asyncio.run(factory())
        except BaseException as exc:  # pragma: no cover - propagate below
            outcome["error"] = exc

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join()

    if "error" in outcome:
        raise outcome["error"]
    if "result" not in outcome:  # pragma: no cover - defensive guard
        raise RuntimeError("async runner thread did not return a result")
    return outcome["result"]


def _run_async_factory(
    factory: Callable[[], Awaitable[T]],
    loop: Optional[asyncio.AbstractEventLoop],
) -> T:
    """Execute ``factory`` within ``loop`` when possible."""

    if loop is not None:
        if loop.is_running():
            try:
                current_loop = asyncio.get_running_loop()
            except RuntimeError:
                current_loop = None
            if current_loop is loop:
                return _call_factory_in_thread(factory)
            future = asyncio.run_coroutine_threadsafe(factory(), loop)
            return future.result()
        return loop.run_until_complete(factory())

    try:
        running_loop = asyncio.get_running_loop()
    except RuntimeError:
        running_loop = None

    if running_loop is not None:
        if running_loop.is_running():
            return _call_factory_in_thread(factory)
        return running_loop.run_until_complete(factory())

    return asyncio.run(factory())


def _deduplicate_preserve_order(values: List[str]) -> List[str]:
    """Return ``values`` without duplicates while preserving order."""

    seen: Dict[str, None] = {}
    unique: List[str] = []
    for raw in values:
        key = str(raw)
        if key not in seen:
            seen[key] = None
            unique.append(key)
    return unique


def _run_recon(domain: str) -> Tuple[List[str], Dict[str, Any]]:
    if _recon is not None:
        try:
            return _recon(domain)
        except (RuntimeError, ValueError) as exc:
            logger.warning("recon_plus failed for %s: %s", domain, exc)
    if _recon_basic is not None:
        try:
            basic_result = _recon_basic(domain)
            if isinstance(basic_result, tuple) and len(basic_result) == 2:
                basic_targets, basic_details = basic_result
            else:
                basic_targets = basic_result
                basic_details = {"targets_only": basic_result}

            if isinstance(basic_targets, str):
                target_list = [basic_targets]
            else:
                try:
                    target_list = [str(item) for item in list(basic_targets or [])]
                except TypeError:
                    target_list = [str(basic_targets)]

            try:
                detail_dict = dict(basic_details or {})
            except Exception:  # pragma: no cover - defensive
                detail_dict = {"targets_only": target_list}
            return target_list, detail_dict
        except (RuntimeError, ValueError) as exc:
            logger.warning("recon_pipeline failed for %s: %s", domain, exc)
    roots = [f"https://{domain}", f"http://{domain}"]
    return roots, {"roots_only": roots}


def _write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _relpath(path: Path, base: Path) -> str:
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return path.as_posix()


def _slugify_artifact(url: str, index: int) -> str:
    parsed = urlparse(url)
    raw = "-".join(filter(None, [parsed.netloc, parsed.path.replace("/", "-")]))
    cleaned = re.sub(r"[^A-Za-z0-9_-]", "-", raw).strip("-") or "page"
    digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:8]
    return f"{index:02d}-{cleaned[:40]}-{digest}"


def _capture_dom(
    domain: str,
    loop: Optional[asyncio.AbstractEventLoop],
    crawler: Callable[[str], Awaitable[Dict[str, Any]]],
) -> Dict[str, Any]:
    try:
        if loop is not None:
            if loop.is_running():
                return _call_factory_in_thread(lambda: crawler(domain))
            return loop.run_until_complete(crawler(domain))
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(crawler(domain))
        return _call_factory_in_thread(lambda: crawler(domain))
    except (OSError, RuntimeError):
        logger.exception("DOM capture failed for %s", domain)
        return {"requests": [], "endpoints": []}


def collect_targets(
    domain: str,
    workdir: Path,
    dom_crawl: bool,
    loop: Optional[asyncio.AbstractEventLoop] = None,
    *,
    hooks: Optional[DiscoveryHooks] = None,
) -> List[str]:
    """Run reconnaissance and optional DOM capture for ``domain``."""

    hooks = hooks or DiscoveryHooks.from_module()

    targets, details = hooks.run_recon(domain)
    targets = list(targets)
    deduped_targets = _deduplicate_preserve_order(targets)
    if len(deduped_targets) != len(targets):
        logger.info(
            "Removed %d duplicate discovery targets for %s",
            len(targets) - len(deduped_targets),
            domain,
        )
    targets = deduped_targets
    Telemetry.event(
        "discovery.recon",
        {"domain": domain, "targets": len(targets)},
    )
    disc_dir = workdir / "discovery"
    disc_dir.mkdir(parents=True, exist_ok=True)
    (workdir / "targets.txt").write_text("\n".join(targets), encoding="utf-8")
    _write_json(disc_dir / "targets.json", {"domain": domain, "targets": targets})
    _write_json(disc_dir / "details.json", details)

    js_eps = details.get("js_endpoints")
    if isinstance(js_eps, list):
        _write_json(disc_dir / "js-endpoints.json", js_eps)

    if dom_crawl and hooks.crawl_and_capture is not None:
        dom = _capture_dom(domain, loop, hooks.crawl_and_capture)

        _write_json(disc_dir / "dom-requests.json", dom.get("requests", []))
        _write_json(disc_dir / "dom-endpoints.json", dom.get("endpoints", []))

        artifact_entries: List[Dict[str, Any]] = []
        pages = dom.get("pages")
        if isinstance(pages, list):
            capture_dir = disc_dir / "dom-capture"
            snapshots_dir = capture_dir / "snapshots"
            screenshots_dir = capture_dir / "screenshots"
            for index, page_info in enumerate(pages, 1):
                if not isinstance(page_info, dict):
                    continue
                url = str(page_info.get("url") or f"https://{domain}")
                slug = _slugify_artifact(url, index)
                entry: Dict[str, Any] = {"url": url}

                html = page_info.get("html")
                if isinstance(html, str) and html:
                    snapshots_dir.mkdir(parents=True, exist_ok=True)
                    html_path = snapshots_dir / f"{slug}.html"
                    html_path.write_text(html, encoding="utf-8")
                    entry["snapshot"] = _relpath(html_path, workdir)

                screenshot = page_info.get("screenshot")
                if isinstance(screenshot, str) and screenshot:
                    try:
                        data = base64.b64decode(screenshot.encode("ascii"), validate=True)
                    except (binascii.Error, ValueError):
                        data = b""
                    if data:
                        screenshots_dir.mkdir(parents=True, exist_ok=True)
                        img_path = screenshots_dir / f"{slug}.png"
                        img_path.write_bytes(data)
                        entry["screenshot"] = _relpath(img_path, workdir)

                per_page_endpoints = page_info.get("endpoints")
                if isinstance(per_page_endpoints, list):
                    entry["endpoints"] = [
                        str(candidate) for candidate in per_page_endpoints if isinstance(candidate, str)
                    ]

                if len(entry) > 1:
                    artifact_entries.append(entry)

        if artifact_entries:
            _write_json(disc_dir / "dom-artifacts.json", artifact_entries)

        Telemetry.event(
            "discovery.dom",
            {
                "domain": domain,
                "requests": len(dom.get("requests", []) or []),
                "endpoints": len(dom.get("endpoints", []) or []),
                "snapshots": len(artifact_entries),
            },
        )

        endpoints = dom.get("endpoints")
        if isinstance(endpoints, list) and endpoints:
            all_targets = _deduplicate_preserve_order(list(targets) + list(endpoints))
            (workdir / "targets.txt").write_text("\n".join(all_targets), encoding="utf-8")
            targets = all_targets

    gql_urls = [t for t in targets if "/graphql" in t.lower()]
    if gql_urls:
        schema_out: Dict[str, Any] = {}
        for gql_url in _deduplicate_preserve_order(gql_urls):
            try:
                schema = _run_async_factory(lambda u=gql_url: hooks.try_introspect(u), loop)
                if schema:
                    schema_out[gql_url] = schema
            except (OSError, RuntimeError):
                logger.exception("GraphQL introspection failed for %s", gql_url)

        if schema_out:
            sdir = workdir / "schema"
            sdir.mkdir(parents=True, exist_ok=True)
            _write_json(sdir / "graphql-introspection.json", schema_out)

            for gql_url, schema in schema_out.items():
                digest = hashlib.sha256(gql_url.encode("utf-8")).hexdigest()[:12]
                _write_json(sdir / f"graphql-introspection-{digest}.json", schema)

            try:  # prime GraphQL cache for probes
                from op_proto.graphql.engine import seed_schemas
            except Exception as exc:  # pragma: no cover - optional dependency missing
                logger.debug("GraphQL schema cache unavailable: %s", exc)
            else:
                try:
                    seed_schemas(schema_out)
                except Exception:  # pragma: no cover - defensive
                    logger.exception("GraphQL schema cache priming failed")

    proto_map = {target: hooks.classify_target_protocols(target) for target in targets}
    _write_json(disc_dir / "protocols.json", proto_map)

    return list(targets)


__all__ = [
    "DiscoveryHooks",
    "collect_targets",
    "_run_recon",
    "crawl_and_capture",
    "try_capture",
    "try_introspect",
    "classify_target_protocols",
]
