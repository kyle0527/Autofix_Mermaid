from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Tuple

from op_core.finding_contract import Finding
from op_core.telemetry import Telemetry
from op_iast import IastConfig, create_session

logger = logging.getLogger(__name__)


def collect_iast_results(camp: Any, workdir: Path) -> Tuple[list[Finding], Path | None]:
    """Collect IAST findings for the provided campaign, if enabled."""

    config = IastConfig.from_obj(getattr(camp, "iast", None))
    if not config.enabled:
        Telemetry.event(
            "pipeline.stage",
            {"stage": "iast.collect", "status": "skipped", "enabled": False},
        )
        return [], None

    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "iast.collect",
            "status": "start",
            "transport": config.transport,
        },
    )

    findings: list[Finding] = []
    output_path: Path | None = None

    session = create_session(config, workdir)
    try:
        with session:
            items = session.collect()
            findings = [item.to_finding() for item in items]
    except Exception as exc:  # pragma: no cover - defensive logging
        logger.warning("IAST collection failed: %s", exc)
        Telemetry.event(
            "pipeline.stage",
            {
                "stage": "iast.collect",
                "status": "error",
                "error": str(exc),
            },
        )
        return [], None

    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "iast.collect",
            "status": "done",
            "findings": len(findings),
        },
    )

    if not findings:
        return [], None

    artifact_dir = Path(config.artifact_dir) if config.artifact_dir else Path("iast")
    if not artifact_dir.is_absolute():
        artifact_dir = workdir / artifact_dir

    try:
        artifact_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:  # pragma: no cover - best effort logging
        logger.warning("Failed to create IAST artifact directory %s: %s", artifact_dir, exc)

    output_path = artifact_dir / "findings.json"
    try:
        output_path.write_text(
            json.dumps([finding.to_dict() for finding in findings], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError as exc:  # pragma: no cover - best effort logging
        logger.warning("Unable to persist IAST findings to %s: %s", output_path, exc)
        Telemetry.event(
            "pipeline.stage",
            {
                "stage": "iast.collect",
                "status": "write_error",
                "error": str(exc),
            },
        )
        output_path = None

    return findings, output_path


__all__ = ["collect_iast_results"]
