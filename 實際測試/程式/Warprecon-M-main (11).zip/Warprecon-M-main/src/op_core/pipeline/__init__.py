# ruff: noqa: F401
from __future__ import annotations

import asyncio
import json
import sys
import threading
from pathlib import Path
from urllib.parse import urlsplit
from typing import Any, Dict, List, Optional, Sequence, Tuple

from op_auth import AuthManager, load_strategy
from op_checks.idor import IdorCheck
from op_control.campaign import Campaign
from op_core.backoff import jitter_backoff
from op_core.finding_contract import Finding, as_finding, as_findings
from op_core.merge_findings import merge as merge_finding_files
from op_core.precision import PrecisionEngine
from op_core.precision_gate import _load_labels
from op_core.history import HistoryDB
from op_core.httpclient import make_async_client
from op_core.rank import rank_findings
from op_core.runner import classify_target_protocols, filter_targets_by_scope, run_hunt
from op_core.telemetry import Telemetry
from op_oob.interactsh import InteractClient
from op_output.artifacts import try_capture
from op_output.html import export_html
from op_output.poc import write_poc_files
from op_output.sarif import to_sarif
from op_proto.graphql.schema import try_introspect
from op_adapters.nuclei import run_nuclei
from op_adapters.sqlmap import run_sqlmap
from op_adapters.xsstrike import run_xsstrike

from .discovery import (
    DiscoveryHooks,
    crawl_and_capture as _default_crawl_and_capture,
    collect_targets as _collect_targets,
    _run_recon as _default_run_recon,
)
from .executor import ExecutorHooks, run_scans as _run_scans
from .iast import collect_iast_results
from .logic import run_logic_workflows
from .planner import prepare_campaign as _prepare_campaign
from .reporter import ReportHooks, export_results as _export_results


# Compatibility exports ----------------------------------------------------

# ``collect_targets`` relies on these attributes when constructing hook
# objects. They remain assignable so tests may monkeypatch the pipeline
# module directly, matching the behaviour of the previous monolithic
# implementation.
_run_recon = _default_run_recon
crawl_and_capture = _default_crawl_and_capture


# Public façade ------------------------------------------------------------


def prepare_campaign(
    campaign_path: Path,
    workdir: Path,
    profile: Optional[Path],
    max_concurrency: Optional[int],
    poc_top: Optional[int],
    capture: Optional[bool],
    history_ttl: Optional[int],
    ultra: bool,
    dom_crawl: bool,
) -> Tuple[Campaign, bool]:
    """Adapter maintaining the original :func:`prepare_campaign` export."""

    return _prepare_campaign(
        campaign_path,
        workdir,
        profile,
        max_concurrency,
        poc_top,
        capture,
        history_ttl,
        ultra,
        dom_crawl,
    )


def _build_discovery_hooks() -> DiscoveryHooks:
    return DiscoveryHooks.from_module(sys.modules[__name__])


def collect_targets(
    domain: str,
    workdir: Path,
    dom_crawl: bool,
    loop: Optional[asyncio.AbstractEventLoop] = None,
) -> Sequence[str]:
    """Proxy to the discovery layer that preserves monkeypatch semantics."""

    return _collect_targets(
        domain,
        workdir,
        dom_crawl,
        loop=loop,
        hooks=_build_discovery_hooks(),
    )


def _build_executor_hooks() -> ExecutorHooks:
    return ExecutorHooks.from_module(sys.modules[__name__])


def run_scans(
    targets: Sequence[str],
    camp: Campaign,
    workdir: Path,
    *,
    resume: bool = False,
) -> Tuple[List[Finding], List[Dict[str, Any]], Any]:
    return _run_scans(targets, camp, workdir, resume=resume, hooks=_build_executor_hooks())


def _build_report_hooks() -> ReportHooks:
    return ReportHooks.from_module(sys.modules[__name__])


def export_results(
    ranked: Sequence[Finding | Dict[str, Any]],
    events: Sequence[Dict[str, Any]],
    oob_state: Any,
    camp: Campaign,
    workdir: Path,
) -> Dict[str, str]:
    return _export_results(
        ranked,
        events,
        oob_state,
        camp,
        workdir,
        hooks=_build_report_hooks(),
    )


def _normalise_host_port(value: str, default_port: int = 443) -> tuple[str, int] | None:
    text = (value or "").strip()
    if not text:
        return None

    if "://" in text:
        parsed = urlsplit(text)
        host = parsed.hostname
        if not host:
            return None
        port = parsed.port
        if port is None:
            scheme = (parsed.scheme or "").lower()
            if scheme in {"https", "grpcs"}:
                port = 443
            elif scheme == "grpc":
                port = 50051
            else:
                port = default_port
        return host, port

    try:
        from op_proto.grpc.enumerate import _split_target as grpc_split_target
    except Exception:  # pragma: no cover - optional dependency missing
        grpc_split_target = None

    if grpc_split_target is not None:
        try:
            return grpc_split_target(text)
        except Exception:
            pass

    if text.startswith("[") and "]" in text:
        host = text[1 : text.find("]")]
        remainder = text[text.find("]") + 1 :]
        if remainder.startswith(":"):
            port_text = remainder[1:]
            try:
                return host, int(port_text)
            except ValueError:
                return host, default_port
        return host, default_port

    if ":" in text:
        host, port_text = text.rsplit(":", 1)
        try:
            port = int(port_text)
        except ValueError:
            port = default_port
        return host, port

    return text, default_port


def _collect_grpc_targets(domain: str, targets: Sequence[str]) -> list[tuple[str, int]]:
    candidates: set[tuple[str, int]] = set()
    base = _normalise_host_port(domain, default_port=443)
    if base and domain.lower().startswith(("grpc://", "grpcs://")):
        candidates.add(base)

    for item in targets:
        text = (item or "").strip()
        if not text:
            continue
        protos = classify_target_protocols(text)
        if "grpc" not in protos and not text.lower().startswith(("grpc://", "grpcs://")):
            continue
        parsed = _normalise_host_port(text, default_port=443)
        if parsed:
            candidates.add(parsed)

    ordered = sorted(candidates)
    return ordered


def _run_grpc_enumeration(
    workdir: Path, targets: Sequence[tuple[str, int]]
) -> list[Dict[str, Any]]:
    from op_proto.grpc.enumerate import _enumerate_services
    from op_proto.grpc.utils import plaintext_on_tls_port, tls_min_version

    findings: list[dict[str, Any]] = []
    if not targets:
        path = workdir / "findings.grpc.json"
        path.write_text("[]", encoding="utf-8")
        return findings

    schema_dir = workdir / "schema"
    schema_dir.mkdir(parents=True, exist_ok=True)

    for host, port in targets:
        target = f"{host}:{port}"
        Telemetry.event(
            "pipeline.stage",
            {"stage": "grpc.enumerate", "status": "start", "target": target},
        )
        try:
            schema = _enumerate_services(target, use_tls=True)
        except Exception as exc:  # pragma: no cover - defensive guard
            schema = {"error": str(exc)}

        schema_path = schema_dir / f"grpc_{host.replace(':', '_')}_{port}.json"
        try:
            schema_path.write_text(
                json.dumps(schema, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except OSError as exc:
            Telemetry.event(
                "pipeline.stage",
                {
                    "stage": "grpc.enumerate",
                    "status": "error",
                    "target": target,
                    "error": str(exc),
                },
            )

        if schema.get("services"):
            Telemetry.event(
                "pipeline.stage",
                {
                    "stage": "grpc.enumerate",
                    "status": "done",
                    "target": target,
                    "services": len(schema["services"]),
                },
            )
        elif schema.get("error"):
            Telemetry.event(
                "pipeline.stage",
                {
                    "stage": "grpc.enumerate",
                    "status": "error",
                    "target": target,
                    "error": str(schema.get("error")),
                },
            )
        else:
            Telemetry.event(
                "pipeline.stage",
                {"stage": "grpc.enumerate", "status": "done", "target": target},
            )

        if plaintext_on_tls_port(host, port):
            findings.append(
                {
                    "type": "grpc.plaintext_on_tls_port",
                    "host": host,
                    "port": port,
                    "severity": "medium",
                    "evidence": "TCP accept on 443 without TLS handshake",
                }
            )

        try:
            import ssl

            if tls_min_version(host, port, ssl.TLSVersion.TLSv1):
                findings.append(
                    {
                        "type": "tls.v1_enabled",
                        "host": host,
                        "port": port,
                        "severity": "low",
                        "evidence": "TLSv1 handshake succeeded",
                    }
                )
        except Exception:
            # TLS probing is best effort; ignore failures silently.
            pass

    findings_path = workdir / "findings.grpc.json"
    findings_path.write_text(
        json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return findings


def _run_misconfig_checks(workdir: Path, targets: Sequence[str]) -> list[Dict[str, Any]]:
    from op_checks.misconfig import run_checks

    http_targets = [t for t in targets if str(t).startswith(("http://", "https://"))]
    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "misconfig.scan",
            "status": "start",
            "targets": len(http_targets),
        },
    )

    findings: list[dict[str, Any]]
    if not http_targets:
        findings = []
    else:
        try:
            raw_results = run_checks(http_targets)
        except Exception as exc:  # pragma: no cover - network dependent
            Telemetry.event(
                "pipeline.stage",
                {
                    "stage": "misconfig.scan",
                    "status": "error",
                    "error": str(exc),
                },
            )
            raw_results = []

        findings = []

        def _append_issue(
            *,
            url: str,
            severity: str,
            title: str,
            detail: str,
            evidence: dict[str, Any],
        ) -> None:
            payload = {
                "check": "misconfig",
                "target": url,
                "severity": severity,
                "title": title,
                "detail": detail,
                "evidence": evidence,
            }
            if url.startswith("http"):
                payload.setdefault("vector", {"protocol": "http"})
            findings.append(payload)

        for item in raw_results:
            if not isinstance(item, dict):
                continue
            if item.get("error"):
                continue
            check = item.get("check")
            if check == "hsts":
                if item.get("result") == "skip" or item.get("present"):
                    continue
                url = str(item.get("url") or "")
                evidence = {
                    "status_code": item.get("status"),
                    "headers": item.get("headers"),
                }
                _append_issue(
                    url=url,
                    severity="medium",
                    title="HSTS missing",
                    detail="Strict-Transport-Security header not present on HTTPS response.",
                    evidence=evidence,
                )
            elif check == "cors":
                if not item.get("wildcard_and_credentials"):
                    continue
                url = str(item.get("url") or "")
                evidence = {
                    "status_code": item.get("status"),
                    "headers": item.get("headers"),
                }
                _append_issue(
                    url=url,
                    severity="high",
                    title="CORS wildcard with credentials",
                    detail="Access-Control-Allow-Origin is '*' while credentials are permitted.",
                    evidence=evidence,
                )
            elif check == "trace":
                if not item.get("enabled"):
                    continue
                url = str(item.get("url") or "")
                evidence = {"status_code": item.get("status")}
                _append_issue(
                    url=url,
                    severity="medium",
                    title="TRACE method enabled",
                    detail="HTTP TRACE method is enabled and may expose request bodies.",
                    evidence=evidence,
                )
            elif check == "csp":
                if not item.get("loose"):
                    continue
                url = str(item.get("url") or "")
                evidence = {
                    "status_code": item.get("status"),
                    "policy": item.get("csp"),
                }
                _append_issue(
                    url=url,
                    severity="low",
                    title="Content-Security-Policy missing or weak",
                    detail="Content-Security-Policy header is missing or allows unsafe-inline scripts.",
                    evidence=evidence,
                )
            elif check == "tlsv1":
                if not item.get("accepted"):
                    continue
                host = str(item.get("host") or "")
                port = item.get("port")
                target = f"{host}:{port}" if host else host
                evidence = {"version": item.get("version")}
                _append_issue(
                    url=target,
                    severity="medium",
                    title="TLSv1 accepted",
                    detail="Server negotiates deprecated TLSv1 connections.",
                    evidence=evidence,
                )

    findings_path = workdir / "findings.misconfig.json"
    findings_path.write_text(
        json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "misconfig.scan",
            "status": "done",
            "targets": len(http_targets),
            "findings": len(findings),
        },
    )

    return findings


def _merge_and_gate(
    workdir: Path,
    *,
    precision_cfg: Any,
    gate_threshold: float | None,
    gate_topn: int | None,
    gate_labels: Path | None,
    iast_artifact: Path | None = None,
) -> tuple[list[Dict[str, Any]], list[Dict[str, Any]], Path, Path]:
    ranked_path = workdir / "ranked.json"
    inputs: list[Path] = [ranked_path]
    grpc_path = workdir / "findings.grpc.json"
    misconfig_path = workdir / "findings.misconfig.json"
    if grpc_path.exists():
        inputs.append(grpc_path)
    if misconfig_path.exists():
        inputs.append(misconfig_path)
    iast_path: Path | None = None
    if iast_artifact is not None:
        candidate = Path(iast_artifact)
        if not candidate.is_absolute():
            candidate = (workdir / candidate).resolve()
        if candidate.exists():
            iast_path = candidate
    if iast_path is None:
        default_iast = workdir / "iast" / "findings.json"
        if default_iast.exists():
            iast_path = default_iast
    if iast_path is not None and iast_path.exists():
        inputs.append(iast_path)

    merged = merge_finding_files(inputs)

    precision_engine = PrecisionEngine(precision_cfg, workdir=workdir)
    if gate_threshold is not None:
        precision_engine.gate_threshold = float(gate_threshold)
    if gate_topn is not None:
        precision_engine.gate_topn = int(gate_topn)

    scored_findings = rank_findings(merged, None, precision_engine)
    scored_dicts = [finding.to_dict() for finding in scored_findings]
    suppressed_dicts = [f.to_dict() for f in precision_engine.ignored + precision_engine.suppressed]
    merged_augmented = scored_dicts + suppressed_dicts

    merged_path = workdir / "ranked.merged.json"
    merged_path.write_text(
        json.dumps(merged_augmented, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "merge.findings",
            "status": "done",
            "inputs": [p.name for p in inputs],
            "merged": len(merged),
        },
    )

    accepts: set[str] = set()
    if gate_labels is not None:
        try:
            accepts = _load_labels(gate_labels)
        except Exception as exc:
            Telemetry.event(
                "pipeline.stage",
                {
                    "stage": "precision.gate",
                    "status": "labels_error",
                    "error": str(exc),
                    "labels": str(gate_labels),
                },
            )
            accepts = set()

    threshold = precision_engine.gate_threshold
    topn = precision_engine.gate_topn
    kept, dropped = precision_engine.apply_gate(scored_dicts, accept_fingerprints=accepts)
    final = kept

    final_path = workdir / "ranked.final.json"
    final_path.write_text(
        json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "precision.score",
            "status": "done",
            "scored": precision_engine.stats.scored,
            "kept": precision_engine.stats.kept,
            "ignored": precision_engine.stats.ignored,
            "suppressed": precision_engine.stats.suppressed,
            "baseline_hits": precision_engine.stats.baseline_hits,
        },
    )

    Telemetry.event(
        "pipeline.stage",
        {
            "stage": "precision.gate",
            "status": "done",
            "threshold": threshold,
            "topn": topn,
            "kept": len(final),
            "merged": len(scored_dicts),
            "dropped": len(dropped),
            "reasons": dict(precision_engine.stats.reasons),
        },
    )

    return merged_augmented, final, merged_path, final_path


def _run_pipeline_in_thread(*args: Any, **kwargs: Any) -> Dict[str, str]:
    outcome: Dict[str, Any] = {}

    def runner() -> None:
        try:
            outcome["result"] = asyncio.run(run_pipeline_async(*args, **kwargs))
        except BaseException as exc:  # pragma: no cover - propagate below
            outcome["error"] = exc

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join()

    if "error" in outcome:
        raise outcome["error"]
    if "result" not in outcome:  # pragma: no cover - defensive guard
        raise RuntimeError("async runner thread did not return a result")
    return outcome["result"]


async def run_pipeline_async(
    domain: str,
    campaign_path: Path,
    workdir: Path,
    max_concurrency: Optional[int] = None,
    poc_top: Optional[int] = None,
    capture: Optional[bool] = None,
    history_ttl: Optional[int] = None,
    profile: Optional[Path] = None,
    dom_crawl: bool = False,
    ultra: bool = False,
    resume: bool = False,
    gate_threshold: float | None = None,
    gate_topn: int | None = None,
    gate_labels: Optional[Path] = None,
) -> Dict[str, str]:
    """Asynchronously execute the Warprecon scanning pipeline."""

    workdir.mkdir(parents=True, exist_ok=True)

    Telemetry.start(workdir, domain=domain, metadata={"campaign": str(campaign_path)})
    Telemetry.event(
        "pipeline.stage",
        {"stage": "prepare_campaign", "status": "start", "resume": bool(resume)},
    )

    artifacts: Dict[str, str] = {}
    ranked: List[Finding] = []
    final_items: List[Dict[str, Any]] = []
    iast_artifact_path: Path | None = None
    iast_findings: List[Finding] = []
    logic_artifact_path: Path | None = None
    logic_findings: List[Finding] = []

    try:
        camp, dom_crawl = await asyncio.to_thread(
            prepare_campaign,
            campaign_path,
            workdir,
            profile,
            max_concurrency,
            poc_top,
            capture,
            history_ttl,
            ultra,
            dom_crawl,
        )
        Telemetry.event(
            "pipeline.stage",
            {"stage": "prepare_campaign", "status": "done", "dom_crawl": bool(dom_crawl)},
        )

        Telemetry.event("pipeline.stage", {"stage": "discovery", "status": "start"})
        targets = await asyncio.to_thread(collect_targets, domain, workdir, dom_crawl)
        Telemetry.event(
            "pipeline.stage",
            {"stage": "discovery", "status": "done", "targets": len(targets)},
        )

        Telemetry.event(
            "pipeline.stage",
            {"stage": "execution", "status": "start", "targets": len(targets)},
        )
        ranked, events, oob_state = await asyncio.to_thread(
            run_scans, targets, camp, workdir, resume=resume
        )
        iast_findings, iast_artifact_path = await asyncio.to_thread(
            collect_iast_results, camp, workdir
        )
        if iast_findings:
            ranked.extend(iast_findings)

        Telemetry.event("pipeline.stage", {"stage": "logic", "status": "start"})
        logic_findings, logic_artifact_path = await run_logic_workflows(
            camp,
            workdir,
            domain,
        )
        if logic_findings:
            ranked.extend(logic_findings)
        Telemetry.event(
            "pipeline.stage",
            {
                "stage": "logic",
                "status": "done",
                "findings": len(logic_findings),
            },
        )

        exec_payload = {
            "stage": "execution",
            "status": "done",
            "targets": len(targets),
            "findings": len(ranked),
        }
        if iast_findings:
            exec_payload["iast"] = len(iast_findings)
        if logic_findings:
            exec_payload["logic"] = len(logic_findings)
        Telemetry.event("pipeline.stage", exec_payload)

        Telemetry.event("pipeline.stage", {"stage": "report", "status": "start"})
        artifacts = await asyncio.to_thread(
            export_results, ranked, events, oob_state, camp, workdir
        )
        if iast_artifact_path is not None:
            artifacts["iast"] = str(iast_artifact_path)
        if logic_artifact_path is not None:
            artifacts["logic"] = str(logic_artifact_path)
        Telemetry.event(
            "pipeline.stage",
            {"stage": "report", "status": "done", "artifacts": sorted(artifacts.keys())},
        )

        grpc_targets = _collect_grpc_targets(domain, targets)
        await asyncio.to_thread(_run_grpc_enumeration, workdir, grpc_targets)
        await asyncio.to_thread(_run_misconfig_checks, workdir, targets)

        merged_items, final_items, merged_path, final_path = await asyncio.to_thread(
            _merge_and_gate,
            workdir,
            precision_cfg=getattr(camp, "precision", None),
            gate_threshold=gate_threshold,
            gate_topn=gate_topn,
            gate_labels=gate_labels,
            iast_artifact=iast_artifact_path,
        )

        Telemetry.observe_findings(final_items)

        artifacts.update(
            {
                "grpc": str(workdir / "findings.grpc.json"),
                "misconfig": str(workdir / "findings.misconfig.json"),
                "merged": str(merged_path),
                "final": str(final_path),
            }
        )
        if iast_artifact_path is not None:
            artifacts.setdefault("iast", str(iast_artifact_path))
        if logic_artifact_path is not None:
            artifacts.setdefault("logic", str(logic_artifact_path))
    except BaseException as exc:
        Telemetry.finish(
            status="error",
            error={"message": str(exc), "type": exc.__class__.__name__},
        )
        raise

    Telemetry.finish(
        status="success",
        artifacts=artifacts,
        extra={"findings": len(final_items) if final_items else len(ranked)},
    )
    return artifacts


def run_pipeline(
    domain: str,
    campaign_path: Path,
    workdir: Path,
    max_concurrency: Optional[int] = None,
    poc_top: Optional[int] = None,
    capture: Optional[bool] = None,
    history_ttl: Optional[int] = None,
    profile: Optional[Path] = None,
    dom_crawl: bool = False,
    ultra: bool = False,
    resume: bool = False,
    gate_threshold: float | None = None,
    gate_topn: int | None = None,
    gate_labels: Optional[Path] = None,
) -> Dict[str, str]:
    """Run the Warprecon scanning pipeline for a single domain."""

    try:
        running_loop = asyncio.get_running_loop()
    except RuntimeError:
        running_loop = None

    if running_loop is not None and running_loop.is_running():
        return _run_pipeline_in_thread(
            domain,
            campaign_path,
            workdir,
            max_concurrency=max_concurrency,
            poc_top=poc_top,
            capture=capture,
            history_ttl=history_ttl,
            profile=profile,
            dom_crawl=dom_crawl,
            ultra=ultra,
            resume=resume,
            gate_threshold=gate_threshold,
            gate_topn=gate_topn,
            gate_labels=gate_labels,
        )

    return asyncio.run(
        run_pipeline_async(
            domain,
            campaign_path,
            workdir,
            max_concurrency=max_concurrency,
            poc_top=poc_top,
            capture=capture,
            history_ttl=history_ttl,
            profile=profile,
            dom_crawl=dom_crawl,
            ultra=ultra,
            resume=resume,
            gate_threshold=gate_threshold,
            gate_topn=gate_topn,
            gate_labels=gate_labels,
        )
    )


__all__ = [
    "prepare_campaign",
    "collect_targets",
    "run_scans",
    "export_results",
    "run_pipeline",
    "run_pipeline_async",
    "DiscoveryHooks",
    "ExecutorHooks",
    "ReportHooks",
]
