from __future__ import annotations

import logging
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from op_adapters.errors import ExternalToolNotInstalledError
from op_auth import AuthManager, build_account_context, load_pool_from_config, load_strategy
from op_checks.idor import IdorCheck
from op_control.campaign import Campaign
from op_core.finding_contract import Finding
from op_core.precision import PrecisionEngine
from op_core.runner import filter_targets_by_scope  # noqa: F401
from op_core.telemetry import Telemetry

logger = logging.getLogger(__name__)


@dataclass
class ExecutorHooks:
    """Dependencies used by :func:`run_scans` during execution."""

    HistoryDB: Callable[..., Any]
    InteractClient: Callable[..., Any]
    AuthManager: Callable[..., Any]
    load_strategy: Callable[[str], Any]
    make_async_client: Callable[..., Any]
    jitter_backoff: Callable[..., Any]
    run_hunt: Callable[..., List[Any]]
    classify_target_protocols: Callable[[str], Any]
    run_nuclei: Callable[..., Iterable[Any]]
    run_sqlmap: Callable[..., Iterable[Any]]
    run_xsstrike: Callable[..., Iterable[Any]]
    rank_findings: Callable[..., Sequence[Any]]
    as_findings: Callable[[Iterable[Any]], List[Finding]]
    as_finding: Callable[[Any], Finding]
    IdorCheck: Callable[..., IdorCheck]
    filter_targets_by_scope: Callable[[Sequence[str], Campaign], List[str]]

    @classmethod
    def from_module(cls, module: ModuleType | None = None) -> "ExecutorHooks":
        mod = module or sys.modules[__name__]
        return cls(
            HistoryDB=getattr(mod, "HistoryDB"),
            InteractClient=getattr(mod, "InteractClient"),
            AuthManager=getattr(mod, "AuthManager"),
            load_strategy=getattr(mod, "load_strategy"),
            make_async_client=getattr(mod, "make_async_client"),
            jitter_backoff=getattr(mod, "jitter_backoff"),
            run_hunt=getattr(mod, "run_hunt"),
            classify_target_protocols=getattr(mod, "classify_target_protocols"),
            run_nuclei=getattr(mod, "run_nuclei"),
            run_sqlmap=getattr(mod, "run_sqlmap"),
            run_xsstrike=getattr(mod, "run_xsstrike"),
            rank_findings=getattr(mod, "rank_findings"),
            as_findings=getattr(mod, "as_findings"),
            as_finding=getattr(mod, "as_finding"),
            IdorCheck=getattr(mod, "IdorCheck"),
            filter_targets_by_scope=getattr(mod, "filter_targets_by_scope"),
        )


@dataclass
class OOBPollingManager:
    """Coordinates periodic polling of an out-of-band channel."""

    client: Any
    collected: List[Any]
    logger: logging.Logger = field(default=logger)

    def poll(self, stage: str, *, delay: float = 0.0) -> None:
        if delay > 0:
            time.sleep(delay)
        try:
            batch = self.client.poll()
        except (OSError, RuntimeError) as exc:
            self.logger.error("OOB poll (%s) failed: %s", stage, exc)
            return
        if batch:
            self.collected.extend(batch)
            self.logger.debug("OOB poll (%s) collected %d events", stage, len(batch))


def run_scans(
    targets: Sequence[str],
    camp: Campaign,
    workdir: Path,
    *,
    resume: bool = False,
    hooks: Optional[ExecutorHooks] = None,
) -> Tuple[List[Finding], List[Dict[str, Any]], Any]:
    """Execute the scanning suite against ``targets``."""

    hooks = hooks or ExecutorHooks.from_module()

    scoped_targets = hooks.filter_targets_by_scope(list(targets), camp)
    if not scoped_targets and targets:
        logger.debug("No targets remained after scope filtering; using original set")
        scoped_targets = list(targets)

    Telemetry.event(
        "executor.start",
        {
            "targets": len(targets),
            "in_scope": len(scoped_targets),
            "resume": bool(resume),
        },
    )

    hist = hooks.HistoryDB(workdir / "history.sqlite3", ttl_days=camp.output.history_ttl_days)
    hunt_targets = list(scoped_targets)
    if resume:
        pending: List[str] = []
        status_getter = getattr(hist, "target_status", None)
        for target in scoped_targets:
            status: Optional[str] = None
            if callable(status_getter):
                try:
                    status = status_getter(target)
                except Exception:
                    status = None
            if status == "success":
                logger.info("Skipping completed target %s", target)
                continue
            pending.append(target)
        hunt_targets = pending

    oob = hooks.InteractClient(
        getattr(camp.oob, "base_url", None),
        getattr(camp.oob, "api_key", None),
    )

    collected_events: List[Any] = []
    poller = OOBPollingManager(oob, collected_events)

    timeout = getattr(camp.limits, "http_timeout", None)
    proxy = getattr(camp.limits, "http_proxy", None) or None
    retries = getattr(camp.limits, "retries", None)

    try:
        request_timeout = float(timeout) if timeout is not None else 10.0
    except (TypeError, ValueError):
        request_timeout = 10.0

    account_context = None
    accounts_cfg = getattr(camp, "accounts", None)
    if accounts_cfg is not None:
        sources = list(getattr(accounts_cfg, "sources", []) or [])
        inline_profiles = getattr(accounts_cfg, "inline_profiles", {}) or {}
        if hasattr(inline_profiles, "model_dump"):
            inline_profiles = inline_profiles.model_dump(mode="python")
        pool = load_pool_from_config(
            sources=sources,
            inline_profiles=inline_profiles,
            default_profile=getattr(accounts_cfg, "default_profile", None),
            base_dir=workdir,
        )
        if pool is not None:
            prefer_roles = list(getattr(accounts_cfg, "prefer_roles", []) or [])
            profile_name = getattr(accounts_cfg, "default_profile", None) or pool.default_profile
            account_context = build_account_context(
                pool,
                profile_name=profile_name,
                prefer_roles=prefer_roles,
                workdir=workdir,
                request_timeout=request_timeout,
            )

    strategies: Dict[str, Any] = {}
    default_role: Optional[str] = None
    if account_context is not None:
        strategies = dict(account_context.strategies)
        default_role = account_context.default_role

    if not strategies:
        strategies = {"default": hooks.load_strategy("none")}
        default_role = "default"

    auth = hooks.AuthManager(
        strategies,
        lambda: hooks.make_async_client(
            workdir,
            timeout=timeout,
            proxy=proxy,
            retries=retries,
            backoff=hooks.jitter_backoff,
        ),
        default_role=default_role,
    )

    proto_hints = {target: hooks.classify_target_protocols(target) for target in hunt_targets}

    base_kwargs: Dict[str, Any] = {
        "targets": hunt_targets,
        "camp": camp,
        "history": hist,
        "oob_client": oob,
        "workdir": workdir,
        "auth": auth,
    }
    optional_kwargs: Dict[str, Any] = {}
    if resume:
        optional_kwargs["resume"] = True
    if proto_hints:
        optional_kwargs["protocol_hints"] = proto_hints

    downgraded_params_logged: set[str] = set()

    def _invoke_run_hunt(base: Dict[str, Any], optional: Dict[str, Any]) -> List[Any]:
        remaining = dict(optional)
        while True:
            try:
                return hooks.run_hunt(**base, **remaining)
            except TypeError as exc:
                msg = str(exc)
                removed = False
                for key in list(remaining):
                    if key in msg:
                        remaining.pop(key)
                        removed = True
                        if key not in downgraded_params_logged:
                            downgraded_params_logged.add(key)
                            logger.warning(
                                "run_hunt missing optional parameter %s; retrying without it",
                                key,
                            )
                            Telemetry.event(
                                "executor.run_hunt.downgrade",
                                {"parameter": key},
                            )
                if not removed:
                    raise
                if not remaining:
                    return hooks.run_hunt(**base)

    findings_raw = _invoke_run_hunt(base_kwargs, optional_kwargs)
    findings = hooks.as_findings(findings_raw)

    poller.poll("post-hunt")

    missing_tools: set[str] = set()

    def _record_missing(tool: str, error: BaseException) -> None:
        if tool in missing_tools:
            return
        missing_tools.add(tool)
        logger.warning("Skipping %s scans: %s", tool, error)
        Telemetry.event("external_tool.missing", {"tool": tool})

    nuclei_items: List[Finding] = []
    try:
        nuclei_items = hooks.as_findings(
            hooks.run_nuclei(str(workdir / "targets.txt"), None)
        )
    except ExternalToolNotInstalledError as exc:
        _record_missing(exc.tool, exc)

    poller.poll("post-nuclei")

    try:
        max_targets_raw = getattr(camp.limits, "max_external_targets", None)
        max_targets = int(max_targets_raw) if max_targets_raw is not None else len(hunt_targets)
    except (TypeError, ValueError):
        max_targets = len(hunt_targets)
    if max_targets < 0:
        max_targets = len(hunt_targets)

    def _coerce_timeout(raw: Any, default: int) -> int:
        try:
            value = int(raw)
            if value <= 0:
                raise ValueError
            return value
        except (TypeError, ValueError):
            return default

    def _coerce_non_negative(raw: Any, default: int) -> int:
        try:
            value = int(raw)
            if value < 0:
                raise ValueError
            return value
        except (TypeError, ValueError):
            return default

    def _coerce_interval(raw: Any, default: float) -> float:
        try:
            value = float(raw)
            if value < 0:
                raise ValueError
            return value
        except (TypeError, ValueError):
            return default

    sqlmap_timeout = _coerce_timeout(getattr(camp.limits, "sqlmap_timeout", None), 120)
    xsstrike_timeout = _coerce_timeout(getattr(camp.limits, "xsstrike_timeout", None), 120)

    extra: List[Finding] = []
    sqlmap_hits = 0
    xsstrike_hits = 0
    for index, target in enumerate(hunt_targets[:max_targets], start=1):
        if "sqlmap" not in missing_tools:
            try:
                sql_items = hooks.as_findings(
                    hooks.run_sqlmap(target, timeout=sqlmap_timeout)
                )
            except ExternalToolNotInstalledError as exc:
                _record_missing(exc.tool, exc)
                sql_items = []
            extra.extend(sql_items)
            sqlmap_hits += len(sql_items)
        if "xsstrike" not in missing_tools:
            try:
                xs_items = hooks.as_findings(
                    hooks.run_xsstrike(target, timeout=xsstrike_timeout)
                )
            except ExternalToolNotInstalledError as exc:
                _record_missing(exc.tool, exc)
                xs_items = []
            extra.extend(xs_items)
            xsstrike_hits += len(xs_items)
        poller.poll(f"external-{index}")
        if {"sqlmap", "xsstrike"}.issubset(missing_tools):
            break

    poller.poll("post-external")

    idor_findings: List[Finding] = []
    idor_cfg_obj = getattr(camp, "idor", None)
    idor_enabled = False
    idor_roles: Any = None
    idor_expand = True
    if isinstance(idor_cfg_obj, Mapping):
        idor_enabled = bool(idor_cfg_obj.get("enabled"))
        idor_roles = idor_cfg_obj.get("roles")
        idor_expand = bool(idor_cfg_obj.get("expand_variants", True))
    elif idor_cfg_obj is not None:
        idor_enabled = bool(getattr(idor_cfg_obj, "enabled", False))
        idor_roles = getattr(idor_cfg_obj, "roles", None)
        idor_expand = bool(getattr(idor_cfg_obj, "expand_variants", True))
    if (not idor_roles) and account_context is not None:
        derived_roles: List[Dict[str, Any]] = []
        for role_name, strategy in account_context.strategies.items():
            artifacts = getattr(strategy, "artifacts", None)
            if artifacts is None:
                continue
            headers = dict(getattr(artifacts, "headers", {}))
            token = getattr(artifacts, "token", None)
            if token and not any(key.lower() == "authorization" for key in headers):
                headers["Authorization"] = f"Bearer {token}"
            role_entry: Dict[str, Any] = {"name": role_name, "headers": headers}
            cookies = dict(getattr(artifacts, "cookies", {}))
            if cookies:
                role_entry["cookies"] = cookies
            derived_roles.append(role_entry)
        if derived_roles:
            idor_roles = derived_roles
    try:
        if idor_enabled:
            pattern = re.compile(r"/(\d+)(?:/|$)")
            api_candidates: List[Dict[str, Any]] = []
            for target in scoped_targets:
                if pattern.search(target):
                    api_candidates.append({"url": target})
            if api_candidates:
                check = hooks.IdorCheck(roles=idor_roles, expand_variants=idor_expand)
                for candidate in check.run(api_candidates):
                    ensured = hooks.as_finding(candidate)
                    if not ensured.target:
                        url = ensured.get("url") or (ensured.meta or {}).get("url")
                        if url:
                            ensured.target = str(url)
                    idor_findings.append(ensured)
    except Exception as exc:  # pragma: no cover - idor check is best-effort
        logger.warning("idor check failed: %s", exc)

    poller.poll("post-idor")

    final_polls = _coerce_non_negative(getattr(camp.limits, "oob_final_polls", 2), 2)
    poll_interval = _coerce_interval(getattr(camp.limits, "oob_poll_interval", 1.0), 1.0)
    for attempt in range(final_polls):
        delay = poll_interval if attempt else 0.0
        poller.poll(f"final-{attempt + 1}", delay=delay)

    merged: List[Finding] = []
    merged.extend(findings)
    merged.extend(nuclei_items)
    merged.extend(extra)
    merged.extend(idor_findings)

    correlated = oob.correlate_findings(merged)
    merged = hooks.as_findings(correlated)

    events = list(collected_events)
    oob_state = oob.export_events()

    precision_cfg = getattr(camp, "precision", None)
    precision_engine = PrecisionEngine(precision_cfg, workdir=workdir)
    ranked_raw = hooks.rank_findings(merged, None, precision_engine)
    ranked = hooks.as_findings(ranked_raw)

    Telemetry.observe_findings(ranked)
    event_payload = {
        "targets": len(hunt_targets),
        "nuclei": len(nuclei_items),
        "sqlmap": sqlmap_hits,
        "xsstrike": xsstrike_hits,
        "idor": len(idor_findings),
        "ranked": len(ranked),
    }
    if missing_tools:
        event_payload["missing_tools"] = sorted(missing_tools)

    Telemetry.event("executor.complete", event_payload)

    return ranked, events, oob_state


__all__ = ["ExecutorHooks", "run_scans"]
