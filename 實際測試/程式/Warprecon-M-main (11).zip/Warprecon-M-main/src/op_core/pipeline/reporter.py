from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from op_core.finding_contract import Finding
from op_core.telemetry import Telemetry


@dataclass
class ReportHooks:
    """Dependencies required when serialising pipeline results."""

    as_findings: Callable[[Iterable[Any]], List[Finding]]
    export_html: Callable[[Path, Sequence[Dict[str, Any]]], str]
    to_sarif: Callable[[Sequence[Dict[str, Any]]], str]
    write_poc_files: Callable[[Path, Dict[str, Any], int], None]
    try_capture: Callable[[str, Path], Any]

    @classmethod
    def from_module(cls, module: ModuleType | None = None) -> "ReportHooks":
        mod = module or sys.modules[__name__]
        return cls(
            as_findings=getattr(mod, "as_findings"),
            export_html=getattr(mod, "export_html"),
            to_sarif=getattr(mod, "to_sarif"),
            write_poc_files=getattr(mod, "write_poc_files"),
            try_capture=getattr(mod, "try_capture"),
        )


def export_results(
    ranked: Sequence[Finding | Dict[str, Any]],
    events: List[Dict[str, Any]],
    oob_state: Any,
    camp,
    workdir: Path,
    *,
    hooks: Optional[ReportHooks] = None,
) -> Dict[str, str]:
    """Serialise ``ranked`` findings and related artifacts."""

    hooks = hooks or ReportHooks.from_module()

    ensured = hooks.as_findings(ranked)
    serialised = [item.to_dict() for item in ensured]

    json_path = workdir / "ranked.json"
    sarif_path = workdir / "out.sarif"
    html_path = Path(hooks.export_html(workdir, serialised))

    Telemetry.event(
        "reporter.write",
        {
            "count": len(serialised),
            "poc_top": int(getattr(camp.output, "poc_top", 0) or 0),
            "capture": bool(getattr(camp.output, "capture", False)),
        },
    )

    json_path.write_text(json.dumps(serialised, ensure_ascii=False, indent=2), encoding="utf-8")
    sarif_path.write_text(hooks.to_sarif(serialised), encoding="utf-8")

    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for item in serialised:
        proto = (item.get("vector", {}).get("protocol") or "").lower()
        if proto:
            grouped.setdefault(proto, []).append(item)

    proto_paths: Dict[str, str] = {}
    for proto, items in grouped.items():
        path = workdir / f"ranked-{proto}.json"
        path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
        proto_paths[proto] = str(path)

    for index, finding in enumerate(ensured[: camp.output.poc_top]):
        hooks.write_poc_files(workdir, finding.to_dict(), index + 1)

    if camp.output.capture:
        artdir = workdir / "artifacts"
        for index, finding in enumerate(ensured[: camp.output.poc_top]):
            url = finding.get("url") or finding.target or ""
            subdir = artdir / f"item_{index + 1:02d}"
            hooks.try_capture(url, subdir)

    oob_dir = workdir / "oob"
    oob_dir.mkdir(parents=True, exist_ok=True)
    (oob_dir / "events.json").write_text(
        json.dumps({"events": events, "state": oob_state}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    result: Dict[str, str] = {"json": str(json_path), "sarif": str(sarif_path), "html": str(html_path)}
    result.update(proto_paths)
    return result


__all__ = ["ReportHooks", "export_results"]
