from __future__ import annotations
from typing import List, Dict
from urllib.parse import urlparse

def _host(u: str) -> str:
    try:
        return urlparse(u).netloc or ""
    except Exception:
        return ""

def reorder_targets_by_http_caps(targets: List[str], caps: List[Dict]) -> List[str]:
    h2=set(); h3=set()
    for it in (caps or []):
        h=_host(it.get("url",""))
        if it.get("http3_hint"): h3.add(h)
        elif it.get("http2"): h2.add(h)
    def key(u: str):
        h=_host(u)
        return (0 if h in h3 else (1 if h in h2 else 2))
    return sorted(list(targets), key=key)
