from __future__ import annotations
import json, time
from pathlib import Path
def emit(path: Path, typ: str, **kw):
    evt = {"ts": time.time(), "type": typ}
    evt.update(kw)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as w:
        w.write(json.dumps(evt, ensure_ascii=False)+"\n")
