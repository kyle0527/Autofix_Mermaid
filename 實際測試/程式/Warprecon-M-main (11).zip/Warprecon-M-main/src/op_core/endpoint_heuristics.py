from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterator, Pattern, Sequence, Tuple


@dataclass(frozen=True)
class EndpointHeuristics:
    """Container for heuristics used to detect likely API/WebSocket endpoints."""

    keywords: Tuple[str, ...]
    request_patterns: Tuple[Pattern[str], ...]
    text_patterns: Tuple[Pattern[str], ...]


_DEFAULT_KEYWORDS: Tuple[str, ...] = (
    "/api/",
    "/graphql",
    "/socket",
    "/ws",
)

_REQUEST_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"fetch\(\s*['\"]([^'\"]+)['\"]", re.I),
    re.compile(r"axios\.(?:get|post|put|delete|patch)\(\s*['\"]([^'\"]+)['\"]", re.I),
    re.compile(r"new\s+WebSocket\(\s*['\"]([^'\"]+)['\"]", re.I),
    re.compile(r"['\"](/(?:api|graphql)/[A-Za-z0-9_\-/]+)['\"]", re.I),
    re.compile(r"(https?://[A-Za-z0-9.\-]+(?::\d+)?/[^\s'\"\\)]+)", re.I),
)

_TEXT_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"/graphql\b", re.I),
    re.compile(r"/api/[A-Za-z0-9_\-/]+", re.I),
    re.compile(r"wss?://[\w.\-]+/\S+", re.I),
)


DEFAULT_ENDPOINT_HEURISTICS = EndpointHeuristics(
    keywords=_DEFAULT_KEYWORDS,
    request_patterns=_REQUEST_PATTERNS,
    text_patterns=_TEXT_PATTERNS,
)


def is_likely_endpoint(url: str, heuristics: EndpointHeuristics = DEFAULT_ENDPOINT_HEURISTICS) -> bool:
    """Return True if the URL is likely an interesting API/WebSocket endpoint."""

    lowered = url.lower()
    return any(keyword in lowered for keyword in heuristics.keywords)


def extract_request_matches(
    text: str, heuristics: EndpointHeuristics = DEFAULT_ENDPOINT_HEURISTICS
) -> Tuple[str, ...]:
    """Extract candidate endpoint strings from JS/HTML request snippets."""

    return tuple(_iter_pattern_matches(text, heuristics.request_patterns))


def extract_text_matches(
    text: str, heuristics: EndpointHeuristics = DEFAULT_ENDPOINT_HEURISTICS
) -> Tuple[str, ...]:
    """Extract candidate endpoint strings from plain text/HTML content."""

    return tuple(_iter_pattern_matches(text, heuristics.text_patterns))


def _iter_pattern_matches(text: str, patterns: Sequence[Pattern[str]]) -> Iterator[str]:
    for pattern in patterns:
        for match in pattern.findall(text):
            if isinstance(match, tuple):
                if match:
                    yield match[0]
            else:
                yield match


__all__ = [
    "EndpointHeuristics",
    "DEFAULT_ENDPOINT_HEURISTICS",
    "is_likely_endpoint",
    "extract_request_matches",
    "extract_text_matches",
]
