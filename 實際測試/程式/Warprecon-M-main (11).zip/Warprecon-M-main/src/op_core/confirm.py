from __future__ import annotations

from typing import Iterable, Tuple


def _variants(s: str) -> Iterable[Tuple[str, str]]:
    """Yield simple string variants used in tests.

    Parameters
    ----------
    s: str
        Seed string.

    Yields
    ------
    Tuple[str, str]
        Pairs of variant name and transformed string.
    """
    yield "case_flip", s.swapcase()
    yield "space_pad", f" {s} "
