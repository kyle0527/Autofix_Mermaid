from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import time
import weakref
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Union


from op_core.finding_contract import Finding


def fp(item: Mapping[str, Any]) -> str:

    """Compute a deterministic fingerprint for a finding candidate.

    Includes protocol and, when present, mode and hashes the full payload to
    reduce collisions from truncation. Uses JSON serialization to avoid
    collisions when delimiter characters appear in fields.
    """
    vector = item.get("vector", {}) or {}
    base_obj = {
        "target": item.get("target", "") or "",
        "protocol": vector.get("protocol", "") or "",
        "location": vector.get("location", "") or "",
        "param": vector.get("param", "") or "",
        "payload": item.get("payload", "") or "",
    }
    mode = item.get("mode")
    if mode:
        base_obj["mode"] = mode
    base = json.dumps(base_obj, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(base.encode("utf-8")).hexdigest()


class DeDup:
    """Track fingerprints of findings using a lightweight SQLite store.

    The store keeps a bounded window of fingerprints governed by ``ttl_days``
    so lookups remain efficient even when processing large campaigns. When
    ``db_path`` is not provided an in-memory database is used.
    """

    def __init__(
        self,
        db_path: Optional[Union[str, Path]] = None,
        ttl_days: Optional[float] = 30.0,
    ) -> None:
        self._ttl_seconds = 0.0 if ttl_days in (None, 0) else max(float(ttl_days), 0.0) * 86400.0
        self._lock = threading.Lock()

        if isinstance(db_path, Path):
            db_path.parent.mkdir(parents=True, exist_ok=True)
            db_location = str(db_path)
        elif isinstance(db_path, str) and db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
            db_location = db_path
        elif db_path:
            db_location = str(db_path)
        else:
            db_location = ":memory:"

        self._conn = sqlite3.connect(db_location, isolation_level=None, check_same_thread=False)
        self._finalizer = weakref.finalize(self, self._conn.close)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.DatabaseError:
            pass
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS fingerprints (
                fingerprint TEXT PRIMARY KEY,
                expires REAL
            )
            """
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_fingerprints_expires ON fingerprints(expires)"
        )

    def _prune(self, now: float) -> None:
        if self._ttl_seconds > 0:
            self._conn.execute(
                "DELETE FROM fingerprints WHERE expires IS NOT NULL AND expires <= ?",
                (now,),
            )

    def seen_before(self, item: Mapping[str, Any] | Finding) -> bool:



        """Return ``True`` if the item's fingerprint has been seen before."""

        digest = fp(item)
        now = time.time()

        with self._lock:
            self._prune(now)
            if self._ttl_seconds > 0:
                row = self._conn.execute(
                    "SELECT 1 FROM fingerprints WHERE fingerprint = ? AND (expires IS NULL OR expires > ?)",
                    (digest, now),
                ).fetchone()
            else:
                row = self._conn.execute(
                    "SELECT 1 FROM fingerprints WHERE fingerprint = ?",
                    (digest,),
                ).fetchone()

            if row:
                return True

            expires = (now + self._ttl_seconds) if self._ttl_seconds > 0 else None
            self._conn.execute(
                "INSERT OR REPLACE INTO fingerprints (fingerprint, expires) VALUES (?, ?)",
                (digest, expires),
            )
            return False

    def close(self) -> None:
        """Close the underlying SQLite connection."""

        with self._lock:
            if self._finalizer.alive:
                self._finalizer()

