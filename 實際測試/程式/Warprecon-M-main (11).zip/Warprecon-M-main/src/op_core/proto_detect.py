from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import urlparse

import httpx

try:  # pragma: no cover - optional dependency
    from aioquic.asyncio.client import connect as _quic_connect
    from aioquic.h3.connection import H3_ALPN, H3Connection
    from aioquic.h3.events import DataReceived, HeadersReceived
    from aioquic.quic.configuration import QuicConfiguration
    from aioquic.quic.events import (
        ConnectionTerminated,
        HandshakeCompleted,
        ProtocolNegotiated,
        QuicEvent,
    )
    from aioquic.asyncio.protocol import QuicConnectionProtocol

    _AIOQUIC_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency import guard
    _quic_connect = None
    H3_ALPN = ["h3"]
    H3Connection = None  # type: ignore[assignment]
    DataReceived = HeadersReceived = None  # type: ignore[assignment]
    QuicConfiguration = None  # type: ignore[assignment]
    QuicEvent = ProtocolNegotiated = HandshakeCompleted = ConnectionTerminated = None  # type: ignore[assignment]
    QuicConnectionProtocol = object  # type: ignore[assignment]
    _AIOQUIC_AVAILABLE = False


quic_connect = _quic_connect


@dataclass
class _Http3Request:
    host: str
    port: int
    scheme: str
    authority: str
    path: str
    server_name: str
    headers: Sequence[Tuple[str, str]]


_ALT_SVC_H3_RE = re.compile(r"h3[^=]*=\"([^\"]+)\"", re.IGNORECASE)


def detect_http_versions(url: str, timeout: float = 5.0) -> Dict[str, bool]:
    hints = {"http2": False, "http3_hint": False, "http3": False}
    try:
        with httpx.Client(http2=True, timeout=timeout, follow_redirects=True) as cli:
            resp = cli.get(url)
            ver = getattr(resp, "http_version", None)
            if ver and "2" in str(ver):
                hints["http2"] = True

            alt_svc = resp.headers.get("alt-svc", "")
            if "h3" in alt_svc.lower():
                hints["http3_hint"] = True
                target_url = str(getattr(resp, "url", url))
                try:
                    probe_result = _probe_http3(
                        target_url, timeout=timeout, alt_svc=alt_svc
                    )
                except TypeError:
                    probe_result = _probe_http3(target_url, timeout=timeout)

                if probe_result:
                    hints["http3"] = True
    except Exception:
        pass
    return hints


def _probe_http3(url: str, *, timeout: float = 5.0, alt_svc: str | None = None) -> bool:
    if not _AIOQUIC_AVAILABLE or _quic_connect is None or QuicConfiguration is None:
        return False

    requests = _build_http3_requests(url, alt_svc=alt_svc)
    if not requests:
        return False

    return _run_async(lambda: _async_probe_http3(requests, timeout))


def _run_async(factory):
    try:
        return asyncio.run(factory())
    except RuntimeError as exc:  # pragma: no cover - fallback for running loop
        if "asyncio.run() cannot be called" in str(exc):
            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(factory())
            finally:
                loop.close()
        raise


async def _async_probe_http3(requests: Sequence[_Http3Request], timeout: float) -> bool:
    for request in requests:
        try:
            if await _async_probe_single(request, timeout):
                return True
        except asyncio.CancelledError:  # pragma: no cover - propagated
            raise
        except Exception:
            continue
    return False


async def _async_probe_single(request: _Http3Request, timeout: float) -> bool:
    assert _quic_connect is not None
    assert QuicConfiguration is not None

    configuration = QuicConfiguration(is_client=True, alpn_protocols=list(H3_ALPN))
    configuration.server_name = request.server_name

    loop = asyncio.get_running_loop()
    result_future: asyncio.Future[bool] = loop.create_future()

    def _protocol_factory(connection, stream_handler=None):  # type: ignore[override]
        return _Http3ProbeProtocol(
            connection,
            stream_handler=stream_handler,
            request=request,
            result_future=result_future,
        )

    async with _quic_connect(
        request.host,
        request.port,
        configuration=configuration,
        create_protocol=_protocol_factory,
    ):
        try:
            return await asyncio.wait_for(asyncio.shield(result_future), timeout)
        except asyncio.TimeoutError:
            return False


class _Http3ProbeProtocol(QuicConnectionProtocol):  # type: ignore[misc]
    def __init__(
        self,
        *args,
        request: _Http3Request,
        result_future: "asyncio.Future[bool]",
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._request = request
        self._future = result_future
        self._http: Optional[H3Connection] = None
        self._stream_id: Optional[int] = None

    def quic_event_received(self, event: QuicEvent) -> None:  # type: ignore[override]
        if self._future.done():
            return

        needs_transmit = False

        if ProtocolNegotiated is not None and isinstance(event, ProtocolNegotiated):
            if event.alpn_protocol not in H3_ALPN:
                self._set_result(False)
                return

        if HandshakeCompleted is not None and isinstance(event, HandshakeCompleted):
            if event.alpn_protocol not in H3_ALPN:
                self._set_result(False)
                return
            if self._http is None and H3Connection is not None:
                self._http = H3Connection(self._quic)
                needs_transmit = True
            self._send_request()
            needs_transmit = True
        elif ConnectionTerminated is not None and isinstance(event, ConnectionTerminated):
            self._set_result(False)
            return

        if self._http is None:
            if needs_transmit:
                self.transmit()
            return

        for http_event in self._http.handle_event(event):  # type: ignore[union-attr]
            needs_transmit = True
            if HeadersReceived is not None and isinstance(http_event, HeadersReceived):
                if http_event.stream_id == self._stream_id:
                    self._set_result(True)
                    return
            if DataReceived is not None and isinstance(http_event, DataReceived):
                if http_event.stream_id == self._stream_id:
                    self._set_result(True)
                    return

        if needs_transmit:
            self.transmit()

    def _send_request(self) -> None:
        if self._http is None or self._stream_id is not None:
            return
        self._stream_id = self._quic.get_next_available_stream_id()
        headers = [
            (":method", "GET"),
            (":scheme", self._request.scheme),
            (":authority", self._request.authority),
            (":path", self._request.path),
        ]
        headers.extend(self._request.headers)
        self._http.send_headers(self._stream_id, headers, end_stream=True)

    def _set_result(self, value: bool) -> None:
        if not self._future.done():
            self._future.set_result(value)
        self.close()
        self.transmit()


if _quic_connect is None or not _AIOQUIC_AVAILABLE:
    _H3ProbeClient = None
else:
    _H3ProbeClient = _Http3ProbeProtocol


def _build_http3_requests(url: str, *, alt_svc: str | None) -> List[_Http3Request]:
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.hostname:
        return []

    scheme = parsed.scheme.lower()
    default_port = 443 if scheme == "https" else 80
    origin_port = parsed.port or default_port
    authority = parsed.hostname if parsed.port in (None, default_port) else f"{parsed.hostname}:{parsed.port}"

    path = parsed.path or "/"
    if parsed.params:
        path += f";{parsed.params}"
    if parsed.query:
        path += f"?{parsed.query}"

    targets: List[Tuple[str, int]] = []
    seen: set[Tuple[str, int]] = set()

    def _add_target(host: str, port: int) -> None:
        key = (host, port)
        if key not in seen:
            seen.add(key)
            targets.append(key)

    _add_target(parsed.hostname, origin_port)

    for authority_value in _extract_alt_svc_authorities(alt_svc or ""):
        host, port = _resolve_authority(authority_value, parsed.hostname, default_port)
        _add_target(host, port)

    headers: List[Tuple[str, str]] = [("user-agent", "warprecon-http3-probe/1.0")]

    requests = [
        _Http3Request(
            host=host,
            port=port,
            scheme=scheme,
            authority=authority,
            path=path,
            server_name=host,
            headers=headers,
        )
        for host, port in targets
    ]

    return requests


def _extract_alt_svc_authorities(header: str) -> Iterable[str]:
    for match in _ALT_SVC_H3_RE.finditer(header):
        yield match.group(1)


def _resolve_authority(authority: str, fallback_host: str, default_port: int) -> Tuple[str, int]:
    if authority.startswith(":"):
        host = fallback_host
        port_text = authority[1:]
        try:
            port = int(port_text)
        except ValueError:
            port = default_port
        return host, port

    parsed = urlparse(f"//{authority}")
    host = parsed.hostname or fallback_host
    port = parsed.port or default_port
    return host, port
