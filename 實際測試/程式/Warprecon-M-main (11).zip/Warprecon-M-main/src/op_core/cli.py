from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, List, Optional

import typer
from typer.models import OptionInfo

from op_checks.base import REGISTRY
from op_checks.idor import IdorCheck
from op_core.commands import hunt as hunt_cmd
from op_core.commands import rank as rank_cmd
from op_core.commands import report as report_cmd
from op_core.configure.cli import configure_app
from op_core.metrics.cli import telemetry_app
from op_core.finding_contract import Finding, as_findings
from op_core.pipeline import run_pipeline
from op_dist.agent import run_agent
from op_dist.queue import FSQueue
from op_output.deliver import make_deliverable_zip
from op_ui.server import create_app
from op_auth.cli import auth_app as auth_cli_app

app = typer.Typer(
    add_completion=False,
    help="Warprecon-M CLI",
    context_settings={"help_option_names": ["-h", "--help"]},
)

app.add_typer(auth_cli_app, name="auth")
app.add_typer(telemetry_app, name="telemetry")
app.add_typer(configure_app, name="configure")


def _read_targets_file(path: Path) -> List[str]:
    content = path.read_text(encoding="utf-8")
    # If file contains JSON (list or dict), parse and return structured APIs
    parsed = _parse_apis(content)
    if isinstance(parsed, list):
        return parsed
    # Fallback: return newline-delimited list of URLs
    return [line.strip() for line in content.splitlines() if line.strip()]


def _parse_apis(raw: str) -> List[Any]:
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return [line.strip() for line in raw.splitlines() if line.strip()]
    if isinstance(data, dict) and "apis" in data:
        data = data["apis"]
    if isinstance(data, list):
        return data
    return [data]


def _load_inline_or_file(source: str) -> List[Any]:
    path = Path(source)
    if path.exists():
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise typer.BadParameter(f"Error reading {path}: {exc}", param_hint="--apis") from exc
        return _parse_apis(raw)
    return _parse_apis(source)


def _ensure_finding_dict(item: Any) -> dict[str, Any]:
    if isinstance(item, Finding):
        return item.to_dict()
    if isinstance(item, dict):
        return dict(item)
    to_dict = getattr(item, "to_dict", None)
    if callable(to_dict):  # pragma: no cover - adapter compatibility
        return dict(to_dict())  # type: ignore[call-arg]
    raise TypeError(f"Unsupported finding object: {type(item)!r}")


def _run_registered_check(check_name: str, apis_data: List[Any], workdir: Path | None) -> List[Any]:
    check_class = REGISTRY.get(check_name)
    if not check_class:
        available = ", ".join(sorted(REGISTRY.keys()))
        raise KeyError(f"Unknown check '{check_name}'. Available: [{available}]")

    check_instance = check_class()
    run_kwargs: dict[str, Any] = {"apis": apis_data}
    if workdir is not None:
        run_kwargs["workdir"] = workdir

    try:
        findings_iter = check_instance.run(**run_kwargs)
    except TypeError:
        run_kwargs.pop("workdir", None)
        findings_iter = check_instance.run(**run_kwargs)
    return list(findings_iter)


@app.command("hunt")
def hunt_command(
    targets: Path = typer.Option(..., "--targets", help="Path to newline-delimited targets file."),
    cfg: Path = typer.Option(..., "--cfg", help="Campaign configuration file."),
    out: Path = typer.Option(..., "--out", help="Output file for hunt results."),
) -> None:
    """Execute adaptive hunt against the provided targets."""

    hunt_cmd.run(targets, cfg, out)


@app.command("rank")
def rank_command(
    infile: Path = typer.Option(..., "--in", "--infile", help="Ranked input JSON file."),
    out: Path = typer.Option(..., "--out", help="Destination for ranked findings."),
) -> None:
    """Rank findings produced by a hunt or pipeline run."""

    rank_cmd.run(infile, out)


@app.command("report")
def report_command(
    infile: Path = typer.Option(..., "--in", "--infile", help="Ranked findings JSON input."),
    out: Path = typer.Option(..., "--out", help="SARIF output path."),
) -> None:
    """Emit a SARIF report from ranked findings."""

    report_cmd.run(infile, out)


@app.command()
def pipeline(
    domain: str = typer.Option(..., "--domain", help="Domain or base URL to analyse."),
    cfg: Path = typer.Option(..., "--cfg", help="Campaign configuration file."),
    workdir: Path = typer.Option(..., "--workdir", help="Working directory for outputs."),
    max_concurrency: int | None = typer.Option(None, "--max-concurrency", help="Maximum concurrent workers."),
    poc_top: int | None = typer.Option(None, "--poc-top", help="Number of PoC payloads to keep."),
    capture: bool = typer.Option(False, "--capture", help="Enable HTTP capture."),
    history_ttl: int | None = typer.Option(None, "--history-ttl", help="History retention in days."),
    profile: Path | None = typer.Option(None, "--profile", help="Optional profile overlay YAML."),
    dom_crawl: bool = typer.Option(False, "--dom-crawl", help="Enable Playwright DOM discovery."),
    ultra: bool = typer.Option(False, "--ultra", help="Enable Ultra mode."),
    resume: bool = typer.Option(False, "--resume", help="Skip targets already marked as successful."),
    gate_threshold: float | None = typer.Option(
        None,
        "--gate-threshold",
        help="Override the campaign precision gate threshold (use configuration when omitted).",
        show_default=False,
    ),
    gate_topn: int | None = typer.Option(
        None,
        "--gate-topn",
        help="Override the campaign precision gate Top-N preservation (use configuration when omitted).",
        show_default=False,
    ),
    gate_labels: Path | None = typer.Option(
        None,
        "--gate-labels",
        help="Optional JSONL labels file providing accepted fingerprints.",
        show_default=False,
    ),
) -> None:
    """Run the end-to-end pipeline (Recon → Hunt → Adapters → Rank → Reports)."""

    if isinstance(gate_threshold, OptionInfo):
        gate_threshold = None
    if isinstance(gate_topn, OptionInfo):
        gate_topn = None
    if isinstance(gate_labels, OptionInfo):
        gate_labels = None

    result = run_pipeline(
        domain,
        cfg,
        workdir,
        max_concurrency=max_concurrency,
        poc_top=poc_top,
        capture=capture,
        history_ttl=history_ttl,
        profile=profile,
        dom_crawl=dom_crawl,
        ultra=ultra,
        resume=resume,
        gate_threshold=gate_threshold,
        gate_topn=gate_topn,
        gate_labels=gate_labels,
    )
    typer.echo(json.dumps(result, ensure_ascii=False, indent=2))


@app.command("queue-add")
def queue_add(
    workdir: Path = typer.Option(..., "--workdir", help="Work directory containing queue."),
    domain: str = typer.Option(..., "--domain", help="Domain to enqueue."),
    cfg: Path = typer.Option(Path("config/campaign.yaml"), "--cfg", help="Campaign configuration file."),
) -> None:
    """Enqueue a new domain task for distributed agents."""

    queue = FSQueue(workdir / "queue")
    tid = queue.enqueue(domain, str(cfg))
    typer.echo(json.dumps({"queued": tid, "domain": domain}, ensure_ascii=False))


agent_app = typer.Typer(help="Agent worker commands")
app.add_typer(agent_app, name="agent")


@agent_app.command("run")
def agent_run(
    workdir: Path = typer.Option(..., "--workdir", help="Work directory for the agent."),
    cfg: Path = typer.Option(..., "--cfg", help="Agent configuration file."),
    max_concurrency: int | None = typer.Option(None, "--max-concurrency", help="Maximum concurrency for the agent."),
    max_loops: int | None = typer.Option(None, "--max-loops", help="Number of queue iterations before exiting."),
) -> None:
    """Execute a filesystem queue-based agent worker."""

    run_agent(workdir, cfg, max_loops=max_loops, max_concurrency=max_concurrency)


@app.command()
def ui(
    workdir: Path = typer.Option(
        ..., "--workdir", help="Work directory that stores pipeline outputs."
    ),
    cfg: Path = typer.Option(..., "--cfg", help="Campaign configuration file."),
    port: int = typer.Option(8787, "--port", help="Port for the UI server."),
    auth_token: Optional[List[str]] = typer.Option(
        None,
        "--auth-token",
        help="Bearer token for UI API authentication (repeat to supply multiple tokens).",
        show_default=False,
    ),
) -> None:
    """Start the local UI server."""

    if isinstance(auth_token, OptionInfo):
        auth_token = None
    tokens = tuple(t.strip() for t in (auth_token or []) if t.strip()) or None

    try:
        ui_app = create_app(workdir, cfg, auth_tokens=tokens)
    except TypeError:
        ui_app = create_app(workdir, cfg)
    except RuntimeError as exc:
        typer.secho(str(exc), fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    ui_app.run(host="127.0.0.1", port=port, debug=False)


@app.command()
def deliver(
    workdir: Path = typer.Option(..., "--workdir", help="Work directory containing artifacts."),
    out: Path | None = typer.Option(None, "--out", help="Optional output ZIP path."),
) -> None:
    """Bundle deliverables (reports, SARIF, PoCs) into a ZIP archive."""

    archive = make_deliverable_zip(workdir, out)
    typer.echo(json.dumps({"zip": archive}, ensure_ascii=False))


@app.command()
def idor(
    targets: Path = typer.Option(..., "--targets", help="File with target URLs (one per line)."),
    out: Path = typer.Option(..., "--out", help="Output JSON file for findings."),
    expand_variants: bool = typer.Option(False, "--expand-variants", help="Generate ID variants."),
    max_variants: int = typer.Option(50, "--max-variants", help="Maximum variants per URL."),
    exclude: List[str] = typer.Option([], "--exclude", help="Regex patterns to exclude URLs."),
    as_json: bool = typer.Option(False, "--json", help="Write output as JSON array (compat)."),
) -> None:
    """Run the IDOR check across listed targets."""

    urls_or_apis = _read_targets_file(targets)
    # If file contained structured apis (list of dicts), use them directly
    if urls_or_apis and isinstance(urls_or_apis[0], dict):
        apis = urls_or_apis
    else:
        apis = [{"url": url} for url in urls_or_apis]
    check = IdorCheck(
        expand_variants=expand_variants,
        max_variants=max_variants,
        exclude_patterns=list(exclude),
    )
    findings = [item.to_dict() for item in as_findings(check.run(apis))]
    out.write_text(json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8")
    typer.echo(json.dumps({"findings": len(findings), "out": str(out)}, ensure_ascii=False))


@app.command()
def checks(
    check: str = typer.Option(..., "--check", help="Check name from registry."),
    apis: str = typer.Option(..., "--apis", help="Path to JSON/newline APIs list or inline JSON."),
    out: Path = typer.Option(..., "--out", help="Output file for findings."),
    workdir: Path | None = typer.Option(None, "--workdir", help="Optional working directory."),
) -> None:
    """Run a registered check against provided APIs."""

    apis_data = _load_inline_or_file(apis)
    if not apis_data:
        raise typer.BadParameter("No APIs provided for check", param_hint="--apis")

    try:
        findings = _run_registered_check(check, apis_data, workdir)
    except KeyError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc

    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as fh:
        for finding in findings:
            to_json = getattr(finding, "to_json", None)
            if callable(to_json):
                fh.write(to_json() + "\n")
            else:
                fh.write(json.dumps(_ensure_finding_dict(finding), ensure_ascii=False) + "\n")

    typer.echo(f"Completed {check} check on {len(apis_data)} APIs")
    typer.echo(f"Found {len(findings)} findings")
    typer.echo(f"Results written to {out}")

    if findings:
        typer.echo("\nFindings summary:")
        for finding in findings:
            payload = _ensure_finding_dict(finding)
            severity = str(payload.get("severity", "info"))
            title = str(payload.get("title", ""))
            target = str(payload.get("target", ""))
            typer.echo(f"  {severity.upper()}: {title}")
            if target:
                typer.echo(f"    Target: {target}")
            meta = payload.get("meta")
            if isinstance(meta, dict) and meta.get("idor_type"):
                typer.echo(f"    Type: {meta['idor_type']}")
            typer.echo("")


def handle_hunt(args: argparse.Namespace) -> None:
    hunt_cmd.run(Path(args.targets), Path(args.cfg), Path(args.out))


def handle_rank(args: argparse.Namespace) -> None:
    rank_cmd.run(Path(args.infile), Path(args.out))


def handle_report(args: argparse.Namespace) -> None:
    report_cmd.run(Path(args.infile), Path(args.out))


def handle_pipeline(args: argparse.Namespace) -> None:
    profile = Path(args.profile) if getattr(args, "profile", None) else None
    gate_labels = None
    raw_labels = getattr(args, "gate_labels", None)
    if raw_labels:
        gate_labels = Path(raw_labels)
    result = run_pipeline(
        args.domain,
        Path(args.cfg),
        Path(args.workdir),
        max_concurrency=getattr(args, "max_concurrency", None),
        poc_top=getattr(args, "poc_top", None),
        capture=getattr(args, "capture", False),
        history_ttl=getattr(args, "history_ttl", None),
        profile=profile,
        dom_crawl=getattr(args, "dom_crawl", False),
        ultra=getattr(args, "ultra", False),
        resume=getattr(args, "resume", False),
        gate_threshold=getattr(args, "gate_threshold", None),
        gate_topn=getattr(args, "gate_topn", None),
        gate_labels=gate_labels,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def handle_queue_add(args: argparse.Namespace) -> None:
    queue = FSQueue(Path(args.workdir) / "queue")
    tid = queue.enqueue(args.domain, args.cfg)
    print(json.dumps({"queued": tid, "domain": args.domain}, ensure_ascii=False))


def handle_agent_run(args: argparse.Namespace) -> None:
    run_agent(
        Path(args.workdir),
        Path(args.cfg),
        max_loops=getattr(args, "max_loops", None),
        max_concurrency=getattr(args, "max_concurrency", None),
    )


def handle_ui(args: argparse.Namespace) -> None:
    ui_app = create_app(Path(args.workdir), Path(args.cfg))
    ui_app.run(host="127.0.0.1", port=getattr(args, "port", 8787), debug=False)


def handle_deliver(args: argparse.Namespace) -> None:
    archive = make_deliverable_zip(
        Path(args.workdir),
        Path(args.out) if getattr(args, "out", None) else None,
    )
    print(json.dumps({"zip": archive}, ensure_ascii=False))


def handle_idor(args: argparse.Namespace) -> None:
    urls = _read_targets_file(Path(args.targets))
    apis = [{"url": url} for url in urls]
    check = IdorCheck(
        expand_variants=getattr(args, "expand_variants", False),
        max_variants=getattr(args, "max_variants", 50),
        exclude_patterns=list(getattr(args, "exclude", []) or []),
    )
    findings = [item.to_dict() for item in as_findings(check.run(apis))]
    out_path = Path(args.out)
    out_path.write_text(json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"findings": len(findings), "out": str(out_path)}, ensure_ascii=False))


def handle_checks(args: argparse.Namespace) -> None:
    apis_data = _load_inline_or_file(args.apis)
    if not apis_data:
        print("No APIs provided for check", file=sys.stderr)
        raise SystemExit(2)

    workdir = Path(args.workdir) if getattr(args, "workdir", None) else None
    try:
        findings = _run_registered_check(args.check, apis_data, workdir)
    except KeyError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2) from exc

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as fh:
        for finding in findings:
            to_json = getattr(finding, "to_json", None)
            if callable(to_json):
                fh.write(to_json() + "\n")
            else:
                fh.write(json.dumps(_ensure_finding_dict(finding), ensure_ascii=False) + "\n")

    print(f"Completed {args.check} check on {len(apis_data)} APIs")
    print(f"Found {len(findings)} findings")
    print(f"Results written to {out_path}")

    if findings:
        print("\nFindings summary:")
        for finding in findings:
            payload = _ensure_finding_dict(finding)
            severity = str(payload.get("severity", "info"))
            title = str(payload.get("title", ""))
            target = str(payload.get("target", ""))
            print(f"  {severity.upper()}: {title}")
            if target:
                print(f"    Target: {target}")
            meta = payload.get("meta")
            if isinstance(meta, dict) and meta.get("idor_type"):
                print(f"    Type: {meta['idor_type']}")
            print("")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="warprecon-m", description="Warprecon-M CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    hunt = sub.add_parser("hunt", help="Adaptive hunt")
    hunt.add_argument("--targets", required=True)
    hunt.add_argument("--cfg", required=True)
    hunt.add_argument("--out", required=True)
    hunt.set_defaults(handler=handle_hunt)

    rank = sub.add_parser("rank", help="Rank findings")
    rank.add_argument("--in", dest="infile", required=True)
    rank.add_argument("--out", required=True)
    rank.set_defaults(handler=handle_rank)

    report = sub.add_parser("report", help="Emit SARIF from ranked JSON")
    report.add_argument("--in", dest="infile", required=True)
    report.add_argument("--out", required=True)
    report.set_defaults(handler=handle_report)

    pipeline = sub.add_parser("pipeline", help="Recon → Hunt → Adapters → Rank → Reports")
    pipeline.add_argument("--domain", required=True)
    pipeline.add_argument("--cfg", required=True)
    pipeline.add_argument("--workdir", required=True)
    pipeline.add_argument("--max-concurrency", type=int, default=None)
    pipeline.add_argument("--poc-top", type=int, default=None)
    pipeline.add_argument("--capture", action="store_true")
    pipeline.add_argument("--history-ttl", type=int, default=None)
    pipeline.add_argument("--profile", type=str, default=None)
    pipeline.add_argument("--dom-crawl", action="store_true")
    pipeline.add_argument("--ultra", action="store_true")
    pipeline.add_argument("--resume", action="store_true")
    pipeline.add_argument("--gate-threshold", type=float, default=None)
    pipeline.add_argument("--gate-topn", type=int, default=None)
    pipeline.add_argument("--gate-labels", type=str, default=None)
    pipeline.set_defaults(handler=handle_pipeline)

    queue_add = sub.add_parser("queue-add", help="Enqueue a domain task")
    queue_add.add_argument("--workdir", required=True)
    queue_add.add_argument("--domain", required=True)
    queue_add.add_argument("--cfg", default="config/campaign.yaml")
    queue_add.set_defaults(handler=handle_queue_add)

    agent = sub.add_parser("agent", help="Run an agent worker")
    agent_sub = agent.add_subparsers(dest="agent_cmd", required=True)
    agent_run_parser = agent_sub.add_parser("run", help="Execute the queue worker")
    agent_run_parser.add_argument("--workdir", required=True)
    agent_run_parser.add_argument("--cfg", required=True)
    agent_run_parser.add_argument("--max-concurrency", type=int, default=None)
    agent_run_parser.add_argument("--max-loops", type=int, default=None)
    agent_run_parser.set_defaults(handler=handle_agent_run)

    ui = sub.add_parser("ui", help="Launch UI server")
    ui.add_argument("--workdir", required=True)
    ui.add_argument("--cfg", required=True)
    ui.add_argument("--port", type=int, default=8787)
    ui.set_defaults(handler=handle_ui)

    deliver = sub.add_parser("deliver", help="Zip outputs for delivery")
    deliver.add_argument("--workdir", required=True)
    deliver.add_argument("--out", default=None)
    deliver.set_defaults(handler=handle_deliver)

    idor = sub.add_parser("idor", help="Run IDOR check over targets file")
    idor.add_argument("--targets", required=True)
    idor.add_argument("--out", required=True)
    idor.add_argument("--expand-variants", action="store_true")
    idor.add_argument("--max-variants", type=int, default=50)
    idor.add_argument("--exclude", action="append", default=[])
    idor.add_argument("--json", action="store_true", dest="as_json", default=False)
    idor.set_defaults(handler=handle_idor)

    checks_parser = sub.add_parser("checks", help="Run a single check against APIs")
    checks_parser.add_argument("--check", required=True)
    checks_parser.add_argument("--apis", required=True)
    checks_parser.add_argument("--out", required=True)
    checks_parser.add_argument("--workdir", default=None)
    checks_parser.set_defaults(handler=handle_checks)

    return parser


def main() -> None:
    app(prog_name="warprecon-m")


if __name__ == "__main__":  # pragma: no cover
    main()
