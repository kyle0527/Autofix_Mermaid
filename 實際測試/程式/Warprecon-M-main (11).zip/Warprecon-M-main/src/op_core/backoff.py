from __future__ import annotations

import asyncio
import logging
import random
from collections.abc import Callable, Sequence
from typing import Any

import httpx

logger = logging.getLogger(__name__)


BackoffCallable = Callable[..., float]


def jitter_backoff(
    base: float = 0.5,
    factor: float = 2.0,
    max_time: float = 8.0,
    attempt: int = 0,
) -> float:
    """Return a jittered exponential delay for the given ``attempt``."""

    t = min(max_time, base * (factor**attempt))
    return t * (0.5 + random.random())


def _resolve_backoff(backoff: BackoffCallable | None, attempt: int) -> float:
    """Evaluate *backoff* for ``attempt`` and normalise the delay."""

    if backoff is None:
        return 0.0

    try:
        delay = backoff(attempt=attempt)
    except TypeError:
        delay = backoff(attempt)  # type: ignore[misc]
    except Exception as exc:  # pragma: no cover - defensive guard
        logger.warning("Backoff callable %r failed on attempt %s: %s", backoff, attempt, exc)
        return 0.0

    try:
        return max(0.0, float(delay))
    except (TypeError, ValueError):
        logger.warning(
            "Backoff callable %r returned non-numeric delay %r on attempt %s",
            backoff,
            delay,
            attempt,
        )
        return 0.0


class RetryingAsyncClient(httpx.AsyncClient):
    """``httpx.AsyncClient`` with retry and backoff support."""

    def __init__(
        self,
        *args: Any,
        retries: int = 0,
        backoff: BackoffCallable | None = None,
        retry_on: Sequence[type[BaseException]] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._max_retries = max(0, int(retries))
        self._backoff = backoff if backoff is not None else jitter_backoff
        if retry_on is None:
            retry_excs: Sequence[type[BaseException]] = (httpx.RequestError,)
        else:
            retry_excs = tuple(retry_on)
        self._retry_exceptions: tuple[type[BaseException], ...] = tuple(retry_excs)

    async def request(self, method: str, url: httpx.URL | str, **kwargs: Any) -> httpx.Response:  # type: ignore[override]
        attempt = 0
        while True:
            try:
                return await super().request(method, url, **kwargs)
            except self._retry_exceptions as exc:
                if attempt >= self._max_retries:
                    raise

                delay = _resolve_backoff(self._backoff, attempt)
                attempt += 1
                if delay > 0:
                    logger.debug(
                        "Retrying %s %s in %.3fs after %s (attempt %s/%s)",
                        method,
                        url,
                        delay,
                        exc,
                        attempt,
                        self._max_retries,
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.debug(
                        "Retrying %s %s immediately after %s (attempt %s/%s)",
                        method,
                        url,
                        exc,
                        attempt,
                        self._max_retries,
                    )

