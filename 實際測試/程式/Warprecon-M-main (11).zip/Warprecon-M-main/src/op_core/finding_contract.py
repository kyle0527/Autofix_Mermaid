from __future__ import annotations

import json
import time
from collections.abc import Iterable, Iterator, Mapping, MutableMapping
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

_BASE_FIELDS: set[str] = {"check", "target", "severity", "title", "detail", "meta", "ts"}


@dataclass
class Finding(MutableMapping[str, Any]):
    """Lightweight container representing a single finding.

    ``Finding`` behaves like the legacy dictionary representation used across the
    code base while exposing convenience attributes for the common fields.  Any
    additional keys are stored transparently and included when serialized back
    to dictionaries or JSON.
    """

    check: str = ""
    target: str = ""
    severity: str = "info"
    title: str = ""
    detail: str = ""
    meta: Optional[Dict[str, Any]] = None
    ts: float = 0.0
    data: Dict[str, Any] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.data, dict):
            self.data = dict(self.data)
        if not isinstance(self.extra, dict):
            self.extra = dict(self.extra)

        if self.meta is None:
            self.meta = {}
        elif not isinstance(self.meta, dict):
            self.meta = dict(self.meta)

        # Fall back to values present in ``data`` when explicit arguments are not
        # provided.  Afterwards keep ``data`` in sync with the attributes.
        for field_name in ("check", "target", "severity", "title", "detail"):
            value = getattr(self, field_name)
            if not value:
                data_value = self.data.get(field_name)
                if data_value:
                    setattr(self, field_name, data_value)
            self.data[field_name] = getattr(self, field_name)

        meta_val = self.data.get("meta", self.meta) or {}
        if not isinstance(meta_val, dict):
            meta_val = dict(meta_val)
        self.meta = meta_val
        self.data["meta"] = self.meta

        ts_val = self.data.get("ts", self.ts)
        try:
            self.ts = float(ts_val) if ts_val else 0.0
        except (TypeError, ValueError):
            self.ts = 0.0
        if self.ts:
            self.data["ts"] = self.ts
        else:
            self.data.setdefault("ts", self.ts)

        # Merge explicit ``extra`` payloads, ignoring core fields.
        for key in list(self.extra.keys()):
            value = self.extra[key]
            if key in _BASE_FIELDS:
                if key == "meta":
                    if not isinstance(value, dict):
                        value = dict(value or {})
                    self.meta = value
                    self.data["meta"] = self.meta
                elif key == "ts":
                    try:
                        self.ts = float(value) if value else 0.0
                    except (TypeError, ValueError):
                        self.ts = 0.0
                    if self.ts:
                        self.data["ts"] = self.ts
                    else:
                        self.data.setdefault("ts", self.ts)
                else:
                    setattr(self, key, value or "")
                    self.data[key] = getattr(self, key)
                del self.extra[key]
            else:
                self.data.setdefault(key, value)

        self._refresh_extra()

    # ------------------------------------------------------------------
    # Mapping protocol --------------------------------------------------
    def __getitem__(self, key: str) -> Any:
        if key == "meta":
            return self.meta
        if key == "ts":
            return self.ts
        if key in _BASE_FIELDS:
            return getattr(self, key)
        return self.data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        if key == "meta":
            self.meta = dict(value) if value is not None else {}
            self.data["meta"] = self.meta
        elif key == "ts":
            try:
                self.ts = float(value) if value else 0.0
            except (TypeError, ValueError):
                self.ts = 0.0
            self.data["ts"] = self.ts
        elif key in _BASE_FIELDS:
            setattr(self, key, value or "")
            self.data[key] = getattr(self, key)
        else:
            self.data[key] = value
        self._refresh_extra()

    def __delitem__(self, key: str) -> None:
        if key == "meta":
            self.meta = {}
            self.data["meta"] = self.meta
        elif key == "ts":
            self.ts = 0.0
            self.data["ts"] = self.ts
        elif key in _BASE_FIELDS:
            default = "" if isinstance(getattr(self, key), str) else 0.0
            setattr(self, key, default)
            self.data[key] = getattr(self, key)
        else:
            del self.data[key]
        self._refresh_extra()

    def __iter__(self) -> Iterator[str]:
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)

    # Convenience helpers ----------------------------------------------
    def get(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        if key == "meta":
            return self.meta if self.meta else default
        if key == "ts":
            return self.ts if self.ts else default
        value = self.data.get(key, default)
        if key in _BASE_FIELDS and value in (None, ""):
            return default
        return value

    def keys(self):  # pragma: no cover - simple proxy
        return self.data.keys()

    def items(self):  # pragma: no cover - simple proxy
        return self.data.items()

    def values(self):  # pragma: no cover - simple proxy
        return self.data.values()

    def copy(self) -> "Finding":
        return Finding.from_dict(self.to_dict())

    @property
    def score(self) -> Optional[float]:
        val = self.data.get("_score")
        if val is None:
            return None
        try:
            return float(val)
        except (TypeError, ValueError):  # pragma: no cover - defensive
            return None

    @score.setter
    def score(self, value: Optional[float]) -> None:
        if value is None:
            self.data.pop("_score", None)
        else:
            self.data["_score"] = value

    @property
    def rank(self) -> Optional[int]:
        val = self.data.get("_rank")
        if val is None:
            return None
        try:
            return int(val)
        except (TypeError, ValueError):  # pragma: no cover - defensive
            return None

    @rank.setter
    def rank(self, value: Optional[int]) -> None:
        if value is None:
            self.data.pop("_rank", None)
        else:
            self.data["_rank"] = value

    @property
    def confirmed(self) -> Optional[bool]:
        return self.data.get("_confirmed")

    @confirmed.setter
    def confirmed(self, value: Optional[bool]) -> None:
        if value is None:
            self.data.pop("_confirmed", None)
        else:
            self.data["_confirmed"] = bool(value)

    def to_dict(self) -> Dict[str, Any]:
        out = dict(self.data)
        out["check"] = self.check
        out["target"] = self.target
        out["severity"] = self.severity
        out["title"] = self.title
        out["detail"] = self.detail
        out["meta"] = self.meta or {}
        out["ts"] = self.ts
        return out

    def to_json(self) -> str:
        payload = self.to_dict()
        if not payload.get("ts"):
            now = time.time()
            payload["ts"] = now
            self.ts = now
            self.data["ts"] = now
        return json.dumps(payload, ensure_ascii=False)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Finding":
        base = dict(payload)
        return cls(
            check=str(base.get("check", "")),
            target=str(base.get("target", "")),
            severity=str(base.get("severity", "info")),
            title=str(base.get("title", "")),
            detail=str(base.get("detail", "")),
            meta=base.get("meta"),
            ts=float(base.get("ts", 0.0) or 0.0),
            data=base,
        )

    @classmethod
    def ensure(cls, obj: "Finding" | Mapping[str, Any]) -> "Finding":
        if isinstance(obj, cls):
            return obj
        if isinstance(obj, Mapping):
            return cls.from_dict(obj)
        raise TypeError(f"Unsupported finding type: {type(obj)!r}")

    @staticmethod
    def from_json(s: str) -> "Finding":
        return Finding.from_dict(json.loads(s))

    def _refresh_extra(self) -> None:
        self.extra = {k: v for k, v in self.data.items() if k not in _BASE_FIELDS}


def as_finding(candidate: Finding | Mapping[str, Any]) -> Finding:
    """Return a :class:`Finding` for *candidate* without altering existing instances."""

    return Finding.ensure(candidate)


def as_findings(items: Iterable[Finding | Mapping[str, Any]]) -> list[Finding]:
    """Materialise all *items* as :class:`Finding` objects."""

    return [as_finding(item) for item in items]
