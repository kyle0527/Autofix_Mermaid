from __future__ import annotations

import asyncio
import inspect
import logging
import threading
import urllib.parse
from collections.abc import Mapping
from fnmatch import fnmatch
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from op_auth import AuthManager, NoAuthStrategy
from op_control.campaign import Campaign
from op_core.backoff import jitter_backoff
from op_core.dedupe import DeDup, fp
from op_core.finding_contract import Finding, as_finding
from op_core.history import HistoryDB
from op_core.httpclient import make_async_client
from op_core.plugins import get_protocol
from op_core.ratelimit import RateLimiter
from op_core.runtime_gate import wait_if_paused
from op_forms.simple import choose_form_fields, extract_forms
from op_oob.interactsh import InteractClient
from op_synth.synth import generate_candidates, probe_positions

logger = logging.getLogger(__name__)


try:  # pragma: no cover - exercised via runtime lookups
    from op_proto.http.engine import http_probe as _http_probe_impl
    _HTTP_PROBE_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    _HTTP_PROBE_AVAILABLE = False

    async def _http_probe_impl(*_args: Any, **_kwargs: Any) -> None:
        return None


try:  # pragma: no cover - exercised via runtime lookups
    from op_proto.graphql.engine import graphql_probe as _graphql_probe_impl
    _GRAPHQL_PROBE_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    _GRAPHQL_PROBE_AVAILABLE = False

    async def _graphql_probe_impl(*_args: Any, **_kwargs: Any) -> None:
        return None


try:  # pragma: no cover - exercised via runtime lookups
    from op_proto.ws.engine import ws_probe as _ws_probe_impl
    _WS_PROBE_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    _WS_PROBE_AVAILABLE = False

    async def _ws_probe_impl(*_args: Any, **_kwargs: Any) -> None:
        return None


try:  # pragma: no cover - exercised via runtime lookups
    from op_proto.grpc.engine import grpc_probe as _grpc_probe_impl
    _GRPC_PROBE_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    _GRPC_PROBE_AVAILABLE = False

    async def _grpc_probe_impl(*_args: Any, **_kwargs: Any) -> None:
        return None


PROBE_FALLBACKS = {
    "http": _http_probe_impl,
    "graphql": _graphql_probe_impl,
    "ws": _ws_probe_impl,
    "grpc": _grpc_probe_impl,
}

PROBE_AVAILABILITY = {
    "http": _HTTP_PROBE_AVAILABLE,
    "graphql": _GRAPHQL_PROBE_AVAILABLE,
    "ws": _WS_PROBE_AVAILABLE,
    "grpc": _GRPC_PROBE_AVAILABLE,
}

_MISSING_PROBE_WARNINGS: set[str] = set()


try:  # optional dependency used for robust gRPC host parsing
    from op_proto.grpc.enumerate import _split_target as _grpc_split_target
except Exception:  # pragma: no cover - gRPC extras optional in tests
    _grpc_split_target = None  # type: ignore


__all__ = [
    "run_hunt_async",
    "run_hunt",
    "classify_target_protocols",
    "filter_targets_by_scope",
]


def _extract_candidate_role(candidate: Any) -> Optional[str]:
    if not isinstance(candidate, Mapping):
        return None

    auth_cfg = candidate.get("auth")
    if isinstance(auth_cfg, Mapping):
        for key in ("role", "account", "profile", "name"):
            value = auth_cfg.get(key)
            if isinstance(value, str):
                value = value.strip()
                if value:
                    return value

    role = candidate.get("auth_role")
    if isinstance(role, str):
        role = role.strip()
        if role:
            return role
    return None


def _merge_session_artifacts(
    candidate: Mapping[str, Any], artifacts: Mapping[str, Any]
) -> Dict[str, Any]:
    """Return a candidate copy enriched with session headers/cookies/etc."""

    merged = dict(candidate)
    if not isinstance(artifacts, Mapping):
        return merged

    def _normalise_mapping(value: Any) -> Dict[str, Any]:
        if not isinstance(value, Mapping):
            return {}
        normalised: Dict[str, Any] = {}
        for key, inner in value.items():
            if inner is None:
                continue
            normalised[str(key)] = inner
        return normalised

    session_headers = _normalise_mapping(artifacts.get("headers"))
    if session_headers:
        combined_headers = dict(session_headers)
        existing_headers = merged.get("headers")
        if isinstance(existing_headers, Mapping):
            combined_headers.update(
                {
                    str(key): value
                    for key, value in existing_headers.items()
                    if value is not None
                }
            )
        merged["headers"] = combined_headers

    session_cookies = _normalise_mapping(artifacts.get("cookies"))
    if session_cookies:
        combined_cookies = dict(session_cookies)
        existing_cookies = merged.get("cookies")
        if isinstance(existing_cookies, Mapping):
            combined_cookies.update(
                {
                    str(key): value
                    for key, value in existing_cookies.items()
                    if value is not None
                }
            )
        merged["cookies"] = combined_cookies

    session_query = _normalise_mapping(artifacts.get("query"))
    if session_query:
        combined_query = dict(session_query)
        existing_query = merged.get("query")
        if isinstance(existing_query, Mapping):
            combined_query.update(dict(existing_query))
        merged["query"] = combined_query

    session_body = _normalise_mapping(artifacts.get("body"))
    if session_body:
        combined_body = dict(session_body)
        existing_body = merged.get("body")
        if isinstance(existing_body, Mapping):
            combined_body.update(dict(existing_body))
        merged["body"] = combined_body

    token = artifacts.get("token")
    if token is not None and not merged.get("token"):
        merged["token"] = token

    return merged


def _scope_patterns(values: Sequence[str] | None) -> List[str]:
    patterns: List[str] = []
    if not values:
        return patterns
    for raw in values:
        if not isinstance(raw, str):
            continue
        stripped = raw.strip()
        if stripped:
            patterns.append(stripped.lower())
    return patterns


def _scope_candidates(target: str) -> List[str]:
    parsed = urllib.parse.urlsplit(target)
    candidates = [target.lower()]
    if parsed.scheme and parsed.netloc:
        candidates.append(f"{parsed.scheme}://{parsed.netloc}".lower())
    if parsed.netloc:
        candidates.append(parsed.netloc.lower())
        candidates.append(f"{parsed.netloc}{parsed.path}".lower())
    if parsed.hostname:
        candidates.append(parsed.hostname.lower())
    if parsed.path:
        candidates.append(parsed.path.lower())
    base = target.split("/", 1)[0].lower()
    if base not in candidates:
        candidates.append(base)
    # remove duplicates preserving order
    seen: set[str] = set()
    ordered: List[str] = []
    for cand in candidates:
        if cand and cand not in seen:
            seen.add(cand)
            ordered.append(cand)
    return ordered


def _matches_scope(patterns: Sequence[str], target: str) -> bool:
    if not patterns:
        return False
    candidates = _scope_candidates(target)
    for pattern in patterns:
        for candidate in candidates:
            if fnmatch(candidate, pattern):
                return True
    return False


def filter_targets_by_scope(targets: Sequence[str], campaign: Campaign) -> List[str]:
    """Return targets that comply with the campaign's allow/deny scope."""

    allow_patterns = _scope_patterns(getattr(campaign, "allow", None))
    deny_patterns = _scope_patterns(getattr(campaign, "deny", None))
    if not allow_patterns and not deny_patterns:
        return list(targets)

    scoped: List[str] = []
    for target in targets:
        if deny_patterns and _matches_scope(deny_patterns, target):
            logger.info("Skipping target %s due to deny scope", target)
            continue
        if allow_patterns and not _matches_scope(allow_patterns, target):
            logger.info("Skipping target %s as it is outside allow scope", target)
            continue
        scoped.append(target)
    return scoped


def classify_target_protocols(target: str) -> List[str]:
    """Infer the set of protocols that apply to *target*.

    The helper performs a best-effort classification using the URL scheme and
    path components. HTTP endpoints that look like GraphQL APIs expose both the
    ``http`` and ``graphql`` protocols so callers can choose either probing
    strategy. When detection fails the function falls back to ``http``.
    """

    parsed = urllib.parse.urlparse(target)
    scheme = (parsed.scheme or "").lower()
    protocols: List[str] = []

    def _add(name: str) -> None:
        name = name.lower()
        if name and name not in protocols:
            protocols.append(name)

    if scheme in {"ws", "wss"}:
        _add("ws")
        return protocols
    if scheme in {"grpc", "grpcs"}:
        _add("grpc")
        return protocols

    if scheme in {"http", "https"}:
        _add("http")
    elif not scheme:
        lowered = target.lower()
        if lowered.startswith("ws://") or lowered.startswith("wss://"):
            return ["ws"]
        if lowered.startswith("grpc://"):
            return ["grpc"]
        head = target.split("/", 1)[0]
        if ":" in head and "@" not in head:
            _add("grpc")
            return protocols
        _add("http")
    else:
        _add(scheme)

    path = (parsed.path or "").lower()
    query = (parsed.query or "").lower()
    if "graphql" in path or "graphql" in query or path.endswith(".graphql"):
        _add("graphql")

    return protocols or ["http"]


def _protocols_for_target(
    target: str, hints: Optional[Dict[str, Iterable[str] | str]]
) -> List[str]:
    hint_list: Sequence[str] | str | None = hints.get(target) if hints else None
    candidates: List[str] = []
    if isinstance(hint_list, str):
        candidates = [hint_list]
    elif isinstance(hint_list, Iterable):
        candidates = list(hint_list)
    else:
        candidates = classify_target_protocols(target)

    seen: set[str] = set()
    ordered: List[str] = []
    for proto in candidates:
        raw = (proto or "").lower()
        if not raw:
            continue
        parts = [raw]
        if "," in raw:
            parts = [p.strip() for p in raw.split(",") if p.strip()]
        for part in parts:
            if part not in seen:
                seen.add(part)
                ordered.append(part)
    return ordered or ["http"]


def _target_host(target: str, protocols: Sequence[str]) -> str:
    parsed = urllib.parse.urlparse(target)
    hostname = parsed.hostname
    if hostname:
        return hostname
    if any(p in {"http", "https", "ws", "graphql"} for p in protocols):
        if parsed.netloc:
            host = parsed.netloc.split("@")[-1]
            return host.split(":")[0]
    if "grpc" in protocols and _grpc_split_target is not None:
        try:
            host, _ = _grpc_split_target(target if ":" in target else f"{target}:443")
            return host
        except Exception:  # pragma: no cover - defensive fallback
            pass
    raw = target
    for prefix in ("grpc://", "ws://", "wss://"):
        if raw.startswith(prefix):
            raw = raw[len(prefix) :]
            break
    if raw.startswith("[") and "]" in raw:
        return raw[1 : raw.find("]")]
    if ":" in raw:
        return raw.split(":", 1)[0]
    return parsed.netloc or parsed.path or raw


def _iter_findings(result: Any) -> List[Finding | Dict[str, Any]]:
    if result is None:
        return []
    if isinstance(result, Finding):
        return [result]
    if isinstance(result, dict):
        return [result]
    if isinstance(result, list):
        out: List[Finding | Dict[str, Any]] = []
        for item in result:
            if isinstance(item, (Finding, dict)):
                out.append(item)
        return out
    return []


def _resolve_probe(name: str):
    probe = get_protocol(name)
    if probe is not None:
        return probe

    fallback = PROBE_FALLBACKS.get(name)
    if fallback is not None and PROBE_AVAILABILITY.get(name, False):
        return fallback

    if name not in _MISSING_PROBE_WARNINGS:
        logger.warning(
            "Protocol probe for '%s' is unavailable; install the optional extra to enable it.",
            name,
        )
        _MISSING_PROBE_WARNINGS.add(name)
    return None


async def run_hunt_async(
    targets: List[str],
    camp: Campaign,
    history: Optional[HistoryDB] = None,
    oob_client: Optional[InteractClient] = None,
    workdir: Optional[Path] = None,
    auth: Optional[AuthManager] = None,
    *,
    resume: bool = False,
    protocol_hints: Optional[Dict[str, Iterable[str] | str]] = None,
) -> List[Finding]:
    """Execute the asynchronous hunting loop across *targets*."""

    from op_bandit.contextual import LinUCB  # Lazy import for lightweight tests

    protocol_hints = protocol_hints or {}

    arms: List[Dict[str, Any]] = [a for a in getattr(camp.bandit, "arms", []) if isinstance(a, dict)]
    if not arms:
        arms = [
            {"mode": "xss", "protocol": "http", "location": "query"},
            {"mode": "sqli", "protocol": "http", "location": "query"},
            {"mode": "ssrf", "protocol": "http", "location": "header"},
            {"mode": "gql", "protocol": "graphql", "location": "body"},
            {"mode": "ws", "protocol": "ws", "location": "message"},
            {"mode": "grpc", "protocol": "grpc", "location": "body"},
        ]

    arm_names = [str(a) for a in arms]
    arm_lookup = {name: spec for name, spec in zip(arm_names, arms)}
    arm_index = {name: idx for idx, name in enumerate(arm_names)}
    bandit = LinUCB(arm_names)

    oob = oob_client or InteractClient(
        getattr(camp.oob, "base_url", None),
        getattr(camp.oob, "api_key", None),
    )

    state_file = (workdir / "limiter_state.json") if workdir else None
    global_rps = getattr(camp.limits, "global_rps", 30) or 30
    per_host_rps = getattr(camp.limits, "per_host_rps", 6) or 6
    jitter_ms = getattr(camp.limits, "jitter_ms", 0) or 0
    limiter = RateLimiter(
        global_rps,
        per_host_rps,
        jitter_ms=jitter_ms,
        state_file=state_file,
    )
    limiter.load_state()

    dedupe_path = (workdir / "fingerprints.sqlite3") if workdir else None
    dedupe_ttl = getattr(history, "ttl_days", None) if history else None
    dd = DeDup(dedupe_path, ttl_days=dedupe_ttl)

    max_concurrency = max(1, int(getattr(camp.limits, "max_concurrency", 1)))
    sem = asyncio.Semaphore(max_concurrency)

    http_timeout = getattr(camp.limits, "http_timeout", None)
    http_proxy = getattr(camp.limits, "http_proxy", None) or None
    http_retries = getattr(camp.limits, "retries", None)
    per_target_payloads = getattr(camp.limits, "per_target_payloads", 4)
    transforms = list(getattr(camp.synth, "transforms", []) or [])
    graphql_budget = getattr(camp.limits, "graphql_budget", None)
    graphql_max_depth = getattr(camp.limits, "graphql_max_depth", None)

    try:
        graphql_budget = int(graphql_budget) if graphql_budget is not None else None
    except Exception:
        graphql_budget = None

    try:
        graphql_max_depth = (
            int(graphql_max_depth) if graphql_max_depth is not None else None
        )
    except Exception:
        graphql_max_depth = None

    if auth is None:
        base_dir = workdir or Path(".")
        auth = AuthManager(
            {"default": NoAuthStrategy()},
            lambda: make_async_client(
                base_dir,
                timeout=http_timeout,
                proxy=http_proxy,
                retries=http_retries,
                backoff=jitter_backoff,
            ),
        )

    prime_callable = getattr(auth, "prime", None)
    if callable(prime_callable):
        maybe_awaitable = prime_callable()
        if inspect.isawaitable(maybe_awaitable):
            await maybe_awaitable

    selected_targets = filter_targets_by_scope(list(targets), camp)
    if not selected_targets and targets:
        logger.debug("No targets remained after scope filtering; proceeding with original set")
        selected_targets = list(targets)
    if history is not None and resume:
        filtered: List[str] = []
        for target in selected_targets:
            try:
                status = history.target_status(target)
            except Exception:
                status = None
            if status == "success":
                continue
            filtered.append(target)
        selected_targets = filtered

    findings: List[Finding] = []

    async def handle_target(target: str) -> None:
        meta: Dict[str, Any] = {}
        produced_count = 0

        def _record(status: str, extra: Optional[Dict[str, Any]] = None) -> None:
            if history is None:
                return
            payload = dict(meta)
            if extra:
                payload.update(extra)
            try:
                history.remember_target(target, status, payload or None)
            except Exception:
                pass

        try:
            async with sem:
                await wait_if_paused(workdir)
                protocols = _protocols_for_target(target, protocol_hints)
                meta["protocols"] = list(protocols)
                host = _target_host(target, protocols)
                limiter_host = str(host or urllib.parse.urlsplit(target).hostname or target or "global")
                default_role = getattr(auth, "default_role", None) or "default"
                client = await auth.client_for(default_role)

                async def _throttle() -> None:
                    await limiter.acquire(limiter_host)

                positions: List[Dict[str, Any]] = []
                form_picks: List[Dict[str, Any]] = []
                if "http" in protocols:
                    try:
                        await _throttle()
                        positions = await probe_positions(target)
                    except Exception:
                        positions = []
                    try:
                        await _throttle()
                        resp = await client.get(target, timeout=8.0)
                        headers = getattr(resp, "headers", {}) or {}
                        ctype = (headers.get("content-type") or "").lower()
                        if "html" in ctype:
                            forms = extract_forms(
                                str(getattr(resp, "url", target)),
                                getattr(resp, "text", "") or "",
                            )
                            form_picks = choose_form_fields(forms)
                    except Exception:
                        form_picks = []

                ordered_entries: List[Tuple[int, Dict[str, Any]]] = []
                for entry in bandit.order({}):
                    name = str(entry.get("name"))
                    spec = arm_lookup.get(name)
                    if spec is None:
                        continue
                    ordered_entries.append((arm_index.get(name, 0), spec))
                if not ordered_entries:
                    ordered_entries = list(zip(range(len(arms)), arms))

                for idx, arm in ordered_entries:
                    proto = (arm.get("protocol") or "http").lower()
                    if proto not in protocols:
                        bandit.update(idx, 0.0)
                        continue

                    candidates = list(
                        generate_candidates(
                            target,
                            arm,
                            per_target=per_target_payloads,
                            transforms=transforms,
                            graphql_budget=graphql_budget,
                            graphql_max_depth=graphql_max_depth,
                        )
                    )

                    if proto == "http" and positions:
                        for pos in positions[:3]:
                            location = pos.get("location")
                            param = pos.get("param")
                            if not location or not param:
                                continue
                            candidates.append(
                                {
                                    "mode": arm.get("mode"),
                                    "protocol": "http",
                                    "location": location,
                                    "param": param,
                                    "payload": "WARPRECON_PROBE",
                                    "transform": "identity",
                                }
                            )

                    if proto == "http" and form_picks:
                        base_payload = "OMEGA_" + (arm.get("mode") or "x")
                        for pick in form_picks[:3]:
                            target_param = pick.get("target_param")
                            ctx = pick.get("ctx")
                            if not target_param:
                                continue
                            candidates.append(
                                {
                                    "mode": arm.get("mode"),
                                    "protocol": "http",
                                    "location": "form",
                                    "param": target_param,
                                    "payload": base_payload,
                                    "transform": "form_ctx",
                                    "form_ctx": ctx,
                                }
                            )

                    arm_success = False
                    probe = _resolve_probe(proto)
                    if probe is None:
                        continue

                    for cand in candidates:
                        vector = {
                            "protocol": cand.get("protocol", proto),
                            "location": cand.get("location"),
                            "param": cand.get("param"),
                        }
                        item: Dict[str, Any] = {
                            "target": target,
                            "vector": vector,
                            "payload": cand.get("payload", ""),
                        }
                        mode = cand.get("mode") or arm.get("mode")
                        if mode:
                            item["mode"] = mode

                        key = fp(item)
                        if history is not None:
                            try:
                                if history.seen(key):
                                    continue
                            except Exception:
                                pass

                        await _throttle()
                        candidate_payload = cand
                        candidate_role = _extract_candidate_role(cand)
                        candidate_client = client
                        if candidate_role:
                            role_name = candidate_role.lower()
                            session_material: Mapping[str, Any] | None = None
                            try:
                                candidate_client = await auth.client_for(role_name)
                            except Exception as exc:
                                logger.debug(
                                    "Failed to obtain client for role %s: %s",
                                    role_name,
                                    exc,
                                )
                                candidate_client = client
                            else:
                                accessor = getattr(auth, "session_artifacts", None)
                                if callable(accessor):
                                    try:
                                        session_material = accessor(role_name)
                                    except Exception as exc:  # pragma: no cover - defensive
                                        logger.debug(
                                            "Failed to export session artifacts for role %s: %s",
                                            role_name,
                                            exc,
                                        )
                                    else:
                                        if session_material:
                                            candidate_payload = _merge_session_artifacts(
                                                candidate_payload,
                                                session_material,
                                            )
                        try:
                            result = await probe(
                                target,
                                candidate_payload,
                                oob,
                                client=candidate_client,
                                retries=http_retries or 0,
                            )
                        except TypeError:
                            result = await probe(target, candidate_payload, oob)
                        except Exception as exc:  # pragma: no cover - defensive guard
                            logger.debug(
                                "Probe %s failed for %s: %s",
                                proto,
                                target,
                                exc,
                            )
                            result = None

                        penalized = False
                        produced = False
                        for produced_item in _iter_findings(result):
                            if isinstance(produced_item, dict) and "_penalize" in produced_item:
                                penalty = float(produced_item.get("_penalize", 0.5))
                                status_raw = produced_item.get("_status")
                                latency_raw = produced_item.get("_latency")
                                try:
                                    status_val = int(status_raw) if status_raw is not None else None
                                except (TypeError, ValueError):
                                    status_val = None
                                try:
                                    latency_val = float(latency_raw) if latency_raw is not None else None
                                except (TypeError, ValueError):
                                    latency_val = None
                                limiter.penalize(host, penalty, status=status_val, latency=latency_val)
                                penalized = True
                                continue

                            finding_obj = as_finding(produced_item)
                            if dd.seen_before(finding_obj):
                                continue
                            findings.append(finding_obj)
                            produced = True
                            produced_count += 1

                        if history is not None:
                            try:
                                history.remember(key, {"ok": produced})
                            except Exception:
                                pass

                        if produced:
                            bandit.update(idx, 1.0)
                            arm_success = True
                        elif penalized and result:
                            break

                    if not arm_success:
                        bandit.update(idx, 0.0)
        except asyncio.CancelledError:
            _record("failed", {"reason": "cancelled"})
            raise
        except Exception as exc:
            logger.exception("Target %s scan failed", target, exc_info=exc)
            _record("failed", {"error": str(exc)})
        else:
            _record("success", {"findings": produced_count})

    try:
        if selected_targets:
            await asyncio.gather(*(handle_target(t) for t in selected_targets))
    finally:
        try:
            await auth.close_all()  # type: ignore[union-attr]
        finally:
            limiter.save_state()

    return findings


def _run_async_in_thread(coro_func, *args, **kwargs):
    outcome: Dict[str, Any] = {}

    def _runner() -> None:
        try:
            outcome["result"] = asyncio.run(coro_func(*args, **kwargs))
        except BaseException as exc:  # pragma: no cover - propagate below
            outcome["error"] = exc

    thread = threading.Thread(target=_runner, daemon=True)
    thread.start()
    thread.join()

    if "error" in outcome:
        raise outcome["error"]
    return outcome.get("result")


def run_hunt(
    targets: List[str],
    camp: Campaign,
    history: Optional[HistoryDB] = None,
    oob_client: Optional[InteractClient] = None,
    workdir: Optional[Path] = None,
    auth: Optional[AuthManager] = None,
    *,
    resume: bool = False,
    protocol_hints: Optional[Dict[str, Iterable[str] | str]] = None,
) -> List[Finding]:
    """Synchronously execute :func:`run_hunt_async`."""

    coro = run_hunt_async(
        list(targets),
        camp,
        history=history,
        oob_client=oob_client,
        workdir=workdir,
        auth=auth,
        resume=resume,
        protocol_hints=protocol_hints,
    )

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is None or not loop.is_running():
        return asyncio.run(coro)

    result = _run_async_in_thread(run_hunt_async, list(targets), camp, history, oob_client, workdir, auth, resume=resume, protocol_hints=protocol_hints)
    return list(result or [])


# Aliases exported for legacy monkeypatch-based tests
http_probe = _http_probe_impl
graphql_probe = _graphql_probe_impl
ws_probe = _ws_probe_impl
grpc_probe = _grpc_probe_impl
