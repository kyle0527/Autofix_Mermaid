"""Precision gate and label integration for ranked findings."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Set

from op_core.precision import PrecisionEngine

def _load_labels(p: Path) -> Set[str]:
    accept: Set[str] = set()
    try:
        for ln in p.read_text(encoding="utf-8").splitlines():
            if not ln.strip():
                continue
            j = json.loads(ln)
            if str(j.get("label", "")).lower() == "accept":
                fp = j.get("fingerprint") or j.get("fp") or j.get("id")
                if fp:
                    accept.add(str(fp))
    except Exception:
        pass
    return accept

def apply_gate(items: List[Dict[str, Any]], min_score: float, confirm_top_n: int, accept_fps: Set[str]) -> List[Dict[str, Any]]:
    engine = PrecisionEngine({}, workdir=Path("."))
    engine.gate_threshold = float(min_score)
    engine.gate_topn = int(confirm_top_n)
    sorted_items = sorted(items, key=lambda x: float(x.get("_score", 0.0) or 0.0), reverse=True)
    kept, _ = engine.apply_gate(sorted_items, accept_fingerprints=accept_fps)
    return kept

def _cli() -> None:
    ap = argparse.ArgumentParser(description="Precision Gate for ranked.json")
    ap.add_argument("--in", dest="infile", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--labels", required=False)
    ap.add_argument("--min-score", type=float, default=0.3)
    ap.add_argument("--confirm-top-n", type=int, default=20)
    args = ap.parse_args()
    items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
    accepts = _load_labels(Path(args.labels)) if args.labels else set()
    out = apply_gate(items, args.min_score, args.confirm_top_n, accepts)
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"in": args.infile, "out": args.out, "kept": len(out)}, ensure_ascii=False))

if __name__ == "__main__":
    _cli()
