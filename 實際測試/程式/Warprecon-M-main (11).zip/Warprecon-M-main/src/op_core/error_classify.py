from __future__ import annotations
"""
op_core.error_classify — classify telemetry events into buckets.
CLI:
  python -m op_core.error_classify --events work/events.log --out work/errors.summary.json
"""
import json, argparse, re
from pathlib import Path
from typing import Dict

CATS = {
  "dns": re.compile(r"\b(name resolution|dns|nodename nor servname)\b", re.I),
  "timeout": re.compile(r"\b(timeout|timed out|deadline)\b", re.I),
  "tls": re.compile(r"\b(handshake|tls|ssl)\b", re.I),
  "conn": re.compile(r"\b(connection refused|reset|broken pipe)\b", re.I),
  "http": re.compile(r"\b(4\d{2}|5\d{2}|http error)\b", re.I)
}

def main():
    ap = argparse.ArgumentParser(description="Classify error events")
    ap.add_argument("--events", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    counts: Dict[str,int] = {k:0 for k in CATS}
    other = 0
    for ln in Path(args.events).read_text(encoding="utf-8").splitlines():
        try:
            j = json.loads(ln)
        except Exception:
            continue
        msg = json.dumps(j, ensure_ascii=False)
        matched = False
        for k, rx in CATS.items():
            if rx.search(msg):
                counts[k]+=1; matched=True; break
        if not matched: other += 1
    counts["other"] = other
    Path(args.out).write_text(json.dumps(counts, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"out": args.out, "counts": counts}, ensure_ascii=False))

if __name__=="__main__":
    main()
