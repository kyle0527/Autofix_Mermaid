from cachetools import TTLCache

# Shared in-memory cache for expensive lookups
shared_cache = TTLCache(maxsize=256, ttl=600)

__all__ = ["shared_cache"]
