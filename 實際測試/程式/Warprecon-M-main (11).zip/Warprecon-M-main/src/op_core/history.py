from __future__ import annotations

import json
import threading
import time
import weakref
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Union


class HistoryDB:
    """History cache stored on disk with an in-memory index."""

    _TARGET_PREFIX = "target::"

    def __init__(
        self,
        path: Union[Path, str],
        ttl_days: Optional[float] = 30,
        flush_interval: int = 128,
    ) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.ttl_days = float(ttl_days or 0.0)
        self.ttl_seconds = (
            0.0 if ttl_days in (None, 0) else max(float(ttl_days), 0.0) * 86400.0
        )

        self._lock = threading.Lock()
        self._cache: Dict[str, float] = {}
        self._meta: Dict[str, Dict[str, Any]] = {}
        self._status: Dict[str, str] = {}
        self._flush_interval = max(int(flush_interval), 1)
        self._writes_since_flush = 0
        self._dirty = False

        self._load_from_disk()

        self._finalizer = weakref.finalize(
            self,
            HistoryDB._finalize_flush,
            self.path,
            self._lock,
            self._cache,
            self._meta,
            self._status,
            self.ttl_seconds,
            HistoryDB._write_file,
        )

    def _load_from_disk(self) -> None:
        if not self.path.exists():
            return

        try:
            with self.path.open("r", encoding="utf-8") as handle:
                used_legacy = False
                try:
                    raw = json.load(handle)
                except json.JSONDecodeError:
                    handle.seek(0)
                    raw = self._load_legacy_lines(handle)
                    used_legacy = True
        except OSError:
            return

        if not isinstance(raw, dict):
            return

        now = time.time()
        cutoff = now - self.ttl_seconds if self.ttl_seconds > 0 else None
        dirty_after_load = False

        for key, value in raw.items():
            if not isinstance(key, str):
                continue

            ts: Any
            meta: Any = None
            status: Any = None

            if isinstance(value, dict):
                ts = value.get("ts", value.get("t"))
                meta = value.get("meta", value.get("m"))
                status = value.get("status")
            elif isinstance(value, list):
                ts = value[0] if value else None
                if len(value) > 1:
                    meta = value[1]
                if len(value) > 2:
                    status = value[2]
            else:
                ts = value

            try:
                ts_float = float(ts)
            except (TypeError, ValueError):
                continue

            if cutoff is not None and ts_float <= cutoff:
                dirty_after_load = True
                continue

            self._cache[key] = ts_float
            if isinstance(meta, dict):
                self._meta[key] = meta
            elif meta is not None:
                # Preserve legacy non-dict metadata by wrapping it.
                self._meta[key] = {"value": meta}

            if isinstance(status, str):
                self._status[key] = status
            else:
                meta_status = None
                if isinstance(meta, dict):
                    meta_status = meta.get("status")
                elif key in self._meta:
                    meta_status = self._meta[key].get("status")
                if isinstance(meta_status, str):
                    self._status[key] = meta_status

        if dirty_after_load or used_legacy:
            self._dirty = True

    @staticmethod
    def _load_legacy_lines(handle) -> Dict[str, Dict[str, Any]]:
        payload: Dict[str, Dict[str, Any]] = {}
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(entry, dict):
                continue
            key = entry.get("k") or entry.get("key")
            if not isinstance(key, str):
                continue
            payload[key] = {
                "ts": entry.get("t") or entry.get("ts"),
                "meta": entry.get("m") or entry.get("meta"),
                "status": entry.get("status"),
            }
        return payload

    def _remove_key(self, key: str) -> None:
        self._cache.pop(key, None)
        self._meta.pop(key, None)
        self._status.pop(key, None)

    def _purge_expired(self, now: float) -> None:
        if self.ttl_seconds <= 0 or not self._cache:
            return
        cutoff = now - self.ttl_seconds
        expired = [key for key, ts in self._cache.items() if ts <= cutoff]
        if not expired:
            return
        for key in expired:
            self._remove_key(key)
        self._dirty = True

    @staticmethod
    def _serialise(
        cache: Dict[str, float],
        meta: Dict[str, Dict[str, Any]],
        status: Dict[str, str],
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        for key, ts in cache.items():
            entry: Dict[str, Any] = {"ts": ts}
            meta_val = meta.get(key)
            if meta_val:
                entry["meta"] = meta_val
            status_val = status.get(key)
            if status_val:
                entry["status"] = status_val
            if len(entry) == 1:
                payload[key] = ts
            else:
                payload[key] = entry
        return payload

    @staticmethod
    def _write_file(
        path: Path,
        cache: Dict[str, float],
        meta: Dict[str, Dict[str, Any]],
        status: Dict[str, str],
    ) -> None:
        tmp_path = path.with_name(path.name + ".tmp")
        payload = HistoryDB._serialise(cache, meta, status)
        with tmp_path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, sort_keys=True)
        tmp_path.replace(path)

    def _flush_if_needed(self, now: float, force: bool = False) -> None:
        if not self._dirty and not force:
            return
        if not force and self._writes_since_flush < self._flush_interval:
            return

        self._purge_expired(now)
        HistoryDB._write_file(self.path, self._cache, self._meta, self._status)
        self._writes_since_flush = 0
        self._dirty = False

    @staticmethod
    def _finalize_flush(
        path: Path,
        lock: threading.Lock,
        cache: Dict[str, float],
        meta: Dict[str, Dict[str, Any]],
        status: Dict[str, str],
        ttl_seconds: float,
        writer: Callable[[Path, Dict[str, float], Dict[str, Dict[str, Any]], Dict[str, str]], None],
    ) -> None:
        with lock:
            if ttl_seconds > 0 and cache:
                cutoff = time.time() - ttl_seconds
                expired = [key for key, ts in list(cache.items()) if ts <= cutoff]
                for key in expired:
                    cache.pop(key, None)
                    meta.pop(key, None)
                    status.pop(key, None)
            writer(path, cache, meta, status)

    def seen(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            ts = self._cache.get(key)
            if ts is None:
                return False
            if self.ttl_seconds > 0 and ts <= now - self.ttl_seconds:
                self._remove_key(key)
                self._dirty = True
                return False
            return True

    def get(self, key: str, *, use_ttl: bool = True) -> Optional[Dict[str, Any]]:
        now = time.time()
        with self._lock:
            ts = self._cache.get(key)
            if ts is None:
                return None
            if use_ttl and self.ttl_seconds > 0 and ts <= now - self.ttl_seconds:
                self._remove_key(key)
                self._dirty = True
                return None
            meta = self._meta.get(key)
            status = self._status.get(key)

        record: Dict[str, Any] = {"k": key, "t": ts}
        if status is not None:
            record["status"] = status
        if meta is not None:
            record["m"] = meta
        return record

    def remember(
        self,
        key: str,
        meta: Optional[Dict[str, Any]] = None,
        *,
        status: Optional[str] = None,
    ) -> None:
        now = time.time()
        with self._lock:
            self._cache[key] = now
            if meta is not None:
                self._meta[key] = meta
            else:
                self._meta.pop(key, None)
            if status is not None:
                self._status[key] = status
            else:
                self._status.pop(key, None)
            self._dirty = True
            self._writes_since_flush += 1
            self._flush_if_needed(now)

    def close(self) -> None:
        with self._lock:
            self._flush_if_needed(time.time(), force=True)
        if self._finalizer.alive:
            self._finalizer.detach()

    def _target_key(self, target: str) -> str:
        return f"{self._TARGET_PREFIX}{target}"

    def remember_target(
        self,
        target: str,
        status: str,
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        payload = dict(meta or {})
        payload.setdefault("target", target)
        self.remember(self._target_key(target), payload, status=status)

    def target_record(
        self,
        target: str,
        *,
        use_ttl: bool = True,
    ) -> Optional[Dict[str, Any]]:
        return self.get(self._target_key(target), use_ttl=use_ttl)

    def target_status(self, target: str, *, use_ttl: bool = True) -> Optional[str]:
        record = self.target_record(target, use_ttl=use_ttl)
        if record is None:
            return None
        status = record.get("status")
        return status if isinstance(status, str) else None
