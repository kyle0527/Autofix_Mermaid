from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, Dict, Iterable, List, Mapping, Optional

from op_core.finding_contract import Finding


BASE = {"critical": 100, "high": 70, "medium": 40, "low": 20, "info": 10}

CVSS_METRIC_ORDER = ("AV", "AC", "PR", "UI", "S", "C", "I", "A")


def _ensure_finding(item: Finding | Mapping[str, Any]) -> Finding:
    if isinstance(item, Finding):
        return item
    return Finding.from_dict(dict(item))


CVSS_ALIASES = {
    "AV": {"N": "NETWORK", "A": "ADJACENT", "L": "LOCAL", "P": "PHYSICAL"},
    "AC": {"L": "LOW", "H": "HIGH"},
    "PR": {"N": "NONE", "L": "LOW", "H": "HIGH"},
    "UI": {"N": "NONE", "R": "REQUIRED"},
    "S": {"U": "UNCHANGED", "C": "CHANGED"},
    "C": {"N": "NONE", "L": "LOW", "H": "HIGH"},
    "I": {"N": "NONE", "L": "LOW", "H": "HIGH"},
    "A": {"N": "NONE", "L": "LOW", "H": "HIGH"},
}

CVSS_WEIGHT_TABLE = {
    "AV": {"NETWORK": 0.85, "ADJACENT": 0.62, "LOCAL": 0.55, "PHYSICAL": 0.2},
    "AC": {"LOW": 0.77, "HIGH": 0.44},
    "UI": {"NONE": 0.85, "REQUIRED": 0.62},
    "C": {"NONE": 0.0, "LOW": 0.22, "HIGH": 0.56},
    "I": {"NONE": 0.0, "LOW": 0.22, "HIGH": 0.56},
    "A": {"NONE": 0.0, "LOW": 0.22, "HIGH": 0.56},
}

CVSS_PRIVILEGES_REQUIRED = {
    "UNCHANGED": {"NONE": 0.85, "LOW": 0.62, "HIGH": 0.27},
    "CHANGED": {"NONE": 0.85, "LOW": 0.68, "HIGH": 0.5},
}

CVSS_ABBREVIATIONS = {
    "AV": {"NETWORK": "N", "ADJACENT": "A", "LOCAL": "L", "PHYSICAL": "P"},
    "AC": {"LOW": "L", "HIGH": "H"},
    "PR": {"NONE": "N", "LOW": "L", "HIGH": "H"},
    "UI": {"NONE": "N", "REQUIRED": "R"},
    "S": {"UNCHANGED": "U", "CHANGED": "C"},
    "C": {"NONE": "N", "LOW": "L", "HIGH": "H"},
    "I": {"NONE": "N", "LOW": "L", "HIGH": "H"},
    "A": {"NONE": "N", "LOW": "L", "HIGH": "H"},
}


def _profile(cwe: str, metrics: Dict[str, str]) -> Dict[str, Dict[str, str]]:
    return {"cwe": cwe, "metrics": metrics}


DEFAULT_PROFILE = _profile(
    "CWE-937",
    {
        "AV": "NETWORK",
        "AC": "LOW",
        "PR": "NONE",
        "UI": "REQUIRED",
        "S": "UNCHANGED",
        "C": "LOW",
        "I": "LOW",
        "A": "LOW",
    },
)

MODE_PROFILES = {
    "xss": _profile(
        "CWE-79",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "REQUIRED",
            "S": "UNCHANGED",
            "C": "LOW",
            "I": "LOW",
            "A": "NONE",
        },
    ),
    "sqli": _profile(
        "CWE-89",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "UNCHANGED",
            "C": "HIGH",
            "I": "HIGH",
            "A": "LOW",
        },
    ),
    "gql": _profile(
        "CWE-89",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "UNCHANGED",
            "C": "HIGH",
            "I": "HIGH",
            "A": "LOW",
        },
    ),
    "ssrf": _profile(
        "CWE-918",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "CHANGED",
            "C": "LOW",
            "I": "LOW",
            "A": "LOW",
        },
    ),
    "idor": _profile(
        "CWE-639",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "UNCHANGED",
            "C": "LOW",
            "I": "LOW",
            "A": "NONE",
        },
    ),
    "csrf": _profile(
        "CWE-352",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "REQUIRED",
            "S": "UNCHANGED",
            "C": "LOW",
            "I": "LOW",
            "A": "NONE",
        },
    ),
    "rce": _profile(
        "CWE-94",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "CHANGED",
            "C": "HIGH",
            "I": "HIGH",
            "A": "HIGH",
        },
    ),
    "command_injection": _profile(
        "CWE-77",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "CHANGED",
            "C": "HIGH",
            "I": "HIGH",
            "A": "HIGH",
        },
    ),
    "xxe": _profile(
        "CWE-611",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "UNCHANGED",
            "C": "LOW",
            "I": "LOW",
            "A": "LOW",
        },
    ),
    "lfi": _profile(
        "CWE-22",
        {
            "AV": "NETWORK",
            "AC": "LOW",
            "PR": "NONE",
            "UI": "NONE",
            "S": "UNCHANGED",
            "C": "LOW",
            "I": "LOW",
            "A": "LOW",
        },
    ),
}

VECTOR_PROFILES = {
    "graphql": MODE_PROFILES["sqli"],
    "grpc": DEFAULT_PROFILE,
    "ws": MODE_PROFILES["xss"],
}


def _clone_profile(profile: Dict[str, Dict[str, str]]) -> Dict[str, Dict[str, str]]:
    return {"cwe": profile["cwe"], "metrics": dict(profile["metrics"])}


def _infer_mode(finding: Mapping[str, Any]) -> Optional[str]:
    raw_mode = finding.get("mode")
    if isinstance(raw_mode, str) and raw_mode.strip():
        return raw_mode.strip().lower()

    vector = finding.get("vector") or {}
    protocol = (vector.get("protocol") or "").lower()
    if protocol in {"graphql", "grpc", "ws"}:
        if protocol == "graphql":
            return "gql"
        return protocol

    tool = (finding.get("tool") or "").lower()
    if tool == "sqlmap":
        return "sqli"
    if tool == "xsstrike":
        return "xss"

    check_name = (finding.get("check") or "").lower()
    if check_name == "idor":
        return "idor"

    severity = (finding.get("severity") or "").lower()
    if severity in {"critical", "high"}:
        return "sqli"
    if severity == "medium":
        return "xss"

    return None


def _resolve_profile(finding: Mapping[str, Any]) -> Dict[str, Dict[str, str]]:
    mode = (finding.get("mode") or "").lower()
    vector = finding.get("vector") or {}
    protocol = (vector.get("protocol") or "").lower()

    if mode in MODE_PROFILES:
        return _clone_profile(MODE_PROFILES[mode])
    if protocol in VECTOR_PROFILES:
        return _clone_profile(VECTOR_PROFILES[protocol])
    return _clone_profile(DEFAULT_PROFILE)


def _normalize_value(metric: str, value: str) -> str:
    raw = (value or "").strip().upper().replace("-", "_")
    aliases = CVSS_ALIASES.get(metric, {})
    return aliases.get(raw, raw)


def _normalize_metrics(metrics: Dict[str, str]) -> Dict[str, str]:
    normalized: Dict[str, str] = {}
    for metric in CVSS_METRIC_ORDER:
        default_val = DEFAULT_PROFILE["metrics"].get(metric, "NONE")
        raw = metrics.get(metric, default_val)
        normalized_val = _normalize_value(metric, raw)
        if metric == "S":
            if normalized_val not in {"UNCHANGED", "CHANGED"}:
                normalized_val = default_val
        elif metric == "PR":
            if normalized_val not in CVSS_PRIVILEGES_REQUIRED["UNCHANGED"]:
                normalized_val = default_val
        else:
            allowed = CVSS_WEIGHT_TABLE.get(metric, CVSS_WEIGHT_TABLE.get("C"))
            if allowed and normalized_val not in allowed:
                normalized_val = default_val
        normalized[metric] = normalized_val
    return normalized


def _round_up_1(value: float) -> float:
    if value <= 0:
        return 0.0
    return math.ceil(value * 10.0) / 10.0


def _cvss_severity(score: float) -> str:
    if score >= 9:
        return "Critical"
    if score >= 7:
        return "High"
    if score >= 4:
        return "Medium"
    if score > 0:
        return "Low"
    return "None"


def _format_vector(metrics: Dict[str, str]) -> str:
    parts: List[str] = []
    for metric in CVSS_METRIC_ORDER:
        abbr_map = CVSS_ABBREVIATIONS.get(metric, {})
        part_value = abbr_map.get(metrics[metric], metrics[metric][:1])
        parts.append(f"{metric}:{part_value}")
    return "CVSS:3.1/" + "/".join(parts)


def compute_cvss_base(metrics: Dict[str, str]) -> Dict[str, object]:
    normalized = _normalize_metrics(metrics)
    scope = normalized["S"]

    av = CVSS_WEIGHT_TABLE["AV"][normalized["AV"]]
    ac = CVSS_WEIGHT_TABLE["AC"][normalized["AC"]]
    ui = CVSS_WEIGHT_TABLE["UI"][normalized["UI"]]
    pr = CVSS_PRIVILEGES_REQUIRED[scope][normalized["PR"]]
    c = CVSS_WEIGHT_TABLE["C"][normalized["C"]]
    i = CVSS_WEIGHT_TABLE["I"][normalized["I"]]
    a = CVSS_WEIGHT_TABLE["A"][normalized["A"]]

    impact_subscore = 1 - (1 - c) * (1 - i) * (1 - a)

    if impact_subscore <= 0:
        base_score = 0.0
    else:
        exploitability = 8.22 * av * ac * pr * ui
        if scope == "UNCHANGED":
            impact = 6.42 * impact_subscore
            score = min(impact + exploitability, 10)
        else:
            impact = 7.52 * (impact_subscore - 0.029) - 3.25 * ((impact_subscore - 0.02) ** 15)
            score = min(1.08 * (impact + exploitability), 10)
        base_score = _round_up_1(score)

    vector = _format_vector(normalized)
    return {
        "base_score": base_score,
        "metrics": normalized,
        "vector": vector,
        "severity": _cvss_severity(base_score),
    }


def strength(finding: Finding) -> float:
    """Compute a heuristic strength score for a finding."""

    score = BASE.get((str(finding.get("severity") or "medium")).lower(), 40)
    evidence = finding.get("evidence", {}) or {}
    if evidence.get("dns_log") or evidence.get("oob_token"):
        score += 35
    if evidence.get("len_delta") and abs(evidence["len_delta"]) > 50:
        score += 10
    if evidence.get("time_delta") and evidence["time_delta"] > 0.2:
        score += 8
    if evidence.get("header_anomaly"):
        score += 5

    vector = finding.get("vector", {}) or {}
    proto = (vector.get("protocol") or "").lower()
    if proto in {"grpc", "ws", "graphql"}:
        score += 10
    if finding.get("tool") in {"sqlmap", "nuclei", "xsstrike"}:
        score += 6
    return score


if TYPE_CHECKING:  # pragma: no cover - optional import for typing only
    from op_core.precision import PrecisionEngine


def rank_findings(
    items: Iterable[Finding | Mapping[str, Any]],
    history: Optional[object] = None,
    precision: "PrecisionEngine | None" = None,
) -> List[Finding]:
    """Rank findings in descending order of importance."""

    del history  # retained for backwards compatibility

    ensured = [_ensure_finding(item) for item in items]
    for finding in ensured:
        inferred_mode = _infer_mode(finding)
        if inferred_mode and not finding.get("mode"):
            finding["mode"] = inferred_mode
        profile = _resolve_profile(finding)
        finding["cvss"] = compute_cvss_base(profile["metrics"])
        finding["cwe"] = profile["cwe"]
        finding.score = strength(finding)

    if precision is not None:
        ordered = precision.score_findings(ensured)
        return list(ordered)

    ordered = sorted(
        ensured,
        key=lambda f: (
            f.get("cvss", {}).get("base_score", 0.0),
            f.score or 0.0,
        ),
        reverse=True,
    )

    for index, finding in enumerate(ordered, start=1):
        finding.rank = index
        if finding.score is None:
            base_score = float(finding.get("cvss", {}).get("base_score", 0.0))
            finding.score = base_score

    return ordered

