from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from json import JSONDecodeError
from pathlib import Path
from typing import Any

import httpx

from op_core.backoff import BackoffCallable, RetryingAsyncClient
from op_core.session import CookieError, load_cookies

logger = logging.getLogger(__name__)

_CONFIG_FILENAMES: tuple[str, ...] = ("httpclient.yaml", "httpclient.yml")


def _first_not_none(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _iter_config_paths(workdir: Path) -> Iterable[Path]:
    candidates = [
        workdir / name for name in _CONFIG_FILENAMES
    ] + [
        workdir / "config" / name for name in _CONFIG_FILENAMES
    ] + [
        Path("config") / name for name in _CONFIG_FILENAMES
    ]
    seen: set[Path] = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        yield path


def _load_file_settings(workdir: Path) -> dict[str, Any]:
    try:
        import yaml  # type: ignore
    except ImportError:  # pragma: no cover - optional dependency guard
        return {}

    for path in _iter_config_paths(workdir):
        if not path.exists():
            continue
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:  # pragma: no cover - defensive guard
            logger.warning("Failed to read HTTP client config %s: %s", path, exc)
            continue
        try:
            data = yaml.safe_load(raw) or {}
        except yaml.YAMLError as exc:  # type: ignore[attr-defined]
            logger.warning("Failed to parse HTTP client config %s: %s", path, exc)
            continue
        if not isinstance(data, dict):
            logger.warning(
                "Ignoring HTTP client config %s with non-mapping payload", path
            )
            continue
        if isinstance(data.get("http_client"), dict):
            data = data["http_client"]
        settings: dict[str, Any] = {}
        for key in ("timeout", "proxy", "retries"):
            if key in data:
                settings[key] = data[key]
        if settings:
            return settings
    return {}


def _load_env_settings() -> dict[str, Any]:
    env: dict[str, Any] = {}
    timeout = os.environ.get("OP_HTTP_TIMEOUT")
    if timeout:
        env["timeout"] = timeout
    proxy = os.environ.get("OP_HTTP_PROXY")
    if proxy:
        env["proxy"] = proxy
    retries = os.environ.get("OP_HTTP_RETRIES")
    if retries:
        env["retries"] = retries
    return env


def _coerce_timeout(raw: Any) -> float | httpx.Timeout | None:
    if raw is None:
        return None
    if isinstance(raw, httpx.Timeout):
        return raw
    if isinstance(raw, (int, float)):
        return float(raw)
    if isinstance(raw, str):
        raw = raw.strip()
        if not raw:
            return None
        try:
            return float(raw)
        except ValueError:
            logger.warning("Invalid HTTP timeout value %r", raw)
            return None
    if isinstance(raw, dict):
        try:
            return httpx.Timeout(**raw)
        except (TypeError, ValueError) as exc:
            logger.warning("Invalid HTTP timeout mapping %s: %s", raw, exc)
            return None
    logger.warning("Unsupported HTTP timeout type %s", type(raw).__name__)
    return None


def _coerce_proxy(raw: Any) -> Any:
    if raw is None:
        return None
    if isinstance(raw, str):
        raw = raw.strip()
        return raw or None
    return raw


def _coerce_retries(raw: Any) -> int | None:
    if raw is None:
        return None
    if isinstance(raw, int):
        return max(0, raw)
    if isinstance(raw, str):
        raw = raw.strip()
        if not raw:
            return None
        try:
            return max(0, int(raw))
        except ValueError:
            logger.warning("Invalid HTTP retries value %r", raw)
            return None
    logger.warning("Unsupported HTTP retries type %s", type(raw).__name__)
    return None


def make_async_client(
    workdir: Path,
    timeout: float | httpx.Timeout | None = None,
    proxy: Any | None = None,
    retries: int | None = None,
    backoff: BackoffCallable | None = None,
    **client_kwargs: Any,
) -> httpx.AsyncClient:
    """Return a configured :class:`httpx.AsyncClient` for ``workdir``."""

    settings = _load_file_settings(workdir)
    env_settings = _load_env_settings()

    resolved_timeout = _coerce_timeout(
        _first_not_none(timeout, env_settings.get("timeout"), settings.get("timeout"))
    )
    if resolved_timeout is None:
        resolved_timeout = 10.0

    resolved_proxy = _coerce_proxy(
        _first_not_none(proxy, env_settings.get("proxy"), settings.get("proxy"))
    )
    resolved_retries = _coerce_retries(
        _first_not_none(retries, env_settings.get("retries"), settings.get("retries"))
    )

    transport_kwargs: dict[str, Any] = {}
    if resolved_proxy is not None:
        transport_kwargs["proxy"] = resolved_proxy
    if resolved_retries is not None:
        transport_kwargs["retries"] = resolved_retries

    try:
        cookies = load_cookies(workdir)
    except (OSError, CookieError, JSONDecodeError) as exc:
        logger.warning("Continuing without cookies after load failure: %s", exc)
        cookies = {}

    params: dict[str, Any] = {
        "follow_redirects": True,
        "cookies": cookies,
        "timeout": resolved_timeout,
    }
    params.update(client_kwargs)

    if "transport" not in params:
        transport = httpx.AsyncHTTPTransport(**transport_kwargs)
        if resolved_retries is not None:
            pool = getattr(transport, "_pool", None)
            if pool is not None and hasattr(pool, "_retries"):
                pool._retries = resolved_retries
        params["transport"] = transport
    elif transport_kwargs:
        logger.debug(
            "Custom transport supplied; skipping default proxy/retry transport configuration."
        )

    retry_count = resolved_retries or 0
    return RetryingAsyncClient(
        retries=retry_count,
        backoff=backoff,
        **params,
    )


__all__ = ["make_async_client"]
