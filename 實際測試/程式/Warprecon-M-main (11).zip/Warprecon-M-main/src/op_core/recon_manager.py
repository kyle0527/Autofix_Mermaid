from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Optional

from .pipeline import discovery as _discovery

DiscoveryHooks = _discovery.DiscoveryHooks
_run_recon = _discovery._run_recon
crawl_and_capture = _discovery.crawl_and_capture
try_capture = _discovery.try_capture
try_introspect = _discovery.try_introspect
classify_target_protocols = _discovery.classify_target_protocols


def collect_targets(
    domain: str,
    workdir: Path,
    dom_crawl: bool,
    loop: Optional[asyncio.AbstractEventLoop] = None,
):
    """Compatibility wrapper delegating to :mod:`op_core.pipeline.discovery`."""

    hooks = DiscoveryHooks.from_module(sys.modules[__name__])
    return _discovery.collect_targets(
        domain,
        workdir,
        dom_crawl,
        loop=loop,
        hooks=hooks,
    )


__all__ = [
    "collect_targets",
    "DiscoveryHooks",
    "_run_recon",
    "crawl_and_capture",
    "try_capture",
    "try_introspect",
    "classify_target_protocols",
]
