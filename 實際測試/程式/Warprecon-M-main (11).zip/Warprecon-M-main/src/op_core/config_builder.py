from __future__ import annotations

"""Helpers for generating campaign and account configuration files."""

from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Optional, Sequence

import yaml

from op_control.campaign import Campaign
from op_control.settings import Settings

__all__ = [
    "CampaignOptions",
    "AccountArtifacts",
    "LoginSpec",
    "RefreshSpec",
    "AccountBlueprint",
    "build_config",
    "build_campaign_document",
    "build_campaign_yaml",
    "build_accounts_document",
    "build_accounts_yaml",
]


@dataclass(slots=True)
class CampaignOptions:
    """Declarative options used to build a campaign configuration."""

    target: str
    spa: bool = False
    budget_minutes: int = 60
    profile: Optional[str] = None
    accounts_profile: Optional[str] = None
    prefer_roles: Sequence[str] = field(default_factory=list)
    include_accounts: bool = True
    include_precision: bool = True
    global_rps: int = 30
    per_host_rps: int = 6
    max_concurrency: int = 8
    http_timeout: float = 10.0
    jitter_ms: int = 120
    retries: int = 1
    per_target_payloads: int = 8
    max_depth: int = 2
    graphql_budget: int = 4
    graphql_max_depth: int = 3

    def preferred_roles(self) -> list[str]:
        seen: set[str] = set()
        ordered: list[str] = []
        for role in self.prefer_roles:
            value = str(role).strip()
            if not value:
                continue
            key = value.lower()
            if key in seen:
                continue
            seen.add(key)
            ordered.append(value)
        return ordered


@dataclass(slots=True)
class AccountArtifacts:
    """Static session material applied when the account is initialised."""

    headers: Mapping[str, str] = field(default_factory=dict)
    cookies: Mapping[str, str] = field(default_factory=dict)
    query: Mapping[str, Any] = field(default_factory=dict)
    body: Mapping[str, Any] = field(default_factory=dict)
    token: Optional[str] = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "headers": {str(k): str(v) for k, v in self.headers.items() if k},
            "cookies": {str(k): str(v) for k, v in self.cookies.items() if k},
            "query": {str(k): v for k, v in self.query.items() if k},
            "body": {str(k): v for k, v in self.body.items() if k},
        }
        if self.token is not None:
            payload["token"] = self.token
        return payload


@dataclass(slots=True)
class LoginSpec:
    """Declarative HTTP login flow."""

    url: str
    method: str = "POST"
    payload: Mapping[str, Any] = field(default_factory=dict)
    headers: Mapping[str, str] = field(default_factory=dict)
    success_status: Sequence[int] = field(default_factory=lambda: [200, 201, 204, 302])

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "url": self.url,
            "method": self.method,
        }
        if self.payload:
            payload["payload"] = dict(self.payload)
        if self.headers:
            payload["headers"] = {str(k): str(v) for k, v in self.headers.items() if k}
        if self.success_status:
            payload["success_status"] = [int(code) for code in self.success_status]
        return payload


@dataclass(slots=True)
class RefreshSpec:
    """Declarative refresh flow executed when a token is near expiry."""

    url: str
    method: str = "POST"
    payload: Mapping[str, Any] = field(default_factory=dict)
    headers: Mapping[str, str] = field(default_factory=dict)
    grace_seconds: int = 30
    retry_backoff_seconds: float = 0.0
    token_path: Optional[str] = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "url": self.url,
            "method": self.method,
            "grace_seconds": int(self.grace_seconds),
            "retry_backoff_seconds": float(self.retry_backoff_seconds),
        }
        if self.payload:
            payload["payload"] = dict(self.payload)
        if self.headers:
            payload["headers"] = {str(k): str(v) for k, v in self.headers.items() if k}
        if self.token_path:
            payload["token_path"] = self.token_path
        return payload


@dataclass(slots=True)
class AccountBlueprint:
    """High-level account description used by the configuration wizard."""

    name: str
    role: str
    strategy: str = "none"
    artifacts: AccountArtifacts = field(default_factory=AccountArtifacts)
    login: Optional[LoginSpec] = None
    refresh: Optional[RefreshSpec] = None
    tags: Mapping[str, str] = field(default_factory=dict)

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "role": self.role,
            "strategy": self.strategy,
            "artifacts": self.artifacts.to_payload(),
        }
        if self.login:
            payload["login"] = self.login.to_payload()
        if self.refresh:
            payload["refresh"] = self.refresh.to_payload()
        tags = {str(k): str(v) for k, v in self.tags.items() if k}
        if tags:
            payload["tags"] = tags
        return payload


def _merge_dict(base: Mapping[str, Any], overrides: Mapping[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in overrides.items():
        if isinstance(value, Mapping) and isinstance(merged.get(key), Mapping):
            merged[key] = _merge_dict(merged[key], value)
        else:
            merged[key] = value
    return merged


def _compact(value: Any) -> Any:
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key, item in value.items():
            compacted = _compact(item)
            if compacted is None:
                continue
            if isinstance(compacted, (dict, list, tuple, set)) and not compacted:
                continue
            if isinstance(compacted, str) and compacted.strip() == "":
                continue
            result[key] = compacted
        return result
    if isinstance(value, list):
        result_list = []
        for item in value:
            compacted = _compact(item)
            if compacted is None:
                continue
            if isinstance(compacted, (dict, list, tuple, set)) and not compacted:
                continue
            result_list.append(compacted)
        return result_list
    return value


def _campaign_defaults() -> dict[str, Any]:
    camp = Campaign()

    def dump(obj: Any) -> dict[str, Any]:
        if hasattr(obj, "model_dump"):
            return obj.model_dump(mode="python")  # type: ignore[call-arg]
        if isinstance(obj, Mapping):
            return dict(obj)
        return {}

    return {
        "scopes": {
            "allow": list(getattr(camp, "allow", []) or []),
            "deny": list(getattr(camp, "deny", []) or []),
        },
        "limits": dump(camp.limits),
        "bandit": dump(camp.bandit),
        "oob": dump(camp.oob),
        "synth": dump(camp.synth),
        "output": dump(camp.output),
        "idor": dump(camp.idor),
        "accounts": dump(camp.accounts),
        "precision": dump(camp.precision),
        "deploy": dump(camp.deploy),
    }


def build_campaign_document(options: CampaignOptions) -> dict[str, Any]:
    """Return a campaign configuration dictionary for *options*."""

    data = _campaign_defaults()
    data.setdefault("scopes", {})["allow"] = [options.target]
    data.setdefault("scopes", {})["deny"] = []

    limits = dict(data.get("limits", {}))
    limits.update(
        {
            "global_rps": int(options.global_rps),
            "per_host_rps": int(options.per_host_rps),
            "max_concurrency": int(options.max_concurrency),
            "http_timeout": float(options.http_timeout),
            "jitter_ms": int(options.jitter_ms),
            "retries": int(options.retries),
            "per_target_payloads": int(options.per_target_payloads),
            "max_depth": int(options.max_depth),
            "graphql_budget": int(options.graphql_budget),
            "graphql_max_depth": int(options.graphql_max_depth),
            "max_scan_minutes": int(options.budget_minutes),
        }
    )
    data["limits"] = limits

    if options.include_accounts:
        accounts = dict(data.get("accounts", {}))
        if not accounts.get("sources"):
            accounts["sources"] = ["config/accounts.yaml"]
        if options.accounts_profile:
            accounts["default_profile"] = options.accounts_profile
        preferred = options.preferred_roles()
        if preferred:
            accounts["prefer_roles"] = preferred
        data["accounts"] = accounts
    else:
        data.pop("accounts", None)

    if not options.include_precision:
        data.pop("precision", None)

    if options.profile:
        data["profile"] = options.profile

    if options.spa:
        notes = dict(data.get("notes", {}))
        notes["dom_crawl"] = True
        data["notes"] = notes

    env_overrides = Settings().to_campaign_overrides()
    if env_overrides:
        data = _merge_dict(data, env_overrides)

    return _compact(data)


def build_campaign_yaml(options: CampaignOptions) -> str:
    """Serialise :class:`CampaignOptions` into a YAML configuration string."""

    document = build_campaign_document(options)
    return yaml.safe_dump(document, sort_keys=False, allow_unicode=True)


def build_config(
    target: str,
    spa: bool = False,
    budget: int = 60,
    profile: Optional[str] = None,
    accounts_profile: Optional[str] = None,
    prefer_roles: Optional[Sequence[str]] = None,
) -> str:
    """Backward-compatible helper returning campaign YAML for *target*."""

    options = CampaignOptions(
        target=target,
        spa=spa,
        budget_minutes=budget,
        profile=profile,
        accounts_profile=accounts_profile,
        prefer_roles=list(prefer_roles or []),
    )
    return build_campaign_yaml(options)


def build_accounts_document(
    profile_name: str,
    accounts: Sequence[AccountBlueprint],
    *,
    description: Optional[str] = None,
    default_profile: Optional[str] = None,
) -> dict[str, Any]:
    """Return an accounts.yaml payload for *accounts* under *profile_name*."""

    profile_payload: dict[str, Any] = {
        "description": description,
        "accounts": [entry.to_payload() for entry in accounts],
    }
    profiles: dict[str, Any] = {profile_name: _compact(profile_payload)}
    payload: dict[str, Any] = {
        "default_profile": default_profile or profile_name,
        "profiles": profiles,
    }
    return _compact(payload)


def build_accounts_yaml(
    profile_name: str,
    accounts: Sequence[AccountBlueprint],
    *,
    description: Optional[str] = None,
    default_profile: Optional[str] = None,
) -> str:
    """Serialise an account profile into YAML."""

    document = build_accounts_document(
        profile_name,
        accounts,
        description=description,
        default_profile=default_profile,
    )
    return yaml.safe_dump(document, sort_keys=False, allow_unicode=True)
