from __future__ import annotations

import contextvars
import json
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping

logger = logging.getLogger(__name__)


def _safe_payload(data: Mapping[str, Any] | None) -> dict[str, Any]:
    if not data:
        return {}
    try:
        return json.loads(json.dumps(data, ensure_ascii=False, default=str))
    except Exception:  # pragma: no cover - defensive fallback
        result: dict[str, Any] = {}
        for key, value in data.items():
            try:
                json.dumps(value)
                result[key] = value
            except TypeError:
                result[key] = str(value)
        return result


@dataclass
class _TelemetrySession:
    session_id: str
    workdir: Path
    state: dict[str, Any]
    events_path: Path
    metrics_path: Path
    lock: threading.RLock = field(default_factory=threading.RLock)
    closed: bool = False
    token: contextvars.Token[str | None] | None = None

    @property
    def summary_path(self) -> Path:
        return self.metrics_path.parent / "metrics.json"

    def prepare_outputs(self) -> None:
        for path in (self.events_path, self.metrics_path, self.summary_path):
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("", encoding="utf-8")
            except Exception as exc:  # pragma: no cover - best effort
                logger.exception("telemetry initialisation failed for %s: %s", path, exc)

    def append_event(
        self,
        event_type: str,
        payload: Mapping[str, Any] | None,
        *,
        allow_closed: bool = False,
    ) -> None:
        with self.lock:
            if not self.state.get("start_ts") or (self.closed and not allow_closed):
                return
            record = {"ts": time.time(), "type": event_type}
            record.update(_safe_payload(payload))
            try:
                with self.events_path.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            except Exception as exc:  # pragma: no cover - best effort logging
                logger.exception("telemetry event failure: %s", exc)

    def _ensure_bucket(self, *keys: str, defaults: Mapping[str, Any]) -> dict[str, Any]:
        bucket: dict[str, Any] = self.state  # type: ignore[assignment]
        for key in keys[:-1]:
            bucket = bucket.setdefault(key, {})  # type: ignore[assignment]
        last = keys[-1]
        if last not in bucket:
            bucket[last] = dict(defaults)
        return bucket[last]

    def _update_duration_stats(
        self,
        bucket: dict[str, Any],
        *,
        elapsed_ms: float,
        failed: bool,
        attempts: int = 0,
    ) -> None:
        bucket["count"] = int(bucket.get("count", 0)) + 1
        bucket["total_ms"] = float(bucket.get("total_ms", 0.0)) + float(elapsed_ms)
        bucket["max_ms"] = float(
            max(float(bucket.get("max_ms", 0.0)), float(elapsed_ms))
        )
        bucket["avg_ms"] = round(bucket["total_ms"] / bucket["count"], 3)
        if attempts:
            bucket["attempts"] = int(bucket.get("attempts", 0)) + int(attempts)
        if failed:
            bucket["failures"] = int(bucket.get("failures", 0)) + 1
        else:
            bucket.setdefault("failures", int(bucket.get("failures", 0)))
        failures = int(bucket.get("failures", 0))
        bucket["success_rate"] = round(
            (bucket["count"] - failures) / bucket["count"], 3
        )

    def record_auth_switch(
        self,
        *,
        role: str,
        action: str,
        elapsed_ms: float,
        outcome: str,
        error: Mapping[str, Any] | None,
    ) -> None:
        payload = {
            "role": role,
            "action": action,
            "elapsed_ms": round(float(elapsed_ms), 3),
            "outcome": outcome,
        }
        if error:
            payload["error"] = _safe_payload(error)

        with self.lock:
            if not self.state.get("start_ts") or self.closed:
                return
            failed = outcome.lower() != "success"
            switch_bucket = self._ensure_bucket(
                "auth",
                "switch",
                defaults={
                    "count": 0,
                    "failures": 0,
                    "total_ms": 0.0,
                    "max_ms": 0.0,
                    "avg_ms": 0.0,
                    "success_rate": 1.0,
                    "roles": {},
                },
            )
            self._update_duration_stats(
                switch_bucket, elapsed_ms=elapsed_ms, failed=failed
            )
            roles = switch_bucket.setdefault("roles", {})
            role_bucket = roles.setdefault(
                role,
                {
                    "count": 0,
                    "failures": 0,
                    "total_ms": 0.0,
                    "max_ms": 0.0,
                    "avg_ms": 0.0,
                    "success_rate": 1.0,
                },
            )
            self._update_duration_stats(
                role_bucket, elapsed_ms=elapsed_ms, failed=failed
            )

        self.append_event("auth.switch", payload)

    def record_auth_refresh(
        self,
        *,
        role: str,
        elapsed_ms: float,
        outcome: str,
        attempts: int,
        error: Mapping[str, Any] | None,
    ) -> None:
        payload = {
            "role": role,
            "elapsed_ms": round(float(elapsed_ms), 3),
            "outcome": outcome,
            "attempts": int(attempts),
        }
        if error:
            payload["error"] = _safe_payload(error)

        with self.lock:
            if not self.state.get("start_ts") or self.closed:
                return
            failed = outcome.lower() != "success"
            refresh_bucket = self._ensure_bucket(
                "auth",
                "refresh",
                defaults={
                    "count": 0,
                    "failures": 0,
                    "total_ms": 0.0,
                    "max_ms": 0.0,
                    "avg_ms": 0.0,
                    "success_rate": 1.0,
                    "attempts": 0,
                    "roles": {},
                },
            )
            self._update_duration_stats(
                refresh_bucket,
                elapsed_ms=elapsed_ms,
                failed=failed,
                attempts=attempts,
            )
            roles = refresh_bucket.setdefault("roles", {})
            role_bucket = roles.setdefault(
                role,
                {
                    "count": 0,
                    "failures": 0,
                    "total_ms": 0.0,
                    "max_ms": 0.0,
                    "avg_ms": 0.0,
                    "success_rate": 1.0,
                    "attempts": 0,
                },
            )
            self._update_duration_stats(
                role_bucket,
                elapsed_ms=elapsed_ms,
                failed=failed,
                attempts=attempts,
            )

        self.append_event("auth.refresh", payload)

    def record_auth_incident(
        self,
        *,
        role: str,
        status_code: int | None,
        reason: str | None,
        url: str | None,
    ) -> None:
        payload: dict[str, Any] = {"role": role}
        if status_code is not None:
            payload["status_code"] = int(status_code)
        if reason:
            payload["reason"] = str(reason)
        if url:
            payload["url"] = str(url)

        with self.lock:
            if not self.state.get("start_ts") or self.closed:
                return
            incident_bucket = self._ensure_bucket(
                "auth",
                "incidents",
                defaults={
                    "count": 0,
                    "statuses": {},
                    "reasons": {},
                    "roles": {},
                },
            )
            incident_bucket["count"] = int(incident_bucket.get("count", 0)) + 1
            if status_code is not None:
                status_key = str(int(status_code))
                statuses = incident_bucket.setdefault("statuses", {})
                statuses[status_key] = int(statuses.get(status_key, 0)) + 1
            if reason:
                reasons = incident_bucket.setdefault("reasons", {})
                reasons[reason] = int(reasons.get(reason, 0)) + 1

            roles = incident_bucket.setdefault("roles", {})
            role_bucket = roles.setdefault(
                role,
                {
                    "count": 0,
                    "statuses": {},
                    "reasons": {},
                },
            )
            role_bucket["count"] = int(role_bucket.get("count", 0)) + 1
            if status_code is not None:
                status_key = str(int(status_code))
                role_status = role_bucket.setdefault("statuses", {})
                role_status[status_key] = int(role_status.get(status_key, 0)) + 1
            if reason:
                role_reasons = role_bucket.setdefault("reasons", {})
                role_reasons[reason] = int(role_reasons.get(reason, 0)) + 1

        self.append_event("auth.incident", payload)

    def record_ws_roundtrip(
        self,
        *,
        endpoint: str,
        elapsed_ms: float,
        success: bool,
        reason: str | None,
        handshake: str | None = None,
        strategy: str | None = None,
    ) -> None:
        payload = {
            "endpoint": endpoint,
            "elapsed_ms": round(float(elapsed_ms), 3),
            "success": bool(success),
        }
        if reason:
            payload["reason"] = reason
        if handshake:
            payload["handshake"] = handshake
        if strategy:
            payload["strategy"] = strategy

        with self.lock:
            if not self.state.get("start_ts") or self.closed:
                return
            failed = not success
            ws_bucket = self._ensure_bucket(
                "websocket",
                "roundtrip",
                defaults={
                    "count": 0,
                    "failures": 0,
                    "total_ms": 0.0,
                    "max_ms": 0.0,
                    "avg_ms": 0.0,
                    "success_rate": 1.0,
                    "reasons": {},
                    "endpoints": {},
                    "handshakes": {},
                },
            )
            self._update_duration_stats(
                ws_bucket, elapsed_ms=elapsed_ms, failed=failed
            )
            if failed and reason:
                reasons = ws_bucket.setdefault("reasons", {})
                reasons[reason] = int(reasons.get(reason, 0)) + 1
            endpoints = ws_bucket.setdefault("endpoints", {})
            endpoint_bucket = endpoints.setdefault(
                endpoint,
                {
                    "count": 0,
                    "failures": 0,
                    "total_ms": 0.0,
                    "max_ms": 0.0,
                    "avg_ms": 0.0,
                    "success_rate": 1.0,
                },
            )
            self._update_duration_stats(
                endpoint_bucket, elapsed_ms=elapsed_ms, failed=failed
            )

            if handshake:
                handshake_key = str(handshake)
                handshakes = ws_bucket.setdefault("handshakes", {})
                handshake_bucket = handshakes.get(handshake_key)
                if handshake_bucket is None:
                    handshake_bucket = {
                        "count": 0,
                        "failures": 0,
                        "total_ms": 0.0,
                        "max_ms": 0.0,
                        "avg_ms": 0.0,
                        "success_rate": 1.0,
                        "reasons": {},
                        "strategies": {},
                    }
                    handshakes[handshake_key] = handshake_bucket
                self._update_duration_stats(
                    handshake_bucket, elapsed_ms=elapsed_ms, failed=failed
                )
                if failed and reason:
                    handshake_reasons = handshake_bucket.setdefault("reasons", {})
                    handshake_reasons[reason] = (
                        int(handshake_reasons.get(reason, 0)) + 1
                    )

                if strategy:
                    handshake_strategies = handshake_bucket.setdefault(
                        "strategies", {}
                    )
                    strategy_key = str(strategy)
                    strategy_bucket = handshake_strategies.get(strategy_key)
                    if strategy_bucket is None:
                        strategy_bucket = {
                            "count": 0,
                            "failures": 0,
                            "total_ms": 0.0,
                            "max_ms": 0.0,
                            "avg_ms": 0.0,
                            "success_rate": 1.0,
                            "reasons": {},
                        }
                        handshake_strategies[strategy_key] = strategy_bucket
                    self._update_duration_stats(
                        strategy_bucket, elapsed_ms=elapsed_ms, failed=failed
                    )
                    if failed and reason:
                        strat_reasons = strategy_bucket.setdefault("reasons", {})
                        strat_reasons[reason] = (
                            int(strat_reasons.get(reason, 0)) + 1
                        )
            elif strategy:
                # Record strategy metrics even if handshake metadata is unavailable.
                unknown_handshake = ws_bucket.setdefault("handshakes", {}).setdefault(
                    "unknown",
                    {
                        "count": 0,
                        "failures": 0,
                        "total_ms": 0.0,
                        "max_ms": 0.0,
                        "avg_ms": 0.0,
                        "success_rate": 1.0,
                        "reasons": {},
                        "strategies": {},
                    },
                )
                self._update_duration_stats(
                    unknown_handshake, elapsed_ms=elapsed_ms, failed=failed
                )
                if failed and reason:
                    unknown_reasons = unknown_handshake.setdefault("reasons", {})
                    unknown_reasons[reason] = int(unknown_reasons.get(reason, 0)) + 1

                strat_bucket = unknown_handshake.setdefault("strategies", {})
                strat_key = str(strategy)
                bucket = strat_bucket.get(strat_key)
                if bucket is None:
                    bucket = {
                        "count": 0,
                        "failures": 0,
                        "total_ms": 0.0,
                        "max_ms": 0.0,
                        "avg_ms": 0.0,
                        "success_rate": 1.0,
                        "reasons": {},
                    }
                    strat_bucket[strat_key] = bucket
                self._update_duration_stats(
                    bucket, elapsed_ms=elapsed_ms, failed=failed
                )
                if failed and reason:
                    bucket_reasons = bucket.setdefault("reasons", {})
                    bucket_reasons[reason] = int(bucket_reasons.get(reason, 0)) + 1

        self.append_event("websocket.roundtrip", payload)

    def _metrics_snapshot_locked(self) -> dict[str, Any]:
        data = dict(self.state)
        start = data.get("start_ts")
        end = data.get("end_ts")
        first_conf = data.get("first_confirmed_ts")
        if start and first_conf:
            data["ttfp_seconds"] = max(0.0, float(first_conf) - float(start))
        else:
            data["ttfp_seconds"] = None
        if start and end:
            data["duration_seconds"] = max(0.0, float(end) - float(start))
        else:
            data["duration_seconds"] = None
        data["ts"] = time.time()
        return data

    def append_metrics(self) -> None:
        with self.lock:
            if not self.state.get("start_ts"):
                return
            snapshot = self._metrics_snapshot_locked()
        self.append_metrics_snapshot(snapshot)

    def update_findings(self, findings: Iterable[Any]) -> None:
        with self.lock:
            if not self.state.get("start_ts") or self.closed:
                return

            total = 0
            confirmed = 0
            now = time.time()
            for item in findings:
                try:
                    if hasattr(item, "to_dict"):
                        payload = item.to_dict()
                    elif isinstance(item, Mapping):
                        payload = dict(item)
                    else:
                        continue
                except Exception:
                    continue

                total += 1
                evidence = payload.get("evidence") or {}
                if payload.get("_confirmed") or evidence.get("sequence_hit"):
                    confirmed += 1

            self.state["hits"] = int(total)
            self.state["confirmed_hits"] = int(confirmed)
            if total and not self.state.get("first_hit_ts"):
                self.state["first_hit_ts"] = now
            if confirmed and not self.state.get("first_confirmed_ts"):
                self.state["first_confirmed_ts"] = now
            snapshot = self._metrics_snapshot_locked()
        self.append_metrics_snapshot(snapshot)

    def append_metrics_snapshot(self, snapshot: Mapping[str, Any]) -> None:
        with self.lock:
            try:
                with self.metrics_path.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps(snapshot, ensure_ascii=False) + "\n")
                self.summary_path.write_text(
                    json.dumps(snapshot, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception as exc:  # pragma: no cover - best effort logging
                logger.exception("telemetry metrics write failure: %s", exc)

    def finish(
        self,
        *,
        status: str,
        error: Mapping[str, Any] | None,
        artifacts: Mapping[str, Any] | None,
        extra: Mapping[str, Any] | None,
    ) -> None:
        with self.lock:
            if not self.state.get("start_ts") or self.closed:
                return

            self.state["end_ts"] = time.time()
            self.state["status"] = status
            if error:
                self.state["error"] = _safe_payload(error)
            if artifacts:
                self.state["artifacts"] = _safe_payload(artifacts)
            if extra:
                self.state.setdefault("extra", {}).update(_safe_payload(extra))

            event_payload = {
                "status": status,
                "artifacts": self.state.get("artifacts", {}),
            }
            if self.state.get("error"):
                event_payload["error"] = self.state["error"]

            snapshot = self._metrics_snapshot_locked()

        event_type = "pipeline.finish" if status == "success" else "pipeline.error"
        self.append_event(event_type, event_payload, allow_closed=True)
        self.append_metrics_snapshot(snapshot)
        with self.lock:
            self.closed = True


class Telemetry:
    """Thread-safe helpers for recording pipeline runtime metrics."""

    _sessions: dict[str, _TelemetrySession] = {}
    _sessions_lock = threading.RLock()
    _session_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
        "telemetry_session_id", default=None
    )

    @classmethod
    def start(
        cls,
        workdir: Path,
        *,
        domain: str | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> str:
        """Initialise telemetry output files for ``workdir``."""

        session_id = uuid.uuid4().hex
        session = _TelemetrySession(
            session_id=session_id,
            workdir=Path(workdir),
            state={
                "workdir": str(workdir),
                "start_ts": time.time(),
                "end_ts": None,
                "first_hit_ts": None,
                "first_confirmed_ts": None,
                "hits": 0,
                "confirmed_hits": 0,
                "status": "running",
                "domain": domain or "",
                "metadata": dict(metadata or {}),
                "error": None,
                "artifacts": {},
            },
            events_path=Path(workdir) / "events.log",
            metrics_path=Path(workdir) / "metrics.jsonl",
        )
        session.prepare_outputs()
        with cls._sessions_lock:
            cls._sessions[session_id] = session
        session.token = cls._session_var.set(session_id)
        session.append_event(
            "pipeline.start",
            {"domain": session.state["domain"], "metadata": session.state["metadata"]},
        )
        session.append_metrics()
        return session_id

    @classmethod
    def event(cls, event_type: str, data: Mapping[str, Any] | None = None) -> None:
        """Persist an event to ``events.log`` in structured JSONL format."""

        session = cls._resolve_session()
        if not session:
            return
        session.append_event(event_type, data)

    @classmethod
    def record_auth_switch(
        cls,
        *,
        role: str,
        action: str,
        elapsed_ms: float,
        outcome: str,
        error: Mapping[str, Any] | None,
    ) -> None:
        session = cls._resolve_session()
        if not session:
            return
        session.record_auth_switch(
            role=role,
            action=action,
            elapsed_ms=elapsed_ms,
            outcome=outcome,
            error=error,
        )

    @classmethod
    def record_auth_refresh(
        cls,
        *,
        role: str,
        elapsed_ms: float,
        outcome: str,
        attempts: int = 1,
        error: Mapping[str, Any] | None = None,
    ) -> None:
        session = cls._resolve_session()
        if not session:
            return
        session.record_auth_refresh(
            role=role,
            elapsed_ms=elapsed_ms,
            outcome=outcome,
            attempts=attempts,
            error=error,
        )

    @classmethod
    def record_auth_incident(
        cls,
        *,
        role: str,
        status_code: int | None = None,
        reason: str | None = None,
        url: str | None = None,
    ) -> None:
        session = cls._resolve_session()
        if not session:
            return
        session.record_auth_incident(
            role=role,
            status_code=status_code,
            reason=reason,
            url=url,
        )

    @classmethod
    def record_ws_roundtrip(
        cls,
        *,
        endpoint: str,
        elapsed_ms: float,
        success: bool,
        reason: str | None = None,
        handshake: str | None = None,
        strategy: str | None = None,
    ) -> None:
        session = cls._resolve_session()
        if not session:
            return
        session.record_ws_roundtrip(
            endpoint=endpoint,
            elapsed_ms=elapsed_ms,
            success=success,
            reason=reason,
            handshake=handshake,
            strategy=strategy,
        )

    @classmethod
    def observe_findings(cls, findings: Iterable[Any]) -> None:
        """Update aggregate finding counters from ``findings``."""

        session = cls._resolve_session()
        if not session:
            return
        session.update_findings(findings)

    @classmethod
    def finish(
        cls,
        *,
        status: str = "success",
        error: Mapping[str, Any] | None = None,
        artifacts: Mapping[str, Any] | None = None,
        extra: Mapping[str, Any] | None = None,
    ) -> None:
        """Mark the pipeline as finished and emit a terminal metric line."""

        session = cls._resolve_session()
        if not session:
            return
        session.finish(status=status, error=error, artifacts=artifacts, extra=extra)
        cls._release_session(session.session_id)

    @classmethod
    def snapshot(cls, session_id: str | None = None) -> dict[str, Any]:
        """Return the latest metrics snapshot for testing and diagnostics."""

        session = cls._resolve_session(session_id)
        if not session:
            return {}
        with session.lock:
            if not session.state.get("start_ts"):
                return {}
            return session._metrics_snapshot_locked()

    @classmethod
    def current_session_id(cls) -> str | None:
        return cls._session_var.get()

    @classmethod
    def _resolve_session(cls, session_id: str | None = None) -> _TelemetrySession | None:
        lookup_id = session_id or cls._session_var.get()
        if not lookup_id:
            return None
        with cls._sessions_lock:
            return cls._sessions.get(lookup_id)

    @classmethod
    def _release_session(cls, session_id: str) -> None:
        with cls._sessions_lock:
            session = cls._sessions.pop(session_id, None)
        if not session:
            return
        if session.token is not None:
            try:
                cls._session_var.reset(session.token)
            except LookupError:  # pragma: no cover - defensive
                pass
