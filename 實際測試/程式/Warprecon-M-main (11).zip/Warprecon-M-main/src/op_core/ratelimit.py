from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
from pathlib import Path
import threading
import time
from typing import Any, Dict


logger = logging.getLogger(__name__)


class TokenBucket:
    def __init__(self, rate: float, burst: int):
        self.rate = rate
        self.capacity = burst
        self.tokens = burst
        self.lock = threading.Lock()
        self.updated = time.monotonic()

    def take(self, n: int = 1) -> bool:
        with self.lock:
            now = time.monotonic()
            delta = now - self.updated
            self.updated = now
            self.tokens = min(self.capacity, self.tokens + delta * self.rate)
            if self.tokens >= n:
                self.tokens -= n
                return True
            return False


class RateLimiter:
    """Async rate limiter supporting persistence and adaptive limits."""

    def __init__(
        self,
        global_rps: float,
        per_host_rps: float,
        jitter_ms: int = 0,
        state_file: str | None = None,
    ) -> None:
        self.global_rps = float(global_rps)
        self.per_host_rps = float(per_host_rps)
        burst_g = max(1, int(self.global_rps))
        burst_h = max(1, int(self.per_host_rps))
        self.global_bucket = TokenBucket(self.global_rps, burst_g)
        self.default_host_burst = burst_h
        self.host_buckets: dict[str, TokenBucket] = {}
        self.host_overrides: dict[str, float] = {}
        self.jitter = jitter_ms / 1000.0
        self.state_file = Path(state_file) if state_file else None
        self.state_lock = threading.Lock()
        self.config_lock = threading.Lock()
        self.min_global_rps = 0.05
        self.max_global_rps = max(self.global_rps * 10.0, self.global_rps + 10.0)
        self.min_per_host_rps = 0.05
        self.max_per_host_rps = max(self.per_host_rps * 10.0, self.per_host_rps + 10.0)
        self._state_write_interval = 1.0
        self._next_state_write = 0.0
        if self.state_file:
            self._load_state()

    def _host_rate(self, host: str) -> float:
        return self.host_overrides.get(host, self.per_host_rps)

    def _bucket_for(self, host: str) -> TokenBucket:
        b = self.host_buckets.get(host)
        if b is None:
            rate = self._host_rate(host)
            burst = max(1, int(rate))
            b = TokenBucket(rate, burst)
            self.host_buckets[host] = b
        return b

    async def acquire(self, host: str) -> None:
        while True:
            took_global = self.global_bucket.take()
            took_host = self._bucket_for(host).take()
            if took_global and took_host:
                self._write_state()
                return
            await asyncio.sleep(0.01 + self.jitter)

    def penalize(
        self,
        host: str,
        penalty: float,
        *,
        status: int | None = None,
        latency: float | None = None,
    ) -> None:
        b = self._bucket_for(host)
        with b.lock:
            b.tokens = max(0.0, b.tokens - penalty)
        if status is not None or latency is not None:
            self.update_from_response(host, status_code=status, latency=latency)
        self._write_state()

    def update_from_response(
        self,
        host: str,
        *,
        status_code: int | None = None,
        latency: float | None = None,
    ) -> None:
        """Adjust global and per-host rates based on feedback."""

        global_penalty = 1.0
        host_penalty = 1.0
        base_penalty = 1.0
        global_boost = 1.0
        host_boost = 1.0
        base_boost = 1.0

        if status_code is not None:
            if status_code == 429:
                global_penalty = min(global_penalty, 0.7)
                host_penalty = min(host_penalty, 0.4)
                base_penalty = min(base_penalty, 0.85)
            elif status_code in {503, 504}:
                global_penalty = min(global_penalty, 0.8)
                host_penalty = min(host_penalty, 0.6)
                base_penalty = min(base_penalty, 0.9)
            elif 500 <= status_code < 600:
                global_penalty = min(global_penalty, 0.9)
                host_penalty = min(host_penalty, 0.75)
                base_penalty = min(base_penalty, 0.95)
            elif 200 <= status_code < 300:
                global_boost = max(global_boost, 1.05)
                host_boost = max(host_boost, 1.08)
                base_boost = max(base_boost, 1.02)

        if latency is not None:
            if latency > 5.0:
                global_penalty = min(global_penalty, 0.6)
                host_penalty = min(host_penalty, 0.5)
                base_penalty = min(base_penalty, 0.85)
            elif latency > 2.5:
                global_penalty = min(global_penalty, 0.75)
                host_penalty = min(host_penalty, 0.65)
                base_penalty = min(base_penalty, 0.9)
            elif latency < 0.3:
                global_boost = max(global_boost, 1.08)
                host_boost = max(host_boost, 1.1)
                base_boost = max(base_boost, 1.04)
            elif latency < 0.6:
                global_boost = max(global_boost, 1.03)
                host_boost = max(host_boost, 1.05)
                base_boost = max(base_boost, 1.02)

        if global_penalty < 1.0 or host_penalty < 1.0 or base_penalty < 1.0:
            if global_penalty < 1.0:
                self._scale_global(global_penalty)
            if base_penalty < 1.0:
                self._scale_per_host_base(base_penalty)
            if host_penalty < 1.0:
                self._scale_host(host, host_penalty)
            return

        if global_boost > 1.0:
            self._scale_global(global_boost)
        if base_boost > 1.0:
            self._scale_per_host_base(base_boost)
        if host_boost > 1.0:
            self._scale_host(host, host_boost)

    def save_state(self) -> None:
        self._write_state(force=True)

    def load_state(self) -> None:
        self._load_state()

    def _write_state(self, *, force: bool = False) -> None:
        if not self.state_file:
            return
        now_mono = time.monotonic()
        if not force and now_mono < self._next_state_write:
            return
        with self.state_lock:
            now_mono = time.monotonic()
            if not force and now_mono < self._next_state_write:
                return
            now_wall = time.time()
            data: Dict[str, Any] = {
                "saved_at": now_wall,
                "global": self._bucket_state(
                    self.global_bucket, self.global_rps, now_wall, now_mono
                ),
                "per_host_rps": self.per_host_rps,
                "hosts": {},
                "host_overrides": dict(self.host_overrides),
            }
            for host, bucket in list(self.host_buckets.items()):
                data["hosts"][host] = self._bucket_state(
                    bucket, self._host_rate(host), now_wall, now_mono
                )

            tmp_path = self.state_file.with_suffix(".tmp")
            try:
                self.state_file.parent.mkdir(parents=True, exist_ok=True)
                with tmp_path.open("w", encoding="utf-8") as fh:
                    json.dump(data, fh)
                os.replace(tmp_path, self.state_file)
            except OSError as exc:
                logger.warning(
                    "Failed to persist rate limiter state to %s: %s", self.state_file, exc
                )
                with contextlib.suppress(FileNotFoundError):
                    os.remove(tmp_path)
            else:
                self._next_state_write = time.monotonic() + self._state_write_interval

    def _load_state(self) -> None:
        if not self.state_file or not self.state_file.exists():
            return
        with self.state_lock:
            try:
                with self.state_file.open("r", encoding="utf-8") as fh:
                    data = json.load(fh)
            except (OSError, json.JSONDecodeError) as exc:
                logger.warning(
                    "Failed to load rate limiter state from %s: %s", self.state_file, exc
                )
                return

            now_wall = time.time()
            now_mono = time.monotonic()
            saved_at = data.get("saved_at")
            try:
                saved_at_f = float(saved_at) if saved_at is not None else 0.0
            except (TypeError, ValueError):
                saved_at_f = 0.0
            base_elapsed = max(0.0, now_wall - saved_at_f) if saved_at_f else 0.0

            global_state = data.get("global")
            if isinstance(global_state, dict):
                rate_val = global_state.get("rate", self.global_rps)
                try:
                    rate = float(rate_val)
                except (TypeError, ValueError):
                    rate = self.global_rps
                self._set_global_rate(rate)
                tokens_val = global_state.get("tokens", self.global_bucket.tokens)
                try:
                    tokens = float(tokens_val)
                except (TypeError, ValueError):
                    tokens = self.global_bucket.tokens
                updated_val = global_state.get("updated")
                try:
                    updated_at = float(updated_val) if updated_val is not None else None
                except (TypeError, ValueError):
                    updated_at = None
                elapsed = base_elapsed if updated_at is None else max(0.0, now_wall - updated_at)
                with self.global_bucket.lock:
                    refill = tokens + elapsed * self.global_bucket.rate
                    self.global_bucket.tokens = min(self.global_bucket.capacity, refill)
                    self.global_bucket.updated = max(now_mono - elapsed, 0.0)

            self.host_buckets.clear()

            overrides = data.get("host_overrides")
            if isinstance(overrides, dict):
                new_overrides: dict[str, float] = {}
                for host, value in overrides.items():
                    try:
                        new_overrides[str(host)] = float(value)
                    except (TypeError, ValueError):
                        continue
                self.host_overrides = new_overrides
            else:
                self.host_overrides = {}

            per_host_base = data.get("per_host_rps")
            if per_host_base is not None:
                try:
                    self._set_per_host_base(float(per_host_base))
                except (TypeError, ValueError):
                    pass

            hosts = data.get("hosts")
            if isinstance(hosts, dict):
                for host, bucket_data in hosts.items():
                    if not isinstance(bucket_data, dict):
                        continue
                    rate_val = bucket_data.get("rate", self._host_rate(host))
                    try:
                        rate = float(rate_val)
                    except (TypeError, ValueError):
                        rate = self._host_rate(host)
                    burst = max(1, int(rate))
                    bucket = TokenBucket(rate, burst)
                    tokens_val = bucket_data.get("tokens", burst)
                    try:
                        tokens = float(tokens_val)
                    except (TypeError, ValueError):
                        tokens = float(burst)
                    updated_val = bucket_data.get("updated")
                    try:
                        updated_at = float(updated_val) if updated_val is not None else None
                    except (TypeError, ValueError):
                        updated_at = None
                    elapsed = base_elapsed if updated_at is None else max(0.0, now_wall - updated_at)
                    refill = tokens + elapsed * rate
                    bucket.tokens = min(bucket.capacity, refill)
                    bucket.updated = max(now_mono - elapsed, 0.0)
                    self.host_buckets[str(host)] = bucket

    def _bucket_state(
        self,
        bucket: TokenBucket,
        rate: float,
        wall_now: float,
        mono_now: float,
    ) -> Dict[str, Any]:
        with bucket.lock:
            elapsed = max(0.0, mono_now - bucket.updated)
            updated_wall = max(0.0, wall_now - elapsed)
            return {
                "rate": rate,
                "capacity": bucket.capacity,
                "tokens": min(bucket.capacity, bucket.tokens),
                "updated": updated_wall,
            }

    def _set_global_rate(self, rate: float) -> None:
        clamped = max(self.min_global_rps, min(self.max_global_rps, rate))
        burst = max(1, int(clamped))
        with self.global_bucket.lock:
            self.global_rps = clamped
            self.global_bucket.rate = clamped
            self.global_bucket.capacity = burst
            self.global_bucket.tokens = min(self.global_bucket.capacity, self.global_bucket.tokens)
            self.global_bucket.updated = time.monotonic()

    def _set_per_host_base(self, rate: float) -> None:
        clamped = max(self.min_per_host_rps, min(self.max_per_host_rps, rate))
        with self.config_lock:
            self.per_host_rps = clamped
            self.default_host_burst = max(1, int(clamped))
            unaffected = [h for h in self.host_buckets if h not in self.host_overrides]
        for host in unaffected:
            self._apply_rate(self.host_buckets[host], clamped)

    def _scale_global(self, factor: float) -> None:
        if factor <= 0:
            return
        self._set_global_rate(self.global_rps * factor)

    def _scale_per_host_base(self, factor: float) -> None:
        if factor <= 0:
            return
        self._set_per_host_base(self.per_host_rps * factor)

    def _scale_host(self, host: str, factor: float) -> None:
        if factor <= 0:
            return
        with self.config_lock:
            current = self.host_overrides.get(host, self.per_host_rps)
            new_rate = max(self.min_per_host_rps, min(self.max_per_host_rps, current * factor))
            self.host_overrides[host] = new_rate
        bucket = self._bucket_for(host)
        self._apply_rate(bucket, new_rate)

    def _apply_rate(self, bucket: TokenBucket, rate: float) -> None:
        burst = max(1, int(rate))
        with bucket.lock:
            bucket.rate = rate
            bucket.capacity = burst
            bucket.tokens = min(bucket.capacity, bucket.tokens)
            bucket.updated = time.monotonic()
