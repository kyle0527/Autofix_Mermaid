from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from op_adapters.errors import ExternalToolNotInstalledError
from op_adapters.nuclei import run_nuclei
from op_adapters.sqlmap import run_sqlmap
from op_adapters.xsstrike import run_xsstrike
from op_auth import AuthManager, build_account_context, load_pool_from_config, load_strategy
from op_checks.idor import IdorCheck
from op_control.campaign import Campaign
from op_core.history import HistoryDB
from op_core.httpclient import make_async_client
from op_core.rank import rank_findings
from op_core.precision import PrecisionEngine
from op_core.runner import filter_targets_by_scope, run_hunt
from op_oob.interactsh import InteractClient
from op_output.artifacts import try_capture
from op_output.html import export_html
from op_output.poc import write_poc_files
from op_output.sarif import to_sarif


logger = logging.getLogger(__name__)


def run_scans(
    targets: List[str], camp: Campaign, workdir: Path
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Any]:
    """Execute the scanning suite against ``targets``.

    Returns the ranked findings, any collected out-of-band events and the
    exported OOB state required for report generation.
    """

    hist = HistoryDB(workdir / "history.jsonl", ttl_days=camp.output.history_ttl_days)
    oob = InteractClient(getattr(camp.oob, "base_url", None), getattr(camp.oob, "api_key", None))

    timeout = getattr(camp.limits, "http_timeout", None)
    try:
        request_timeout = float(timeout) if timeout is not None else 10.0
    except (TypeError, ValueError):
        request_timeout = 10.0

    account_context = None
    accounts_cfg = getattr(camp, "accounts", None)
    if accounts_cfg is not None:
        sources = list(getattr(accounts_cfg, "sources", []) or [])
        inline_profiles = getattr(accounts_cfg, "inline_profiles", {}) or {}
        if hasattr(inline_profiles, "model_dump"):
            inline_profiles = inline_profiles.model_dump(mode="python")
        pool = load_pool_from_config(
            sources=sources,
            inline_profiles=inline_profiles,
            default_profile=getattr(accounts_cfg, "default_profile", None),
            base_dir=workdir,
        )
        if pool is not None:
            prefer_roles = list(getattr(accounts_cfg, "prefer_roles", []) or [])
            profile_name = getattr(accounts_cfg, "default_profile", None) or pool.default_profile
            account_context = build_account_context(
                pool,
                profile_name=profile_name,
                prefer_roles=prefer_roles,
                workdir=workdir,
                request_timeout=request_timeout,
            )

    strategies: Dict[str, Any] = {}
    default_role: Optional[str] = None
    if account_context is not None:
        strategies = dict(account_context.strategies)
        default_role = account_context.default_role

    if not strategies:
        strategies = {"default": load_strategy("none")}
        default_role = "default"

    auth = AuthManager(
        strategies,
        lambda: make_async_client(workdir, timeout=timeout),
        default_role=default_role,
    )
    scoped_targets = filter_targets_by_scope(list(targets), camp)

    findings = run_hunt(
        scoped_targets,
        camp,
        hist,
        oob_client=oob,
        workdir=workdir,
        auth=auth,
    )

    try:
        events = oob.poll()
    except (OSError, RuntimeError) as e:
        logger.warning("oob poll failed: %s", e)
        events = []

    oob_state = oob.export_events()

    oob_dir = workdir / "oob"
    oob_dir.mkdir(parents=True, exist_ok=True)
    (oob_dir / "events.json").write_text(
        json.dumps(
            {"events": events, "state": oob.export_events()},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    findings = oob.correlate_findings(findings)

    missing_tools: set[str] = set()

    def _record_missing(tool: str, error: BaseException) -> None:
        if tool in missing_tools:
            return
        missing_tools.add(tool)
        logger.warning("Skipping %s scans: %s", tool, error)

    nuclei_items: List[Dict] = []
    try:
        nuclei_items = run_nuclei(str(workdir / "targets.txt"), None)
    except ExternalToolNotInstalledError as exc:
        _record_missing(exc.tool, exc)

    extra: List[Dict] = []
    max_targets = getattr(camp.limits, "max_external_targets", len(scoped_targets))
    for t in scoped_targets[:max_targets]:
        if "sqlmap" not in missing_tools:
            try:
                extra += run_sqlmap(t)
            except ExternalToolNotInstalledError as exc:
                _record_missing(exc.tool, exc)
        if "xsstrike" not in missing_tools:
            try:
                extra += run_xsstrike(t)
            except ExternalToolNotInstalledError as exc:
                _record_missing(exc.tool, exc)
        if {"sqlmap", "xsstrike"}.issubset(missing_tools):
            break

    # IDOR check (optional via campaign idor.enabled)
    idor_cfg = getattr(camp, "idor", {}) or {}
    idor_findings: List[Dict[str, Any]] = []
    try:
        if idor_cfg.get("enabled"):
            # Build candidate API list: numeric-looking endpoints from discovered targets
            api_candidates = []
            import re

            for t in scoped_targets:
                if re.search(r"/(\d+)(?:/|$)", t):
                    api_candidates.append({"url": t})
            if api_candidates:
                roles = idor_cfg.get("roles")
                expand = bool(idor_cfg.get("expand_variants", True))
                if not roles and account_context is not None:
                    derived_roles: List[Dict[str, Any]] = []
                    for role_name, strategy in account_context.strategies.items():
                        artifacts = getattr(strategy, "artifacts", None)
                        if artifacts is None:
                            continue
                        headers = dict(getattr(artifacts, "headers", {}))
                        token = getattr(artifacts, "token", None)
                        if token and not any(key.lower() == "authorization" for key in headers):
                            headers["Authorization"] = f"Bearer {token}"
                        role_entry: Dict[str, Any] = {"name": role_name, "headers": headers}
                        cookies = dict(getattr(artifacts, "cookies", {}))
                        if cookies:
                            role_entry["cookies"] = cookies
                        derived_roles.append(role_entry)
                    if derived_roles:
                        roles = derived_roles
                check = IdorCheck(roles=roles, expand_variants=expand)
                # Findings are dataclasses -> convert to dict for merge
                for f in check.run(api_candidates):
                    d = f.__dict__.copy()
                    # unify key naming with other findings (target/url)
                    if "target" not in d:
                        d["target"] = d.get("url") or d.get("meta", {}).get("url")
                    idor_findings.append(d)
    except Exception as e:  # non-fatal
        logger.warning("idor check failed: %s", e)

    merged = findings + nuclei_items + extra + idor_findings
    precision_engine = PrecisionEngine(getattr(camp, "precision", None), workdir=workdir)
    ranked = rank_findings(merged, None, precision_engine)

    return ranked, events, oob_state


def export_results(
    ranked: List[Dict[str, Any]],
    events: List[Dict[str, Any]],
    oob_state: Any,
    camp: Campaign,
    workdir: Path,
) -> Dict[str, str]:
    """Write result artifacts for ``ranked`` findings.

    A dictionary with paths to the JSON, SARIF and HTML report files is
    returned.
    """

    json_path = workdir / "ranked.json"
    sarif_path = workdir / "out.sarif"
    html_path = Path(export_html(workdir, ranked))
    json_path.write_text(
        json.dumps(ranked, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    sarif_path.write_text(to_sarif(ranked), encoding="utf-8")
    for i, f in enumerate(ranked[: camp.output.poc_top]):
        write_poc_files(workdir, f, i + 1)
    if camp.output.capture:
        artdir = workdir / "artifacts"
        for i, f in enumerate(ranked[: camp.output.poc_top]):
            url = f.get("url") or f.get("target", "")

            sub = artdir / f"item_{i + 1:02d}"
            try_capture(url, sub)

    oob_dir = workdir / "oob"
    oob_dir.mkdir(parents=True, exist_ok=True)
    (oob_dir / "events.json").write_text(
        json.dumps({"events": events, "state": oob_state}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return {"json": str(json_path), "sarif": str(sarif_path), "html": str(html_path)}

