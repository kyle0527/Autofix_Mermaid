"""Baseline helpers for the precision engine."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Pattern


@dataclass(slots=True)
class BaselineEntry:
    fingerprint: str | None
    target_contains: str | None
    pattern: Pattern[str] | None
    action: str
    reason: str
    penalty: float | None

    def matches(self, *, fingerprint: str | None, target: str) -> bool:
        if self.fingerprint and fingerprint:
            if fingerprint == self.fingerprint:
                return True
        if self.pattern and self.pattern.search(target):
            return True
        if self.target_contains and self.target_contains in target.lower():
            return True
        return False


class BaselineStore:
    """Load and query baseline suppression entries."""

    def __init__(self, path: Path | None) -> None:
        self.path = path
        self.entries: list[BaselineEntry] = []
        if path is not None:
            self._load(path)

    def _load(self, path: Path) -> None:
        if not path.exists():
            return
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError:
            return

        payloads: list[Mapping[str, Any]] = []
        try:
            loaded = json.loads(raw)
            if isinstance(loaded, Mapping):
                payloads.append(loaded)
            elif isinstance(loaded, Iterable):
                for item in loaded:
                    if isinstance(item, Mapping):
                        payloads.append(item)
        except json.JSONDecodeError:
            for line in raw.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(payload, Mapping):
                    payloads.append(payload)

        for payload in payloads:
            fingerprint = payload.get("fingerprint") or payload.get("fp") or payload.get("id")
            if isinstance(fingerprint, str) and fingerprint.strip():
                fingerprint = fingerprint.strip()
            else:
                fingerprint = None

            target_raw = payload.get("target") or payload.get("path") or payload.get("url")
            if isinstance(target_raw, str) and target_raw.strip():
                target_contains = target_raw.strip().lower()
            else:
                target_contains = None

            regex_raw = payload.get("regex") or payload.get("pattern")
            pattern: Pattern[str] | None = None
            if isinstance(regex_raw, str) and regex_raw.strip():
                try:
                    pattern = re.compile(regex_raw, re.IGNORECASE)
                except re.error:
                    pattern = None

            action = str(payload.get("action") or "downgrade").lower()
            reason = str(payload.get("reason") or payload.get("label") or "baseline")
            penalty_val = payload.get("penalty")
            penalty = None
            try:
                if penalty_val is not None:
                    penalty = float(penalty_val)
            except (TypeError, ValueError):
                penalty = None

            self.entries.append(
                BaselineEntry(
                    fingerprint=fingerprint,
                    target_contains=target_contains,
                    pattern=pattern,
                    action=action,
                    reason=reason,
                    penalty=penalty,
                )
            )

    def match(self, finding: Mapping[str, Any]) -> BaselineEntry | None:
        fingerprint = finding.get("fingerprint") or finding.get("fp") or finding.get("id")
        if fingerprint is not None:
            fingerprint = str(fingerprint)
        target = str(finding.get("target") or "")
        for entry in self.entries:
            if entry.matches(fingerprint=fingerprint, target=target):
                return entry
        return None


__all__ = ["BaselineStore", "BaselineEntry"]
