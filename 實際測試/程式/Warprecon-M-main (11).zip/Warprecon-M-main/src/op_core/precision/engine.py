"""Precision scoring, ignore handling and gating helpers."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, MutableMapping, Sequence

from op_core.finding_contract import Finding, as_finding
from op_core.rank import compute_cvss_base, strength

from .baseline import BaselineEntry, BaselineStore
from .ignore import IgnoreRule


@dataclass(slots=True)
class PrecisionStats:
    scored: int = 0
    ignored: int = 0
    baseline_hits: int = 0
    suppressed: int = 0
    kept: int = 0
    gate_input: int = 0
    gate_kept: int = 0
    gate_dropped: int = 0
    reasons: Counter[str] = field(default_factory=Counter)


class PrecisionEngine:
    """Apply precision rules such as weighting, ignore filters and gating."""

    def __init__(self, config: Any | None = None, *, workdir: Path | None = None) -> None:
        self.config = config
        self.workdir = Path(workdir or ".").resolve()
        weights_cfg = self._section(config, "weights")
        baseline_cfg = self._section(config, "baseline")
        ignore_cfg = self._list_section(config, "ignore")
        gate_cfg = self._section(config, "gate")

        severity_map = self._as_mapping(weights_cfg.get("severity"))
        self.severity_weights: dict[str, float] = {
            str(key).lower(): float(value)
            for key, value in severity_map.items()
            if self._is_number(value)
        }
        self.oob_weight: float = float(weights_cfg.get("oob_hit", 0.0) or 0.0)
        penalty_map = self._as_mapping(weights_cfg.get("penalties"))
        self.penalties: dict[str, float] = {
            str(key).lower(): float(value)
            for key, value in penalty_map.items()
            if self._is_number(value)
        }

        history_path = baseline_cfg.get("history_path")
        baseline_path: Path | None = None
        if history_path:
            candidate = Path(history_path)
            if not candidate.is_absolute():
                candidate = self.workdir / candidate
            baseline_path = candidate
        self.baseline = BaselineStore(baseline_path)
        self.baseline_default_penalty = float(self.penalties.get("baseline", -1.0))

        self.ignore_rules = [IgnoreRule.from_dict(rule) for rule in ignore_cfg if isinstance(rule, Mapping)]

        self.gate_threshold = float(gate_cfg.get("threshold", 0.0) or 0.0)
        self.gate_topn = int(gate_cfg.get("top_n", gate_cfg.get("topn", 0)) or 0)
        self.gate_prefer_confirmed = bool(gate_cfg.get("prefer_confirmed", True))
        self.gate_min_score = float(gate_cfg.get("min_score", 0.0) or 0.0)

        self.stats = PrecisionStats()
        self._last_suppressed: list[Finding] = []
        self._last_ignored: list[Finding] = []

    @staticmethod
    def _is_number(value: Any) -> bool:
        try:
            float(value)
        except (TypeError, ValueError):
            return False
        return True

    @staticmethod
    def _as_mapping(value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if isinstance(value, Mapping):
            return dict(value)
        dump = getattr(value, "model_dump", None)
        if callable(dump):
            return dict(dump(mode="python"))
        return {}

    def _section(self, source: Any | None, key: str) -> dict[str, Any]:
        if source is None:
            return {}
        if isinstance(source, Mapping):
            return self._as_mapping(source.get(key))
        return self._as_mapping(getattr(source, key, None))

    def _list_section(self, source: Any | None, key: str) -> list[Any]:
        if source is None:
            return []
        if isinstance(source, Mapping):
            value = source.get(key, [])
        else:
            value = getattr(source, key, [])
        if hasattr(value, "model_dump"):
            value = value.model_dump(mode="python")
        return list(value or [])

    def _collect_tags(self, finding: Mapping[str, Any]) -> set[str]:
        tags: set[str] = set()
        check = finding.get("check")
        if isinstance(check, str) and check:
            tags.add(check.lower())
        category = finding.get("category")
        if isinstance(category, str) and category:
            tags.add(category.lower())
        mode = finding.get("mode")
        if isinstance(mode, str) and mode:
            tags.add(mode.lower())
        vector = finding.get("vector") or {}
        if isinstance(vector, Mapping):
            proto = vector.get("protocol")
            if isinstance(proto, str) and proto:
                tags.add(proto.lower())
            param = vector.get("param")
            if isinstance(param, str) and param:
                tags.add(param.lower())
        tool = finding.get("tool")
        if isinstance(tool, str) and tool:
            tags.add(tool.lower())
        extra_tags = finding.get("tags") or []
        if isinstance(extra_tags, Sequence):
            for tag in extra_tags:
                if isinstance(tag, str) and tag:
                    tags.add(tag.lower())
        return tags

    def _match_ignore(self, finding: Mapping[str, Any]) -> IgnoreRule | None:
        for rule in self.ignore_rules:
            if rule.matches(finding):
                return rule
        return None

    def score_findings(self, items: Iterable[Mapping[str, Any] | Finding]) -> list[Finding]:
        findings = [as_finding(item) for item in items]
        kept: list[Finding] = []
        ignored: list[Finding] = []
        suppressed: list[Finding] = []
        baseline_hits = 0

        for finding in findings:
            precision_meta: dict[str, Any] = dict(finding.get("_precision", {}))
            ignore_rule = self._match_ignore(finding)
            if ignore_rule is not None:
                precision_meta["ignored"] = {"reason": ignore_rule.reason or "rule"}
                finding["_precision"] = precision_meta
                ignored.append(finding)
                continue

            cvss_payload = finding.get("cvss")
            if not isinstance(cvss_payload, Mapping):
                profile = compute_cvss_base({})
                finding["cvss"] = profile
            else:
                profile = cvss_payload
            base_score = float(profile.get("base_score", 0.0))
            severity = str(finding.get("severity") or "medium").lower()
            severity_weight = self.severity_weights.get(severity, 1.0)
            weighted_base = base_score * severity_weight

            heuristic = strength(finding) / 40.0

            evidence = finding.get("evidence") or {}
            oob_bonus = 0.0
            if isinstance(evidence, Mapping):
                if evidence.get("dns_log") or evidence.get("oob_token") or evidence.get("oob" ):
                    oob_bonus = self.oob_weight

            penalty_total = 0.0
            tags = self._collect_tags(finding)
            for key, value in self.penalties.items():
                if key == "baseline":
                    continue
                if key in tags:
                    penalty_total += value

            baseline_entry: BaselineEntry | None = self.baseline.match(finding)
            baseline_penalty = 0.0
            if baseline_entry is not None:
                baseline_hits += 1
                baseline_penalty = (
                    baseline_entry.penalty
                    if baseline_entry.penalty is not None
                    else self.baseline_default_penalty
                )
                precision_meta["baseline"] = {
                    "reason": baseline_entry.reason,
                    "action": baseline_entry.action,
                    "penalty": baseline_penalty,
                }
                if baseline_entry.action in {"suppress", "drop"}:
                    suppressed.append(finding)
                    finding["_precision"] = precision_meta
                    continue

            components = {
                "base": round(base_score, 3),
                "severity_weight": round(severity_weight, 3),
                "weighted_base": round(weighted_base, 3),
                "heuristic": round(heuristic, 3),
                "oob": round(oob_bonus, 3),
                "penalties": round(penalty_total, 3),
                "baseline": round(baseline_penalty, 3),
            }

            score = weighted_base + heuristic + oob_bonus + penalty_total + baseline_penalty
            if score < 0:
                score = 0.0
            finding.score = round(score, 3)
            precision_meta["components"] = components
            finding["_precision"] = precision_meta
            kept.append(finding)

        kept.sort(key=lambda f: (f.score or 0.0, f.get("cvss", {}).get("base_score", 0.0)), reverse=True)
        for idx, finding in enumerate(kept, start=1):
            finding.rank = idx

        self._last_suppressed = suppressed
        self._last_ignored = ignored
        self.stats = PrecisionStats(
            scored=len(findings),
            ignored=len(ignored),
            baseline_hits=baseline_hits,
            suppressed=len(suppressed) + len(ignored),
            kept=len(kept),
        )
        return kept

    @property
    def ignored(self) -> list[Finding]:
        return list(self._last_ignored)

    @property
    def suppressed(self) -> list[Finding]:
        return list(self._last_suppressed)

    def apply_gate(
        self,
        items: Sequence[MutableMapping[str, Any]],
        *,
        accept_fingerprints: Iterable[str] | None = None,
    ) -> tuple[list[MutableMapping[str, Any]], list[MutableMapping[str, Any]]]:
        accepts = {str(fp) for fp in (accept_fingerprints or []) if fp}
        ordered = sorted(items, key=lambda item: float(item.get("_score", 0.0) or 0.0), reverse=True)

        kept: list[MutableMapping[str, Any]] = []
        dropped: list[MutableMapping[str, Any]] = []
        stats_reasons: Counter[str] = Counter()

        for idx, item in enumerate(ordered, start=1):
            meta = dict(item.get("_precision", {}))
            gate_meta = dict(meta.get("gate", {}))
            reasons: list[str] = []
            fingerprint = item.get("fingerprint") or item.get("fp") or item.get("id")
            fingerprint = str(fingerprint) if fingerprint is not None else ""
            severity = str(item.get("severity") or "").lower()
            score = float(item.get("_score", 0.0) or 0.0)

            accepted = False
            if fingerprint and fingerprint in accepts:
                accepted = True
                reasons.append("label")
            if severity in {"critical", "high"}:
                accepted = True
                reasons.append("severity")
            if self.gate_topn and idx <= self.gate_topn:
                accepted = True
                reasons.append("topn")
            if score >= self.gate_threshold:
                accepted = True
                reasons.append("threshold")
            if self.gate_prefer_confirmed and bool(item.get("confirmed")):
                accepted = True
                reasons.append("confirmed")
            if score < self.gate_min_score:
                accepted = False
                reasons.append("min_score")

            gate_meta["accepted"] = accepted
            gate_meta["reasons"] = reasons
            meta["gate"] = gate_meta
            item["_precision"] = meta
            item["_rank"] = idx

            if accepted:
                kept.append(item)
                for reason in reasons:
                    stats_reasons[reason] += 1
            else:
                dropped.append(item)
                if not reasons:
                    stats_reasons["dropped"] += 1
                else:
                    for reason in reasons:
                        stats_reasons[reason] += 1

        self.stats.gate_input = len(ordered)
        self.stats.gate_kept = len(kept)
        self.stats.gate_dropped = len(dropped)
        self.stats.reasons = stats_reasons
        return kept, dropped


__all__ = ["PrecisionEngine", "PrecisionStats"]
