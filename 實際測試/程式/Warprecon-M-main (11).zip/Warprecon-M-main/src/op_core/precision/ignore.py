"""Ignore rule helpers for the precision engine."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Mapping, Pattern


@dataclass(slots=True)
class IgnoreRule:
    """Match findings that should be suppressed before gating."""

    path_contains: str | None = None
    param_equals: str | None = None
    text_contains: str | None = None
    pattern: Pattern[str] | None = None
    severity: str | None = None
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "IgnoreRule":
        path = str(payload.get("path") or payload.get("target") or "") or None
        param = str(payload.get("param") or "") or None
        text = str(payload.get("contains") or payload.get("string") or "") or None
        regex_raw = payload.get("regex")
        pattern = None
        if isinstance(regex_raw, str) and regex_raw.strip():
            try:
                pattern = re.compile(regex_raw, re.IGNORECASE)
            except re.error:
                pattern = None
        severity = payload.get("severity")
        if isinstance(severity, str) and severity.strip():
            severity = severity.strip().lower()
        else:
            severity = None
        reason = str(payload.get("reason") or payload.get("label") or "")
        if path:
            path = path.lower()
        if param:
            param = param.lower()
        if text:
            text = text.lower()
        return cls(
            path_contains=path,
            param_equals=param,
            text_contains=text,
            pattern=pattern,
            severity=severity,
            reason=reason,
        )

    def matches(self, finding: Mapping[str, Any]) -> bool:
        target = str(finding.get("target") or "")
        if self.path_contains and self.path_contains not in target.lower():
            return False

        if self.severity:
            severity = str(finding.get("severity") or "").lower()
            if severity != self.severity:
                return False

        if self.param_equals:
            vector = finding.get("vector") or {}
            candidate = None
            if isinstance(vector, Mapping):
                candidate = vector.get("param") or vector.get("parameter")
            if candidate is None:
                candidate = finding.get("param")
            if candidate is None:
                candidate = finding.get("parameter")
            if candidate is None:
                return False
            candidate_str = str(candidate).lower()
            if candidate_str != self.param_equals:
                return False

        haystacks: list[str] = []
        detail = finding.get("detail")
        if isinstance(detail, str):
            haystacks.append(detail.lower())
        evidence = finding.get("evidence")
        if isinstance(evidence, Mapping):
            try:
                haystacks.append(json.dumps(evidence, ensure_ascii=False).lower())
            except TypeError:
                haystacks.append(str(evidence).lower())
        description = finding.get("description")
        if isinstance(description, str):
            haystacks.append(description.lower())

        if self.text_contains:
            text_hit = any(self.text_contains in hay for hay in haystacks if hay)
            if not text_hit:
                return False

        if self.pattern is not None:
            candidate_sources = haystacks + [target.lower()]
            if not any(self.pattern.search(source or "") for source in candidate_sources):
                return False

        return True


__all__ = ["IgnoreRule"]
