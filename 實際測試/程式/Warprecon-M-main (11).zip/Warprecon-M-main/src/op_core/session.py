from __future__ import annotations

import json
import logging
from json import JSONDecodeError
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypeAlias

if TYPE_CHECKING:  # pragma: no cover - typing helper
    from httpx import Cookies as _Cookies
else:  # pragma: no cover - runtime fallback for type check tools

    class _Cookies(dict):
        """Lightweight stand-in used when httpx is unavailable."""

        pass


CookieJar: TypeAlias = _Cookies | dict[str, str]

logger = logging.getLogger(__name__)


class CookieError(ValueError):
    """Base class for cookie loading failures."""


class CookieParseError(CookieError):
    """Raised when the cookies file cannot be parsed as JSON."""


class CookieFormatError(CookieError):
    """Raised when a cookie entry is missing required data."""


def _read_cookie_file(path: Path) -> Any:
    """Return the raw data from ``path``.

    Raises ``OSError`` when the file cannot be read and ``CookieParseError`` when
    JSON parsing fails.
    """

    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("Failed to read cookies from %s: %s", path, exc)
        raise

    try:
        return json.loads(raw_text)
    except JSONDecodeError as exc:
        logger.warning("Failed to parse cookies JSON from %s: %s", path, exc)
        raise CookieParseError(f"Failed to parse cookies JSON from {path}") from exc


def _extract_cookie_entries(data: Any, source: Path) -> list[dict[str, Any]]:
    """Return the cookie entry list from ``data`` or raise ``CookieFormatError``."""

    if isinstance(data, dict):
        cookies = data.get("cookies")
        if not isinstance(cookies, list):
            message = f"Cookie file {source} must contain a 'cookies' list"
            logger.warning(message)
            raise CookieFormatError(message)
        return cookies
    if isinstance(data, list):
        return data
    message = (
        f"Cookie file {source} must be a list of cookie entries or contain a 'cookies' list"
    )
    logger.warning(message)
    raise CookieFormatError(message)


def _normalise_cookie(
    entry: dict[str, Any], index: int, source: Path
) -> tuple[str, str, str | None, str]:
    """Validate and normalise a cookie entry."""

    missing = [key for key in ("name", "value") if entry.get(key) is None]
    if missing:
        message = (
            f"Cookie entry #{index} in {source} missing required fields: {', '.join(missing)}"
        )
        logger.warning(message)
        raise CookieFormatError(message)

    name = entry["name"]
    value = entry["value"]
    if not isinstance(name, str) or not isinstance(value, str):
        message = (
            f"Cookie entry #{index} in {source} must define string 'name' and 'value'"
        )
        logger.warning(message)
        raise CookieFormatError(message)

    domain_raw = entry.get("domain")
    if domain_raw in (None, ""):
        domain: str | None = None
    elif isinstance(domain_raw, str):
        domain = domain_raw.lstrip(".") if entry.get("hostOnly") else domain_raw
        domain = domain or None
    else:
        message = f"Cookie entry #{index} in {source} has non-string domain"
        logger.warning(message)
        raise CookieFormatError(message)

    path_raw = entry.get("path")
    if path_raw in (None, ""):
        path_value = "/"
    elif isinstance(path_raw, str):
        path_value = path_raw
    else:
        message = f"Cookie entry #{index} in {source} has non-string path"
        logger.warning(message)
        raise CookieFormatError(message)

    return name, value, domain, path_value


def load_cookies(workdir: Path) -> CookieJar:
    """Load cookies from ``<workdir>/session/cookies.json``.

    Raises:
        CookieParseError: If the file cannot be parsed as JSON.
        CookieFormatError: If cookie entries are missing required fields.
    """

    try:  # httpx may be optional in some environments
        from httpx import Cookies  # type: ignore
    except ImportError:  # pragma: no cover - fallback for minimal envs
        Cookies = dict  # type: ignore[assignment]

    jar: CookieJar = Cookies()
    cookies_file = workdir / "session" / "cookies.json"
    if not cookies_file.exists():
        return jar

    raw_data = _read_cookie_file(cookies_file)
    entries = _extract_cookie_entries(raw_data, cookies_file)

    for index, raw_entry in enumerate(entries):
        if not isinstance(raw_entry, dict):
            message = (
                f"Cookie entry #{index} in {cookies_file} must be a JSON object"
            )
            logger.warning(message)
            raise CookieFormatError(message)
        name, value, domain, path_value = _normalise_cookie(
            raw_entry, index, cookies_file
        )

        try:
            if isinstance(jar, dict):
                jar[name] = value
            else:
                jar.set(name, value, domain=domain or "", path=path_value)
        except (TypeError, ValueError) as exc:
            logger.debug(
                "Skipping invalid cookie %s from %s: %s", name, cookies_file, exc
            )

    return jar


__all__ = [
    "CookieError",
    "CookieFormatError",
    "CookieJar",
    "CookieParseError",
    "load_cookies",
]

