from __future__ import annotations

"""Interactive Typer commands that generate configuration scaffolding."""

from pathlib import Path
from typing import Dict, Iterable, List

import typer

from op_core.config_builder import (
    AccountArtifacts,
    AccountBlueprint,
    CampaignOptions,
    LoginSpec,
    RefreshSpec,
    build_accounts_yaml,
    build_campaign_yaml,
)

configure_app = typer.Typer(
    help="Generate campaign.yaml and accounts.yaml templates via a guided wizard.",
)


def _ensure_value(value: str | None, *, prompt: str, default: str | None = None) -> str:
    if value is not None and value.strip():
        return value.strip()
    result = typer.prompt(prompt, default=default or "")
    return result.strip()


def _prompt_bool(message: str, default: bool = False) -> bool:
    return typer.confirm(message, default=default)


def _prompt_mapping(title: str) -> Dict[str, str]:
    typer.echo(f"{title}: enter key=value pairs. Leave blank to finish.")
    result: Dict[str, str] = {}
    while True:
        entry = typer.prompt(f"{title} entry", default="", show_default=False).strip()
        if not entry:
            break
        if "=" not in entry:
            typer.echo("  Use key=value format. Example: Authorization=Bearer token")
            continue
        key, value = entry.split("=", 1)
        key = key.strip()
        if not key:
            typer.echo("  Key cannot be empty.")
            continue
        result[key] = value.strip()
    return result


def _prompt_status_codes(default: Iterable[int]) -> List[int]:
    raw = typer.prompt(
        "Successful HTTP status codes",
        default=",".join(str(code) for code in default),
    )
    values: List[int] = []
    for part in raw.split(","):
        item = part.strip()
        if not item:
            continue
        try:
            values.append(int(item))
        except ValueError:
            typer.echo(f"  Ignoring invalid status code '{item}'.")
    return values or list(default)


def _prompt_int(message: str, default: int) -> int:
    while True:
        raw = typer.prompt(message, default=str(default)).strip()
        if not raw:
            return default
        try:
            return int(raw)
        except ValueError:
            typer.echo("  Please enter an integer value.")


def _prompt_float(message: str, default: float) -> float:
    while True:
        raw = typer.prompt(message, default=str(default)).strip()
        if not raw:
            return default
        try:
            return float(raw)
        except ValueError:
            typer.echo("  Please enter a numeric value.")


def _prompt_login(strategy: str) -> LoginSpec | None:
    if not _prompt_bool("Configure a login HTTP request?", default=strategy != "none"):
        return None

    url = typer.prompt("Login URL", default="", show_default=False).strip()
    if not url:
        return None
    method = typer.prompt("Login method", default="POST").strip().upper() or "POST"
    payload = _prompt_mapping("Login payload")
    headers = _prompt_mapping("Login headers")
    success = _prompt_status_codes([200, 201, 204, 302])
    return LoginSpec(url=url, method=method, payload=payload, headers=headers, success_status=success)


def _prompt_refresh() -> RefreshSpec | None:
    if not _prompt_bool("Configure an automatic refresh flow?", default=False):
        return None

    url = typer.prompt("Refresh URL", default="", show_default=False).strip()
    if not url:
        return None
    method = typer.prompt("Refresh method", default="POST").strip().upper() or "POST"
    payload = _prompt_mapping("Refresh payload")
    headers = _prompt_mapping("Refresh headers")
    grace = _prompt_int("Grace period in seconds", default=30)
    backoff = _prompt_float("Retry backoff seconds", default=0.0)
    token_path = typer.prompt(
        "Token JSON path (e.g. data.access_token)", default="", show_default=False
    ).strip()
    return RefreshSpec(
        url=url,
        method=method,
        payload=payload,
        headers=headers,
        grace_seconds=grace,
        retry_backoff_seconds=backoff,
        token_path=token_path or None,
    )


def _prompt_strategy() -> str:
    choices = {"cookie", "jwt", "oauth", "none"}
    default_choice = "cookie"
    while True:
        raw = typer.prompt(
            "Authentication strategy [cookie/jwt/oauth/none]",
            default=default_choice,
        ).strip().lower()
        if raw in choices:
            return raw
        typer.echo("  Choose one of: cookie, jwt, oauth, none.")


def _write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    typer.echo(f"Wrote {path}")


@configure_app.command("campaign")
def configure_campaign(
    target: str | None = typer.Option(None, "--target", help="Primary scope URL (https://example.com)."),
    spa: bool | None = typer.Option(
        None,
        "--spa/--no-spa",
        help="Enable DOM crawling hints (default: ask interactively).",
        show_default=False,
    ),
    budget: int | None = typer.Option(None, "--budget", help="Scan time budget in minutes."),
    profile: Path | None = typer.Option(None, "--profile", help="Optional overlay profile YAML path."),
    accounts_profile: str | None = typer.Option(None, "--accounts-profile", help="Default account profile name."),
    prefer_roles: List[str] = typer.Option([], "--prefer-role", help="Preferred account roles (repeat flag)."),
    include_accounts: bool = typer.Option(True, "--accounts/--no-accounts", help="Include an accounts block referencing accounts.yaml."),
    include_precision: bool = typer.Option(True, "--precision/--no-precision", help="Include Precision defaults."),
    output: Path = typer.Option(Path("config/campaign.generated.yaml"), "--output", help="Destination for the generated YAML."),
    global_rps: int = typer.Option(30, "--global-rps", help="Global requests-per-second limit."),
    per_host_rps: int = typer.Option(6, "--per-host-rps", help="Per-host RPS limit."),
    max_concurrency: int = typer.Option(8, "--max-concurrency", help="Maximum concurrent HTTP requests."),
    http_timeout: float = typer.Option(10.0, "--http-timeout", help="HTTP timeout in seconds."),
) -> None:
    """Generate a campaign.yaml template with sane defaults."""

    resolved_target = _ensure_value(target, prompt="Target base URL (e.g. https://app.example)")
    resolved_budget = budget if budget is not None else _prompt_int("Scan budget minutes", default=60)
    resolved_spa = spa if spa is not None else _prompt_bool("Enable DOM crawling hints?", default=False)

    resolved_accounts_profile = accounts_profile
    if include_accounts and not resolved_accounts_profile:
        resolved_accounts_profile = _ensure_value("", prompt="Default account profile", default="default")

    options = CampaignOptions(
        target=resolved_target,
        spa=resolved_spa,
        budget_minutes=resolved_budget,
        profile=str(profile) if profile else None,
        accounts_profile=resolved_accounts_profile,
        prefer_roles=prefer_roles,
        include_accounts=include_accounts,
        include_precision=include_precision,
        global_rps=global_rps,
        per_host_rps=per_host_rps,
        max_concurrency=max_concurrency,
        http_timeout=http_timeout,
    )
    content = build_campaign_yaml(options)
    _write_file(output, content)


@configure_app.command("accounts")
def configure_accounts(
    profile_name: str | None = typer.Option(None, "--profile-name", help="Profile identifier (e.g. default)."),
    description: str | None = typer.Option(None, "--description", help="Optional profile description."),
    default_profile: str | None = typer.Option(None, "--default-profile", help="Override the pool default profile."),
    output: Path = typer.Option(Path("config/accounts.generated.yaml"), "--output", help="Destination YAML file."),
) -> None:
    """Interactively build an accounts.yaml file."""

    resolved_profile = _ensure_value(profile_name, prompt="Profile name", default="default")
    resolved_description = description
    if description is None:
        resolved_description = typer.prompt("Profile description", default="", show_default=False).strip() or None

    entries: List[AccountBlueprint] = []
    idx = 1
    while True:
        typer.echo("\n=== Account #%d ===" % idx)
        name = _ensure_value(None, prompt="Account name", default=f"account{idx}")
        role = _ensure_value(None, prompt="Role", default="user")
        strategy = _prompt_strategy()
        artifacts = AccountArtifacts(
            headers=_prompt_mapping("Static headers"),
            cookies=_prompt_mapping("Static cookies"),
            query=_prompt_mapping("Default query parameters"),
            body=_prompt_mapping("Default body parameters"),
            token=typer.prompt("Static token (leave blank if not applicable)", default="", show_default=False).strip() or None,
        )
        login = _prompt_login(strategy)
        refresh = _prompt_refresh()
        tags = _prompt_mapping("Tags")
        entries.append(
            AccountBlueprint(
                name=name,
                role=role,
                strategy=strategy,
                artifacts=artifacts,
                login=login,
                refresh=refresh,
                tags=tags,
            )
        )
        idx += 1
        if not _prompt_bool("Add another account?", default=False):
            break

    if not entries:
        typer.echo("No accounts provided; aborting without writing a file.")
        raise typer.Exit(code=1)

    content = build_accounts_yaml(
        resolved_profile,
        entries,
        description=resolved_description,
        default_profile=default_profile,
    )
    _write_file(output, content)

