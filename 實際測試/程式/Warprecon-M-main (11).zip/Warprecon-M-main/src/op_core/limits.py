from __future__ import annotations
import asyncio
from urllib.parse import urlparse

class Scheduler:
    def __init__(self, max_global: int = 16, max_per_host: int = 8):
        self.global_sem = asyncio.Semaphore(max_global)
        self.per_host: dict[str, asyncio.Semaphore] = {}
        self.max_per_host = max_per_host
    def _host(self, url: str) -> str:
        try:
            return urlparse(url).netloc or ""
        except Exception:
            return ""
    def _sem(self, host: str) -> asyncio.Semaphore:
        if host not in self.per_host:
            self.per_host[host] = asyncio.Semaphore(self.max_per_host)
        return self.per_host[host]
    def guard(self, url: str):
        host = self._host(url)
        sem = self._sem(host)
        class _Guard:
            async def __aenter__(self_non):
                await self.global_sem.acquire(); await sem.acquire()
            async def __aexit__(self_non, exc_type, exc, tb):
                sem.release(); self.global_sem.release()
        return _Guard()
