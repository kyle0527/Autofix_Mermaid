from __future__ import annotations
from pathlib import Path
import json, time
from typing import Dict

class FileBackoffState:
    def __init__(self, path: Path):
        self.path = path
        self._cache: Dict[str, float] = {}
        self._load()

    def _load(self):
        try:
            self._cache = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self._cache = {}

    def _save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self._cache, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def get(self, host: str) -> float:
        return float(self._cache.get(host, 0.0))

    def set_until(self, host: str, until: float):
        self._cache[host] = float(until)
        self._save()

    def clean(self):
        now = time.monotonic()
        remove = [h for h,u in self._cache.items() if u <= now]
        for h in remove:
            self._cache.pop(h, None)
        if remove:
            self._save()
