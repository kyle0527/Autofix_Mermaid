"""Utilities for aggregating telemetry metrics into operator-friendly summaries."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping

__all__ = [
    "DurationStats",
    "AuthTiming",
    "AuthIncidents",
    "WebSocketHandshakeSummary",
    "WebSocketSummary",
    "TelemetrySummary",
    "load_summary",
    "render_text",
]


def _coerce_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _coerce_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _as_duration(data: Mapping[str, Any] | None) -> "DurationStats":
    if not isinstance(data, Mapping):
        return DurationStats()
    return DurationStats(
        count=_coerce_int(data.get("count")),
        avg_ms=_coerce_float(data.get("avg_ms")),
        max_ms=_coerce_float(data.get("max_ms")),
        success_rate=_coerce_float(data.get("success_rate", 1.0)),
    )


@dataclass
class DurationStats:
    """Aggregate duration metrics (count, average latency, success rate)."""

    count: int = 0
    avg_ms: float = 0.0
    max_ms: float = 0.0
    success_rate: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AuthTiming:
    """Authentication timing metrics grouped by global and per-role stats."""

    totals: DurationStats = field(default_factory=DurationStats)
    per_role: dict[str, DurationStats] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "totals": self.totals.to_dict(),
            "per_role": {key: value.to_dict() for key, value in sorted(self.per_role.items())},
        }


@dataclass
class AuthIncidents:
    """Incident counters emitted when responses trigger auth refresh heuristics."""

    count: int = 0
    statuses: dict[str, int] = field(default_factory=dict)
    reasons: dict[str, int] = field(default_factory=dict)
    per_role: dict[str, dict[str, dict[str, int] | int]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        def _normalise(value: Mapping[str, Any]) -> dict[str, Any]:
            return {str(key): _coerce_int(val) for key, val in value.items()}

        return {
            "count": self.count,
            "statuses": _normalise(self.statuses),
            "reasons": _normalise(self.reasons),
            "per_role": {
                role: {
                    "count": _coerce_int(data.get("count")),
                    "statuses": _normalise(data.get("statuses", {})),
                    "reasons": _normalise(data.get("reasons", {})),
                }
                for role, data in sorted(self.per_role.items())
            },
        }


@dataclass
class WebSocketHandshakeSummary:
    """Aggregated statistics for a specific WebSocket handshake profile."""

    totals: DurationStats = field(default_factory=DurationStats)
    reasons: dict[str, int] = field(default_factory=dict)
    per_strategy: dict[str, DurationStats] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "totals": self.totals.to_dict(),
            "reasons": {key: _coerce_int(val) for key, val in sorted(self.reasons.items())},
            "per_strategy": {
                name: stats.to_dict() for name, stats in sorted(self.per_strategy.items())
            },
        }


@dataclass
class WebSocketSummary:
    """Aggregated WebSocket round trip metrics."""

    totals: DurationStats = field(default_factory=DurationStats)
    reasons: dict[str, int] = field(default_factory=dict)
    per_endpoint: dict[str, DurationStats] = field(default_factory=dict)
    per_handshake: dict[str, WebSocketHandshakeSummary] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "totals": self.totals.to_dict(),
            "reasons": {key: _coerce_int(val) for key, val in sorted(self.reasons.items())},
            "per_endpoint": {
                endpoint: stats.to_dict() for endpoint, stats in sorted(self.per_endpoint.items())
            },
            "per_handshake": {
                name: summary.to_dict()
                for name, summary in sorted(self.per_handshake.items())
            },
        }


@dataclass
class TelemetrySummary:
    """High-level aggregation of telemetry metrics for operator review."""

    status: str | None = None
    duration_seconds: float | None = None
    ttfp_seconds: float | None = None
    hits: int = 0
    confirmed_hits: int = 0
    auth_switch: AuthTiming | None = None
    auth_refresh: AuthTiming | None = None
    auth_incidents: AuthIncidents | None = None
    websocket: WebSocketSummary | None = None

    @classmethod
    def from_snapshot(cls, snapshot: Mapping[str, Any]) -> "TelemetrySummary":
        auth_section = snapshot.get("auth") if isinstance(snapshot, Mapping) else {}
        websocket_section = snapshot.get("websocket") if isinstance(snapshot, Mapping) else {}

        def _build_auth_timing(key: str) -> AuthTiming | None:
            if not isinstance(auth_section, Mapping):
                return None
            bucket = auth_section.get(key)
            if not isinstance(bucket, Mapping) or not bucket.get("count"):
                return None
            totals = _as_duration(bucket)
            per_role: dict[str, DurationStats] = {}
            roles = bucket.get("roles")
            if isinstance(roles, Mapping):
                for role, data in roles.items():
                    if not isinstance(data, Mapping):
                        continue
                    stats = _as_duration(data)
                    if stats.count:
                        per_role[str(role)] = stats
            return AuthTiming(totals=totals, per_role=per_role)

        def _build_incidents() -> AuthIncidents | None:
            if not isinstance(auth_section, Mapping):
                return None
            bucket = auth_section.get("incidents")
            if not isinstance(bucket, Mapping) or not bucket.get("count"):
                return None
            result = AuthIncidents(
                count=_coerce_int(bucket.get("count")),
                statuses={str(k): _coerce_int(v) for k, v in (bucket.get("statuses", {})).items()},
                reasons={str(k): _coerce_int(v) for k, v in (bucket.get("reasons", {})).items()},
                per_role={},
            )
            role_data = bucket.get("roles")
            if isinstance(role_data, Mapping):
                for role, data in role_data.items():
                    if not isinstance(data, Mapping):
                        continue
                    result.per_role[str(role)] = {
                        "count": _coerce_int(data.get("count")),
                        "statuses": {
                            str(k): _coerce_int(v)
                            for k, v in (data.get("statuses", {})).items()
                        },
                        "reasons": {
                            str(k): _coerce_int(v)
                            for k, v in (data.get("reasons", {})).items()
                        },
                    }
            return result

        def _build_websocket() -> WebSocketSummary | None:
            if not isinstance(websocket_section, Mapping):
                return None
            bucket = websocket_section.get("roundtrip")
            if not isinstance(bucket, Mapping) or not bucket.get("count"):
                return None
            totals = _as_duration(bucket)
            reasons = {
                str(key): _coerce_int(val)
                for key, val in (bucket.get("reasons", {})).items()
            }
            per_endpoint: dict[str, DurationStats] = {}
            endpoints = bucket.get("endpoints")
            if isinstance(endpoints, Mapping):
                for endpoint, data in endpoints.items():
                    if not isinstance(data, Mapping):
                        continue
                    stats = _as_duration(data)
                    if stats.count:
                        per_endpoint[str(endpoint)] = stats
            per_handshake: dict[str, WebSocketHandshakeSummary] = {}
            handshakes = bucket.get("handshakes")
            if isinstance(handshakes, Mapping):
                for name, data in handshakes.items():
                    if not isinstance(data, Mapping):
                        continue
                    stats = _as_duration(data)
                    if not stats.count:
                        continue
                    handshake_reasons = {
                        str(key): _coerce_int(val)
                        for key, val in (data.get("reasons", {})).items()
                    }
                    strategy_stats: dict[str, DurationStats] = {}
                    strategies = data.get("strategies")
                    if isinstance(strategies, Mapping):
                        for strategy_name, strategy_data in strategies.items():
                            if not isinstance(strategy_data, Mapping):
                                continue
                            strat_stats = _as_duration(strategy_data)
                            if strat_stats.count:
                                strategy_stats[str(strategy_name)] = strat_stats
                    per_handshake[str(name)] = WebSocketHandshakeSummary(
                        totals=stats,
                        reasons=handshake_reasons,
                        per_strategy=strategy_stats,
                    )
            return WebSocketSummary(
                totals=totals,
                reasons=reasons,
                per_endpoint=per_endpoint,
                per_handshake=per_handshake,
            )

        return cls(
            status=str(snapshot.get("status")) if snapshot.get("status") else None,
            duration_seconds=snapshot.get("duration_seconds"),
            ttfp_seconds=snapshot.get("ttfp_seconds"),
            hits=_coerce_int(snapshot.get("hits")),
            confirmed_hits=_coerce_int(snapshot.get("confirmed_hits")),
            auth_switch=_build_auth_timing("switch"),
            auth_refresh=_build_auth_timing("refresh"),
            auth_incidents=_build_incidents(),
            websocket=_build_websocket(),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "duration_seconds": self.duration_seconds,
            "ttfp_seconds": self.ttfp_seconds,
            "hits": self.hits,
            "confirmed_hits": self.confirmed_hits,
            "auth_switch": self.auth_switch.to_dict() if self.auth_switch else None,
            "auth_refresh": self.auth_refresh.to_dict() if self.auth_refresh else None,
            "auth_incidents": self.auth_incidents.to_dict() if self.auth_incidents else None,
            "websocket": self.websocket.to_dict() if self.websocket else None,
        }


def _resolve_metrics_file(path: Path) -> Path:
    if path.is_file():
        return path
    summary = path / "metrics.json"
    if summary.exists():
        return summary
    jsonl = path / "metrics.jsonl"
    if jsonl.exists():
        return jsonl
    raise FileNotFoundError(f"No telemetry metrics found at {path}")


def _read_snapshot_from_file(path: Path) -> Mapping[str, Any]:
    if path.name.endswith(".jsonl"):
        # Return the last non-empty line.
        for line in reversed(path.read_text(encoding="utf-8").splitlines()):
            text = line.strip()
            if not text:
                continue
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                continue
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_summary(path: Path) -> TelemetrySummary:
    """Load telemetry metrics from ``path`` into a :class:`TelemetrySummary`."""

    metrics_file = _resolve_metrics_file(Path(path))
    snapshot = _read_snapshot_from_file(metrics_file)
    if not isinstance(snapshot, Mapping):
        snapshot = {}
    return TelemetrySummary.from_snapshot(snapshot)


def render_text(summary: TelemetrySummary) -> str:
    """Render ``summary`` into a human-friendly, deterministic text report."""

    lines: list[str] = ["Pipeline"]
    lines.append(f"  Status: {summary.status or 'unknown'}")
    if summary.duration_seconds is not None:
        lines.append(f"  Duration: {summary.duration_seconds:.3f}s")
    if summary.ttfp_seconds is not None:
        lines.append(f"  Time to first confirmed: {summary.ttfp_seconds:.3f}s")
    lines.append(
        f"  Findings: {summary.confirmed_hits}/{summary.hits} confirmed/total"
    )

    def _format_duration(prefix: str, timing: AuthTiming | None) -> None:
        if timing is None:
            return
        totals = timing.totals
        lines.append(
            f"{prefix}: count={totals.count}, avg={totals.avg_ms:.2f}ms, "
            f"max={totals.max_ms:.2f}ms, success={totals.success_rate:.3f}"
        )
        if timing.per_role:
            for role, stats in sorted(timing.per_role.items()):
                lines.append(
                    f"    [{role}] count={stats.count}, avg={stats.avg_ms:.2f}ms, "
                    f"max={stats.max_ms:.2f}ms, success={stats.success_rate:.3f}"
                )

    if summary.auth_switch or summary.auth_refresh or summary.auth_incidents:
        lines.append("Authentication")
        _format_duration("  Switch", summary.auth_switch)
        _format_duration("  Refresh", summary.auth_refresh)
        if summary.auth_incidents:
            incidents = summary.auth_incidents
            lines.append(f"  Incidents: {incidents.count}")
            if incidents.statuses:
                status_pairs = ", ".join(
                    f"{code}:{count}" for code, count in sorted(incidents.statuses.items())
                )
                lines.append(f"    Statuses: {status_pairs}")
            if incidents.reasons:
                reason_pairs = ", ".join(
                    f"{reason}:{count}" for reason, count in sorted(incidents.reasons.items())
                )
                lines.append(f"    Reasons: {reason_pairs}")
            for role, payload in sorted(incidents.per_role.items()):
                lines.append(
                    f"    [{role}] count={payload['count']}, "
                    f"statuses={payload['statuses']}, reasons={payload['reasons']}"
                )

    if summary.websocket:
        ws = summary.websocket
        lines.append("WebSocket")
        totals = ws.totals
        lines.append(
            f"  Round trips: count={totals.count}, avg={totals.avg_ms:.2f}ms, "
            f"max={totals.max_ms:.2f}ms, success={totals.success_rate:.3f}"
        )
        if ws.reasons:
            reason_pairs = ", ".join(
                f"{reason}:{count}" for reason, count in sorted(ws.reasons.items())
            )
            lines.append(f"    Reasons: {reason_pairs}")
        if ws.per_endpoint:
            for endpoint, stats in sorted(ws.per_endpoint.items()):
                lines.append(
                    f"    [{endpoint}] count={stats.count}, avg={stats.avg_ms:.2f}ms, "
                    f"max={stats.max_ms:.2f}ms, success={stats.success_rate:.3f}"
                )
        if ws.per_handshake:
            for name, handshake in sorted(ws.per_handshake.items()):
                stats = handshake.totals
                lines.append(
                    f"    <{name}> count={stats.count}, avg={stats.avg_ms:.2f}ms, "
                    f"max={stats.max_ms:.2f}ms, success={stats.success_rate:.3f}"
                )
                if handshake.reasons:
                    handshake_pairs = ", ".join(
                        f"{reason}:{count}" for reason, count in sorted(handshake.reasons.items())
                    )
                    lines.append(f"      Reasons: {handshake_pairs}")
                if handshake.per_strategy:
                    for strategy, strat_stats in sorted(handshake.per_strategy.items()):
                        lines.append(
                            f"      [{strategy}] count={strat_stats.count}, avg={strat_stats.avg_ms:.2f}ms, "
                            f"max={strat_stats.max_ms:.2f}ms, success={strat_stats.success_rate:.3f}"
                        )

    return "\n".join(lines)
