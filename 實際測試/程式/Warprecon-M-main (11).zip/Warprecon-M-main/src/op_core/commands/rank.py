"""Implementation of the ``rank`` sub-command."""

from __future__ import annotations

import json
from pathlib import Path

from op_core.rank import rank_findings

__all__ = ["run"]


def run(infile: Path, out_path: Path) -> None:
    """Rank findings from ``infile`` and write them to ``out_path``."""

    items = json.loads(infile.read_text(encoding="utf-8"))
    ranked = rank_findings(items)
    out_path.write_text(json.dumps(ranked, ensure_ascii=False, indent=2), encoding="utf-8")
