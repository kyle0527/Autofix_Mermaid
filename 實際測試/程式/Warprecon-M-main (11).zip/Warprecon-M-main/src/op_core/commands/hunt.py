"""Implementation of the ``hunt`` sub-command."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from op_control.campaign import load_campaign
from op_core.runner import run_hunt

__all__ = ["run"]


def _read_targets(path: Path) -> list[str]:
    content = path.read_text(encoding="utf-8")
    return [line.strip() for line in content.splitlines() if line.strip()]


def _serialise(items: Iterable[dict]) -> str:
    return "\n".join(json.dumps(item, ensure_ascii=False) for item in items)


def run(targets_path: Path, cfg_path: Path, out_path: Path) -> None:
    """Execute the adaptive hunt and persist results.

    Parameters
    ----------
    targets_path:
        File containing newline-delimited targets.
    cfg_path:
        Campaign configuration used to build hunt pipeline.
    out_path:
        Destination file that will receive newline-delimited JSON results.
    """

    campaign = load_campaign(cfg_path)
    targets = _read_targets(targets_path)
    items = run_hunt(targets, campaign, None)
    out_path.write_text(_serialise(items), encoding="utf-8")
