"""Implementation of the ``report`` sub-command."""

from __future__ import annotations

import json
from pathlib import Path

from op_output.sarif import to_sarif

__all__ = ["run"]


def run(infile: Path, out_path: Path) -> None:
    """Generate a SARIF report from ``infile`` into ``out_path``."""

    items = json.loads(infile.read_text(encoding="utf-8"))
    out_path.write_text(to_sarif(items), encoding="utf-8")
