from __future__ import annotations

import logging
from importlib import metadata
from typing import Any, Dict, Mapping, Optional, Protocol

logger = logging.getLogger(__name__)


class ProtocolProbe(Protocol):
    async def __call__(
        self,
        target: str,
        cand: Dict[str, Any],
        mint: Any,
        client: Any | None = None,
        retries: int = 0,
    ) -> Optional[Any]:
        """Inspect ``target`` using ``cand`` and return a finding."""


# Global registry mapping protocol name -> probe function
_probe_registry: Dict[str, ProtocolProbe] = {}
_ENTRYPOINTS_LOADED = False


def _entry_points_for(group: str):
    try:
        eps = metadata.entry_points()
    except Exception as exc:  # pragma: no cover - defensive guard
        logger.debug("entry_points() lookup failed: %s", exc)
        return ()

    if hasattr(eps, "select"):
        selected = eps.select(group=group)
    else:  # pragma: no cover - legacy importlib.metadata API
        selected = eps.get(group, []) if isinstance(eps, dict) else []

    return tuple(selected)


def _register_protocol_candidates(obj: Any) -> None:
    mapping_candidates = []
    if isinstance(obj, Mapping):
        mapping_candidates.append(obj)
    else:
        for attr in ("PROTOCOL_PROBES", "protocol_probes"):
            candidate = getattr(obj, attr, None)
            if isinstance(candidate, Mapping):
                mapping_candidates.append(candidate)

        register_fn = getattr(obj, "register_protocols", None)
        if callable(register_fn):
            try:
                maybe_mapping = register_fn(register_protocol)
                if isinstance(maybe_mapping, Mapping):
                    mapping_candidates.append(maybe_mapping)
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "Protocol plugin %s.register_protocols failed: %s",
                    getattr(obj, "__name__", repr(obj)),
                    exc,
                )

    for mapping in mapping_candidates:
        for name, probe in mapping.items():
            if isinstance(name, str) and callable(probe):
                register_protocol(name, probe)


def _load_entrypoint_protocols() -> None:
    global _ENTRYPOINTS_LOADED
    if _ENTRYPOINTS_LOADED:
        return

    for ep in _entry_points_for("warprecon.plugins"):
        try:
            result = ep.load()
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning(
                "Failed to load protocol entry point %s (%s): %s", ep.name, ep.value, exc
            )
            continue

        _register_protocol_candidates(result)

    _ENTRYPOINTS_LOADED = True


def register_protocol(name: str, probe: ProtocolProbe) -> None:
    """Register ``probe`` under ``name`` in the global registry."""
    _probe_registry[name] = probe


def get_protocol(name: str) -> Optional[ProtocolProbe]:
    return _probe_registry.get(name)


def unregister_protocol(name: str) -> None:
    _probe_registry.pop(name, None)


# Register built-in protocol probes -----------------------------------------------------------
try:  # HTTP
    from op_proto.http.engine import http_probe as _http_probe

    async def _http_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        return await _http_probe(target, cand, mint, client, retries=retries)

    register_protocol("http", _http_wrapper)
except Exception:  # pragma: no cover - optional dependency
    pass

try:  # GraphQL
    from op_proto.graphql.engine import graphql_probe as _graphql_probe

    async def _gql_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        return await _graphql_probe(target, cand, mint, retries=retries)

    register_protocol("graphql", _gql_wrapper)
except Exception:  # pragma: no cover
    pass

try:  # WebSocket
    from op_proto.ws.engine import ws_probe as _ws_probe

    async def _ws_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        return await _ws_probe(target, cand, mint, retries=retries)

    register_protocol("ws", _ws_wrapper)
except Exception:  # pragma: no cover
    pass

try:  # gRPC
    from op_proto.grpc.engine import grpc_probe as _grpc_probe

    async def _grpc_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        res = await _grpc_probe(target, cand, mint)
        if isinstance(res, list):
            return res[0] if res else None
        return res

    register_protocol("grpc", _grpc_wrapper)
except Exception:  # pragma: no cover
    pass


_load_entrypoint_protocols()
