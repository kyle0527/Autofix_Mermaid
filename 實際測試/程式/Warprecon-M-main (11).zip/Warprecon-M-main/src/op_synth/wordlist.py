from __future__ import annotations

from pathlib import Path
from typing import Iterable


def save_wordlist(
    directory: Path,
    words: Iterable[str],
    name: str = "wordlist",
) -> str:
    """Save *words* to a file within *directory* and return the file path."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    seen = set()
    ordered = []
    for w in words:
        if w not in seen:
            ordered.append(w)
            seen.add(w)
    path = directory / f"{name}.txt"
    path.write_text("\n".join(ordered), encoding="utf-8")
    return str(path)
