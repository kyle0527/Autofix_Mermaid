from typing import Iterable
from . import idor, oauth

class Check:
    name = "base"
    def run(self, *args, **kwargs) -> Iterable:
        raise NotImplementedError

# registry for simple CLI dispatch
REGISTRY = {
    "idor": idor.IdorCheck,
    "oauth": oauth.OAuthOpenRedirectCheck,
}
