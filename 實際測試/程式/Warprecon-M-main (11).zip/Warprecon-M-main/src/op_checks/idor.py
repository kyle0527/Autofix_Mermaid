from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import httpx

from op_core.finding_contract import Finding
from op_checks.idor_diff import ResponseSnapshot, diff_snapshots, guess_identifier
from op_core.session import CookieError, load_cookies

logger = logging.getLogger(__name__)


@dataclass
class Role:
    name: str
    headers: Dict[str, str]
    cookies: Dict[str, str]
    user_id: Optional[int] = None

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "Role":
        headers = dict(data.get("headers") or {})
        cookies = dict(data.get("cookies") or {})
        uid: Optional[int] = None
        raw_uid = data.get("user_id", headers.get("X-User-ID"))
        if isinstance(raw_uid, str):
            raw_uid = raw_uid.strip()
            if raw_uid.isdigit():
                uid = int(raw_uid)
        elif isinstance(raw_uid, int):
            uid = raw_uid
        name = data.get("name") or f"role_{len(headers)}"
        return Role(name=name, headers=headers, cookies=cookies, user_id=uid)


class SessionManager:
    """Manage authentication material for different roles."""

    def __init__(self, workdir: Optional[Path] = None) -> None:
        self.workdir = workdir or Path(".")
        self.sessions: Dict[str, Dict[str, Any]] = {}
        if workdir is None:
            self.base_cookies: Dict[str, str] = {}
            return
        try:
            self.base_cookies = dict(load_cookies(self.workdir))
        except (OSError, CookieError) as exc:
            logger.warning("Failed to load base cookies from %s: %s", self.workdir, exc)
            self.base_cookies = {}

    def add_session(self, role: str, auth_data: Dict[str, Any]) -> None:
        record = {
            "headers": dict(auth_data.get("headers") or {}),
            "cookies": dict(auth_data.get("cookies") or {}),
            "token": auth_data.get("token"),
            "meta": {
                k: v
                for k, v in auth_data.items()
                if k not in {"headers", "cookies", "token"}
            },
            "created_at": time.time(),
            "auth_data": dict(auth_data),
        }
        self.sessions[role] = record

    def get_session(self, role: str) -> Optional[Dict[str, Any]]:
        return self.sessions.get(role)

    def get_auth_headers(self, role: str) -> Dict[str, str]:
        session = self.get_session(role)
        if not session:
            return {}
        headers = dict(session.get("headers", {}))
        token = session.get("token")
        if token and "authorization" not in {k.lower() for k in headers}:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def get_auth_cookies(self, role: str) -> Dict[str, str]:
        session = self.get_session(role)
        if not session:
            return dict(self.base_cookies)
        cookies = dict(session.get("cookies", {}))
        if not cookies and self.base_cookies:
            cookies.update(self.base_cookies)
        return cookies


class IdVariantGenerator:
    """Generate ID variants based on URL path and query parameters."""

    _NUMERIC = re.compile(r"^\d+$")
    _UUID = re.compile(r"^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$", re.I)
    _TOKEN = re.compile(r"^[A-Za-z0-9]{6,}$")

    def extract_ids_from_url(self, url: str) -> List[Tuple[str, str, Any]]:
        ids: List[Tuple[str, str, Any]] = []
        parsed = urlparse(url)
        segments = [seg for seg in parsed.path.split("/") if seg]
        for idx, segment in enumerate(segments):
            if self._NUMERIC.fullmatch(segment):
                ids.append(("path", str(idx), int(segment)))
            elif self._UUID.fullmatch(segment) or self._TOKEN.fullmatch(segment):
                ids.append(("path", str(idx), segment))
        query_params = parse_qs(parsed.query)
        for key, values in query_params.items():
            for value in values:
                if self._NUMERIC.fullmatch(value):
                    ids.append(("query", key, int(value)))
                elif self._UUID.fullmatch(value) or self._TOKEN.fullmatch(value):
                    ids.append(("query", key, value))
        return ids

    def generate_variants(self, url: str, original_ids: List[Tuple[str, str, Any]]) -> List[str]:
        variants: List[str] = []
        parsed = urlparse(url)
        for location, param, value in original_ids:
            if isinstance(value, int):
                candidate_values = [value + 1, max(1, value - 1), value + 10]
            else:
                candidate_values = [f"{value}1", "admin", "test"]
            for candidate in candidate_values:
                if location == "path":
                    segments = parsed.path.split("/")
                    index = int(param) + (0 if segments and segments[0] else 1)
                    if 0 <= index < len(segments):
                        new_segments = segments[:]
                        new_segments[index] = str(candidate)
                        new_path = "/".join(new_segments)
                        new_url = urlunparse(
                            (
                                parsed.scheme,
                                parsed.netloc,
                                new_path,
                                parsed.params,
                                parsed.query,
                                parsed.fragment,
                            )
                        )
                        variants.append(new_url)
                else:
                    params = parse_qs(parsed.query, keep_blank_values=True)
                    params[param] = [str(candidate)]
                    new_query = urlencode(params, doseq=True)
                    new_url = urlunparse(
                        (
                            parsed.scheme,
                            parsed.netloc,
                            parsed.path,
                            parsed.params,
                            new_query,
                            parsed.fragment,
                        )
                    )
                    variants.append(new_url)
        seen = set()
        ordered: List[str] = []
        for variant in variants:
            if variant not in seen:
                seen.add(variant)
                ordered.append(variant)
        return ordered


class RequestReplay:
    """Replay HTTP requests with different authentication contexts."""

    def __init__(self, session_manager: SessionManager) -> None:
        self.session_manager = session_manager
        # Reusable async clients per role to allow cookie persistence and avoid
        # per-request cookie setting (httpx deprecation warning)
        self._clients: Dict[str, httpx.AsyncClient] = {}
        # Track the session material used to build each cached client so we can
        # rebuild them whenever authentication changes.
        self._client_state: Dict[str, Tuple[Dict[str, str], Dict[str, str]]] = {}

    def reset_clients(self, roles: Optional[Iterable[str]] = None) -> None:
        """Close and remove cached clients.

        When session material changes we want subsequent replays to rebuild
        their AsyncClient with fresh defaults instead of reusing stale header
        or cookie state.
        """

        names = list(roles) if roles is not None else list(self._clients.keys())
        to_close: List[httpx.AsyncClient] = []
        for name in names:
            client = self._clients.pop(name, None)
            if client is not None:
                to_close.append(client)
            self._client_state.pop(name, None)
        for client in to_close:
            if client is None or getattr(client, "is_closed", False):
                continue
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                asyncio.run(client.aclose())
            else:
                loop.create_task(client.aclose())

    async def replay_request(
        self,
        url: str,
        method: str = "GET",
        role: Optional[str] = None,
        timeout: float = 10.0,
    ) -> Optional[Dict[str, Any]]:
        # Prepare headers/cookies from session manager but attach them to a
        # per-role AsyncClient so cookies persist across requests.
        headers: Dict[str, str] = {}
        cookies: Dict[str, str] = {}
        client: Optional[httpx.AsyncClient] = None
        if role:
            headers.update(self.session_manager.get_auth_headers(role))
            cookies.update(self.session_manager.get_auth_cookies(role))

            desired_state = (dict(headers), dict(cookies))
            existing_state = self._client_state.get(role)
            if existing_state is not None and existing_state != desired_state:
                self.reset_clients([role])

            # Reuse or create an AsyncClient for this role
            client = self._clients.get(role)
            if client is None or client.is_closed:
                client = httpx.AsyncClient(
                    follow_redirects=True,
                    headers=headers or None,
                    cookies=cookies or None,
                )
                self._clients[role] = client
                self._client_state[role] = desired_state
        else:
            # create a transient client for anonymous requests
            async with httpx.AsyncClient(follow_redirects=True) as anon_client:
                return await self._execute_replay(
                    anon_client,
                    method=method,
                    url=url,
                    timeout=timeout,
                    role=role,
                    headers=headers,
                    cookies=cookies,
                )

        return await self._execute_replay(
            client,
            method=method,
            url=url,
            timeout=timeout,
            role=role,
            headers=headers,
            cookies=cookies,
        )

    async def _execute_replay(
        self,
        client: httpx.AsyncClient,
        *,
        method: str,
        url: str,
        timeout: float,
        role: Optional[str],
        headers: Dict[str, str],
        cookies: Dict[str, str],
    ) -> Optional[Dict[str, Any]]:
        request_headers = dict(headers)
        request_cookies = dict(cookies)

        logger.debug(
            "Replaying request %s %s role=%s headers=%s cookies=%s using client=%s",
            method,
            url,
            role,
            request_headers,
            request_cookies,
            isinstance(client, httpx.AsyncClient),
        )
        try:
            response = await client.request(
                method=method,
                url=url,
                timeout=timeout,
                headers=request_headers or None,
                cookies=request_cookies or None,
            )
        except Exception as exc:  # pragma: no cover - network issues are reported upstream
            logger.debug("Replay request error %s %s role=%s: %s", method, url, role, exc)
            return {
                "url": url,
                "method": method,
                "role": role,
                "status_code": None,
                "error": str(exc),
            }

        logger.debug(
            "Replay response %s %s -> status=%s len=%s headers=%s",
            method,
            url,
            response.status_code,
            len(response.content),
            dict(response.headers),
        )
        snippet = response.text[:1000]
        return {
            "url": url,
            "method": method,
            "role": role,
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "content_length": len(response.content),
            "content": snippet,
            "request_headers": request_headers,
            # request_cookies is what was configured on the client for this role
            "request_cookies": request_cookies,
        }


class IdorDetector:
    """Utility class used by tests and the check implementation."""

    def __init__(self, workdir: Optional[Path] = None) -> None:
        self.session_manager = SessionManager(workdir)
        self.request_replay = RequestReplay(self.session_manager)
        self.variant_generator = IdVariantGenerator()

    def setup_test_sessions(self, base_url: str) -> None:
        """Populate default sessions for admin, user and anonymous roles."""
        admin_data = self._attempt_login(base_url, "admin", "admin123")
        if not admin_data:
            admin_data = {"headers": {"X-User-Role": "admin"}, "token": "admin-token"}
        self.session_manager.add_session("admin", admin_data)

        user_data = self._attempt_login(base_url, "user1", "user123")
        if not user_data:
            user_data = {"headers": {"X-User-Role": "user"}, "token": "user-token"}
        self.session_manager.add_session("user", user_data)

        self.session_manager.add_session("anonymous", {})

    def _attempt_login(self, base_url: str, username: str, password: str) -> Optional[Dict[str, Any]]:
        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.post(
                    f"{base_url}/login",
                    json={"username": username, "password": password},
                )
                if response.status_code != 200:
                    return None
                data = response.json()
                if not data.get("success"):
                    return None
                return {
                    "headers": {},
                    "cookies": dict(response.cookies),
                    "token": data.get("token"),
                    "user": data.get("user", {}),
                }
        except Exception:  # pragma: no cover - login helpers are best-effort
            return None

    def _ensure_sessions(self, roles: Sequence[Role]) -> None:
        self.request_replay.reset_clients()
        self.session_manager.sessions.clear()
        for role in roles:
            auth_data = {
                "headers": dict(role.headers),
                "cookies": dict(role.cookies),
            }
            if role.user_id is not None:
                auth_data["user_id"] = role.user_id
            self.session_manager.add_session(role.name, auth_data)

    @staticmethod
    def _normalise_fields(response: Mapping[str, Any]) -> Dict[str, Any]:
        headers = {k.lower(): v for k, v in dict(response.get("headers") or {}).items()}
        body = response.get("content") or ""
        fields: Dict[str, Any] = {}

        content_length = response.get("content_length")
        if isinstance(content_length, int):
            fields["content_length"] = content_length

        ctype = str(headers.get("content-type") or "").lower()
        parsed: Any = None
        if body and ("json" in ctype or body.strip().startswith("{")):
            try:
                parsed = json.loads(body)
            except json.JSONDecodeError:
                parsed = None
        if isinstance(parsed, Mapping):
            for key, value in parsed.items():
                if isinstance(value, (str, int, float, bool)) or value is None:
                    fields[str(key)] = value
        elif parsed is not None:
            fields["body"] = parsed
        elif body:
            fields["body"] = body

        return fields

    def _snapshot_response(
        self,
        role: str,
        resource_id: str,
        response: Mapping[str, Any],
    ) -> ResponseSnapshot:
        fields = self._normalise_fields(response)
        identifier = guess_identifier(fields)
        if identifier is None:
            headers = {k.lower(): v for k, v in dict(response.get("headers") or {}).items()}
            etag = headers.get("etag")
            if etag:
                identifier = str(etag)
        status = response.get("status_code")
        if isinstance(status, bool):  # guard against True/False
            status = int(status)
        elif not isinstance(status, int):
            status = None
        return ResponseSnapshot(
            role=role,
            resource_id=resource_id,
            status_code=status,
            identifier=identifier,
            fields=fields,
        )

    async def detect_idor_single_url(
        self,
        url: str,
        method: str = "GET",
        *,
        roles: Optional[Sequence[Role]] = None,
        owner_user_id: Optional[int] = None,
        timeout: float = 10.0,
        expand_variants: bool = False,
        max_variants: int = 50,
    ) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            return findings

        original_ids = self.variant_generator.extract_ids_from_url(url)

        roles_were_provided = bool(roles)
        if roles is None or not roles:
            roles = [
                Role("admin", {"X-User-ID": "1"}, {}),
                Role("user", {"X-User-ID": "2"}, {}),
                Role("anonymous", {}, {}),
            ]
        self._ensure_sessions(roles)

        owner_role = None
        if owner_user_id is not None:
            owner_role = next((r for r in roles if r.user_id == owner_user_id), None)
        # If owner_user_id was provided but no Role had user_id set, try matching via headers
        if owner_role is None and owner_user_id is not None:
            owner_role = next(
                (
                    r
                    for r in roles
                    if str(r.headers.get("X-User-ID") or r.headers.get("x-user-id") or "") == str(owner_user_id)
                ),
                None,
            )

        # Fallback: choose the first role if still not found
        if owner_role is None:
            owner_role = roles[0]

        # If roles were not provided, attempt to populate sensible default sessions
        if not roles_were_provided:
            base_url = f"{parsed.scheme}://{parsed.netloc}"
            try:
                self.setup_test_sessions(base_url)
            except Exception:
                # best-effort; continue without raising
                pass

        owner_resp = await self.request_replay.replay_request(
            url, method, owner_role.name, timeout=timeout
        )
        if not owner_resp:
            logger.debug("Owner request returned no response for %s (role=%s)", url, owner_role.name)
            return findings

        owner_snapshot = self._snapshot_response(owner_role.name, url, owner_resp)
        owner_status = owner_snapshot.status_code
        owner_length = owner_resp.get("content_length", 0) or 0
        logger.debug(
            "IDOR owner response for %s %s: status=%s length=%s error=%s",
            method,
            url,
            owner_status,
            owner_length,
            owner_resp.get("error"),
        )

        for alt in roles:
            if alt.name == owner_role.name:
                continue
            resp = await self.request_replay.replay_request(
                url, method, alt.name, timeout=timeout
            )
            if not resp:
                continue
            alt_snapshot = self._snapshot_response(alt.name, url, resp)
            diff = diff_snapshots(owner_snapshot, alt_snapshot)
            logger.debug(
                "IDOR alt response for %s %s role=%s: status=%s length=%s error=%s",
                method,
                url,
                alt.name,
                alt_snapshot.status_code,
                resp.get("content_length"),
                resp.get("error"),
            )
            alt_status = alt_snapshot.status_code
            if owner_status in (401, 403) and alt_status == 200:
                findings.append(
                    {
                        "type": "idor_reverse_authorization",
                        "severity": "high",
                        "detail": "Non-owner received successful response while owner was denied.",
                        "role": alt.name,
                        "pattern": "reverse_bypass",
                        "url": url,
                        "owner_status": owner_status,
                        "alt_status": alt_status,
                        "diff": diff,
                    }
                )
            elif owner_status == 200 and alt_status == 206:
                findings.append(
                    {
                        "type": "idor_partial_disclosure",
                        "severity": "low",
                        "detail": "Non-owner received partial content while owner had full access.",
                        "role": alt.name,
                        "pattern": "partial_disclosure",
                        "url": url,
                        "owner_status": owner_status,
                        "alt_status": alt_status,
                        "diff": diff,
                    }
                )
            elif owner_status == 200 and alt_status == 200 and original_ids:
                findings.append(
                    {
                        "type": "idor_direct_access",
                        "severity": "medium",
                        "detail": "Non-owner received owner-equivalent response.",
                        "role": alt.name,
                        "pattern": "direct_access",
                        "url": url,
                        "owner_status": owner_status,
                        "alt_status": alt_status,
                        "diff": diff,
                    }
                )
            elif owner_status == 200 and alt_status == 200:
                alt_length = resp.get("content_length", 0) or 0
                if abs(owner_length - alt_length) > 50 or diff["field_differences"]:
                    findings.append(
                        {
                            "type": "idor_content_discrepancy",
                            "severity": "medium",
                            "detail": "Response size differs significantly between owner and non-owner.",
                            "role": alt.name,
                            "pattern": "content_discrepancy",
                            "url": url,
                            "owner_status": owner_status,
                            "alt_status": alt_status,
                            "diff": diff,
                            "owner_length": owner_length,
                            "alt_length": alt_length,
                        }
                    )

        if not expand_variants:
            # Add owner_status into a debug finding when nothing was found so test output
            # contains owner_status for analysis
            if not findings and original_ids:
                # create a no-pattern debug entry with owner_status recorded
                findings.append(
                    {
                        "type": "idor_none",
                        "severity": "info",
                        "detail": "No clear IDOR indicators detected.",
                        "pattern": None,
                        "url": url,
                        "owner_status": owner_status,
                        "owner_request_headers": owner_resp.get("request_headers"),
                        "owner_request_cookies": owner_resp.get("request_cookies"),
                        "owner_response_headers": owner_resp.get("headers"),
                        "owner_response_snippet": owner_resp.get("content"),
                    }
                )
            return findings

        variant_urls = self.variant_generator.generate_variants(url, original_ids)[:max_variants]
        for variant_url in variant_urls:
            owner_variant_resp = await self.request_replay.replay_request(
                variant_url, method, owner_role.name, timeout=timeout
            )
            owner_variant_snapshot = (
                self._snapshot_response(owner_role.name, variant_url, owner_variant_resp)
                if owner_variant_resp
                else None
            )
            owner_variant_status = (
                owner_variant_snapshot.status_code if owner_variant_snapshot else None
            )

            for alt in roles:
                if alt.name == owner_role.name:
                    continue
                resp = await self.request_replay.replay_request(
                    variant_url, method, alt.name, timeout=timeout
                )
                if not resp:
                    continue
                alt_snapshot = self._snapshot_response(alt.name, variant_url, resp)
                if alt_snapshot.status_code not in {200, 206}:
                    continue

                baseline = owner_variant_snapshot or ResponseSnapshot(
                    role=owner_role.name,
                    resource_id=variant_url,
                    status_code=owner_variant_status,
                    identifier=None,
                    fields={},
                )
                diff = diff_snapshots(baseline, alt_snapshot)

                severity = "high" if owner_variant_status in {401, 403} else "medium"
                detail = "Variant identifier accessible by non-owner."
                if alt_snapshot.status_code == 206 and owner_variant_status == 200:
                    severity = "low"
                    detail = "Variant returns partial content to non-owner."

                findings.append(
                    {
                        "type": "idor_variant_access",
                        "severity": severity,
                        "detail": detail,
                        "role": alt.name,
                        "pattern": "variant_access",
                        "url": variant_url,
                        "owner_status": owner_variant_status,
                        "alt_status": alt_snapshot.status_code,
                        "diff": diff,
                    }
                )
        return findings


class IdorCheck:
    name = "idor"

    def __init__(
        self,
        roles: Optional[List[Dict[str, Any]]] = None,
        timeout: float = 6.0,
        expand_variants: bool = False,
        exclude_patterns: Optional[List[str]] = None,
        max_variants: int = 50,
    ) -> None:
        if roles is None:
            roles = [
                {"name": "user1", "headers": {"X-User-ID": "1"}},
                {"name": "user2", "headers": {"X-User-ID": "2"}},
                {"name": "anon", "headers": {}},
            ]
        self.roles: List[Role] = [Role.from_dict(r) for r in roles]
        self.timeout = timeout
        self.expand_variants = expand_variants
        self.exclude_patterns = exclude_patterns or []
        self._exclude_re = [re.compile(pat) for pat in self.exclude_patterns if pat]
        self.max_variants = max_variants
        self.detector = IdorDetector()

    def _is_excluded(self, url: str) -> bool:
        return any(pat.search(url) for pat in self._exclude_re)

    @staticmethod
    def _normalize_api(api: Any) -> Tuple[str, str, Optional[int]]:
        if isinstance(api, str):
            return api, "GET", None
        if isinstance(api, dict):
            url = api.get("url", "")
            method = api.get("method", "GET")
            owner = api.get("owner_user_id")
            if isinstance(owner, str) and owner.isdigit():
                owner = int(owner)
            return url, method.upper(), owner
        return "", "GET", None

    def _prepare_targets(
        self, apis: Optional[Iterable[Any]]
    ) -> List[Tuple[str, str, Optional[int]]]:
        if apis is None:
            return []
        targets: List[Tuple[str, str, Optional[int]]] = []
        for api in apis:
            url, method, owner_id = self._normalize_api(api)
            if not url or self._is_excluded(url):
                continue
            targets.append((url, method, owner_id))
        return targets

    def _detector_for_workdir(self, workdir: Path | str | None) -> IdorDetector:
        if workdir is None:
            return self.detector
        workdir_path = workdir if isinstance(workdir, Path) else Path(workdir)
        return IdorDetector(workdir=workdir_path)

    async def _detect_all(
        self,
        detector: IdorDetector,
        targets: List[Tuple[str, str, Optional[int]]],
    ) -> List[Any]:
        if not targets:
            return []
        coroutines = [
            detector.detect_idor_single_url(
                url,
                method,
                roles=self.roles,
                owner_user_id=owner_id,
                timeout=self.timeout,
                expand_variants=self.expand_variants,
                max_variants=self.max_variants,
            )
            for url, method, owner_id in targets
        ]
        if not coroutines:
            return []
        return await asyncio.gather(*coroutines, return_exceptions=True)

    def _generate_findings(
        self,
        targets: List[Tuple[str, str, Optional[int]]],
        results: List[Any],
    ) -> Iterable[Finding]:
        for idx, (url, method, owner_id) in enumerate(targets):
            base_meta = {"method": method, "owner_user_id": owner_id, "url": url}
            result: Any = results[idx] if idx < len(results) else []
            if isinstance(result, Exception):
                logger.error(
                    "IDOR detection failed for %s %s: %s", method, url, result
                )
                yield Finding(
                    check=self.name,
                    target=url,
                    severity="error",
                    title="IDOR check execution failed",
                    detail=f"Error while executing IDOR detection: {result}",
                    meta=base_meta,
                )
                continue
            if not result:
                yield Finding(
                    check=self.name,
                    target=url,
                    severity="info",
                    title="IDOR check executed",
                    detail="No clear IDOR indicators detected.",
                    meta=base_meta,
                )
                continue
            for item in result:
                severity = item.get("severity", "medium")
                title = item.get("type", "idor_finding")
                detail = item.get("detail", "")
                meta = dict(base_meta)
                meta.update(
                    {
                        k: v
                        for k, v in item.items()
                        if k not in {"severity", "detail", "type"}
                    }
                )
                yield Finding(
                    check=self.name,
                    target=url,
                    severity=severity,
                    title=title,
                    detail=detail or f"{title} detected.",
                    meta=meta,
                )

    def run(
        self,
        apis: Optional[Iterable[Any]] = None,
        workdir: Optional[Path | str] = None,
    ) -> Iterable[Finding]:
        if not apis:
            return []
        targets = self._prepare_targets(apis)
        if not targets:
            return []
        detector = self._detector_for_workdir(workdir)
        try:
            results = asyncio.run(self._detect_all(detector, targets))
        except RuntimeError as exc:
            if "event loop" in str(exc).lower():
                raise RuntimeError(
                    "IdorCheck.run() cannot be used inside an existing event loop; use run_async instead."
                ) from exc
            raise
        return list(self._generate_findings(targets, results))

    async def run_async(
        self,
        apis: Optional[Iterable[Any]] = None,
        workdir: Optional[Path | str] = None,
    ) -> List[Finding]:
        if not apis:
            return []
        targets = self._prepare_targets(apis)
        if not targets:
            return []
        detector = self._detector_for_workdir(workdir)
        results = await self._detect_all(detector, targets)
        return list(self._generate_findings(targets, results))

    # Backwards-compatible alias expected by tests
    async_run = run_async
