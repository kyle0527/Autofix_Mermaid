from __future__ import annotations

import copy
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import httpx

from op_core.finding_contract import Finding

logger = logging.getLogger(__name__)

# Change this to a domain you control when running real checks
EVIL_HOST = "https://example-evil.invalid"

_REDIRECT_KEYWORDS = ("redirect", "return", "continue", "next", "callback")
_REDIRECT_STATUS = {301, 302, 303, 307, 308}


def _ensure_list(values: Any) -> List[str]:
    if isinstance(values, (list, tuple)):
        return [_ensure_str(value) for value in values]
    return [_ensure_str(values)]


def _ensure_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except Exception:  # pragma: no cover - defensive
            return value.decode("latin-1", errors="ignore")
    return str(value)


def _merge_map(target: Dict[str, List[str]], source: Optional[Dict[str, Any]]) -> None:
    if not source:
        return
    for key, value in source.items():
        target[_ensure_str(key)] = _ensure_list(value)


@dataclass
class _OAuthEndpoint:
    name: str
    method: str
    url: str
    headers: Dict[str, str]
    query: Dict[str, List[str]]
    form: Dict[str, List[str]]
    json_body: Dict[str, Any]
    source: Any


@dataclass(frozen=True)
class _ParamCandidate:
    name: str
    location: str  # "query", "form", "json"
    values: List[str]


def _coerce_api_entries(apis: Any) -> List[Any]:
    if apis is None:
        return []
    if isinstance(apis, list):
        return apis
    if isinstance(apis, dict):
        embedded = apis.get("apis")
        if isinstance(embedded, list):
            return embedded
        return [apis]
    return [apis]


def _normalize_headers(raw: Optional[Dict[str, Any]]) -> Dict[str, str]:
    headers: Dict[str, str] = {}
    if not isinstance(raw, dict):
        return headers
    for key, value in raw.items():
        headers[_ensure_str(key)] = _ensure_str(value)
    return headers


def _normalize_entry(entry: Any, index: int) -> Optional[_OAuthEndpoint]:
    if isinstance(entry, str):
        url = entry.strip()
        if not url:
            return None
        parsed = urlparse(url)
        query = {
            k: [_ensure_str(v) for v in vals]
            for k, vals in parse_qs(parsed.query, keep_blank_values=True).items()
        }
        return _OAuthEndpoint(
            name=f"oauth_{index}",
            method="GET",
            url=url,
            headers={},
            query=query,
            form={},
            json_body={},
            source=entry,
        )

    if not isinstance(entry, dict):
        return None

    request_block = entry.get("request") if isinstance(entry.get("request"), dict) else None

    def _extract(key: str, *fallbacks: str) -> Any:
        if request_block and request_block.get(key) not in (None, ""):
            return request_block.get(key)
        for fb in fallbacks:
            val = entry.get(fb)
            if val not in (None, ""):
                return val
        return entry.get(key)

    url = _extract(
        "url",
        "endpoint",
        "authorize_url",
        "authorization_url",
        "href",
    )
    if not url:
        return None
    method = _extract("method", "http_method", "verb") or "GET"
    name = _extract("name", "operationId", "id", "label") or f"oauth_{index}"

    headers = _normalize_headers(entry.get("headers"))
    headers.update(_normalize_headers(request_block.get("headers") if request_block else None))

    query: Dict[str, List[str]] = {}
    parsed = urlparse(_ensure_str(url))
    query.update(
        {
            k: [_ensure_str(v) for v in vals]
            for k, vals in parse_qs(parsed.query, keep_blank_values=True).items()
        }
    )
    _merge_map(query, entry.get("params"))
    _merge_map(query, entry.get("query"))
    if request_block:
        _merge_map(query, request_block.get("params"))
        _merge_map(query, request_block.get("query"))

    form: Dict[str, List[str]] = {}
    _merge_map(form, entry.get("data"))
    _merge_map(form, entry.get("form"))
    _merge_map(form, entry.get("form_params"))
    body = entry.get("body")
    if isinstance(body, dict):
        _merge_map(form, body)
    if request_block:
        _merge_map(form, request_block.get("data"))
        _merge_map(form, request_block.get("form"))
        block_body = request_block.get("body")
        if isinstance(block_body, dict):
            _merge_map(form, block_body)

    json_body: Dict[str, Any] = {}
    if isinstance(entry.get("json"), dict):
        json_body.update(entry.get("json"))
    if request_block and isinstance(request_block.get("json"), dict):
        json_body.update(request_block.get("json"))

    return _OAuthEndpoint(
        name=_ensure_str(name),
        method=_ensure_str(method).upper() or "GET",
        url=_ensure_str(url),
        headers=headers,
        query=query,
        form=form,
        json_body=json_body,
        source=entry,
    )


def _normalize_endpoints(apis: Any) -> List[_OAuthEndpoint]:
    entries = _coerce_api_entries(apis)
    endpoints: List[_OAuthEndpoint] = []
    for index, entry in enumerate(entries):
        normalized = _normalize_entry(entry, index)
        if normalized:
            endpoints.append(normalized)
    return endpoints


def _is_redirect_param(name: str) -> bool:
    lowered = name.lower()
    return any(keyword in lowered for keyword in _REDIRECT_KEYWORDS)


def _find_redirect_params(endpoint: _OAuthEndpoint) -> List[_ParamCandidate]:
    candidates: List[_ParamCandidate] = []
    for key, values in endpoint.query.items():
        if _is_redirect_param(key):
            candidates.append(_ParamCandidate(key, "query", values))
    for key, values in endpoint.form.items():
        if _is_redirect_param(key):
            candidates.append(_ParamCandidate(key, "form", values))
    for key, value in endpoint.json_body.items():
        if not _is_redirect_param(key):
            continue
        if isinstance(value, (list, tuple)):
            values = [_ensure_str(v) for v in value]
        else:
            values = [_ensure_str(value)]
        candidates.append(_ParamCandidate(key, "json", values))
    return candidates


def _build_query_url(url: str, query: Dict[str, List[str]]) -> str:
    parsed = urlparse(url)
    query_pairs = [(key, value) for key, values in query.items() for value in values]
    new_query = urlencode(query_pairs, doseq=True)
    return urlunparse(parsed._replace(query=new_query))


def _prepare_form_payload(data: Dict[str, List[str]]) -> Optional[Dict[str, Any]]:
    if not data:
        return None
    payload: Dict[str, Any] = {}
    for key, values in data.items():
        if not values:
            payload[key] = ""
        elif len(values) == 1:
            payload[key] = values[0]
        else:
            payload[key] = list(values)
    return payload


def _prepare_request_payload(
    endpoint: _OAuthEndpoint,
    candidate: _ParamCandidate,
    evil_host: str,
) -> Tuple[str, Optional[List[Tuple[str, str]]], Optional[Dict[str, Any]]]:
    query = {key: list(values) for key, values in endpoint.query.items()}
    form = {key: list(values) for key, values in endpoint.form.items()}
    json_body = copy.deepcopy(endpoint.json_body)

    if candidate.location == "query":
        query[candidate.name] = [_ensure_str(evil_host)]
    elif candidate.location == "form":
        form[candidate.name] = [_ensure_str(evil_host)]
    else:
        json_body[candidate.name] = _ensure_str(evil_host)

    url = _build_query_url(endpoint.url, query)
    return url, _prepare_form_payload(form), json_body if json_body else None


def _parse_host(value: str) -> Tuple[str, Optional[str]]:
    if not value:
        return "", None
    parsed = urlparse(value if "//" in value else f"//{value}", scheme="https")
    host = (parsed.hostname or "").lower()
    scheme = parsed.scheme.lower() if parsed.scheme else None
    return host, scheme


def _is_open_redirect(location: Optional[str], evil_host: str) -> bool:
    if not location:
        return False
    location = location.strip()
    if not location:
        return False

    evil_host_name, evil_scheme = _parse_host(evil_host)
    if not evil_host_name:
        return False

    parsed = urlparse(location)
    if parsed.hostname:
        return parsed.hostname.lower() == evil_host_name
    if location.startswith("//"):
        derived_host, _ = _parse_host(f"{evil_scheme or 'https'}:{location}")
        return derived_host == evil_host_name
    candidate = location.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    return candidate.lower() == evil_host_name


def _issue_probe(
    client: httpx.Client,
    endpoint: _OAuthEndpoint,
    candidate: _ParamCandidate,
    evil_host: str,
    timeout: float,
) -> Optional[Dict[str, Any]]:
    url, form_data, json_payload = _prepare_request_payload(endpoint, candidate, evil_host)
    request_kwargs: Dict[str, Any] = {
        "method": endpoint.method,
        "url": url,
        "headers": endpoint.headers or None,
        "timeout": timeout,
    }
    if form_data is not None:
        request_kwargs["data"] = form_data
    if json_payload is not None:
        request_kwargs["json"] = json_payload

    try:
        response = client.request(**request_kwargs)
    except httpx.HTTPError as exc:
        logger.debug(
            "OAuth redirect probe against %s failed: %s", endpoint.url, exc
        )
        return None

    location = response.headers.get("Location")
    is_redirect = response.status_code in _REDIRECT_STATUS
    return {
        "response": response,
        "location": location,
        "is_redirect": is_redirect,
        "mutated_url": url,
        "form_data": form_data,
        "json_payload": json_payload,
    }


def _build_finding(
    endpoint: _OAuthEndpoint,
    candidate: _ParamCandidate,
    probe: Dict[str, Any],
    evil_host: str,
) -> Finding:
    response: httpx.Response = probe["response"]
    location = probe.get("location")
    detail = (
        f"Parameter '{candidate.name}' accepted the attacker-controlled redirect URI "
        f"({evil_host}) and the server responded with a redirect to the supplied host."
    )
    meta: Dict[str, Any] = {
        "parameter": candidate.name,
        "location": candidate.location,
        "status_code": response.status_code,
        "redirect_location": location,
        "method": endpoint.method,
        "injected_value": evil_host,
        "original_values": candidate.values,
        "response_headers": dict(response.headers),
        "request": {
            "url": probe.get("mutated_url"),
            "headers": endpoint.headers,
        },
    }
    if probe.get("form_data") is not None:
        meta["request"]["form_data"] = probe["form_data"]
    if probe.get("json_payload") is not None:
        meta["request"]["json_body"] = probe["json_payload"]

    return Finding(
        check="oauth_open_redirect",
        target=endpoint.url,
        severity="high",
        title="OAuth redirect parameter allows arbitrary redirect",
        detail=detail,
        meta=meta,
        ts=time.time(),
    )


class OAuthOpenRedirectCheck:
    name = "oauth"

    def run(self, apis=None, **kwargs) -> Iterable[Finding]:
        endpoints = _normalize_endpoints(apis)
        if not endpoints:
            return []

        evil_host = _ensure_str(
            kwargs.get("payload_host")
            or kwargs.get("attacker_host")
            or EVIL_HOST
        )
        timeout = float(kwargs.get("timeout", 10.0))

        client: Optional[httpx.Client] = kwargs.get("client")
        close_client = False
        if client is None:
            client_kwargs: Dict[str, Any] = {"timeout": timeout, "follow_redirects": False}
            for key in ("verify", "proxies", "transport", "limits", "http2"):
                if key in kwargs:
                    client_kwargs[key] = kwargs[key]
            client = httpx.Client(**client_kwargs)
            close_client = True

        findings: List[Finding] = []
        try:
            for endpoint in endpoints:
                seen: set[Tuple[str, str]] = set()
                for candidate in _find_redirect_params(endpoint):
                    key = (candidate.name, candidate.location)
                    if key in seen:
                        continue
                    seen.add(key)
                    probe = _issue_probe(client, endpoint, candidate, evil_host, timeout)
                    if not probe or not probe.get("is_redirect"):
                        continue
                    if _is_open_redirect(probe.get("location"), evil_host):
                        findings.append(
                            _build_finding(endpoint, candidate, probe, evil_host)
                        )
        finally:
            if close_client and client is not None:
                client.close()

        return findings
