from __future__ import annotations

"""Helpers for diffing responses observed during IDOR checks."""

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Dict, Mapping

_IDENTIFIER_KEYS = ("id", "uuid", "identifier", "resource_id", "slug")


@dataclass(frozen=True)
class ResponseSnapshot:
    """Immutable view of a response used when comparing roles."""

    role: str
    resource_id: str
    status_code: int | None
    identifier: str | None
    fields: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "fields", MappingProxyType(dict(self.fields)))


def guess_identifier(fields: Mapping[str, Any]) -> str | None:
    for key in _IDENTIFIER_KEYS:
        value = fields.get(key)
        if isinstance(value, (str, int)) and value != "":
            return str(value)
    return None


def diff_snapshots(baseline: ResponseSnapshot, candidate: ResponseSnapshot) -> Dict[str, Any]:
    keys = set(baseline.fields) | set(candidate.fields)
    differences = {
        key: (baseline.fields.get(key), candidate.fields.get(key))
        for key in sorted(keys)
        if baseline.fields.get(key) != candidate.fields.get(key)
    }
    return {
        "resource_id": baseline.resource_id,
        "status_changed": baseline.status_code != candidate.status_code,
        "status_codes": (baseline.status_code, candidate.status_code),
        "identifier_changed": baseline.identifier != candidate.identifier,
        "identifier_values": (baseline.identifier, candidate.identifier),
        "field_differences": differences,
    }


__all__ = ["ResponseSnapshot", "guess_identifier", "diff_snapshots"]

