from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from op_checks.idor import IdorCheck

def main() -> None:
    ap = argparse.ArgumentParser(description="IDOR check CLI (MVP)")
    ap.add_argument("--targets", required=True, help="File with URLs (one per line)")
    ap.add_argument("--out", required=True, help="Output JSON file")
    ap.add_argument("--expand-variants", action="store_true", help="Generate numeric ID +/- variants")
    ap.add_argument("--roles", default=None, help="JSON list of role objects (optional)")
    args = ap.parse_args()
    urls = [ln.strip() for ln in Path(args.targets).read_text(encoding="utf-8").splitlines() if ln.strip()]
    roles = None
    if args.roles:
        try:
            roles = json.loads(Path(args.roles).read_text(encoding="utf-8")) if Path(args.roles).exists() else json.loads(args.roles)
        except Exception as e:  # noqa
            print(json.dumps({"error":"invalid roles JSON", "detail": str(e)}, ensure_ascii=False), file=sys.stderr)
            sys.exit(2)
    apis = [{"url": u} for u in urls]
    check = IdorCheck(roles=roles, expand_variants=args.expand_variants)
    findings = [f.__dict__ for f in check.run(apis)]
    Path(args.out).write_text(json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"findings": len(findings), "out": args.out}, ensure_ascii=False))

if __name__ == "__main__":
    main()
