from __future__ import annotations
"""
op_checks.misconfig
Simple HTTP misconfiguration checks:
1) Missing HSTS on HTTPS
2) CORS wildcard "*" with credentials=true
3) TRACE method enabled
4) Loose Content-Security-Policy (none or "unsafe-inline")
5) Old TLS versions accepted on :443
"""
import argparse, json, ssl, socket, http.client, urllib.parse, logging
from pathlib import Path
from typing import List, Dict, Any

def _https_hsts(url: str) -> Dict[str, Any]:
    o = urllib.parse.urlparse(url)
    if o.scheme != "https":
        return {"check": "hsts", "url": url, "result": "skip"}
    con = http.client.HTTPSConnection(o.hostname, o.port or 443, timeout=6, context=ssl._create_unverified_context())
    try:
        con.request("GET", o.path or "/")
        r = con.getresponse()
        h = {k.lower(): v for (k, v) in r.getheaders()}
        return {"check": "hsts", "url": url, "present": ("strict-transport-security" in h), "status": r.status}
    except (OSError, http.client.HTTPException) as e:
        logging.getLogger(__name__).warning("hsts check failed for %s: %s", url, e)
        return {"check": "hsts", "url": url, "error": str(e)}
    finally:
        try:
            con.close()
        except Exception:
            pass

def _cors(url: str) -> Dict[str, Any]:
    o = urllib.parse.urlparse(url)
    con_cls = http.client.HTTPSConnection if o.scheme == "https" else http.client.HTTPConnection
    con = con_cls(o.hostname, o.port or (443 if o.scheme == "https" else 80), timeout=6)
    try:
        headers = {"Origin": "https://evil.example", "Cookie": "a=b"}
        con.request("GET", o.path or "/", headers=headers)
        r = con.getresponse()
        h = {k.lower(): v for (k, v) in r.getheaders()}
        allow_o = h.get("access-control-allow-origin")
        allow_c = h.get("access-control-allow-credentials")
        vul = (allow_o == "*" and (allow_c or "").lower() == "true")
        return {
            "check": "cors",
            "url": url,
            "wildcard_and_credentials": vul,
            "status": r.status,
            "headers": {"origin": allow_o, "credentials": allow_c},
        }
    except (OSError, http.client.HTTPException) as e:
        logging.getLogger(__name__).warning("cors check failed for %s: %s", url, e)
        return {"check": "cors", "url": url, "error": str(e)}
    finally:
        try:
            con.close()
        except Exception:
            pass

def _trace(url: str) -> Dict[str, Any]:
    o = urllib.parse.urlparse(url)
    con_cls = http.client.HTTPSConnection if o.scheme == "https" else http.client.HTTPConnection
    con = con_cls(o.hostname, o.port or (443 if o.scheme == "https" else 80), timeout=6)
    try:
        con._http_vsn = 11
        con._http_vsn_str = "HTTP/1.1"
        con.putrequest("TRACE", o.path or "/")
        con.endheaders()
        r = con.getresponse()
        return {"check": "trace", "url": url, "enabled": r.status < 405, "status": r.status}
    except (OSError, http.client.HTTPException) as e:
        logging.getLogger(__name__).warning("trace check failed for %s: %s", url, e)
        return {"check": "trace", "url": url, "error": str(e)}
    finally:
        try:
            con.close()
        except Exception:
            pass

def _csp(url: str) -> Dict[str, Any]:
    o = urllib.parse.urlparse(url)
    con_cls = http.client.HTTPSConnection if o.scheme == "https" else http.client.HTTPConnection
    con = con_cls(o.hostname, o.port or (443 if o.scheme == "https" else 80), timeout=6)
    try:
        con.request("GET", o.path or "/")
        r = con.getresponse()
        h = {k.lower(): v for (k, v) in r.getheaders()}
        csp = h.get("content-security-policy", "").lower()
        loose = (not csp) or ("unsafe-inline" in csp)
        return {"check": "csp", "url": url, "loose": loose, "status": r.status, "csp": csp[:200]}
    except (OSError, http.client.HTTPException) as e:
        logging.getLogger(__name__).warning("csp check failed for %s: %s", url, e)
        return {"check": "csp", "url": url, "error": str(e)}
    finally:
        try:
            con.close()
        except Exception:
            pass

def _tls_old(host: str, port: int=443) -> Dict[str, Any]:
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.minimum_version = ssl.TLSVersion.TLSv1
        ctx.maximum_version = ssl.TLSVersion.TLSv1
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=3.0) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                ver = ssock.version()
                return {"check":"tlsv1","host":host,"port":port,"accepted": True, "version": ver}
    except Exception as e:
        return {"check":"tlsv1","host":host,"port":port,"accepted": False, "error": str(e)}

def run_checks(urls: List[str]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for u in urls[:5000]:  # safety bound
        out.append(_https_hsts(u))
        out.append(_cors(u))
        out.append(_trace(u))
        out.append(_csp(u))
        # TLS old probe against host only
        o = urllib.parse.urlparse(u)
        if o.scheme == "https" and o.hostname:
            out.append(_tls_old(o.hostname, o.port or 443))
    return out

def _cli() -> None:
    ap = argparse.ArgumentParser(description="HTTP misconfiguration checks")
    ap.add_argument("--targets", required=True, help="targets.txt (one URL per line)")
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()
    urls = [ln.strip() for ln in Path(args.targets).read_text(encoding="utf-8").splitlines() if ln.strip()]
    res = run_checks(urls)
    outp = Path(args.workdir)/"findings.misconfig.json"
    outp.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"findings": len(res), "out": str(outp)}, ensure_ascii=False))

if __name__ == "__main__":
    _cli()
