from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
try:
    from pydantic import BaseModel
except Exception:  # pragma: no cover - fallback for test environments without pydantic
    # Minimal fallback so tests that only import this module don't fail.
    class BaseModel:  # type: ignore
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


class Limits(BaseModel):
    global_rps: int = 30
    per_host_rps: int = 6
    jitter_ms: int = 120
    max_concurrency: int = 8
    per_target_payloads: int = 8
    retries: int = 1
    max_depth: int = 2
    http_timeout: float = 10.0
    http_proxy: Optional[str] = None
    graphql_budget: int = 4
    graphql_max_depth: int = 3
    sqlmap_timeout: int = 120
    xsstrike_timeout: int = 120


class BanditCfg(BaseModel):
    algo: str = "linucb"
    arms: List[Dict[str, Any]] = []


class OOBCfg(BaseModel):
    provider: str = "interactsh"
    base_url: Optional[str] = None
    api_key: Optional[str] = None


class SynthCfg(BaseModel):
    transforms: List[str] = [
        "identity",
        "double_encode",
        "quote_flip",
        "split_keywords",
        "gql_variants",
    ]


class OutputCfg(BaseModel):
    poc_top: int = 5
    capture: bool = False
    history_ttl_days: int = 30


class IdorCfg(BaseModel):
    enabled: bool = True
    max_variants_per_id: int = 10
    test_roles: List[str] = ["admin", "user", "anonymous"]
    session_config: Dict[str, Dict[str, Any]] = {}


class AccountsCfg(BaseModel):
    sources: List[str] = []
    default_profile: Optional[str] = None
    prefer_roles: List[str] = []
    inline_profiles: Dict[str, Any] = {}


class IastCfg(BaseModel):
    enabled: bool = False
    transport: str = "embedded"
    endpoint: Optional[str] = None
    api_key: Optional[str] = None
    artifact_dir: Optional[str] = None
    buffer_path: Optional[str] = None
    startup_timeout: float = 5.0
    environment: Dict[str, Any] = {}


class LogicWorkflowCfg(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    enabled: bool = True
    path: Optional[str] = None
    manifest: Dict[str, Any] = {}
    variables: Dict[str, Any] = {}
    check: Optional[str] = None
    severity: Optional[str] = None


class LogicCfg(BaseModel):
    enabled: bool = False
    base_url: Optional[str] = None
    context: Dict[str, Any] = {}
    max_steps: int = 20
    workflows: List[LogicWorkflowCfg] = []


class PrecisionWeightsCfg(BaseModel):
    oob_hit: float = 1.0
    severity: Dict[str, float] = {}
    penalties: Dict[str, float] = {}


class PrecisionBaselineCfg(BaseModel):
    history_path: Optional[str] = None
    sync: bool = True


class PrecisionGateCfg(BaseModel):
    mode: str = "threshold"
    threshold: float = 0.0
    top_n: int = 25
    prefer_confirmed: bool = True
    min_score: float = 0.0


class PrecisionCfg(BaseModel):
    weights: PrecisionWeightsCfg = PrecisionWeightsCfg()
    baseline: PrecisionBaselineCfg = PrecisionBaselineCfg()
    ignore: List[Dict[str, Any]] = []
    gate: PrecisionGateCfg = PrecisionGateCfg()


class DeployCfg(BaseModel):
    profile: str = "default"
    compose_file: Optional[str] = None
    install_script: Optional[str] = None
    qa_checks: List[str] = []


class Campaign(BaseModel):
    allow: List[str] = []
    deny: List[str] = []
    limits: Limits = Limits()
    bandit: BanditCfg = BanditCfg()
    oob: OOBCfg = OOBCfg()
    synth: SynthCfg = SynthCfg()
    output: OutputCfg = OutputCfg()
    idor: IdorCfg = IdorCfg()
    accounts: AccountsCfg = AccountsCfg()
    iast: IastCfg = IastCfg()
    logic: LogicCfg = LogicCfg()
    precision: PrecisionCfg = PrecisionCfg()
    deploy: DeployCfg = DeployCfg()


def _merge_dict(base: Dict[str, Any], overrides: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(base)
    for key, value in (overrides or {}).items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge_dict(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_campaign(p: Path) -> Campaign:
    """Load a campaign configuration from *p*.

    The configuration file is optional; when absent or partially populated,
    default :class:`Campaign` values are used. Environment overrides declared
    through :class:`op_control.settings.Settings` are merged on top of the YAML
    content and take precedence.
    """

    from .settings import Settings

    data: Dict[str, Any] = {}
    if Path(p).exists():
        data = yaml.safe_load(Path(p).read_text(encoding="utf-8")) or {}

    env_overrides = Settings().to_campaign_overrides()
    if env_overrides:
        data = _merge_dict(data, env_overrides)

    return Campaign(
        allow=data.get("scopes", {}).get("allow", []),
        deny=data.get("scopes", {}).get("deny", []),
        limits=Limits(**(data.get("limits") or {})),
        bandit=BanditCfg(**(data.get("bandit") or {})),
        oob=OOBCfg(**(data.get("oob") or {})),
        synth=SynthCfg(**(data.get("synth") or {})),
        output=OutputCfg(**(data.get("output") or {})),
        idor=IdorCfg(**(data.get("idor") or {})),
        accounts=AccountsCfg(**(data.get("accounts") or {})),
        iast=IastCfg(**(data.get("iast") or {})),
        logic=LogicCfg(**(data.get("logic") or {})),
        precision=PrecisionCfg(**(data.get("precision") or {})),
        deploy=DeployCfg(**(data.get("deploy") or {})),
    )

