"""Runtime configuration loaded from environment variables.

This module exposes a :class:`Settings` object that builds on
``pydantic.BaseSettings`` so that values can be provided via a ``.env`` file
or the process environment.  The resulting structure mirrors the campaign
YAML schema and can be merged into the parsed configuration to override
selected fields (for example the global RPS limits or OOB API keys).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

try:  # pragma: no cover - exercised in environments with pydantic installed
    from pydantic import BaseModel, Field
    from pydantic_settings import BaseSettings, SettingsConfigDict
except Exception:  # pragma: no cover - fallback for test environments

    class BaseModel:  # type: ignore[override]
        """Minimal stand-in used when pydantic is unavailable."""

        def __init__(self, **kwargs: Any) -> None:
            for key, value in kwargs.items():
                setattr(self, key, value)

        def model_dump(self, **_: Any) -> Dict[str, Any]:
            return dict(self.__dict__)

    def Field(*, default: Any = None, default_factory: Any | None = None):  # type: ignore[override]
        if default_factory is not None:
            return default_factory()
        return default

    class BaseSettings(BaseModel):  # type: ignore[override]
        model_config: Dict[str, Any] = {}

    def SettingsConfigDict(**_: Any) -> Dict[str, Any]:  # type: ignore[override]
        return {}


class ScopesSettings(BaseModel):
    allow: Optional[List[str]] = None
    deny: Optional[List[str]] = None


class LimitsSettings(BaseModel):
    global_rps: Optional[int] = None
    per_host_rps: Optional[int] = None
    jitter_ms: Optional[int] = None
    max_concurrency: Optional[int] = None
    per_target_payloads: Optional[int] = None
    retries: Optional[int] = None
    max_depth: Optional[int] = None
    graphql_budget: Optional[int] = None
    graphql_max_depth: Optional[int] = None


class BanditSettings(BaseModel):
    algo: Optional[str] = None
    arms: Optional[List[Dict[str, Any]]] = None


class OOBSettings(BaseModel):
    provider: Optional[str] = None
    base_url: Optional[str] = None
    api_key: Optional[str] = None


class SynthSettings(BaseModel):
    transforms: Optional[List[str]] = None


class OutputSettings(BaseModel):
    poc_top: Optional[int] = None
    capture: Optional[bool] = None
    history_ttl_days: Optional[int] = None


class IdorSettings(BaseModel):
    enabled: Optional[bool] = None
    max_variants_per_id: Optional[int] = None
    test_roles: Optional[List[str]] = None
    session_config: Optional[Dict[str, Dict[str, Any]]] = None


class AccountsSettings(BaseModel):
    sources: Optional[List[str]] = None
    default_profile: Optional[str] = None
    prefer_roles: Optional[List[str]] = None
    inline_profiles: Optional[Dict[str, Any]] = None


class IastSettings(BaseModel):
    enabled: Optional[bool] = None
    transport: Optional[str] = None
    endpoint: Optional[str] = None
    api_key: Optional[str] = None
    artifact_dir: Optional[str] = None
    buffer_path: Optional[str] = None
    startup_timeout: Optional[float] = None
    environment: Optional[Dict[str, Any]] = None


class LogicSettings(BaseModel):
    enabled: Optional[bool] = None
    base_url: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    max_steps: Optional[int] = None
    workflows: Optional[List[Dict[str, Any]]] = None


class PrecisionWeightsSettings(BaseModel):
    oob_hit: Optional[float] = None
    severity: Optional[Dict[str, float]] = None
    penalties: Optional[Dict[str, float]] = None


class PrecisionBaselineSettings(BaseModel):
    history_path: Optional[str] = None
    sync: Optional[bool] = None


class PrecisionGateSettings(BaseModel):
    mode: Optional[str] = None
    threshold: Optional[float] = None
    top_n: Optional[int] = None
    prefer_confirmed: Optional[bool] = None
    min_score: Optional[float] = None


class PrecisionSettings(BaseModel):
    weights: Optional[PrecisionWeightsSettings] = None
    baseline: Optional[PrecisionBaselineSettings] = None
    ignore: Optional[List[Dict[str, Any]]] = None
    gate: Optional[PrecisionGateSettings] = None


class DeploySettings(BaseModel):
    profile: Optional[str] = None
    compose_file: Optional[str] = None
    install_script: Optional[str] = None
    qa_checks: Optional[List[str]] = None


class Settings(BaseSettings):
    """Environment driven overrides for campaign configuration."""

    model_config = SettingsConfigDict(
        env_prefix="OP_",
        env_file=".env",
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    scopes: ScopesSettings = Field(default_factory=ScopesSettings)
    limits: LimitsSettings = Field(default_factory=LimitsSettings)
    bandit: BanditSettings = Field(default_factory=BanditSettings)
    oob: OOBSettings = Field(default_factory=OOBSettings)
    synth: SynthSettings = Field(default_factory=SynthSettings)
    output: OutputSettings = Field(default_factory=OutputSettings)
    idor: IdorSettings = Field(default_factory=IdorSettings)
    accounts: AccountsSettings = Field(default_factory=AccountsSettings)
    iast: IastSettings = Field(default_factory=IastSettings)
    logic: LogicSettings = Field(default_factory=LogicSettings)
    precision: PrecisionSettings = Field(default_factory=PrecisionSettings)
    deploy: DeploySettings = Field(default_factory=DeploySettings)

    def to_campaign_overrides(self) -> Dict[str, Any]:
        """Return a nested dictionary with unset values removed."""

        data = self.model_dump(mode="python", exclude_none=True)
        return _prune_empty(data)


def _prune_empty(data: Dict[str, Any]) -> Dict[str, Any]:
    """Remove empty dictionaries from *data* recursively."""

    pruned: Dict[str, Any] = {}
    for key, value in data.items():
        if isinstance(value, dict):
            nested = _prune_empty(value)
            if nested:
                pruned[key] = nested
        else:
            pruned[key] = value
    return pruned

