from __future__ import annotations
from pathlib import Path
from typing import Any, Dict
import yaml

def _deep_merge(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(a)
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def merge_to_file(base_path: Path, overlay_path: Path, out_path: Path) -> Path:
    a = yaml.safe_load(base_path.read_text(encoding="utf-8")) or {}
    b = yaml.safe_load(overlay_path.read_text(encoding="utf-8")) or {}
    out = _deep_merge(a, b)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(yaml.safe_dump(out, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return out_path
