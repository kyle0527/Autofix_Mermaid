"""WebSocket probing engine supporting handshake matrices and GraphQL flows."""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import random
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from urllib.parse import urlparse

import websockets
from websockets.exceptions import ConnectionClosed, InvalidHandshake, InvalidStatus

from op_core.telemetry import Telemetry

if TYPE_CHECKING:  # pragma: no cover - type hint only
    from websockets.legacy.client import WebSocketClientProtocol
else:  # pragma: no cover - runtime fallback for type checking
    WebSocketClientProtocol = Any  # type: ignore[misc,assignment]

try:
    _CONNECT_HEADER_PARAM = (
        "additional_headers"
        if "additional_headers" in inspect.signature(websockets.connect).parameters
        else "extra_headers"
    )
except (ValueError, TypeError):  # pragma: no cover - fallback for unusual environments
    _CONNECT_HEADER_PARAM = "extra_headers"

Message = str | bytes


@dataclass(frozen=True)
class HandshakeProfile:
    """Parameters describing a WebSocket handshake attempt."""

    name: str
    subprotocols: Tuple[str, ...] = ()
    compression: Optional[str] = None
    ping_interval: float = 20.0
    ping_timeout: float = 20.0
    heartbeat: bool = False
    graphql_protocol: Optional[str] = None  # ``graphql-ws`` or ``graphql-transport-ws``

    def connect_kwargs(self) -> Dict[str, Any]:
        kwargs: Dict[str, Any] = {
            "ping_interval": self.ping_interval,
            "ping_timeout": self.ping_timeout,
        }
        if self.subprotocols:
            kwargs["subprotocols"] = list(self.subprotocols)
        if self.compression is not None:
            kwargs["compression"] = self.compression
        return kwargs


@dataclass(frozen=True)
class PayloadStrategy:
    """Strategy producing payload messages for a probe exchange."""

    name: str
    generator: Any

    def build(
        self, target: str, candidate: Dict[str, Any], token: str, profile: HandshakeProfile
    ) -> Sequence[Message]:
        return self.generator(target, candidate, token, profile)


_HANDSHAKES: Tuple[HandshakeProfile, ...] = (
    HandshakeProfile(name="vanilla"),
    HandshakeProfile(name="heartbeat", heartbeat=True, ping_interval=10.0, ping_timeout=10.0),
    HandshakeProfile(name="permessage-deflate", compression="deflate"),
    HandshakeProfile(
        name="graphql-transport-ws",
        subprotocols=("graphql-transport-ws",),
        heartbeat=True,
        ping_interval=12.0,
        ping_timeout=12.0,
        graphql_protocol="graphql-transport-ws",
    ),
    HandshakeProfile(
        name="graphql-ws",
        subprotocols=("graphql-ws",),
        heartbeat=True,
        ping_interval=12.0,
        ping_timeout=12.0,
        graphql_protocol="graphql-ws",
    ),
    HandshakeProfile(
        name="stomp",
        subprotocols=("v12.stomp", "v11.stomp", "v10.stomp"),
        heartbeat=True,
        ping_interval=10.0,
        ping_timeout=10.0,
    ),
    HandshakeProfile(
        name="socketio",
        heartbeat=True,
        ping_interval=25.0,
        ping_timeout=10.0,
    ),
)


def _looks_like_graphql(target: str, candidate: Dict[str, Any]) -> bool:
    payload = candidate.get("payload")
    if isinstance(payload, str) and any(word in payload.lower() for word in ("subscription", "query", "mutation")):
        return True
    return "graphql" in target.lower()


def _candidate_subprotocols(candidate: Mapping[str, Any]) -> Tuple[str, ...]:
    raw = candidate.get("subprotocols") or candidate.get("ws_subprotocols")
    if raw is None:
        return ()
    values: Iterable[str]
    if isinstance(raw, (list, tuple, set)):
        values = [str(item) for item in raw if isinstance(item, str) and item.strip()]
    elif isinstance(raw, str):
        values = [part.strip() for part in raw.split(",") if part.strip()]
    else:
        return ()
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        normalised = value.strip()
        if not normalised or normalised.lower() in seen:
            continue
        seen.add(normalised.lower())
        result.append(normalised)
    return tuple(result)


def _protocol_hints(target: str, candidate: Mapping[str, Any]) -> List[str]:
    hints: List[str] = []
    haystack = [target]
    for key in ("mode", "protocol", "transport"):
        value = candidate.get(key)
        if isinstance(value, str):
            haystack.append(value)
    payload = candidate.get("payload")
    if isinstance(payload, str):
        haystack.append(payload)
    text = " ".join(item.lower() for item in haystack if isinstance(item, str))
    if "socket.io" in text or "socketio" in text:
        hints.append("socketio")
    if "stomp" in text:
        hints.append("stomp")
    if isinstance(candidate.get("socketio_event"), str):
        hints.append("socketio")
    return hints


def _select_handshakes(target: str, candidate: Dict[str, Any]) -> Sequence[HandshakeProfile]:
    base: List[HandshakeProfile] = list(_HANDSHAKES)

    if _looks_like_graphql(target, candidate):
        graphql = [p for p in base if p.graphql_protocol]
        others = [p for p in base if not p.graphql_protocol]
        base = graphql + others

    hints = _protocol_hints(target, candidate)
    if hints:
        ordering: List[HandshakeProfile] = []
        for hint in hints:
            for profile in base:
                if profile.name == hint and profile not in ordering:
                    ordering.append(profile)
        base = ordering + [p for p in base if p not in ordering]

    subprotocols = _candidate_subprotocols(candidate)
    if subprotocols:
        for value in subprotocols:
            base.insert(0, HandshakeProfile(name=f"subprotocol:{value}", subprotocols=(value,)))

    seen: set[tuple[str, Tuple[str, ...]]] = set()
    unique: List[HandshakeProfile] = []
    for profile in base:
        key = (profile.name, profile.subprotocols)
        if key in seen:
            continue
        seen.add(key)
        unique.append(profile)
    return unique


def _collect_extra_headers(candidate: Dict[str, Any]) -> List[Tuple[str, str]]:
    extras: Dict[str, str] = {}
    for key in ("ws_headers", "headers"):
        raw = candidate.get(key)
        if not isinstance(raw, dict):
            continue
        for header, value in raw.items():
            if not isinstance(header, str) or value is None:
                continue
            extras[header] = str(value)
    return list(extras.items())


def _extract_header_values(headers: Any, key: str) -> List[str]:
    if headers is None:
        return []
    try:
        getter = getattr(headers, "get_all")
        if callable(getter):
            values = getter(key)
            if isinstance(values, list):
                return [str(v) for v in values if v]
    except Exception:  # pragma: no cover - defensive fallback
        pass
    try:
        if isinstance(headers, Mapping):
            value = headers.get(key)
            if value is None:
                return []
            if isinstance(value, (list, tuple)):
                return [str(v) for v in value if v]
            return [str(value)]
    except Exception:  # pragma: no cover - defensive fallback
        return []
    return []


def _subprotocol_hints_from_headers(headers: Any) -> Tuple[str, ...]:
    values = _extract_header_values(headers, "Sec-WebSocket-Protocol")
    protocols: list[str] = []
    for value in values:
        for part in value.split(","):
            token = part.strip()
            if not token:
                continue
            if token not in protocols:
                protocols.append(token)
    return tuple(protocols)


def _extend_profiles_with_protocols(
    profiles: List[HandshakeProfile], discovered: set[str], protocols: Iterable[str]
) -> None:
    for proto in protocols:
        if not proto:
            continue
        key = proto.strip()
        lower = key.lower()
        if lower in discovered:
            continue
        discovered.add(lower)
        profiles.append(HandshakeProfile(name=f"subprotocol:{key}", subprotocols=(key,)))


def _build_connection_init_message(candidate: Dict[str, Any], token: str) -> Dict[str, Any]:
    message_payload: Dict[str, Any] = {}
    raw_init = candidate.get("connection_init")
    if isinstance(raw_init, dict):
        payload_section = raw_init.get("payload")
        if isinstance(payload_section, dict):
            message_payload.update({k: v for k, v in payload_section.items() if v is not None})
        else:
            message_payload.update({k: v for k, v in raw_init.items() if k != "type" and v is not None})
    custom_payload = candidate.get("init_payload")
    if isinstance(custom_payload, dict):
        for key, value in custom_payload.items():
            if value is None or not isinstance(key, str):
                continue
            message_payload[key] = value
    if "token" not in message_payload:
        message_payload["token"] = token
    return {"type": "connection_init", "payload": message_payload}


def _candidate_payload(target: str, candidate: Dict[str, Any], token: str, profile: HandshakeProfile) -> Sequence[Message]:
    if profile.graphql_protocol:
        return ()
    payload = candidate.get("payload")
    if payload is None:
        return ()
    if isinstance(payload, (bytes, bytearray)):
        return [bytes(payload)]
    return [str(payload)]


def _json_probe_payload(target: str, candidate: Dict[str, Any], token: str, profile: HandshakeProfile) -> Sequence[Message]:
    if profile.graphql_protocol:
        return ()
    envelope = {
        "action": candidate.get("mode", "probe"),
        "token": token,
        "meta": {
            "target": target,
            "transform": candidate.get("transform"),
            "ts": time.time(),
        },
    }
    return [json.dumps(envelope)]


def _binary_probe_payload(target: str, candidate: Dict[str, Any], token: str, profile: HandshakeProfile) -> Sequence[Message]:
    if profile.graphql_protocol:
        return ()
    marker = f"{candidate.get('mode', 'probe')}::{token}".encode("utf-8")
    return [marker]


_PAYLOAD_STRATEGIES: Tuple[PayloadStrategy, ...] = (
    PayloadStrategy("candidate", _candidate_payload),
    PayloadStrategy("json-probe", _json_probe_payload),
    PayloadStrategy("binary-probe", _binary_probe_payload),
)


def _stomp_frame(command: str, headers: Mapping[str, str], body: str | None = None) -> str:
    lines = [command]
    for key, value in headers.items():
        lines.append(f"{key}:{value}")
    lines.append("")
    if body is not None:
        lines.append(body)
    return "\n".join(lines) + "\x00"


def _safe_json_loads(payload: str) -> Any:
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return payload


async def _send_message(ws: WebSocketClientProtocol, message: Message) -> None:
    if isinstance(message, (bytes, bytearray)):
        await ws.send(bytes(message))
    else:
        await ws.send(str(message))


async def _wait_for_message(ws: WebSocketClientProtocol, timeout: float = 5.0) -> Optional[Message]:
    try:
        return await asyncio.wait_for(ws.recv(), timeout=timeout)
    except asyncio.TimeoutError:
        return None
    except ConnectionClosed:
        return None


def _ensure_text(message: Message) -> str:
    if isinstance(message, bytes):
        return message.decode("utf-8", errors="replace")
    return str(message)


async def _wait_for_nonempty_text(
    ws: WebSocketClientProtocol,
    *,
    timeout: float = 5.0,
    max_heartbeats: int = 4,
) -> Optional[str]:
    started = time.perf_counter()
    heartbeats = 0
    while True:
        remaining = timeout - (time.perf_counter() - started)
        if remaining <= 0:
            return None
        message = await _wait_for_message(ws, timeout=remaining)
        if message is None:
            return None
        text = _ensure_text(message)
        if text.strip("\n\r\x00 "):
            return text
        heartbeats += 1
        if heartbeats >= max_heartbeats:
            return None


def _format_snippet(message: Message) -> str:
    if isinstance(message, bytes):
        return base64.b64encode(message[:120]).decode("ascii")
    return str(message)[:200]


def _build_finding(
    target: str,
    candidate: Dict[str, Any],
    profile: HandshakeProfile,
    strategy: str,
    sent: Message,
    received: Message,
    elapsed: float,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    evidence = {
        "snippet": _format_snippet(received),
        "handshake": profile.name,
        "strategy": strategy,
        "latency": round(elapsed, 3),
    }
    if profile.subprotocols:
        evidence["subprotocol"] = profile.subprotocols[0]
    if isinstance(received, bytes):
        evidence["response_type"] = "binary"
    else:
        evidence["response_type"] = "text"
    if extra:
        evidence.update(extra)
    payload_value: Any
    if isinstance(sent, bytes):
        payload_value = sent.decode("utf-8", errors="replace")
    else:
        payload_value = sent
    return {
        "target": target,
        "vector": {"protocol": "ws", "location": candidate.get("location", "message"), "param": candidate.get("param")},
        "payload": payload_value,
        "tool": "warprecon-m-ws",
        "evidence": evidence,
        "severity": "medium",
        "url": target,
    }


async def _run_payload_strategies(
    ws: WebSocketClientProtocol,
    target: str,
    candidate: Dict[str, Any],
    profile: HandshakeProfile,
    token: str,
) -> Optional[Dict[str, Any]]:
    for strategy in _PAYLOAD_STRATEGIES:
        messages = strategy.build(target, candidate, token, profile)
        for message in messages:
            await _send_message(ws, message)
            received = await _wait_for_message(ws)
            if received is None:
                continue
            return {
                "strategy": strategy.name,
                "sent": message,
                "received": received,
            }
    return None


def _build_graphql_subscription_payload(
    profile: HandshakeProfile, candidate: Dict[str, Any], token: str
) -> Tuple[str, Dict[str, Any]]:
    raw = candidate.get("payload")
    query = raw if isinstance(raw, str) and raw.strip() else "subscription{__typename}"
    variables = candidate.get("variables") if isinstance(candidate.get("variables"), dict) else {}
    variables.setdefault("probeToken", token)
    op_id = candidate.get("operation_id") or token.replace("-", "")
    if profile.graphql_protocol == "graphql-transport-ws":
        message = {
            "id": op_id,
            "type": "subscribe",
            "payload": {"query": query, "variables": variables},
        }
    else:
        message = {
            "id": op_id,
            "type": "start",
            "payload": {"query": query, "variables": variables},
        }
    return op_id, message


async def _await_graphql_message(ws: WebSocketClientProtocol, timeout: float = 5.0) -> Optional[Dict[str, Any]]:
    while True:
        raw = await _wait_for_message(ws, timeout=timeout)
        if raw is None:
            return None
        if isinstance(raw, bytes):
            try:
                raw = raw.decode("utf-8")
            except UnicodeDecodeError:
                return None
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return None
        msg_type = parsed.get("type")
        if msg_type == "ping":
            await _send_message(ws, json.dumps({"type": "pong"}))
            continue
        return parsed


async def _run_graphql_subscription(
    ws: WebSocketClientProtocol,
    target: str,
    candidate: Dict[str, Any],
    profile: HandshakeProfile,
    token: str,
) -> Optional[Dict[str, Any]]:
    init_message = _build_connection_init_message(candidate, token)
    await _send_message(ws, json.dumps(init_message))
    ack = await _await_graphql_message(ws, timeout=6.0)
    if not ack or ack.get("type") != "connection_ack":
        return None
    op_id, subscribe = _build_graphql_subscription_payload(profile, candidate, token)
    await _send_message(ws, json.dumps(subscribe))
    while True:
        message = await _await_graphql_message(ws, timeout=6.0)
        if message is None:
            return None
        msg_type = message.get("type")
        if msg_type in {"next", "data"}:
            payload = message.get("payload", {})
            snippet = json.dumps(payload)[:200]
            extra = {
                "graphql": {
                    "ack": ack,
                    "message_type": msg_type,
                    "operation_id": op_id,
                },
                "snippet": snippet,
            }
            return {
                "strategy": "graphql-subscription",
                "sent": json.dumps(subscribe),
                "received": json.dumps(message),
                "extra": extra,
            }
        if msg_type in {"complete", "error"}:
            extra = {
                "graphql": {
                    "ack": ack,
                    "message_type": msg_type,
                    "operation_id": op_id,
                }
            }
            return {
                "strategy": "graphql-subscription",
                "sent": json.dumps(subscribe),
                "received": json.dumps(message),
                "extra": extra,
            }


async def _run_stomp_exchange(
    ws: WebSocketClientProtocol,
    target: str,
    candidate: Dict[str, Any],
    profile: HandshakeProfile,
    token: str,
) -> Optional[Dict[str, Any]]:
    parsed = urlparse(target)
    host = parsed.hostname or "localhost"
    connect_headers = {
        "accept-version": "1.2,1.1,1.0",
        "heart-beat": candidate.get("stomp_heartbeat", "10000,10000"),
        "host": host,
    }
    if isinstance(candidate.get("stomp_login"), str):
        connect_headers["login"] = str(candidate["stomp_login"])
    if isinstance(candidate.get("stomp_passcode"), str):
        connect_headers["passcode"] = str(candidate["stomp_passcode"])

    await _send_message(ws, _stomp_frame("CONNECT", connect_headers))
    ack = await _wait_for_nonempty_text(ws, timeout=6.0)
    if not ack:
        return None

    if not ack.upper().startswith("CONNECTED"):
        return None

    destination = candidate.get("stomp_destination")
    if not isinstance(destination, str) or not destination:
        destination = "/topic/warprecon"
    payload = candidate.get("payload")
    if isinstance(payload, str) and payload.strip():
        body = payload
    elif isinstance(payload, (dict, list)):
        body = json.dumps(payload)
    else:
        body = token

    send_headers = {
        "destination": destination,
        "content-type": "text/plain",
    }
    if isinstance(candidate.get("stomp_headers"), Mapping):
        for key, value in candidate["stomp_headers"].items():
            if isinstance(key, str) and value is not None:
                send_headers[key] = str(value)

    frame = _stomp_frame("SEND", send_headers, body)
    await _send_message(ws, frame)

    reply = await _wait_for_nonempty_text(ws, timeout=6.0)
    if not reply:
        return None

    upper = reply.upper()
    extra = {
        "stomp": {
            "connected": ack,
            "reply": reply,
        }
    }
    if upper.startswith("ERROR"):
        extra["stomp"]["error"] = True
    return {
        "strategy": "stomp-error" if upper.startswith("ERROR") else "stomp-send",
        "sent": frame,
        "received": reply,
        "extra": extra,
    }


async def _run_socketio_exchange(
    ws: WebSocketClientProtocol,
    target: str,
    candidate: Dict[str, Any],
    profile: HandshakeProfile,
    token: str,
) -> Optional[Dict[str, Any]]:
    handshake_info: Any = None
    for _ in range(4):
        message = await _wait_for_message(ws, timeout=6.0)
        if message is None:
            break
        text = _ensure_text(message)
        if text.startswith("0"):
            handshake_info = _safe_json_loads(text[1:])
            break
        if text.startswith("2"):
            await _send_message(ws, "3")
            continue
        if text.startswith("40"):
            handshake_info = _safe_json_loads(text[2:] or "{}")
            break
    if handshake_info is None:
        handshake_info = {}

    await _send_message(ws, "40")

    event_name = candidate.get("socketio_event") or candidate.get("event") or "probe"
    payload = candidate.get("payload")
    if isinstance(payload, (dict, list)):
        envelope = payload
    else:
        envelope = {"token": token}
        if payload not in (None, ""):
            envelope["payload"] = payload
    event_payload = json.dumps([event_name, envelope])
    await _send_message(ws, f"42{event_payload}")

    while True:
        message = await _wait_for_message(ws, timeout=6.0)
        if message is None:
            return None
        text = _ensure_text(message)
        if text.startswith("2"):
            await _send_message(ws, "3")
            continue
        if text.startswith("3"):
            continue
        if text.startswith("42") or text.startswith("43"):
            extra = {
                "socketio": {
                    "handshake": handshake_info,
                    "reply": _safe_json_loads(text[2:]),
                }
            }
            return {
                "strategy": "socketio-event",
                "sent": f"42{event_payload}",
                "received": text,
                "extra": extra,
            }
        if text.startswith("44"):
            extra = {
                "socketio": {
                    "handshake": handshake_info,
                    "reply": _safe_json_loads(text[2:]),
                    "error": True,
                }
            }
            return {
                "strategy": "socketio-event",
                "sent": f"42{event_payload}",
                "received": text,
                "extra": extra,
            }

async def ws_probe(target: str, cand: Dict[str, Any], mint, retries: int = 1) -> Optional[Dict[str, Any]]:
    delay = 0.4
    penalty: Optional[Dict[str, Any]] = None
    attempts = max(1, 1 + int(retries))
    profiles = list(_select_handshakes(target, cand))
    discovered_protocols: set[str] = set()
    for profile in profiles:
        for proto in profile.subprotocols:
            discovered_protocols.add(proto.lower())

    for attempt in range(attempts):
        if attempt > 0:
            await asyncio.sleep(delay + random.uniform(0, 0.2))
            delay = min(2.5, delay * 1.8)

        index = 0
        while index < len(profiles):
            profile = profiles[index]
            index += 1
            token = mint.mint("ws") if hasattr(mint, "mint") else f"ws-{random.randint(0, 9999)}"
            start = time.perf_counter()
            try:
                connect_kwargs = profile.connect_kwargs()
                extra_headers = _collect_extra_headers(cand)
                if extra_headers:
                    connect_kwargs[_CONNECT_HEADER_PARAM] = extra_headers
                async with websockets.connect(target, **connect_kwargs) as ws:
                    observed_proto = getattr(ws, "subprotocol", None)
                    if profile.heartbeat:
                        try:
                            await ws.ping()
                        except Exception:
                            pass
                    if profile.name == "stomp":
                        result = await _run_stomp_exchange(ws, target, cand, profile, token)
                    elif profile.name == "socketio":
                        result = await _run_socketio_exchange(ws, target, cand, profile, token)
                    elif profile.graphql_protocol:
                        result = await _run_graphql_subscription(ws, target, cand, profile, token)
                    else:
                        result = await _run_payload_strategies(ws, target, cand, profile, token)
                    elapsed = time.perf_counter() - start
                    if result:
                        evidence_extra = dict(result.get("extra") or {})
                        snippet_override = evidence_extra.pop("snippet", None)
                        if observed_proto and "subprotocol" not in evidence_extra:
                            evidence_extra["subprotocol"] = observed_proto
                        finding = _build_finding(
                            target,
                            cand,
                            profile,
                            result["strategy"],
                            result["sent"],
                            result["received"],
                            elapsed,
                            extra=evidence_extra or None,
                        )
                        if snippet_override:
                            finding["evidence"]["snippet"] = snippet_override
                        Telemetry.record_ws_roundtrip(
                            endpoint=target,
                            elapsed_ms=elapsed * 1000.0,
                            success=True,
                            reason=None,
                            handshake=profile.name,
                            strategy=result["strategy"],
                        )
                        return finding

                    Telemetry.record_ws_roundtrip(
                        endpoint=target,
                        elapsed_ms=elapsed * 1000.0,
                        success=False,
                        reason="no_message",
                        handshake=profile.name,
                    )
                    penalty = {
                        "_penalize": delay,
                        "_status": None,
                        "_latency": round(elapsed, 3),
                    }
            except InvalidStatus as exc:
                elapsed = time.perf_counter() - start
                response = getattr(exc, "response", None)
                status_code = getattr(response, "status_code", None)
                reason = f"http_{status_code}" if status_code else "handshake"
                Telemetry.record_ws_roundtrip(
                    endpoint=target,
                    elapsed_ms=elapsed * 1000.0,
                    success=False,
                    reason=reason,
                    handshake=profile.name,
                )
                headers = getattr(response, "headers", None)
                _extend_profiles_with_protocols(
                    profiles,
                    discovered_protocols,
                    _subprotocol_hints_from_headers(headers),
                )
                penalty = {
                    "_penalize": delay,
                    "_status": status_code,
                    "_latency": round(elapsed, 3),
                }
                continue
            except InvalidHandshake as exc:
                elapsed = time.perf_counter() - start
                Telemetry.record_ws_roundtrip(
                    endpoint=target,
                    elapsed_ms=elapsed * 1000.0,
                    success=False,
                    reason="handshake",
                    handshake=profile.name,
                )
                headers = getattr(exc, "response_headers", None)
                _extend_profiles_with_protocols(
                    profiles,
                    discovered_protocols,
                    _subprotocol_hints_from_headers(headers),
                )
                penalty = {
                    "_penalize": delay,
                    "_status": None,
                    "_latency": round(elapsed, 3),
                }
                continue
            except Exception as exc:
                elapsed = time.perf_counter() - start
                Telemetry.record_ws_roundtrip(
                    endpoint=target,
                    elapsed_ms=elapsed * 1000.0,
                    success=False,
                    reason=exc.__class__.__name__.lower(),
                    handshake=profile.name,
                )
                penalty = {
                    "_penalize": delay,
                    "_status": None,
                    "_latency": round(elapsed, 3),
                }

    return penalty


__all__ = ["ws_probe"]
