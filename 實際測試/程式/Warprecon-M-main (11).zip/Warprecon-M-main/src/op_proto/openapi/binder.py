from __future__ import annotations
"""
op_proto.openapi.binder — derive minimal valid payload from OpenAPI v3 schema
"""
from typing import Dict, Any
def _stub_for_schema(s: Dict[str, Any]) -> Any:
    t = (s.get("type") or "").lower()
    if "enum" in s: return s["enum"][0]
    if "default" in s: return s["default"]
    if t == "string": return (s.get("example") or "warprecon-m")
    if t == "integer": return int(s.get("minimum", 1))
    if t == "number": return float(s.get("minimum", 1.0))
    if t == "boolean": return True
    if t == "array": return [_stub_for_schema(s.get("items", {"type":"string"}))]
    if t == "object":
        out = {}
        props = s.get("properties", {}) or {}
        req = set(s.get("required", []) or [])
        for k, ps in props.items():
            if k in req or ps:
                out[k] = _stub_for_schema(ps or {"type":"string"})
        return out or {"name":"warprecon-m"}
    return "warprecon-m"
