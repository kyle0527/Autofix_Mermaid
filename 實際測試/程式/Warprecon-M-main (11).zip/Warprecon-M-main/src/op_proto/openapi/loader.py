from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import yaml


def load_spec(path: Path) -> Dict[str, Any]:
    s = path.read_text(encoding="utf-8")
    try:
        data = json.loads(s)
    except Exception:
        data = yaml.safe_load(s)
    return data or {}


def list_operations(spec: Dict[str, Any]) -> List[Dict[str, Any]]:
    operations: List[Dict[str, Any]] = []
    paths = spec.get("paths", {}) or {}
    for path, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue
        for method, details in path_item.items():
            if not isinstance(method, str):
                continue
            verb = method.lower()
            if verb not in {"get", "post", "put", "delete", "patch", "head", "options", "trace"}:
                continue
            if not isinstance(details, dict):
                continue
            operations.append(
                {
                    "path": path,
                    "method": verb,
                    "operationId": details.get("operationId"),
                    "summary": details.get("summary"),
                    "parameters": details.get("parameters"),
                    "requestBody": details.get("requestBody"),
                    "responses": details.get("responses"),
                    "raw": details,
                }
            )
    return operations
