"""op_proto.openapi.sequence_v2 — POST→GET using binder-derived payloads."""

from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .binder import _stub_for_schema
from .loader import load_spec, list_operations

try:  # pragma: no cover - optional dependency
    import httpx
except Exception:  # pragma: no cover - optional dependency
    httpx = None  # type: ignore[assignment]


def _extract_request_schema(operation: Dict[str, Any]) -> Dict[str, Any]:
    raw = operation.get("raw") if isinstance(operation, dict) else None
    if not isinstance(raw, dict):
        return {}
    request_body = raw.get("requestBody")
    if not isinstance(request_body, dict):
        return {}
    content = request_body.get("content")
    if not isinstance(content, dict):
        return {}
    for ctype, meta in content.items():
        if not isinstance(ctype, str) or not isinstance(meta, dict):
            continue
        if "json" in ctype.lower():
            schema = meta.get("schema")
            if isinstance(schema, dict):
                return schema
    return {}


def _path_param_names(operation: Dict[str, Any]) -> List[str]:
    path = str(operation.get("path", ""))
    return [segment.strip() for segment in re.findall(r"\{([^}]+)\}", path) if segment.strip()]


def _is_identifier_param(name: str) -> bool:
    lowered = name.lower()
    return any(keyword in lowered for keyword in ("id", "uuid", "guid", "key"))


def _pairs(spec: Dict[str, Any]) -> List[Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], List[str]]]:
    ops = list_operations(spec)
    posts = [op for op in ops if op.get("method") == "post"]
    gets = [op for op in ops if op.get("method") == "get"]
    pairs: List[Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], List[str]]] = []
    for post in posts:
        post_path = str(post.get("path", ""))
        schema = _extract_request_schema(post)
        body = _stub_for_schema(schema or {"type": "object"})
        base = post_path.rstrip("/")
        for get in gets:
            get_path = str(get.get("path", ""))
            params = [name for name in _path_param_names(get) if _is_identifier_param(name)]
            if get_path.startswith(base) and params:
                pairs.append((post, get, body, params))
    return pairs


def _normalise_key(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def _extract_identifier_values(data: Any, param_names: Sequence[str]) -> Dict[str, Any]:
    wanted = {_normalise_key(name): name for name in param_names if name}
    found: Dict[str, Any] = {}

    def _visit(node: Any) -> None:
        if len(found) == len(wanted):
            return
        if isinstance(node, dict):
            for key, value in node.items():
                if not isinstance(key, str):
                    continue
                normalised = _normalise_key(key)
                for target, original in wanted.items():
                    if original in found:
                        continue
                    if normalised == target or normalised.endswith(target):
                        found[original] = value
                _visit(value)
        elif isinstance(node, list):
            for item in node:
                _visit(item)

    _visit(data)
    return found

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--base", required=True)
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--run", action="store_true")
    ap.add_argument(
        "--insecure",
        action="store_true",
        help="Disable TLS certificate verification when replaying requests.",
    )
    args = ap.parse_args()

    spec = load_spec(Path(args.spec))
    pairs = _pairs(spec)
    outdir = Path(args.workdir) / "sequence_v2"
    outdir.mkdir(parents=True, exist_ok=True)
    manifest = []
    for i, (post, get, body, params) in enumerate(pairs[:10], start=1):
        entry = {
            "post": post.get("path"),
            "get": get.get("path"),
            "body": body,
            "post_method": post.get("method"),
            "get_method": get.get("method"),
            "path_params": params,
        }
        evidence_path: Optional[Path] = None
        if args.run and httpx:
            evidence: Dict[str, Any] = {
                "post": {},
                "get": {},
            }
            with httpx.Client(timeout=10, verify=not args.insecure) as cx:
                post_url = args.base.rstrip("/") + str(post.get("path", ""))
                t_post = time.perf_counter()
                post_resp = cx.post(post_url, json=body)
                post_elapsed = round(time.perf_counter() - t_post, 3)
                snippet = post_resp.text[:240] if post_resp.text else ""
                evidence["post"] = {
                    "url": post_url,
                    "status": post_resp.status_code,
                    "latency": post_elapsed,
                    "snippet": snippet,
                }
                post_json: Dict[str, Any] = {}
                try:
                    parsed = post_resp.json()
                    if isinstance(parsed, dict):
                        post_json = parsed
                        evidence["post"]["json"] = parsed
                except Exception:
                    pass
                values = _extract_identifier_values(post_json, params) if params else {}
                if values and len(values) == len(params):
                    get_url = args.base.rstrip("/") + str(get.get("path", ""))
                    resolved = get_url
                    for name, value in values.items():
                        resolved = resolved.replace(f"{{{name}}}", str(value))
                    t_get = time.perf_counter()
                    get_resp = cx.get(resolved)
                    get_elapsed = round(time.perf_counter() - t_get, 3)
                    evidence["get"] = {
                        "url": resolved,
                        "status": get_resp.status_code,
                        "latency": get_elapsed,
                        "snippet": get_resp.text[:240] if get_resp.text else "",
                    }
                    entry["resolved_params"] = {k: values[k] for k in params if k in values}
                else:
                    missing = [p for p in params if p not in (values or {})]
                    evidence["get"] = {"reason": "missing id in POST response", "missing": missing}
            evidence_path = outdir / f"pair_{i:02d}_evidence.json"
            evidence_path.write_text(
                json.dumps(evidence, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            entry["evidence"] = str(evidence_path)
        manifest.append(entry)
        # emit artifacts
        Path(outdir/f"pair_{i:02d}.json").write_text(
            json.dumps(
                {
                    "post": post.get("path"),
                    "get": get.get("path"),
                    "body": body,
                    "post_method": post.get("method"),
                    "get_method": get.get("method"),
                    "path_params": params,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    Path(outdir/"manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"pairs":len(manifest), "outdir": str(outdir)}, ensure_ascii=False))

if __name__=="__main__":
    main()
