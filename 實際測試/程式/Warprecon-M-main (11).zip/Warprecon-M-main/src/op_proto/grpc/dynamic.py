from __future__ import annotations
"""
op_proto.grpc.dynamic
Generic gRPC invocation using grpcurl if available; reflection fallback prints schema.
CLI:
  python -m op_proto.grpc.dynamic --target host:443 --method package.Service/Method --data '{"k":"v"}' --workdir work/m4
Outputs:
  work/m4/findings.grpc.dynamic.json
"""
import argparse, json, shutil, subprocess, sys
from pathlib import Path

def _run(cmd, input_data=None, timeout=15):
    try:
        p = subprocess.run(cmd, input=input_data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, check=False)
        return p.returncode, p.stdout, p.stderr
    except Exception as e:
        return 1, b"", str(e).encode()

def invoke_grpcurl(target: str, method: str, data: str, insecure: bool=False):
    exe = shutil.which("grpcurl")
    if not exe:
        return {"error":"grpcurl not installed"}
    cmd = [exe, "-plaintext"] if insecure else [exe]
    cmd += ["-d", data, target, method]
    code, out, err = _run(cmd, timeout=30)
    return {"code":code, "stdout": out.decode("utf-8","ignore"), "stderr": err.decode("utf-8","ignore")}

def list_services_grpcurl(target: str, insecure: bool=False):
    exe = shutil.which("grpcurl")
    if not exe:
        return {"error":"grpcurl not installed"}
    cmd = [exe, "-plaintext"] if insecure else [exe]
    cmd += ["-plaintext"] if (":80" in target and not insecure) else []
    cmd += ["-list", target]
    code, out, err = _run(cmd, timeout=15)
    return {"code":code, "stdout": out.decode("utf-8","ignore"), "stderr": err.decode("utf-8","ignore")}

def main():
    ap = argparse.ArgumentParser(description="Generic gRPC dynamic invoker")
    ap.add_argument("--target", required=True)
    ap.add_argument("--method", help="package.Service/Method")
    ap.add_argument("--data", default='{}')
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--insecure", action="store_true", help="plaintext call")
    args = ap.parse_args()

    work = Path(args.workdir); work.mkdir(parents=True, exist_ok=True)
    findings = []
    if args.method:
        res = invoke_grpcurl(args.target, args.method, args.data, insecure=args.insecure)
        item = {"protocol":"grpc","target":args.target,"method":args.method,"request":args.data,"severity":"info"}
        if res.get("code")==0:
            item.update({"type":"grpc.dynamic.ok","_score":0.55,"evidence":res.get("stdout","")[:1000]})
        else:
            item.update({"type":"grpc.dynamic.err","_score":0.25,"evidence":res.get("stderr","")[:1000]})
        findings.append(item)
    else:
        lst = list_services_grpcurl(args.target, insecure=args.insecure)
        findings.append({"protocol":"grpc","target":args.target,"type":"grpc.dynamic.list","severity":"info","_score":0.3,"evidence":lst.get("stdout","")[:1000]})
    out = work/"findings.grpc.dynamic.json"
    out.write_text(json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"out": str(out), "count": len(findings)}, ensure_ascii=False))

if __name__=="__main__":
    main()
