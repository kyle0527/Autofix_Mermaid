from __future__ import annotations

"""
op_proto.grpc.enumerate
- Enumerate gRPC services/methods using reflection (if available).
- Emit schema/{host}_{port}.json and findings.grpc.json

Targets are expected to be supplied as ``host`` or ``host:port``.  When a
port is omitted the enumerator assumes ``443``.  IPv6 literals should use the
standard bracket notation (``[2001:db8::1]:50051``) when paired with an
explicit port.
"""
import argparse
import ipaddress
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib.parse import urlsplit

try:
    import grpc
    from google.protobuf import descriptor_pb2
    from grpc_reflection.v1alpha import reflection as grpc_reflection
except Exception:  # pragma: no cover
    grpc = None  # type: ignore

from .utils import plaintext_on_tls_port, tls_min_version


def _split_target(target: str) -> Tuple[str, int]:
    """Return a validated ``(host, port)`` tuple for *target*.

    The input must be a hostname or IP address optionally followed by a port.
    IPv6 literals paired with a port must be wrapped in square brackets.
    """

    target = target.strip()
    if not target:
        raise ValueError("target must be a non-empty host[:port] string")

    host: str
    port: int | None = None

    if target.startswith("["):
        end = target.find("]")
        if end == -1:
            raise ValueError(f"invalid IPv6 target {target!r}: missing closing bracket")
        host = target[1:end]
        remainder = target[end + 1 :]
        if remainder:
            if not remainder.startswith(":"):
                raise ValueError(f"invalid IPv6 target {target!r}: unexpected suffix")
            port = _parse_port(remainder[1:], target)
        try:
            ipaddress.IPv6Address(host)
        except ValueError as exc:  # pragma: no cover - validation path
            raise ValueError(f"invalid IPv6 address in target {target!r}") from exc
    else:
        try:
            ipaddress.ip_address(target)
        except ValueError:
            split = urlsplit(f"//{target}")
            if split.path or split.query or split.fragment:
                raise ValueError(
                    f"invalid target {target!r}: unexpected path or query component"
                )
            if split.username or split.password:
                raise ValueError(f"invalid target {target!r}: unexpected userinfo component")
            netloc = split.netloc
            if not netloc:
                raise ValueError(f"invalid target {target!r}: missing hostname")
            if ":" in netloc:
                host_part, port_text = netloc.rsplit(":", 1)
                port = _parse_port(port_text, target)
                host = host_part
            else:
                host = netloc
        else:
            host = target

    if not host:
        raise ValueError(f"invalid target {target!r}: missing hostname")
    if port is None:
        port = 443
    if not (1 <= port <= 65535):
        raise ValueError(f"port {port} out of range in target {target!r}")
    return host, port


def _parse_port(port_text: str, target: str) -> int:
    if not port_text:
        raise ValueError(f"invalid target {target!r}: missing port number")
    if not port_text.isdigit():
        raise ValueError(f"invalid target {target!r}: port must be numeric")
    port = int(port_text)
    if not (1 <= port <= 65535):
        raise ValueError(f"port {port} out of range in target {target!r}")
    return port


def _enumerate_services(
    target: str, use_tls: bool = True, timeout: float = 5.0
) -> Dict[str, Any]:
    if grpc is None:
        return {"error": "grpcio/grpcio-reflection not installed"}
    options = (("grpc.ssl_target_name_override", target.split(":")[0]),)
    channel = None
    try:
        if use_tls:
            channel = grpc.secure_channel(
                target, grpc.ssl_channel_credentials(), options=options
            )
        else:
            channel = grpc.insecure_channel(target)
        grpc.channel_ready_future(channel).result(timeout=timeout)
        stub = grpc_reflection.ReflectionStub(channel)  # type: ignore
        services = stub.ListServices(
            grpc_reflection.ServerReflectionRequest(list_services="")
        )  # type: ignore
        out: Dict[str, Any] = {"services": []}
        names: List[str] = []
        for resp in services:
            if resp.list_services_response:
                for s in resp.list_services_response.service:
                    if s.name.startswith("grpc.reflection."):
                        continue
                    names.append(s.name)

        service_index: Dict[str, Dict[str, Any]] = {}
        for sname in names:
            entry = {"name": sname}
            service_index[sname] = entry
            out["services"].append(entry)

        for sname in names:
            req = grpc_reflection.ServerReflectionRequest(
                file_containing_symbol=sname
            )  # type: ignore
            for r in stub.ServerReflectionInfo(iter([req])):
                if not r.file_descriptor_response:
                    continue
                for b in r.file_descriptor_response.file_descriptor_proto:
                    fd = descriptor_pb2.FileDescriptorProto()
                    fd.ParseFromString(b)
                    package = fd.package or ""
                    for svc in fd.service:
                        full_name = f"{package}.{svc.name}" if package else svc.name
                        matches = (
                            full_name == sname
                            or sname.endswith(f".{svc.name}")
                            or svc.name == sname
                        )
                        if not matches:
                            continue
                        entry = service_index.get(sname)
                        if entry is None:
                            entry = {"name": full_name}
                            service_index[sname] = entry
                            out["services"].append(entry)
                        entry["name"] = full_name
                        entry["file"] = fd.name
                        methods = entry.setdefault("methods", [])
                        existing = {m.get("name") for m in methods if isinstance(m, dict)}
                        for method in svc.method:
                            if method.name in existing:
                                continue
                            if method.client_streaming and method.server_streaming:
                                method_type = "stream-stream"
                            elif method.client_streaming:
                                method_type = "stream-unary"
                            elif method.server_streaming:
                                method_type = "unary-stream"
                            else:
                                method_type = "unary-unary"
                            methods.append(
                                {
                                    "name": method.name,
                                    "type": method_type,
                                    "client_streaming": bool(method.client_streaming),
                                    "server_streaming": bool(method.server_streaming),
                                    "input": method.input_type,
                                    "output": method.output_type,
                                    "fq_name": f"/{full_name}/{method.name}",
                                }
                            )
        return out
    except Exception as e:
        return {"error": str(e)}
    finally:
        try:
            if channel:
                channel.close()
        except Exception:
            pass


def enumerate_methods(
    target: str,
    tls: bool = True,
    timeout: float = 5.0,
) -> List[str]:
    """Return a list of service names exposed by *target*.

    This stub leverages :func:`_enumerate_services` and never raises.  The
    returned list may be empty if reflection is not available or dependencies
    are missing.
    """
    try:
        schema = _enumerate_services(target, use_tls=tls, timeout=timeout)
        return [s.get("name", "") for s in schema.get("services", [])]
    except Exception:
        return []


def main() -> None:
    ap = argparse.ArgumentParser(description="gRPC reflection enumerator")
    ap.add_argument("--target", required=True, help="host:port")
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()
    host, port = _split_target(args.target)
    workdir = Path(args.workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    schema_dir = workdir / "schema"
    schema_dir.mkdir(parents=True, exist_ok=True)

    findings: List[Dict[str, Any]] = []
    schema = _enumerate_services(f"{host}:{port}", use_tls=True)
    schema_path = schema_dir / f"grpc_{host.replace(':', '_')}_{port}.json"
    schema_path.write_text(
        json.dumps(schema, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if plaintext_on_tls_port(host, port):
        findings.append(
            {
                "type": "grpc.plaintext_on_tls_port",
                "host": host,
                "port": port,
                "severity": "medium",
                "evidence": "TCP accept on 443 without TLS handshake",
            }
        )
    # TLSv1 allowed?
    try:
        import ssl

        if tls_min_version(host, port, ssl.TLSVersion.TLSv1):
            findings.append(
                {
                    "type": "tls.v1_enabled",
                    "host": host,
                    "port": port,
                    "severity": "low",
                    "evidence": "TLSv1 handshake succeeded",
                }
            )
    except Exception:
        pass

    (workdir / "findings.grpc.json").write_text(
        json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {"schema": str(schema_path), "findings": len(findings)},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
