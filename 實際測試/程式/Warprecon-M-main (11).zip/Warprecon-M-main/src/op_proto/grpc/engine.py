"""Minimal gRPC probing utilities used by Warprecon-M."""

from __future__ import annotations

import argparse
import base64
import json
import time

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .enumerate import _enumerate_services, _split_target
from .utils import plaintext_on_tls_port, tls_min_version


def _coerce_payload(data: Any) -> bytes:
    if data is None:
        return b""
    if isinstance(data, bytes):
        return data
    if isinstance(data, bytearray):
        return bytes(data)
    if isinstance(data, str):
        return data.encode("utf-8")
    try:
        return json.dumps(data).encode("utf-8")
    except Exception:
        return str(data).encode("utf-8", errors="ignore")



def _auto_select_unary_method(schema: Dict[str, Any]) -> Optional[str]:
    services = schema.get("services") if isinstance(schema, dict) else None
    if not isinstance(services, list):
        return None
    for service in services:
        if not isinstance(service, dict):
            continue
        service_name = service.get("name")
        methods = service.get("methods")
        if not isinstance(methods, list):
            continue
        for method in methods:
            if not isinstance(method, dict):
                continue
            if method.get("type") != "unary-unary":
                continue
            fq = method.get("fq_name")
            if isinstance(fq, str) and fq:
                return fq
            mname = method.get("name")
            if isinstance(service_name, str) and isinstance(mname, str) and service_name:
                cleaned_service = service_name.strip("/")
                if cleaned_service:
                    return f"/{cleaned_service}/{mname}"
    return None


def _has_services(schema: Any) -> bool:
    if not isinstance(schema, dict):
        return False
    services = schema.get("services")
    if not isinstance(services, list):
        return False
    return any(isinstance(service, dict) for service in services)


def _summarize_attempt(schema: Any, use_tls: bool) -> Dict[str, Any]:
    summary: Dict[str, Any] = {"use_tls": use_tls}
    if isinstance(schema, dict):
        services = schema.get("services")
        if isinstance(services, list):
            summary["services"] = len(services)
        error = schema.get("error")
        if error:
            summary["error"] = str(error)
    else:
        summary["error"] = "invalid"
    return summary


def _looks_like_tls_error(schema: Any) -> bool:
    if not isinstance(schema, dict):
        return False
    error = schema.get("error")
    if not isinstance(error, str):
        return False
    lowered = error.lower()
    keywords = (
        "tls",
        "ssl",
        "handshake",
        "wrong version",
        "protocol error",
        "plaintext",
        "http2",
    )
    return any(keyword in lowered for keyword in keywords)


def _should_retry_plaintext(schema: Any, plaintext_hint: Optional[bool]) -> bool:
    if _looks_like_tls_error(schema):
        return True
    if not plaintext_hint:
        return False
    if isinstance(schema, dict) and schema.get("error"):
        return True
    return False


@dataclass
class EnumerationOutcome:
    schema: Dict[str, Any]
    active_tls: bool
    attempts: List[Dict[str, Any]]
    plaintext_hint: Optional[bool]


def _enumerate_with_plaintext_retry(
    endpoint: str,
    host: str,
    port: int,
    prefer_tls: bool,
    timeout: float,
) -> EnumerationOutcome:
    schema_raw: Any = _enumerate_services(endpoint, use_tls=prefer_tls, timeout=timeout)
    schema: Dict[str, Any] = schema_raw if isinstance(schema_raw, dict) else {}
    attempts: List[Dict[str, Any]] = [_summarize_attempt(schema, prefer_tls)]
    active_tls = prefer_tls
    plaintext_hint: Optional[bool] = None

    if prefer_tls:
        plaintext_hint = plaintext_on_tls_port(host, port)
        if _should_retry_plaintext(schema, plaintext_hint):
            retry_raw: Any = _enumerate_services(endpoint, use_tls=False, timeout=timeout)
            retry_schema: Dict[str, Any] = retry_raw if isinstance(retry_raw, dict) else {}
            attempts.append(_summarize_attempt(retry_schema, False))
            if _has_services(retry_schema) and (not _has_services(schema) or schema.get("error")):
                schema = retry_schema
                active_tls = False

    return EnumerationOutcome(
        schema=schema,
        active_tls=active_tls,
        attempts=attempts,
        plaintext_hint=plaintext_hint,
    )


async def grpc_probe(target: str, cand: Dict, mint) -> Optional[List[Dict]]:
    """Async wrapper around :func:`grpc_probe_sync` for pipeline compatibility."""

    return grpc_probe_sync(target, cand)


def grpc_probe_sync(target: str, cand: Optional[Dict[str, Any]] = None) -> List[Dict]:
    """Minimal synchronous gRPC probe used by :func:`grpc_probe`.

    Returns a list of ``informational`` findings when plaintext transport or
    obsolete TLS versions are detected.  The function never raises and
    otherwise returns an empty list.
    """
    try:
        host, port = _split_target(target if ":" in target else f"{target}:443")
        cand = cand or {}
        outs: List[Dict[str, Any]] = []
        default_tls = port == 443
        prefer_tls = bool(cand.get("tls", default_tls))
        if cand.get("insecure"):
            prefer_tls = False
        endpoint = f"{host}:{port}"
        try:
            enum_timeout = float(cand.get("timeout", 5.0))
        except (TypeError, ValueError):
            enum_timeout = 5.0

        outcome = _enumerate_with_plaintext_retry(
            endpoint,
            host,
            port,
            prefer_tls,
            enum_timeout,
        )
        schema = outcome.schema
        active_tls = outcome.active_tls
        attempts = outcome.attempts
        plaintext_hint = outcome.plaintext_hint
        scheme = "grpcs" if active_tls else "grpc"
        url = f"{scheme}://{endpoint}"

        services = []
        if isinstance(schema, dict):
            services = [
                s.get("name")
                for s in schema.get("services", [])
                if isinstance(s, dict) and s.get("name")
            ]
        reflection_status = "ok" if services else "degraded"
        evidence: Dict[str, Any] = {
            "host": host,
            "port": port,
            "use_tls": active_tls,
            "status": reflection_status,
            "services": services,
        }
        if isinstance(schema, dict) and schema.get("error"):
            evidence["error"] = schema.get("error")
        if schema:
            evidence["schema"] = schema
        if attempts:
            evidence["enumeration_attempts"] = attempts
        outs.append(
            {
                "target": target,
                "vector": {"protocol": "grpc", "location": "reflection", "param": None},
                "payload": None,
                "tool": "warprecon-m-grpc",
                "evidence": evidence,
                "severity": "info",
                "url": url,
            }
        )

        if plaintext_hint is None:
            plaintext_hint = plaintext_on_tls_port(host, port)
        if plaintext_hint:
            outs.append(
                {
                    "target": target,
                    "vector": {"protocol": "grpc", "location": "transport", "param": "plaintext"},
                    "payload": None,
                    "tool": "warprecon-m-grpc",
                    "evidence": {
                        "message": "TCP accept on port 443 without TLS handshake",
                        "host": host,
                        "port": port,
                    },
                    "severity": "medium",
                    "url": url,
                }
            )
        try:
            import ssl

            if tls_min_version(host, port, ssl.TLSVersion.TLSv1):
                outs.append(
                    {
                        "target": target,
                        "vector": {"protocol": "grpc", "location": "transport", "param": "tls"},
                        "payload": None,
                        "tool": "warprecon-m-grpc",
                        "evidence": {
                            "message": "TLSv1 handshake succeeded",
                            "min_version": "TLSv1",
                            "host": host,
                            "port": port,
                        },
                        "severity": "low",
                        "url": url,
                    }
                )
        except Exception:
            pass

        method = cand.get("method") or cand.get("rpc") or cand.get("endpoint")
        auto_method: Optional[str] = None
        if not method and isinstance(schema, dict):
            auto_method = _auto_select_unary_method(schema)
            method = auto_method
        payload_bytes = _coerce_payload(cand.get("payload"))
        try:
            rpc_timeout = float(cand.get("rpc_timeout", cand.get("timeout", 5.0)))
        except (TypeError, ValueError):
            rpc_timeout = enum_timeout
        if method:
            call_result = probe_unary_unary(
                endpoint,
                str(method),
                payload_bytes,
                tls=active_tls,
                timeout=rpc_timeout,
            )
            evidence = {k: v for k, v in call_result.items() if k not in {"target", "method"}}
            severity = "info" if call_result.get("status") == "ok" else "low"
            if auto_method and str(method) == auto_method:
                evidence["auto_discovered"] = True
            outs.append(
                {
                    "target": target,
                    "vector": {"protocol": "grpc", "location": "method", "param": str(method)},
                    "payload": evidence.get("request_preview"),
                    "tool": "warprecon-m-grpc",
                    "evidence": evidence,
                    "severity": severity,
                    "url": url,
                }
            )
        else:
            services = schema.get("services") if isinstance(schema, dict) else []
            has_methods = any(
                isinstance(service, dict) and service.get("methods") for service in (services or [])
            )
            reason = "no unary-unary method specified"
            if has_methods and not auto_method:
                reason = "no unary-unary method discovered"
            outs.append(
                {
                    "target": target,
                    "vector": {"protocol": "grpc", "location": "method", "param": None},
                    "payload": None,
                    "tool": "warprecon-m-grpc",
                    "evidence": {
                        "status": "degraded",
                        "reason": reason,
                    },
                    "severity": "info",
                    "url": url,
                }
            )
        return outs
    except Exception:
        return []


def probe_unary_unary(
    target: str,
    method: str,
    payload: bytes,
    *,
    tls: bool = False,
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """Best-effort unary-unary gRPC probe returning evidence for the exchange."""

    payload_bytes = payload if isinstance(payload, bytes) else _coerce_payload(payload)
    preview = base64.b64encode(payload_bytes[:160]).decode("ascii") if payload_bytes else ""
    result: Dict[str, Any] = {
        "target": target,
        "method": method,
        "sent": len(payload_bytes),
        "tls": tls,
        "timeout": timeout,
        "request_preview": preview,
    }
    try:
        import grpc
    except Exception:
        result["status"] = "degraded"
        result["error"] = "grpcio not installed"
        return result

    channel = None
    start = time.perf_counter()
    try:
        if tls:
            channel = grpc.secure_channel(target, grpc.ssl_channel_credentials())
        else:
            channel = grpc.insecure_channel(target)
        stub = channel.unary_unary(
            method,
            request_serializer=lambda data: data,
            response_deserializer=lambda data: data,
        )
        response = stub(payload_bytes, timeout=timeout)
        elapsed = round(time.perf_counter() - start, 3)
        result["status"] = "ok"
        result["latency"] = elapsed
        if isinstance(response, bytes):
            result["response_size"] = len(response)
            result["response_preview"] = base64.b64encode(response[:200]).decode("ascii")
        else:
            result["response_preview"] = str(response)[:200]
    except grpc.RpcError as exc:
        elapsed = round(time.perf_counter() - start, 3)
        result["status"] = "error"
        result["latency"] = elapsed
        try:
            code = exc.code()
            result["grpc_code"] = code.name if code else None
        except Exception:
            result["grpc_code"] = None
        try:
            details = exc.details()
        except Exception:
            details = None
        result["error"] = details or str(exc)
    except Exception as exc:  # pragma: no cover - transport errors
        result["status"] = "error"
        result["error"] = str(exc)
    finally:
        try:
            if channel:
                channel.close()
        except Exception:
            pass
    return result


def reflect_services(
    target: str, tls: bool = True, timeout: float = 5.0
) -> Dict[str, Any]:
    """Return gRPC reflection information for *target*.

    The real engine would perform a network call using gRPC reflection.  This
    lightweight stub reuses :func:`_enumerate_services` and never raises,
    allowing unit tests to exercise the API without depending on gRPC
    libraries or network availability.
    """
    try:
        return _enumerate_services(target, use_tls=tls, timeout=timeout)
    except Exception:
        return {}


def _cli() -> None:
    ap = argparse.ArgumentParser(description="gRPC minimal engine CLI")
    ap.add_argument("--target", required=True)
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()
    host, port = _split_target(args.target)
    workdir = Path(args.workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    out = {
        "schema": _enumerate_services(f"{host}:{port}", use_tls=True),
        "plaintext_on_tls": plaintext_on_tls_port(host, port),
    }
    (workdir / "findings.grpc.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {"ok": True, "findings": str(workdir / "findings.grpc.json")},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    _cli()
