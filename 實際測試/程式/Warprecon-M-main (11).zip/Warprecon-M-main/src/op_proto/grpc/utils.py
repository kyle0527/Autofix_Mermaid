from __future__ import annotations
from typing import Optional, Tuple
import socket, ssl

def try_tcp(host: str, port: int, timeout: float=3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            return True
    except Exception:
        return False

def plaintext_on_tls_port(host: str, port: int=443, timeout: float=3.0) -> bool:
    """Return True if a plaintext TCP connect to 443 seems accepted (heuristic)."""
    if port != 443: return False
    return try_tcp(host, port, timeout=timeout)

def tls_min_version(host: str, port: int=443, version: ssl.TLSVersion=ssl.TLSVersion.TLSv1) -> bool:
    """Attempt old TLS version handshake. Returns True if handshake succeeds (insecure)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = version
    ctx.maximum_version = version
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((host, port), timeout=3.0) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                _ = ssock.version()
                return True
    except Exception:
        return False
