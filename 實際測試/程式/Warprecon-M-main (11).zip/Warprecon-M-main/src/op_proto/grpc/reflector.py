from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence

from .enumerate import _enumerate_services, _split_target

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _ReflectionDeps:
    grpc: Any
    grpc_reflection: Any
    descriptor_pb2: Any
    json_format: Any
    descriptor_pool: Any
    pb_descriptor: Any


def _load_reflection_dependencies() -> _ReflectionDeps:
    try:
        import grpc
        from grpc_reflection.v1alpha import reflection as grpc_reflection
        from google.protobuf import descriptor as pb_descriptor
        from google.protobuf import descriptor_pb2, descriptor_pool, json_format
    except Exception as exc:  # pragma: no cover - dependency guard
        raise RuntimeError("grpcio/grpcio-reflection not installed") from exc

    return _ReflectionDeps(
        grpc=grpc,
        grpc_reflection=grpc_reflection,
        descriptor_pb2=descriptor_pb2,
        json_format=json_format,
        descriptor_pool=descriptor_pool,
        pb_descriptor=pb_descriptor,
    )


def _normalize_symbol(symbol: Optional[str]) -> str:
    if not symbol:
        return ""
    cleaned = str(symbol).strip()
    if not cleaned:
        return ""
    while cleaned.startswith("/"):
        cleaned = cleaned[1:]
    while cleaned.startswith("."):
        cleaned = cleaned[1:]
    return cleaned.replace("/", ".")


def _service_symbol(method_fq_name: Optional[str]) -> str:
    method_symbol = _normalize_symbol(method_fq_name)
    if not method_symbol:
        return ""
    if "." not in method_symbol:
        return method_symbol
    return method_symbol.rsplit(".", 1)[0]


def _create_stub(
    deps: _ReflectionDeps, endpoint: str, use_tls: bool, host_override: str
):
    options = (("grpc.ssl_target_name_override", host_override),)
    if use_tls:
        credentials = deps.grpc.ssl_channel_credentials()
        channel = deps.grpc.secure_channel(endpoint, credentials, options=options)
    else:
        channel = deps.grpc.insecure_channel(endpoint)
    stub = deps.grpc_reflection.ReflectionStub(channel)
    return channel, stub


def _wait_for_channel_ready(deps: _ReflectionDeps, channel: Any, timeout: float) -> None:
    ready_future = deps.grpc.channel_ready_future(channel)
    ready_future.result(timeout=timeout)


def _collect_file_descriptors(
    deps: _ReflectionDeps,
    stub: Any,
    symbols: Sequence[str],
    timeout: float,
) -> tuple[List[Any], List[str]]:
    descriptors: List[Any] = []
    errors: List[str] = []
    seen: set[bytes] = set()
    for symbol in symbols:
        if not symbol:
            continue
        try:
            request = deps.grpc_reflection.ServerReflectionRequest(
                file_containing_symbol=symbol
            )
        except Exception as exc:
            errors.append(str(exc))
            continue
        try:
            responses = stub.ServerReflectionInfo(iter([request]), timeout=timeout)
        except Exception as exc:  # pragma: no cover - transport errors
            errors.append(str(exc))
            continue
        for resp in responses:
            error_resp = getattr(resp, "error_response", None)
            if error_resp:
                message = getattr(error_resp, "error_message", "") or ""
                code = getattr(error_resp, "error_code", None)
                if code is not None:
                    message = message or f"code={code}"
                errors.append(message or "reflection error")
                continue
            file_resp = getattr(resp, "file_descriptor_response", None)
            if not file_resp:
                continue
            raw_list = getattr(file_resp, "file_descriptor_proto", None) or []
            for raw in raw_list:
                if raw in seen:
                    continue
                seen.add(raw)
                descriptor = deps.descriptor_pb2.FileDescriptorProto()
                descriptor.ParseFromString(raw)
                descriptors.append(descriptor)
    return descriptors, errors


def _build_pool(deps: _ReflectionDeps, descriptors: Iterable[Any]) -> Any:
    pool = deps.descriptor_pool.DescriptorPool()
    for descriptor in descriptors:
        try:
            pool.Add(descriptor)
        except Exception:
            continue
    return pool


def _summarize_descriptor(deps: _ReflectionDeps, message: Any) -> Dict[str, Any]:
    fd = deps.pb_descriptor.FieldDescriptor
    type_names = {
        fd.TYPE_DOUBLE: "double",
        fd.TYPE_FLOAT: "float",
        fd.TYPE_INT64: "int64",
        fd.TYPE_UINT64: "uint64",
        fd.TYPE_INT32: "int32",
        fd.TYPE_FIXED64: "fixed64",
        fd.TYPE_FIXED32: "fixed32",
        fd.TYPE_BOOL: "bool",
        fd.TYPE_STRING: "string",
        fd.TYPE_MESSAGE: "message",
        fd.TYPE_BYTES: "bytes",
        fd.TYPE_UINT32: "uint32",
        fd.TYPE_ENUM: "enum",
        fd.TYPE_SFIXED32: "sfixed32",
        fd.TYPE_SFIXED64: "sfixed64",
        fd.TYPE_SINT32: "sint32",
        fd.TYPE_SINT64: "sint64",
        fd.TYPE_GROUP: "group",
    }
    label_names = {
        fd.LABEL_OPTIONAL: "optional",
        fd.LABEL_REPEATED: "repeated",
        fd.LABEL_REQUIRED: "required",
    }
    fields: List[Dict[str, Any]] = []
    for field in message.fields:
        entry: Dict[str, Any] = {
            "name": field.name,
            "type": type_names.get(field.type, str(field.type)),
            "label": label_names.get(field.label, str(field.label)),
        }
        if field.message_type is not None:
            entry["message_type"] = field.message_type.full_name
        if field.enum_type is not None:
            entry["enum_type"] = field.enum_type.full_name
        if getattr(field, "containing_oneof", None) is not None:
            entry["oneof"] = field.containing_oneof.name
        default_value = getattr(field, "default_value", None)
        if (
            field.label != fd.LABEL_REPEATED
            and getattr(field, "has_default_value", False)
            and default_value is not None
        ):
            entry["default"] = default_value
        fields.append(entry)
    return {"type": message.full_name, "fields": fields}


def _describe_message(
    deps: _ReflectionDeps, pool: Any, message_symbol: Optional[str]
) -> Optional[Dict[str, Any]]:
    symbol = _normalize_symbol(message_symbol)
    if not symbol:
        return None
    try:
        descriptor = pool.FindMessageTypeByName(symbol)
    except Exception:
        return None
    return _summarize_descriptor(deps, descriptor)


def _match_method(schema: Dict[str, Any], method: str) -> Optional[Dict[str, Any]]:
    target_symbol = _normalize_symbol(method)
    services = schema.get("services") if isinstance(schema, dict) else None
    if not isinstance(services, list):
        return None
    for service in services:
        if not isinstance(service, dict):
            continue
        methods = service.get("methods")
        if not isinstance(methods, list):
            continue
        for entry in methods:
            if not isinstance(entry, dict):
                continue
            candidates = {
                _normalize_symbol(entry.get("fq_name")),
                _normalize_symbol(entry.get("name")),
            }
            if any(candidate and candidate == target_symbol for candidate in candidates):
                result = dict(entry)
                if "service" not in result:
                    result["service"] = service.get("name")
                return result
    return None


def call_reflect_json(
    target: str,
    method: str,
    message: Dict[str, Any],
    tls: bool = False,
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """Return gRPC reflection data for *target* and *method*.

    The helper connects to the reflection endpoint (when available), fetches the
    schema for the requested method and summarises the request/response
    messages.  When gRPC dependencies are missing or reflection is not
    supported the function returns a degraded status rather than raising.
    """

    result: Dict[str, Any] = {
        "target": target,
        "method": method,
        "request": message,
        "tls": tls,
        "timeout": timeout,
    }

    try:
        deps = _load_reflection_dependencies()
    except RuntimeError as exc:
        result["status"] = "degraded"
        result["error"] = str(exc)
        return result

    try:
        host, port = _split_target(target)
    except ValueError as exc:
        result["status"] = "error"
        result["error"] = str(exc)
        return result

    endpoint = f"{host}:{port}"
    result["endpoint"] = endpoint

    schema = _enumerate_services(endpoint, use_tls=tls, timeout=timeout)
    result["schema"] = schema

    services = schema.get("services") if isinstance(schema, dict) else None
    if not services:
        error_message = None
        if isinstance(schema, dict):
            error_message = schema.get("error")
        result["status"] = "degraded"
        result["error"] = error_message or "no services discovered via reflection"
        return result

    method_entry = _match_method(schema, method)
    if method_entry is None:
        message_text = f"method {method!r} not found via reflection"
        if schema.get("services"):
            logger.debug(message_text)
        result["status"] = "degraded"
        result["error"] = message_text
        return result
    result["method_info"] = method_entry

    channel = None
    try:
        channel, stub = _create_stub(deps, endpoint, tls, host)
        _wait_for_channel_ready(deps, channel, timeout)
    except Exception as exc:
        logger.debug("Failed to prepare reflection channel: %s", exc)
        if channel is not None:
            try:
                channel.close()
            except Exception:
                pass
        result["status"] = "degraded"
        result["error"] = f"failed to establish reflection channel: {exc}"
        return result

    symbols = [
        _service_symbol(method_entry.get("fq_name") or method),
        _normalize_symbol(method_entry.get("input")),
        _normalize_symbol(method_entry.get("output")),
    ]

    try:
        descriptors, errors = _collect_file_descriptors(deps, stub, symbols, timeout)
    finally:
        try:
            if channel is not None:
                channel.close()
        except Exception:
            pass

    status = "ok"
    if errors:
        status = "degraded"
        result["errors"] = errors

    if descriptors:
        result["descriptors"] = [
            deps.json_format.MessageToDict(fd, preserving_proto_field_name=True)
            for fd in descriptors
        ]
        pool = _build_pool(deps, descriptors)
        request_schema = _describe_message(deps, pool, method_entry.get("input"))
        if request_schema:
            result["request_schema"] = request_schema
        response_schema = _describe_message(deps, pool, method_entry.get("output"))
        if response_schema:
            result["response_schema"] = response_schema
    else:
        status = "degraded"
        result.setdefault("errors", []).append(
            "no descriptors returned from reflection"
        )

    result["status"] = status
    return result
