from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

try:  # pragma: no cover - optional dependency
    import httpx
except Exception:  # pragma: no cover
    httpx = None  # type: ignore

from .schema import (
    GraphQLArgument,
    GraphQLField,
    GraphQLSchema,
    GraphQLType,
    TypeRef,
    render_selection,
)

Candidate = Dict[str, Any]


def generate_candidates(
    schema: Dict[str, Any], budget: int = 1, max_depth: int = 3
) -> List[Candidate]:
    """Generate GraphQL operation candidates from an introspection *schema*."""

    try:
        gql_schema = GraphQLSchema.from_introspection(schema)
    except Exception:
        return [{"query": "query { __typename }"}]

    operations: List[Tuple[str, GraphQLType]] = []
    for op_name, type_name in (
        ("query", gql_schema.query_type),
        ("mutation", gql_schema.mutation_type),
        ("subscription", gql_schema.subscription_type),
    ):
        gql_type = gql_schema.get_type(type_name)
        if gql_type and gql_type.fields:
            operations.append((op_name, gql_type))

    candidates: List[Candidate] = []
    for operation_name, root_type in operations:
        for field in root_type.fields.values():
            if field.name.startswith("__"):
                continue
            cand = _build_operation(
                operation_name, field, gql_schema, max_depth=max_depth
            )
            if cand is not None:
                candidates.append(cand)
    if not candidates:
        return [{"query": "query { __typename }"}]
    if budget > 0:
        essential = max(1, min(len(operations), budget))
        selected = candidates[: budget]
        if len(selected) < essential:
            selected = candidates[:essential]
        return selected
    return candidates


def probe_set(
    url: str, queries: Iterable[Union[str, Candidate]], timeout: float = 1.0
) -> List[Dict[str, Any]]:
    """Send *queries* to *url* and collect results."""

    outs: List[Dict[str, Any]] = []
    for q in queries:
        payload: Dict[str, Any]
        query_text: Optional[str]
        if isinstance(q, str):
            query_text = q
            payload = {"query": q}
        elif isinstance(q, dict):
            query_text = q.get("query") or q.get("payload")
            if not query_text:
                continue
            payload = {"query": query_text}
            if "variables" in q and q["variables"] is not None:
                payload["variables"] = q["variables"]
        else:
            query_text = str(q)
            payload = {"query": query_text}
        if httpx is None:
            outs.append({"query": query_text, "error": "httpx not installed"})
            continue
        try:
            r = httpx.post(url, json=payload, timeout=timeout)
            try:
                data = r.json()
                if isinstance(data, dict):
                    data.setdefault("query", query_text)
                outs.append(data)
            except Exception:
                outs.append({"query": query_text, "status": r.status_code})
        except Exception as e:  # pragma: no cover - network dependent
            outs.append({"query": query_text, "error": str(e)})
    return outs


def _build_operation(
    op_kind: str,
    field: GraphQLField,
    schema: GraphQLSchema,
    *,
    max_depth: int = 3,
) -> Optional[Candidate]:
    type_ref = field.type
    operation = op_kind or "query"
    op_name = f"{operation}_{field.name}"
    var_defs, arg_values, variables = _prepare_arguments(field, schema)
    header = f"{operation} {op_name}"
    if var_defs:
        header += f"({', '.join(var_defs)})"
    args_expr = f"({', '.join(arg_values)})" if arg_values else ""
    selection_lines = render_selection(
        schema, type_ref, depth=2, max_depth=max_depth
    )
    lines: List[str] = [header + " {"]
    base = type_ref.unwrap()
    if base.kind in {"OBJECT", "INTERFACE", "UNION"} and base.name:
        lines.append(f"  {field.name}{args_expr} {{")
        if selection_lines:
            lines.extend(selection_lines)
        else:
            lines.append("    __typename")
        lines.append("  }")
    else:
        lines.append(f"  {field.name}{args_expr}")
    lines.append("}")
    candidate: Candidate = {"query": "\n".join(lines), "operation": operation}
    if variables:
        candidate["variables"] = variables
    return candidate


def _prepare_arguments(
    field: GraphQLField, schema: GraphQLSchema
) -> Tuple[List[str], List[str], Dict[str, Any]]:
    var_defs: List[str] = []
    arg_values: List[str] = []
    variables: Dict[str, Any] = {}
    for arg in field.args.values():
        var_name = f"{field.name}_{arg.name}".replace("__", "_")
        var_type = arg.type.render()
        sample = _sample_value(arg, schema)
        if sample is None:
            sample = "sample"
        var_defs.append(f"${var_name}: {var_type}")
        arg_values.append(f"{arg.name}: ${var_name}")
        variables[var_name] = sample
    return var_defs, arg_values, variables


def _sample_value(arg: GraphQLArgument, schema: GraphQLSchema) -> Any:
    if arg.default_value is not None:
        parsed = _parse_default(arg.default_value)
        if parsed is not None:
            return parsed
    return _sample_from_type(arg.type, schema)


def _sample_from_type(type_ref: TypeRef, schema: GraphQLSchema) -> Any:
    if type_ref.kind == "NON_NULL" and type_ref.of_type is not None:
        return _sample_from_type(type_ref.of_type, schema)
    if type_ref.kind == "LIST" and type_ref.of_type is not None:
        inner = _sample_from_type(type_ref.of_type, schema)
        return [inner]
    base = type_ref.unwrap()
    if base.kind == "SCALAR":
        return _scalar_placeholder(base.name)
    if base.kind == "ENUM":
        enum_type = schema.get_type(base.name)
        if enum_type and enum_type.enum_values:
            return enum_type.enum_values[0]
        return "VALUE"
    if base.kind == "INPUT_OBJECT":
        input_type = schema.get_type(base.name)
        if input_type and input_type.input_fields:
            sample: Dict[str, Any] = {}
            for name, input_field in list(input_type.input_fields.items())[:4]:
                sample[name] = _sample_from_type(input_field.type, schema)
            return sample
        return {}
    return "sample"


def _scalar_placeholder(name: Optional[str]) -> Any:
    placeholders: Dict[str, Any] = {
        "String": "sample",
        "ID": "example-id",
        "Int": 1,
        "Float": 0.5,
        "Boolean": False,
    }
    if name is None:
        return "sample"
    return placeholders.get(name, "sample")


def _parse_default(value: str) -> Any:
    if value is None:
        return None
    try:
        import json

        return json.loads(value)
    except Exception:
        if value.startswith("\"") and value.endswith("\""):
            return value.strip("\"")
        if value.lower() in {"true", "false"}:
            return value.lower() == "true"
        try:
            if "." in value:
                return float(value)
            return int(value)
        except Exception:
            return None
