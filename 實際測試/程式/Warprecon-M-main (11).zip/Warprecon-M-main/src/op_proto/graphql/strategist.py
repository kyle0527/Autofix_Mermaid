from __future__ import annotations

import re
from typing import Any, Dict, List, Optional


def parse_hints(text: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "types": [],
        "fields": [],
        "expected": [],
        "variables": {},
        "arguments": [],
    }
    for m in re.findall(r'on type\s+"([A-Za-z_][A-Za-z0-9_]*)"', text):
        out["types"].append(m)
    for m in re.findall(r'Cannot query field\s+"([A-Za-z_][A-Za-z0-9_]*)"', text):
        out["fields"].append(m)
    for m in re.findall(r'Expected type\s+([A-Za-z_][A-Za-z0-9_!]*)', text):
        out["expected"].append(m)
    for name, type_hint in re.findall(
        r'Variable\s+"\$([A-Za-z_][A-Za-z0-9_]*)"\s+of\s+required\s+type\s+"([^"\s]+)"',
        text,
    ):
        if name not in out["variables"]:
            out["variables"][name] = type_hint
    for name, type_hint in re.findall(
        r'Variable\s+"\$([A-Za-z_][A-Za-z0-9_]*)"\s+got\s+invalid\s+value[^;]*;\s*Expected\s+type\s+([^\.\s]+)',
        text,
    ):
        if name not in out["variables"]:
            out["variables"][name] = type_hint
    for arg, type_hint in re.findall(
        r'Argument\s+"([A-Za-z_][A-Za-z0-9_]*)"\s+of\s+required\s+type\s+"([^"\s]+)"',
        text,
    ):
        entry = {"name": arg, "type": type_hint}
        if entry not in out["arguments"]:
            out["arguments"].append(entry)
    for key in ("types", "fields", "expected"):
        seen: set[str] = set()
        uniq: List[str] = []
        for value in out[key]:
            if value not in seen:
                seen.add(value)
                uniq.append(value)
        out[key] = uniq
    return out


def suggest_next(prev_query: str, hints: Dict[str, Any]) -> Optional[str]:
    types = hints.get("types") if isinstance(hints, dict) else None
    if types:
        target_type = str(types[0])
        safe = target_type.replace('"', '\\"')
        return (
            "query __TypeHint {\n"
            f'  __type(name: "{safe}") {{\n'
            "    name\n"
            "    kind\n"
            "    fields { name }\n"
            "  }\n"
            "}"
        )
    fields = hints.get("fields") if isinstance(hints, dict) else None
    if fields:
        field = str(fields[0])
        return f"query __FieldHint {{ __typename {field}:__typename }}"
    return "query { __typename }"


def plan_queries(
    seed: str,
    errors_texts: List[str],
    max_steps: int = 3,
    *,
    hints: Optional[Dict[str, Any]] = None,
) -> List[str]:
    """Generate follow-up queries guided by *hints* parsed from errors."""

    plan: List[str] = []
    last = seed
    base_hints = hints or parse_hints(" ".join(x for x in errors_texts if isinstance(x, str)))
    for _ in range(max_steps):
        nxt = suggest_next(last, base_hints)
        if not nxt or nxt == last:
            break
        plan.append(nxt)
        last = nxt
    return plan
