from __future__ import annotations

import asyncio
import random
import time
from urllib.parse import urldefrag, urlsplit

import httpx

from typing import Any, Dict, List, Optional
from .strategist import parse_hints, plan_queries
from .schema import try_introspect

SCHEMA_CACHE: Dict[str, Dict[str, Any]] = {}


def _canonicalize(url: str) -> str:
    base = urldefrag(url.strip())[0]
    return base.rstrip("/")


def _schema_keys(url: str) -> List[str]:
    keys: List[str] = []
    canon = _canonicalize(url)
    if canon:
        keys.append(canon)
        parsed = urlsplit(canon)
        if parsed.netloc:
            keys.append(f"{parsed.netloc}{parsed.path}")
            if parsed.scheme in {"http", "https"}:
                alt_scheme = "https" if parsed.scheme == "http" else "http"
                keys.append(f"{alt_scheme}://{parsed.netloc}{parsed.path}")
    # remove empty/duplicate entries preserving order
    seen = set()
    uniq: List[str] = []
    for key in keys:
        if key and key not in seen:
            seen.add(key)
            uniq.append(key)
    return uniq


def seed_schemas(schemas: Dict[str, Any]) -> None:
    """Prime the in-memory schema cache used for query planning."""

    if not isinstance(schemas, dict):
        return
    for url, schema in schemas.items():
        if not isinstance(url, str) or not schema:
            continue
        for key in _schema_keys(url):
            SCHEMA_CACHE[key] = schema


def _schema_for_target(target: str) -> Optional[Dict[str, Any]]:
    for key in _schema_keys(target):
        if key in SCHEMA_CACHE:
            return SCHEMA_CACHE[key]
    return None


async def _ensure_schema_cached(target: str) -> Optional[Dict[str, Any]]:
    """Ensure the introspection result for *target* is cached locally."""

    cached = _schema_for_target(target)
    if cached is not None:
        return cached

    try:
        schema = await try_introspect(target)
    except Exception:
        schema = None
    if schema:
        seed_schemas({target: schema})
        return schema
    return None


def _extract_root_types(schema: Dict[str, Any]) -> List[str]:
    names: List[str] = []
    data = schema.get("data") if isinstance(schema, dict) else None
    if isinstance(data, dict):
        schema_block = data.get("__schema")
        if isinstance(schema_block, dict):
            for key in ("queryType", "mutationType", "subscriptionType"):
                node = schema_block.get(key)
                if isinstance(node, dict):
                    name = node.get("name")
                    if isinstance(name, str) and name and not name.startswith("__"):
                        names.append(name)
    return names


def _extract_type_names(schema: Dict[str, Any]) -> List[str]:
    names: List[str] = []
    data = schema.get("data") if isinstance(schema, dict) else None
    if isinstance(data, dict):
        schema_block = data.get("__schema")
        if isinstance(schema_block, dict):
            types = schema_block.get("types")
            if isinstance(types, list):
                for entry in types:
                    if not isinstance(entry, dict):
                        continue
                    name = entry.get("name")
                    kind = entry.get("kind")
                    if not isinstance(name, str) or not name or name.startswith("__"):
                        continue
                    if kind not in {"OBJECT", "INTERFACE", "UNION", "ENUM"}:
                        continue
                    names.append(name)
    return names


def _render_type_query(name: str) -> str:
    safe = name.replace('"', '\\"')
    return (
        f'query __Introspect_{safe} '
        f'{{ __type(name: "{safe}") {{ name kind fields {{ name }} }} }}'
    )


def _is_typename_query(text: str) -> bool:
    try:
        compact = "".join(text.split()).lower()
    except Exception:
        return False
    return compact == "query{__typename}"


def schema_payloads_for(
    target: str,
    limit: int = 3,
    *,
    max_depth: int = 3,
    budget: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """Return GraphQL operation blueprints derived from cached schemas."""

    schema = _schema_for_target(target)
    if not schema:
        return []

    hard_limit = max(1, int(limit) if isinstance(limit, int) else 1)
    if budget is not None:
        try:
            hard_limit = max(1, min(hard_limit, int(budget)))
        except Exception:
            hard_limit = max(1, hard_limit)

    planned: List[Dict[str, Any]] = []
    try:
        from .runner import generate_candidates as _generate_candidates

        planned = _generate_candidates(
            schema, budget=hard_limit, max_depth=max_depth
        )
    except Exception:
        planned = []

    outputs: List[Dict[str, Any]] = []
    for cand in planned:
        if not isinstance(cand, dict):
            continue
        query = cand.get("query") or cand.get("payload")
        if not isinstance(query, str) or not query.strip():
            continue
        entry: Dict[str, Any] = {"payload": query}
        variables = cand.get("variables")
        if isinstance(variables, dict) and variables:
            entry["variables"] = variables
        op = cand.get("operation")
        if isinstance(op, str) and op:
            entry["operation"] = op
        outputs.append(entry)
        if len(outputs) >= hard_limit:
            break

    if outputs and all(_is_typename_query(entry.get("payload", "")) for entry in outputs):
        outputs = []

    if outputs:
        return outputs[:hard_limit]

    queries: List[str] = []
    seen: set[str] = set()

    for name in _extract_root_types(schema):
        if name in seen:
            continue
        queries.append(_render_type_query(name))
        seen.add(name)
        if len(queries) >= hard_limit:
            break

    for name in _extract_type_names(schema):
        if len(queries) >= hard_limit:
            break
        if name in seen:
            continue
        queries.append(_render_type_query(name))
        seen.add(name)

    if not queries:
        queries.append("query { __typename }")

    return [{"payload": q} for q in queries[:hard_limit]]


RETRY_STATUS = {429, 502, 503, 504}


def _coerce_positive_int(value: Any, default: int) -> int:
    try:
        ivalue = int(value)
    except Exception:
        return default
    return ivalue if ivalue > 0 else default


def _placeholder_for_type_hint(type_hint: str) -> Any:
    text = (type_hint or "String").strip()
    if not text:
        return "sample"
    while text.endswith("!"):
        text = text[:-1].strip()
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        return [_placeholder_for_type_hint(inner) or "sample"]
    mapping: Dict[str, Any] = {
        "STRING": "sample",
        "ID": "example-id",
        "INT": 1,
        "FLOAT": 0.5,
        "BOOLEAN": False,
        "JSON": {},
    }
    upper = text.upper()
    if upper in mapping:
        return mapping[upper]
    if text.endswith("Input"):
        return {}
    if upper in {"AWSJSON", "JSONB", "ANY"}:
        return {}
    return "sample"


def _infer_variables_from_hints(
    hints: Dict[str, Any], existing: Dict[str, Any]
) -> Dict[str, Any]:
    inferred: Dict[str, Any] = {}
    variables = hints.get("variables") if isinstance(hints, dict) else None
    if isinstance(variables, dict):
        for raw_name, type_hint in variables.items():
            name = raw_name.lstrip("$")
            if name in existing or name in inferred:
                continue
            inferred[name] = _placeholder_for_type_hint(str(type_hint))
    return inferred


async def _post_json(
    url: str,
    payload: Dict[str, Any],
    *,
    client: Optional[httpx.AsyncClient] = None,
    timeout: float = 12.0,
) -> httpx.Response:
    if client is not None:
        return await client.post(url, json=payload, timeout=timeout)
    async with httpx.AsyncClient(timeout=timeout) as owned:
        return await owned.post(url, json=payload)


async def graphql_probe(
    target: str,
    cand: Dict,
    mint,
    retries: int = 1,
    strategist_steps: int = 3,
    *,
    client: Optional[httpx.AsyncClient] = None,
) -> Dict | None:
    seed = cand.get("payload")
    canonical = "".join(seed.split()).lower() if isinstance(seed, str) else ""

    provided_vars = cand.get("variables") if isinstance(cand.get("variables"), dict) else {}
    variables: Dict[str, Any] = dict(provided_vars)
    inferred_variables: Dict[str, Any] = {}

    try:
        request_timeout = float(cand.get("timeout", 12.0))
    except Exception:
        request_timeout = 12.0
    if request_timeout <= 0:
        request_timeout = 12.0

    await _ensure_schema_cached(target)
    max_depth = _coerce_positive_int(cand.get("max_depth"), 3)
    budget = cand.get("budget")
    budget_int = None
    if budget is not None:
        budget_int = _coerce_positive_int(budget, 1)

    if not seed or canonical == "query{__typename}":
        limit = budget_int or 1
        tailored = schema_payloads_for(
            target,
            limit=limit,
            max_depth=max_depth,
            budget=budget_int,
        )
        if tailored:
            choice = tailored[0]
            if isinstance(choice, dict):
                alt = choice.get("payload") or choice.get("query")
                if isinstance(alt, str) and alt.strip():
                    seed = alt
                vars_candidate = choice.get("variables")
                if not variables and isinstance(vars_candidate, dict):
                    variables.update(vars_candidate)
            elif isinstance(choice, str) and choice.strip():
                seed = choice
    if not seed:
        seed = "query { __typename }"

    delay = 0.4
    penal: Optional[Dict[str, Any]] = None
    attempts = max(1, 1 + int(retries))
    for attempt in range(attempts):
        if attempt > 0:
            await asyncio.sleep(delay + random.uniform(0, 0.2))
            delay = min(2.5, delay * 1.8)
        try:
            errors_texts: List[str] = []
            hints: Dict[str, Any] = {}
            snippet = ""
            response_url = target
            status = None
            elapsed = 0.0
            for var_pass in range(2):
                payload: Dict[str, Any] = {"query": seed}
                if variables:
                    payload["variables"] = variables
                t1 = time.perf_counter()
                r = await _post_json(target, payload, client=client, timeout=request_timeout)
                status = getattr(r, "status_code", 200)
                elapsed = round(time.perf_counter() - t1, 3)
                if status in RETRY_STATUS:
                    penal = {"_penalize": delay, "_status": int(status), "_latency": elapsed}
                    if attempt < retries:
                        break
                txt = r.text or ""
                snippet = txt[:240]
                response_url = str(getattr(r, "url", target))
                ctype = r.headers.get("content-type", "") if hasattr(r, "headers") else ""
                body: Dict[str, Any] = {}
                if ctype.lower().startswith("application/json"):
                    try:
                        body = r.json()
                    except Exception:
                        body = {}
                errors_texts = []
                if isinstance(body, dict) and "errors" in body:
                    for e in body.get("errors") or []:
                        if isinstance(e, dict):
                            msg = e.get("message") or ""
                            if msg:
                                errors_texts.append(msg)
                hints = parse_hints(" ".join(errors_texts)) if errors_texts else {}
                if status == 200 and "__typename" in txt and not errors_texts:
                    evidence: Dict[str, Any] = {
                        "snippet": snippet,
                        "latency": elapsed,
                    }
                    if inferred_variables:
                        evidence["inferred_variables"] = inferred_variables
                    if hints:
                        evidence["hints"] = hints
                    evidence["status_code"] = status
                    return {
                        "target": target,
                        "vector": {"protocol": "graphql", "location": "body", "param": None},
                        "payload": seed,
                        "tool": "warprecon-m-graphql",
                        "evidence": evidence,
                        "severity": "medium",
                        "url": response_url,
                    }
                new_vars = _infer_variables_from_hints(hints, variables)
                if var_pass == 0 and new_vars:
                    variables.update(new_vars)
                    inferred_variables.update(new_vars)
                    continue
                break

            if penal and penal.get("_status") in RETRY_STATUS and attempt < retries:
                continue

            if errors_texts and strategist_steps > 0:
                plan = plan_queries(
                    seed,
                    errors_texts,
                    max_steps=max(1, int(strategist_steps)),
                    hints=hints,
                )
                seen = {seed}
                for q in plan:
                    if q in seen:
                        continue
                    seen.add(q)
                    payload = {"query": q}
                    t2 = time.perf_counter()
                    r2 = await _post_json(target, payload, client=client, timeout=request_timeout)
                    elapsed2 = round(time.perf_counter() - t2, 3)
                    txt2 = r2.text or ""
                    status2 = getattr(r2, "status_code", 200)
                    response_url2 = str(getattr(r2, "url", target))
                    if "__typename" in txt2 or status2 == 200:
                        evidence: Dict[str, Any] = {
                            "snippet": txt2[:240],
                            "latency": elapsed2,
                        }
                        if hints:
                            evidence["hints"] = hints
                        if inferred_variables:
                            evidence["inferred_variables"] = inferred_variables
                        evidence["status_code"] = status2
                        return {
                            "target": target,
                            "vector": {"protocol": "graphql", "location": "body", "param": None},
                            "payload": q,
                            "tool": "warprecon-m-graphql",
                            "evidence": evidence,
                            "severity": "medium",
                            "url": response_url2,
                        }
            break
        except Exception:
            penal = {"_penalize": delay, "_status": None, "_latency": delay}
            if attempt < retries:
                continue
            break
    return penal
