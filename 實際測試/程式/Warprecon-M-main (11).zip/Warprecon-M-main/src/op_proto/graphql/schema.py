from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, Iterable, List, Optional, Sequence, Set

import httpx

_INTROSPECT = {
    "query": """
    query Introspect {
      __schema {
        queryType { name }
        mutationType { name }
        subscriptionType { name }
        types {
          kind
          name
          fields(includeDeprecated: true) {
            name
            args {
              name
              defaultValue
              type {
                kind
                name
                ofType {
                  kind
                  name
                  ofType {
                    kind
                    name
                    ofType {
                      kind
                      name
                      ofType {
                        kind
                        name
                      }
                    }
                  }
                }
              }
            }
            type {
              kind
              name
              ofType {
                kind
                name
                ofType {
                  kind
                  name
                  ofType {
                    kind
                    name
                    ofType {
                      kind
                      name
                    }
                  }
                }
              }
            }
          }
          inputFields {
            name
            defaultValue
            type {
              kind
              name
              ofType {
                kind
                name
                ofType {
                  kind
                  name
                  ofType {
                    kind
                    name
                    ofType {
                      kind
                      name
                    }
                  }
                }
              }
            }
          }
          enumValues(includeDeprecated: true) {
            name
          }
          possibleTypes {
            kind
            name
          }
        }
      }
    }
    """.strip(),
    "variables": None,
}


@dataclass
class TypeRef:
    """GraphQL type reference as described by the introspection schema."""

    kind: str
    name: Optional[str] = None
    of_type: Optional["TypeRef"] = None

    def unwrap(self) -> "TypeRef":
        node: TypeRef = self
        while node.kind in {"NON_NULL", "LIST"} and node.of_type is not None:
            node = node.of_type
        return node

    def render(self) -> str:
        if self.kind == "NON_NULL":
            inner = self.of_type.render() if self.of_type else "String"
            return inner.rstrip("!") + "!"
        if self.kind == "LIST":
            inner = self.of_type.render() if self.of_type else "String"
            return f"[{inner}]"
        return self.name or self.kind or "String"


@dataclass
class GraphQLArgument:
    name: str
    type: TypeRef
    default_value: Optional[str] = None


@dataclass
class GraphQLField:
    name: str
    type: TypeRef
    args: Dict[str, GraphQLArgument] = field(default_factory=dict)


@dataclass
class GraphQLType:
    name: str
    kind: str
    fields: Dict[str, GraphQLField] = field(default_factory=dict)
    input_fields: Dict[str, GraphQLArgument] = field(default_factory=dict)
    enum_values: List[str] = field(default_factory=list)
    possible_types: List[str] = field(default_factory=list)


@dataclass
class GraphQLSchema:
    types: Dict[str, GraphQLType]
    query_type: Optional[str]
    mutation_type: Optional[str]
    subscription_type: Optional[str]

    def get_type(self, name: Optional[str]) -> Optional[GraphQLType]:
        if not name:
            return None
        return self.types.get(name)

    @classmethod
    def from_introspection(cls, payload: Dict[str, Any]) -> "GraphQLSchema":
        schema_data = _locate_schema(payload)
        if not schema_data:
            raise ValueError("Missing __schema section")
        types: Dict[str, GraphQLType] = {}
        for entry in schema_data.get("types", []) or []:
            name = entry.get("name")
            kind = entry.get("kind") or "OBJECT"
            if not name or name.startswith("__"):
                continue
            gql_type = GraphQLType(name=name, kind=kind)
            gql_type.fields = {
                field_data["name"]: _parse_field(field_data)
                for field_data in _iter_valid(entry.get("fields"))
                if field_data.get("name")
            }
            gql_type.input_fields = {
                input_data["name"]: _parse_argument(input_data)
                for input_data in _iter_valid(entry.get("inputFields"))
                if input_data.get("name")
            }
            gql_type.enum_values = [
                enum.get("name")
                for enum in _iter_valid(entry.get("enumValues"))
                if enum.get("name")
            ]
            gql_type.possible_types = [
                possible.get("name")
                for possible in _iter_valid(entry.get("possibleTypes"))
                if possible.get("name")
            ]
            types[name] = gql_type
        return cls(
            types=types,
            query_type=_type_name(schema_data.get("queryType")),
            mutation_type=_type_name(schema_data.get("mutationType")),
            subscription_type=_type_name(schema_data.get("subscriptionType")),
        )


def _iter_valid(value: Optional[Iterable[Any]]) -> Iterable[Any]:
    if value is None:
        return []
    return value


def _type_name(data: Optional[Dict[str, Any]]) -> Optional[str]:
    if not isinstance(data, dict):
        return None
    return data.get("name")


def _parse_type(node: Optional[Dict[str, Any]]) -> TypeRef:
    if not isinstance(node, dict):
        return TypeRef(kind="SCALAR", name="String")
    return TypeRef(
        kind=node.get("kind") or "SCALAR",
        name=node.get("name"),
        of_type=_parse_type(node.get("ofType")) if node.get("ofType") else None,
    )


def _parse_argument(data: Dict[str, Any]) -> GraphQLArgument:
    return GraphQLArgument(
        name=data.get("name", "arg"),
        type=_parse_type(data.get("type")),
        default_value=data.get("defaultValue"),
    )


def _parse_field(data: Dict[str, Any]) -> GraphQLField:
    field = GraphQLField(name=data.get("name", "field"), type=_parse_type(data.get("type")))
    field.args = {
        arg_data.get("name", "arg"): _parse_argument(arg_data)
        for arg_data in _iter_valid(data.get("args"))
        if arg_data.get("name")
    }
    return field


def _locate_schema(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if "__schema" in payload:
        candidate = payload.get("__schema")
        if isinstance(candidate, dict):
            return candidate
    data = payload.get("data")
    if isinstance(data, dict):
        schema = data.get("__schema")
        if isinstance(schema, dict):
            return schema
    return None


_IntrospectionCall = Callable[[httpx.AsyncClient, str], Awaitable[httpx.Response]]


@dataclass(frozen=True)
class IntrospectionStrategy:
    """Encapsulates an HTTP transport used during introspection."""

    name: str
    execute: _IntrospectionCall


async def _introspect_via_post_json(client: httpx.AsyncClient, url: str) -> httpx.Response:
    return await client.post(url, json=_INTROSPECT)


async def _introspect_via_post_graphql(client: httpx.AsyncClient, url: str) -> httpx.Response:
    headers = {"Content-Type": "application/graphql"}
    return await client.post(url, content=_INTROSPECT["query"], headers=headers)


async def _introspect_via_get(client: httpx.AsyncClient, url: str) -> httpx.Response:
    return await client.get(url, params={"query": _INTROSPECT["query"]})


DEFAULT_INTROSPECTION_STRATEGIES: tuple[IntrospectionStrategy, ...] = (
    IntrospectionStrategy("post-json", _introspect_via_post_json),
    IntrospectionStrategy("post-graphql", _introspect_via_post_graphql),
    IntrospectionStrategy("get", _introspect_via_get),
)


async def try_introspect(
    url: str,
    timeout: float = 8.0,
    strategies: Optional[Sequence[IntrospectionStrategy]] = None,
) -> dict | None:
    """Attempt GraphQL introspection against *url* using the provided strategies."""

    selected = tuple(strategies) if strategies is not None else DEFAULT_INTROSPECTION_STRATEGIES

    try:
        async with httpx.AsyncClient(
            timeout=timeout,
            headers={
                "Accept": "application/graphql-response+json, application/json;q=0.9",
            },
        ) as client:
            for strategy in selected:
                try:
                    response = await strategy.execute(client, url)
                except Exception:
                    continue
                payload = _extract_introspection_payload(response)
                if payload is not None:
                    return payload
    except Exception:
        return None
    return None


def _extract_introspection_payload(response: httpx.Response) -> Optional[dict]:
    if response.status_code not in {200, 400}:
        return None
    content_type = response.headers.get("content-type", "").lower()
    if content_type and "json" not in content_type and "graphql" not in content_type:
        return None
    try:
        payload = response.json()
    except Exception:
        return None
    if isinstance(payload, dict) and ("data" in payload or "errors" in payload):
        return payload
    if isinstance(payload, dict) and "__schema" in payload:
        return payload
    return None


def render_selection(
    schema: GraphQLSchema,
    type_ref: TypeRef,
    depth: int = 1,
    max_depth: int = 3,
    visited: Optional[Set[str]] = None,
) -> List[str]:
    base = type_ref.unwrap()
    if not base.name or base.kind in {"SCALAR", "ENUM"}:
        return []
    if visited is None:
        visited = set()
    if base.name in visited or depth > max_depth:
        return ["  " * depth + "__typename"]
    visited = set(visited)
    visited.add(base.name)
    gql_type = schema.get_type(base.name)
    indent = "  " * depth
    lines: List[str] = [f"{indent}__typename"]
    if not gql_type:
        return lines

    if base.kind == "UNION":
        added = 0
        for name in gql_type.possible_types:
            if not name:
                continue
            frag_ref = TypeRef(kind="OBJECT", name=name)
            frag_lines = render_selection(
                schema,
                frag_ref,
                depth=depth + 1,
                max_depth=max_depth,
                visited=visited,
            )
            lines.append(f"{indent}... on {name} {{")
            if frag_lines:
                lines.extend(frag_lines)
            else:
                lines.append("  " * (depth + 1) + "__typename")
            lines.append(f"{indent}}}")
            added += 1
            if added >= 3:
                break
        return lines

    count = 0
    if gql_type.fields:
        for field in gql_type.fields.values():
            if field.name.startswith("__"):
                continue
            if field.args:
                continue
            field_base = field.type.unwrap()
            if field_base.kind in {"OBJECT", "INTERFACE", "UNION"} and field_base.name:
                sub_lines = render_selection(
                    schema,
                    field.type,
                    depth=depth + 1,
                    max_depth=max_depth,
                    visited=visited,
                )
                if sub_lines:
                    lines.append(f"{indent}{field.name} {{")
                    lines.extend(sub_lines)
                    lines.append(f"{indent}}}")
            else:
                lines.append(f"{indent}{field.name}")
            count += 1
            if count >= 4:
                break

    if base.kind == "INTERFACE" and gql_type.possible_types:
        frag_added = 0
        for name in gql_type.possible_types:
            if not name or name in visited:
                continue
            frag_ref = TypeRef(kind="OBJECT", name=name)
            frag_lines = render_selection(
                schema,
                frag_ref,
                depth=depth + 1,
                max_depth=max_depth,
                visited=visited,
            )
            lines.append(f"{indent}... on {name} {{")
            if frag_lines:
                lines.extend(frag_lines)
            else:
                lines.append("  " * (depth + 1) + "__typename")
            lines.append(f"{indent}}}")
            frag_added += 1
            if frag_added >= 2:
                break

    return lines
