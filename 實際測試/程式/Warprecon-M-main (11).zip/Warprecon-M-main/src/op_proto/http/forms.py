from __future__ import annotations
from typing import List, Dict, Tuple
import re
from urllib.parse import urljoin

_FORM_RE = re.compile(r'(?is)<form[^>]*action=["\']?([^"\' >]+)?[^>]*>(.*?)</form>')
_INPUT_RE = re.compile(r'(?is)<input[^>]*name=["\']([^"\']+)["\'][^>]*value=["\']?([^"\']*)["\']?[^>]*>')

def parse_forms(html: str, base: str) -> List[Dict]:
    forms: List[Dict] = []
    for m in _FORM_RE.findall(html):
        action, inner = m
        inputs = {n: v for (n, v) in _INPUT_RE.findall(inner)}
        forms.append({"action": urljoin(base, action or ""), "inputs": inputs})
    return forms

def guess_csrf_name(inputs: Dict[str, str]) -> str|None:
    keys = list(inputs.keys())
    for k in keys:
        lk = k.lower()
        if "csrf" in lk or "token" in lk or "auth" in lk:
            return k
    return None
