from __future__ import annotations

import asyncio
import copy
import json
import random
import secrets
import time
import urllib.parse
from typing import Any, Dict, Optional

import httpx

from op_forms.simple import extract_csrf_tokens

RETRY_STATUS = {429, 502, 503, 504}

def _compose_url(base: str, cand: Dict, payload: Optional[str]) -> str:
    u = urllib.parse.urlparse(base)
    loc = cand.get("location")
    if loc == "query":
        pname = cand.get("param", "q")
        value = urllib.parse.quote_plus(payload or "", safe="%&=:/")
        q = f"{u.query}&{pname}={value}" if u.query else f"{pname}={value}"
        return urllib.parse.urlunparse(
            (u.scheme, u.netloc, u.path, u.params, q, u.fragment)
        )
    if loc == "path":
        base_path = u.path or "/"
        if payload:
            if not base_path.endswith("/"):
                base_path = base_path.rstrip("/") + "/"
            segment = urllib.parse.quote(payload, safe="%:@/")
            path = base_path + segment
        else:
            path = base_path
        return urllib.parse.urlunparse(
            (u.scheme, u.netloc, path, u.params, u.query, u.fragment)
        )
    return base


def _normalise_json_ctx(raw: Any) -> Dict[str, Any]:
    if isinstance(raw, dict):
        try:
            return copy.deepcopy(raw)
        except Exception:
            return dict(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = None
        if isinstance(parsed, dict):
            return parsed
    return {}


def _assign_json_path(target: Dict[str, Any], path: str, value: Any) -> Dict[str, Any]:
    if not isinstance(target, dict):
        target = {}
    if not path:
        return target
    # translate foo[0].bar to ["foo", "0", "bar"]
    segments = []
    for chunk in path.replace("[", ".").replace("]", ".").split("."):
        if chunk:
            segments.append(chunk)
    if not segments:
        return target
    cursor: Any = target
    for idx, segment in enumerate(segments):
        is_last = idx == len(segments) - 1
        next_segment = segments[idx + 1] if not is_last else None
        if isinstance(cursor, dict):
            if is_last:
                cursor[segment] = value
                break
            container = cursor.get(segment)
            if isinstance(container, (dict, list)):
                cursor = container
                continue
            if next_segment and next_segment.isdigit():
                cursor[segment] = []
            else:
                cursor[segment] = {}
            cursor = cursor[segment]
        elif isinstance(cursor, list):
            if not segment.isdigit():
                break
            list_index = int(segment)
            while len(cursor) <= list_index:
                cursor.append({})
            if is_last:
                cursor[list_index] = value
                break
            container = cursor[list_index]
            if not isinstance(container, (dict, list)):
                if next_segment and next_segment.isdigit():
                    container = []
                else:
                    container = {}
                cursor[list_index] = container
            cursor = cursor[list_index]
        else:
            break
    return target


def _apply_transform(transform: Optional[str], value: str) -> str:
    if not transform or transform in {"identity", "form_ctx"}:
        return value
    try:  # pragma: no cover - optional dependency path
        from op_synth import synth

        func = getattr(synth, transform, None)
        if callable(func):
            return str(func(value))
        func = synth.TRANSFORMS.get(transform)
        if callable(func):
            return str(func(value))
    except Exception:
        return value
    return value


def _mint_token(mint) -> str:
    if hasattr(mint, "mint"):
        try:
            return str(mint.mint("s"))
        except Exception:
            pass
    return f"s{secrets.token_hex(6)}.disabled"


def _ssrf_payload(cand: Dict, mint) -> tuple[str, Dict[str, object]]:
    raw = cand.get("payload") if isinstance(cand.get("payload"), str) else ""
    token = _mint_token(mint)
    scheme = "http"
    if isinstance(raw, str):
        lower = raw.lower()
        if lower.startswith("https://"):
            scheme = "https"
        elif lower.startswith("http://"):
            scheme = "http"
    url_value = f"{scheme}://{token}/"
    payload_value = url_value
    if raw:
        for placeholder in ("{token}", "{{token}}", "{oob}", "{{oob}}", "{url}"):
            if placeholder in raw:
                replacement = token if "token" in placeholder else url_value
                payload_value = raw.replace(placeholder, replacement)
                break
    if payload_value == url_value and raw and "://" in raw:
        parsed = urllib.parse.urlsplit(raw)
        netloc = token
        if parsed.port:
            netloc = f"{token}:{parsed.port}"
        path = parsed.path or "/"
        payload_value = urllib.parse.urlunsplit(
            (parsed.scheme or scheme, netloc, path, parsed.query, parsed.fragment)
        )
    payload_value = _apply_transform(cand.get("transform"), payload_value)
    evidence = {"oob_token": token, "transform": cand.get("transform")}
    return payload_value, evidence

def _allow_by_ctype(mode: str, ctype: str, txt_hint: str) -> bool:
    ctype = (ctype or '').lower()
    if mode == 'xss':
        return ('text/html' in ctype) or ('xhtml' in ctype) or ('<html' in (txt_hint or '').lower())
    if mode == 'sqli':
        return ('text/html' in ctype) or ('json' in ctype) or (not ctype)
    return True

async def http_probe(target: str, cand: Dict, mint, client: httpx.AsyncClient, retries: int = 1) -> Dict | None:
    headers: Dict[str, str] = {}
    cookies: Dict[str, str] = {}
    base_headers = cand.get("headers") if isinstance(cand.get("headers"), dict) else None
    if isinstance(base_headers, dict):
        for key, value in base_headers.items():
            if not isinstance(key, str) or value is None:
                continue
            headers[key] = str(value)
    base_cookies = cand.get("cookies") if isinstance(cand.get("cookies"), dict) else None
    if isinstance(base_cookies, dict):
        for key, value in base_cookies.items():
            if not isinstance(key, str) or value is None:
                continue
            cookies[key] = str(value)
    baseline_headers = dict(headers)
    baseline_cookies = dict(cookies)
    data = None
    json_payload = None
    baseline_data: Optional[Dict[str, Any]] = None
    baseline_json: Optional[Dict[str, Any]] = None
    baseline_url = target
    mode = str(cand.get("mode") or "").lower()
    loc = cand.get("location")

    original_payload = cand.get("payload")
    payload_text = original_payload if isinstance(original_payload, str) else str(original_payload or "")
    ssrf_evidence: Optional[Dict[str, object]] = None
    if mode == "ssrf":
        payload_text, ssrf_evidence = _ssrf_payload(cand, mint)

    ssrf_payload = payload_text if mode == "ssrf" else None

    url = _compose_url(target, cand, payload_text)

    # form context handling
    form_ctx = cand.get("form_ctx") if isinstance(cand.get("form_ctx"), dict) else None
    if loc == "header" and cand.get("param"):
        headers[cand["param"]] = payload_text
    elif loc == "cookie" and cand.get("param"):
        cookies[cand["param"]] = payload_text
    elif loc == "form":
        pname = cand.get("param", "q")
        data = {}
        if form_ctx and isinstance(form_ctx.get("inputs"), list):
            # keep original values, override target field with payload, include CSRF tokens
            for inp in form_ctx["inputs"]:
                n = inp.get("name")
                v = inp.get("value", "")
                if not n:
                    continue
                data[n] = v
            tokens = extract_csrf_tokens(form_ctx["inputs"])
            data.update(tokens)
            baseline_data = dict(data)
            data[pname] = payload_text
        else:
            baseline_data = {pname: ""}
            data = {pname: payload_text}
        # if action differs from base, send to action url
        if form_ctx and form_ctx.get("action"):
            url = form_ctx["action"]
            baseline_url = form_ctx["action"]
    elif loc == "json":
        base_json = _normalise_json_ctx(cand.get("json_ctx"))
        pname = cand.get("param", "q")
        baseline_json = copy.deepcopy(base_json)
        json_payload = _assign_json_path(copy.deepcopy(base_json), pname, payload_text)
    else:
        if form_ctx and isinstance(form_ctx.get("inputs"), list) and not baseline_data:
            tokens = extract_csrf_tokens(form_ctx["inputs"])
            if tokens:
                baseline_data = dict(tokens)

    ssrf_sent = False

    method = str(
        cand.get(
            "method",
            "post" if data is not None or json_payload is not None else "get",
        )
        or "get"
    ).lower()

    try:
        request_timeout = float(cand.get("timeout", 12.0))
    except Exception:
        request_timeout = 12.0
    if request_timeout <= 0:
        request_timeout = 12.0

    request_kwargs: Dict[str, Any] = {
        "headers": headers,
        "cookies": cookies,
        "timeout": request_timeout,
    }
    if data is not None:
        request_kwargs["data"] = data
    if json_payload is not None:
        request_kwargs["json"] = json_payload

    baseline_kwargs: Dict[str, Any] = {
        "headers": dict(baseline_headers),
        "cookies": dict(baseline_cookies),
        "timeout": request_timeout,
    }
    if baseline_data is not None:
        baseline_kwargs["data"] = baseline_data
    if baseline_json is not None:
        baseline_kwargs["json"] = baseline_json

    base_len = 0
    ctype0 = ""
    r0 = None
    try:
        if hasattr(client, "request"):
            r0 = await client.request(method.upper(), baseline_url, **baseline_kwargs)
        else:
            request_func = getattr(client, method.lower())
            r0 = await request_func(baseline_url, **baseline_kwargs)
        base_len = len(getattr(r0, "text", "") or "")
        ctype0 = getattr(r0, "headers", {}).get("content-type", "")
        baseline_status = getattr(r0, "status_code", None)
    except Exception:
        baseline_status = None

    if (
        r0 is None
        or (baseline_status in {405, 415, 501} and method.upper() != "GET")
    ):
        try:
            r0 = await client.get(
                target,
                headers=dict(baseline_headers),
                cookies=dict(baseline_cookies),
                timeout=min(request_timeout, 8.0),
            )
            base_len = len(getattr(r0, "text", "") or "")
            ctype0 = getattr(r0, "headers", {}).get("content-type", "")
        except Exception:
            r0 = None
            base_len = 0
            ctype0 = ""

    if not _allow_by_ctype(mode or "", ctype0, getattr(r0, "text", "")):
        return None

    delay = 0.4
    penal = None
    response_url = url
    for attempt in range(max(1, 1 + int(retries))):
        if attempt > 0:
            await asyncio.sleep(delay + random.uniform(0, 0.2))
            delay = min(2.5, delay * 1.8)

        try:
            t1 = time.perf_counter()
            if hasattr(client, "request"):
                r = await client.request(method.upper(), url, **request_kwargs)
            else:
                request_func = getattr(client, method.lower())
                r = await request_func(url, **request_kwargs)
            status = getattr(r, "status_code", 200)
            response_url = str(getattr(r, "url", url))
            dt = time.perf_counter() - t1
            elapsed = round(dt, 3)
            if status in RETRY_STATUS:
                penal = {"_penalize": delay, "_status": int(status), "_latency": elapsed}
                if attempt < retries:
                    continue
            txt = (r.text or "").lower()
            hit = False
            ev = {"time_delta": elapsed, "transform": cand.get("transform"), "status_code": status}
            ev["method"] = method.upper()
            if mode == "xss" and ("<script>" in txt or "onload=" in txt):
                hit = True
                ev["snippet"] = r.text[:200]
                ev["len_delta"] = len(r.text) - base_len
            if mode == "sqli" and any(k in txt for k in ["syntax", "sql", "mysql", "postgres", "sqlite"]):
                hit = True
                ev["snippet"] = r.text[:200]
                ev["len_delta"] = len(r.text) - base_len
            if mode == "ssrf":
                ssrf_sent = True
                if ssrf_evidence is None:
                    ssrf_evidence = {"transform": cand.get("transform")}
                body_text = r.text or ""
                ssrf_evidence["time_delta"] = elapsed
                ssrf_evidence["status_code"] = status
                ssrf_evidence["len_delta"] = len(body_text) - base_len
                if body_text:
                    ssrf_evidence["snippet"] = body_text[:200]
                ssrf_evidence["method"] = method.upper()
            if hit:
                payload_value = ssrf_payload if ssrf_payload is not None else payload_text
                severity = "medium" if mode == "xss" else "high"
                return {
                    "target": target,
                    "vector": {"protocol": "http", "location": loc, "param": cand.get("param")},
                    "payload": payload_value,
                    "tool": "warprecon-m-http",
                    "evidence": ev,
                    "severity": severity,
                    "url": response_url,
                }
            break
        except Exception:
            penal = {"_penalize": delay, "_status": None, "_latency": delay}
            if attempt < retries:
                continue
            break
    if mode == "ssrf" and ssrf_payload:
        if ssrf_sent:
            evidence = ssrf_evidence or {
                "transform": cand.get("transform"),
                "method": method.upper(),
            }
            return {
                "target": target,
                "vector": {"protocol": "http", "location": loc, "param": cand.get("param")},
                "payload": ssrf_payload,
                "tool": "warprecon-m-http",
                "evidence": evidence,
                "severity": "info",
                "url": response_url,
            }
        return penal
    return penal
