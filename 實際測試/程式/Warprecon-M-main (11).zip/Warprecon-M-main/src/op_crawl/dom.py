from __future__ import annotations
from typing import Dict, Iterable, List, Set, Tuple
from urllib.parse import urlparse, urljoin

from op_core.endpoint_heuristics import extract_request_matches

def _same_host(u: str, host: str) -> bool:
    try:
        return urlparse(u).netloc.split(':')[0].lower() == host.lower()
    except Exception:
        return False

def _extract_endpoints(html: str, base: str, host: str) -> List[str]:
    out: List[str] = []
    for raw in extract_request_matches(html):
        u = urljoin(base, raw)
        if _same_host(u, host):
            out.append(u)
    return list(dict.fromkeys(out))

def render_discover(url: str, max_pages: int = 6, wait_ms: int = 800) -> Tuple[List[str], Dict]:
    """
    Best-effort DOM discovery using Playwright (if available). Returns (endpoints, details).
    details: { 'pages': [], 'errors': [] }
    """
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception:
        return [], {"note": "playwright not installed"}

    from urllib.parse import urlparse
    host = urlparse(url).netloc.split(':')[0]
    pages_seen = 0
    endpoints: List[str] = []
    endpoint_seen: Set[str] = set()
    request_urls: List[str] = []
    processed_requests = 0
    details = {"pages": [], "errors": []}

    def _record_endpoints(values: Iterable[str]) -> List[str]:
        collected: List[str] = []
        for value in values:
            if not value:
                continue
            if value not in collected:
                collected.append(value)
            if value not in endpoint_seen:
                endpoint_seen.add(value)
                endpoints.append(value)
        return collected

    def _on_request(request) -> None:  # type: ignore[no-untyped-def]
        try:
            u = getattr(request, "url", "")
        except Exception:
            u = ""
        if not u:
            return
        if _same_host(u, host):
            request_urls.append(u)
            _record_endpoints([u])

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(ignore_https_errors=True)
            page = context.new_page()
            try:
                page.on("request", _on_request)
            except Exception:
                pass
            page.goto(url, wait_until="domcontentloaded")
            def _harvest():
                nonlocal processed_requests
                html = page.content()
                eps = _extract_endpoints(html, str(page.url), host)
                new_requests = request_urls[processed_requests:]
                processed_requests = len(request_urls)
                network_eps = list(dict.fromkeys(new_requests))
                combined = _record_endpoints(list(dict.fromkeys(eps + network_eps)))
                details["pages"].append({"url": str(page.url), "endpoints": combined[:50]})
            _harvest()
            # Click simple anchors and SPA links (limited to same host, anchor clicks)
            anchors = page.query_selector_all("a[href]")
            for a in anchors[:max_pages-1]:
                try:
                    href = a.get_attribute("href") or ""
                    if not href: continue
                    from urllib.parse import urljoin
                    absu = urljoin(str(page.url), href)
                    if not _same_host(absu, host): continue
                    a.click()
                    page.wait_for_timeout(wait_ms)
                    _harvest()
                    pages_seen += 1
                    if pages_seen >= max_pages: break
                except Exception as ex:
                    details["errors"].append(str(ex))
            browser.close()
    except Exception as ex:
        details["errors"].append(str(ex))
    return endpoints, details
