from __future__ import annotations

import base64
import logging
import secrets
import time
from typing import Any, Dict, Iterable, List, Mapping, Optional

from op_core.finding_contract import Finding, as_finding

try:  # pragma: no cover - optional dependency
    import httpx
except Exception:  # pragma: no cover - optional dependency
    httpx = None  # type: ignore[assignment]

try:  # pragma: no cover - optional dependency
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa

    _HAS_CRYPTO = True
except Exception:  # pragma: no cover - optional dependency
    _HAS_CRYPTO = False


logger = logging.getLogger(__name__)


class InteractClient:
    """Client for interacting with Interactsh-compatible services."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        use_rsa: bool = True,
    ) -> None:
        self.base_url = (base_url or "").rstrip("/")
        self.api_key = api_key or ""
        self.enabled = bool(self.base_url and httpx is not None)
        self.domain: Optional[str] = None
        self._registered = False
        self._tokens: Dict[str, Dict[str, Any]] = {}
        self._events: List[Dict[str, Any]] = []
        self._last_poll = 0.0
        self._corr_id = secrets.token_hex(8)
        self._secret = secrets.token_hex(12)
        self._use_rsa = bool(use_rsa and _HAS_CRYPTO)
        self._priv_pem: Optional[bytes] = None
        self._pub_pem: Optional[bytes] = None

        if self._use_rsa:
            try:
                key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
                self._priv_pem = key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption(),
                )
                self._pub_pem = key.public_key().public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo,
                )
            except Exception:  # pragma: no cover - unexpected optional failure
                self._use_rsa = False
                self._priv_pem = None
                self._pub_pem = None

    # ------------------------------------------------------------------
    # HTTP helpers -----------------------------------------------------
    def _headers(self) -> Dict[str, str]:
        headers = {"accept": "application/json"}
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"
        headers["x-correlation-id"] = self._corr_id
        headers["x-secret"] = self._secret
        return headers

    def register(self) -> None:
        if not self.enabled or self._registered or httpx is None:
            return

        try:
            url = f"{self.base_url}/register"
            payload: Dict[str, str] = {
                "secret": self._secret,
                "correlation-id": self._corr_id,
            }
            if self._use_rsa and self._pub_pem:
                payload["public-key"] = base64.b64encode(self._pub_pem).decode("ascii")

            with httpx.Client(timeout=6.0) as client:  # type: ignore[operator]
                response = client.post(url, json=payload, headers=self._headers())
                if response.status_code == 200:
                    data = response.json()
                    self.domain = (
                        data.get("domain")
                        or data.get("oob_domain")
                        or data.get("subdomain")
                        or self.domain
                    )
                if not self.domain:
                    from urllib.parse import urlparse

                    parsed = urlparse(self.base_url)
                    self.domain = parsed.netloc or "oob.local"

            self._registered = True
        except httpx.RequestError as exc:  # type: ignore[attr-defined]
            logger.warning("Interactsh register failed: %s", exc)
            self.enabled = False
            self._registered = False
            self.domain = None
        except Exception as exc:  # pragma: no cover - unexpected failure
            logger.exception("Unexpected Interactsh register error: %s", exc)
            self.enabled = False
            self._registered = False
            self.domain = None

    # ------------------------------------------------------------------
    # Public API -------------------------------------------------------
    def mint(self, prefix: Optional[str] = None) -> str:
        label = f"{prefix or 't'}{secrets.token_hex(6)}"
        if self.enabled and not self._registered:
            self.register()

        if self.enabled and self.domain:
            fqdn = f"{label}.{self.domain}"
        else:
            fqdn = f"{label}.disabled"

        self._tokens[label] = {"fqdn": fqdn, "created_at": time.time(), "hits": []}
        return fqdn

    def _flex_poll(self) -> List[Dict[str, Any]]:
        if not self.enabled or not self._registered or httpx is None:
            return []

        def _normalise(payload: Any) -> List[Dict[str, Any]]:
            if not isinstance(payload, dict):
                return []
            items = (
                payload.get("events")
                or payload.get("records")
                or payload.get("data")
                or []
            )
            normalised: List[Dict[str, Any]] = []
            for entry in items:
                if not isinstance(entry, dict):
                    continue
                host = entry.get("host") or entry.get("full-id") or entry.get("domain") or ""
                ip = entry.get("remote_addr") or entry.get("remote-address") or entry.get("ip") or ""
                protocol = entry.get("protocol") or entry.get("type") or "http"
                request = entry.get("request") or entry.get("raw-request") or ""
                normalised.append(
                    {
                        "host": host,
                        "ip": ip,
                        "protocol": protocol,
                        "request": request,
                        "raw": entry,
                    }
                )
            return normalised

        headers = self._headers()
        query = {"id": self._corr_id, "secret": self._secret}

        try:
            with httpx.Client(timeout=6.0) as client:  # type: ignore[operator]
                try:
                    response = client.get(f"{self.base_url}/poll", params=query, headers=headers)
                    if response.status_code == 200:
                        events = _normalise(response.json())
                        if events:
                            return events
                except httpx.RequestError as exc:  # type: ignore[attr-defined]
                    logger.warning("Interactsh poll GET failed: %s", exc)

                try:
                    response = client.post(f"{self.base_url}/poll", json=query, headers=headers)
                    if response.status_code == 200:
                        events = _normalise(response.json())
                        if events:
                            return events
                except httpx.RequestError as exc:  # type: ignore[attr-defined]
                    logger.warning("Interactsh poll POST failed: %s", exc)
        except Exception as exc:  # pragma: no cover - unexpected failure
            logger.exception("Interactsh poll client error: %s", exc)

        return []

    def poll(self) -> List[Dict[str, Any]]:
        now = time.time()
        if now - self._last_poll < 2.0:
            return []
        self._last_poll = now

        try:
            events = self._flex_poll()
        except Exception as exc:  # pragma: no cover - defensive guard
            logger.exception("Interactsh poll error: %s", exc)
            events = []

        if events:
            self._events.extend(events)
            for label, meta in self._tokens.items():
                hits = meta.setdefault("hits", [])
                for event in events:
                    host = event.get("host") or ""
                    if label and label in host:
                        hits.append(event)
        return events

    def correlate_findings(
        self, findings: Iterable[Mapping[str, Any] | Finding]
    ) -> List[Finding]:
        updated: List[Finding] = []
        label_hits: Dict[str, List[Dict[str, Any]]] = {}
        fqdn_hits: Dict[str, List[Dict[str, Any]]] = {}

        for label, meta in self._tokens.items():
            hits = list(meta.get("hits") or [])
            if not hits:
                continue
            label_hits[label] = hits
            fqdn = meta.get("fqdn")
            if isinstance(fqdn, str):
                fqdn_hits[fqdn] = hits

        for raw in findings:
            finding = as_finding(raw)
            evidence = finding.get("evidence") or {}
            token = evidence.get("oob_token") or ""
            label = token.split(".", 1)[0] if token else ""
            hits = label_hits.get(label) or fqdn_hits.get(token) or []
            if hits:
                new_evidence = dict(evidence)
                new_evidence["oob_events"] = hits
                finding["evidence"] = new_evidence

                severity = (finding.get("severity") or "").lower()
                if severity in {"", "low", "medium", "high"}:
                    finding["severity"] = "critical"
                finding["_oob_verified"] = True
            updated.append(finding)

        return updated

    def export_events(self) -> Dict[str, Any]:
        return {
            "tokens": self._tokens,
            "events": self._events,
            "domain": self.domain,
            "enabled": self.enabled,
            "corr_id": self._corr_id,
        }


__all__ = ["InteractClient"]
