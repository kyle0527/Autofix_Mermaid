"""Prioritize targets based on HTTP protocol support."""

from __future__ import annotations
from urllib.parse import urlparse
from pathlib import Path
import json


def _host(u: str) -> str:
    try:
        return urlparse(u).netloc or ""
    except Exception:
        return ""


def post_rank(ranked):
    """Boost scores for HTTP/2 and HTTP/3 capable hosts.

    Args:
        ranked (list[dict]): Ranked results with ``url`` or ``target`` fields and
            optional ``_score`` values.

    Returns:
        list[dict]: Ranked results sorted by updated ``_score`` and annotated with
        new ``_rank`` values.
    """

    # Read discovery/http-capabilities.json if exists and bump scores for h2/h3 targets
    try:
        # guess workdir by traversing up from first item's url/target (not trivial); rely on env: pass via evidence if needed
        # Simpler: try typical locations
        caps_path = None
        for base in ["work/upgrade", "work"]:  # best-effort
            p = Path(base)
            if p.exists():
                for c in p.rglob("http-capabilities.json"):
                    caps_path = c
                    break
            if caps_path:
                break
        if not caps_path:
            return ranked
        caps = json.loads(caps_path.read_text(encoding="utf-8"))
        hostmap = {}
        for it in caps:
            h = _host(it.get("url", ""))
            if h:
                hostmap[h] = {"http2": bool(it.get("http2")), "http3": bool(it.get("http3_hint"))}
        for f in ranked:
            u = f.get("url") or f.get("target") or ""
            h = _host(u)
            info = hostmap.get(h)
            if not info:
                continue
            bump = 0.0
            if info.get("http2"):
                bump += 2.0
            if info.get("http3"):
                bump += 3.0
            if bump:
                f["_score"] = f.get("_score", 0) + bump
        # re-rank index
        ranked.sort(key=lambda x: float(x.get("_score", 0)), reverse=True)
        for i, x in enumerate(ranked, start=1):
            x["_rank"] = i
        return ranked
    except Exception:
        return ranked
