"""De-duplicate ranked results based on normalized URLs and protocols."""

from __future__ import annotations
from urllib.parse import urlparse, parse_qsl, urlunparse


def _norm(u: str) -> str:
    try:
        p = urlparse(u)
        qs = "&".join(
            sorted([f"{k}={v}" for k, v in parse_qsl(p.query, keep_blank_values=True)])
        )
        return urlunparse((p.scheme, p.netloc, p.path, p.params, qs, ""))
    except Exception:
        return u


def post_rank(ranked):
    """Remove duplicate findings and reassign ranks.

    Args:
        ranked (list[dict]): Ranked results containing ``url`` or ``target`` and an
            optional ``vector`` mapping that may include ``protocol``.

    Returns:
        list[dict]: The de-duplicated ranked results with sequential ``_rank``
        values.
    """

    seen = {}
    out = []
    for f in ranked:
        u = f.get("url") or f.get("target") or ""
        key = (_norm(u), (f.get("vector", {}) or {}).get("protocol"))
        if key in seen:
            if f.get("_score", 0) > seen[key].get("_score", 0):
                idx = out.index(seen[key])
                out[idx] = f
                seen[key] = f
            continue
        seen[key] = f
        out.append(f)
    for i, x in enumerate(out, start=1):
        x["_rank"] = i
    return out
