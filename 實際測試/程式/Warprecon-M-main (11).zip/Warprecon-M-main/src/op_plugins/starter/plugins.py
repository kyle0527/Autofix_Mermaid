from __future__ import annotations
"""
op_plugins.starter.plugins
Three simple post-processing plugins operating on ranked findings (list[dict]).
- add_header_leak_tag
- flag_cache_poison_indicator
- grpc_policy_hint
"""
from typing import List, Dict, Any

def add_header_leak_tag(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    for it in items:
        h = str(it.get("evidence","")).lower()
        if "authorization:" in h or "set-cookie:" in h:
            it.setdefault("tags", []).append("header-leak")
            it["_score"] = max(float(it.get("_score",0.0)), 0.65)
    return items

def flag_cache_poison_indicator(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    for it in items:
        ev = str(it.get("evidence","")).lower()
        if "x-cache" in ev or "age:" in ev:
            it.setdefault("tags", []).append("cache-hint")
    return items

def grpc_policy_hint(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    for it in items:
        if it.get("protocol")=="grpc" and "plaintext" in str(it.get("type","")):
            it.setdefault("tags", []).append("grpc-policy")
            it["severity"]="medium"
            it["_score"]=max(float(it.get("_score",0.0)), 0.55)
    return items

def apply_all(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    items = add_header_leak_tag(items)
    items = flag_cache_poison_indicator(items)
    items = grpc_policy_hint(items)
    return items
