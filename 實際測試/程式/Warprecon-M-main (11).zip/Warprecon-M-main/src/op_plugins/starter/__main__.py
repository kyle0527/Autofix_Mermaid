from __future__ import annotations
import json, argparse
from pathlib import Path
from .plugins import apply_all

def main():
    ap = argparse.ArgumentParser(description="Apply starter plugins to ranked findings")
    ap.add_argument("--in", dest="infile", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
    out = apply_all(items)
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"in": args.infile, "out": args.out, "count": len(out)}, ensure_ascii=False))

if __name__=="__main__":
    main()
