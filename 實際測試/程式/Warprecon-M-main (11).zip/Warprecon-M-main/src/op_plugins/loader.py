from __future__ import annotations

import json
import logging
from importlib import metadata, util

from importlib import import_module
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, List, Tuple


logger = logging.getLogger(__name__)

HOOK_NAMES = ["vector_probe", "post_rank", "artifact_exporter"]



def _registry_candidates(workdir: Path) -> List[Path]:
    """Return possible registry.json locations ordered by priority."""

    candidates = [
        workdir / "plugins" / "registry.json",
        workdir / "registry.json",
        Path("plugins/registry.json"),
        Path("ext/plugins/registry.json"),
    ]
    seen: set[Path] = set()
    ordered: List[Path] = []
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        ordered.append(path)
    return ordered


def _iter_registry_modules(workdir: Path) -> Iterable[Tuple[str, Path]]:
    """Yield ``(module, source_path)`` pairs from available registries."""

    for path in _registry_candidates(workdir):
        if not path.exists():
            continue
        try:
            content = path.read_text(encoding="utf-8")
            data: Any = json.loads(content)
        except Exception as exc:  # pragma: no cover - logged for visibility
            logger.warning("Failed to load plugin registry %s: %s", path, exc)
            continue

        entries: Iterable[Any]
        if isinstance(data, dict):
            entries = data.get("plugins", [])
        elif isinstance(data, list):
            entries = data
        else:
            logger.debug("Unsupported registry format in %s", path)
            continue

        for item in entries:
            module_name: str | None = None
            if isinstance(item, str):
                module_name = item
            elif isinstance(item, dict):
                module_name = item.get("module")
            if module_name:
                yield module_name, path


def _store_hook(
    hooks: Dict[str, List[Callable]],
    seen: Dict[str, set[tuple[str, str]]],
    hook_name: str,
    func: Callable,
) -> None:
    code = getattr(func, "__code__", None)
    identifier: tuple[str, str]
    if code is not None:
        try:
            filename = str(Path(code.co_filename).resolve())
        except Exception:  # pragma: no cover - path resolution best-effort
            filename = str(code.co_filename)
        identifier = (filename, getattr(func, "__name__", repr(func)))
    else:  # pragma: no cover - uncommon, but keep deterministic key
        identifier = (getattr(func, "__module__", "unknown"), getattr(func, "__name__", repr(func)))

    if identifier in seen[hook_name]:
        return

    seen[hook_name].add(identifier)
    hooks[hook_name].append(func)


def _register_hooks(
    hooks: Dict[str, List[Callable]],
    seen: Dict[str, set[tuple[str, str]]],
    plugin_obj: Any,
    source: str,
) -> None:
    """Populate ``hooks`` with callables found on ``plugin_obj``."""

    if plugin_obj is None:
        return

    if isinstance(plugin_obj, dict):
        for hook_name in HOOK_NAMES:
            func = plugin_obj.get(hook_name)
            if callable(func):
                _store_hook(hooks, seen, hook_name, func)
        return

    if isinstance(plugin_obj, ModuleType):
        for hook_name in HOOK_NAMES:
            func = getattr(plugin_obj, hook_name, None)
            if callable(func):
                _store_hook(hooks, seen, hook_name, func)
        return

    if callable(plugin_obj):
        hook_name = getattr(plugin_obj, "__name__", "")
        if hook_name in HOOK_NAMES:
            _store_hook(hooks, seen, hook_name, plugin_obj)
            return
        try:
            nested = plugin_obj()
        except TypeError:
            logger.debug("Plugin callable %s from %s ignored (unsupported signature)", plugin_obj, source)
            return
        _register_hooks(hooks, seen, nested, source)
        return

    for hook_name in HOOK_NAMES:
        func = getattr(plugin_obj, hook_name, None)
        if callable(func):
            _store_hook(hooks, seen, hook_name, func)


def _import_module(module_name: str, source: str) -> ModuleType | None:
    try:
        return import_module(module_name)
    except Exception as exc:  # pragma: no cover - logged for visibility
        logger.warning("Failed to import plugin module %s from %s: %s", module_name, source, exc)
    return None


def _load_module(path: Path) -> ModuleType | None:
    """Dynamically load a module from ``path``.

    Returns ``None`` if the module could not be imported.
    """
    try:
        module_name = f"op_plugin_{path.stem}"
        spec = util.spec_from_file_location(module_name, path)
        if spec and spec.loader:
            mod = util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore[assignment]
            return mod
    except Exception as exc:
        logger.warning("Failed to load plugin %s: %s", path, exc)
    return None


def _collect_hooks(obj: object, hooks: Dict[str, List[Callable]]) -> None:
    for hook_name in HOOK_NAMES:
        func = getattr(obj, hook_name, None)
        if callable(func):
            hooks[hook_name].append(func)


def load_plugins(workdir: Path) -> Dict[str, List[Callable]]:
    """Search for plugin modules and collect hook functions.

    The following directories are scanned for ``*.py`` files:

    * ``<workdir>/plugins``
    * ``./plugins``
    * ``./ext/plugins``
    * ``op_plugins/builtin`` (within the package)

    For every discovered module the hooks ``vector_probe``, ``post_rank`` and
    ``artifact_exporter`` are collected if present.
    """

    search_paths = [
        workdir / "plugins",
        Path("plugins"),
        Path("ext/plugins"),
        Path(__file__).resolve().parent / "builtin",
    ]

    hooks: Dict[str, List[Callable]] = {name: [] for name in HOOK_NAMES}

    loaded_files: set[Path] = set()

    # keep track of already-seen hooks to avoid duplicates
    seen_hooks: Dict[str, set[tuple[str, str]]] = {name: set() for name in HOOK_NAMES}

    # 1) Installed packages via entry points (support multiple entry_point API shapes)
    try:
        entries = metadata.entry_points()
    except Exception as exc:  # pragma: no cover - logged for visibility
        logger.warning("Failed to inspect entry points: %s", exc)
        entries = []

    # Check both legacy group name and the package-specific group
    ep_groups = ["warprecon.plugins", "warprecon_m.plugins"]
    for group in ep_groups:
        try:
            if hasattr(entries, "select"):
                selected = entries.select(group=group)  # type: ignore[call-arg]
            elif isinstance(entries, dict):
                selected = entries.get(group, [])
            else:
                selected = [ep for ep in entries if getattr(ep, "group", None) == group]
        except Exception:
            selected = []

        for ep in selected:
            try:
                plugin_obj = ep.load()
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "Failed to load plugin entry point %s (%s): %s", getattr(ep, "name", None), getattr(ep, "value", None), exc
                )
                continue

            module_path = getattr(plugin_obj, "__file__", None)
            if module_path:
                try:
                    loaded_files.add(Path(module_path).resolve())
                except Exception:  # pragma: no cover - Path resolution errors are rare
                    pass

            _register_hooks(hooks, seen_hooks, plugin_obj, str(getattr(ep, "value", ep)))

    # 1) Legacy filesystem discovery
    for directory in search_paths:
        if not directory.exists():
            continue

        for plugin_path in sorted(directory.glob("*.py")):
            mod = _load_module(plugin_path)
            if mod:
                _register_hooks(hooks, seen_hooks, mod, str(plugin_path))

    # 2) Registries pointing to importable modules
    seen_modules: set[str] = set()
    for module_name, source in _iter_registry_modules(workdir):
        if module_name in seen_modules:
            continue
        seen_modules.add(module_name)
        mod = _import_module(module_name, str(source))
        if mod:
            _register_hooks(hooks, seen_hooks, mod, module_name)

    # 3) Python entry points (pip-installed plugins)
    try:
        entries = metadata.entry_points()
    except Exception as exc:  # pragma: no cover - logged for visibility
        logger.warning("Failed to inspect entry points: %s", exc)
        entries = []

    if hasattr(entries, "select"):
        selected = entries.select(group="warprecon_m.plugins")  # type: ignore[call-arg]
    elif isinstance(entries, dict):
        selected = entries.get("warprecon_m.plugins", [])
    else:  # pragma: no cover - fallback path
        selected = [
            ep for ep in entries if getattr(ep, "group", None) == "warprecon_m.plugins"
        ]

    for entry in selected:
        identifier = f"{entry.module}:{entry.attr}" if getattr(entry, "attr", None) else entry.module
        if identifier in seen_modules:
            continue
        seen_modules.add(identifier)
        try:
            plugin_obj = entry.load()
        except Exception as exc:  # pragma: no cover - logged for visibility
            logger.warning(
                "Failed to load plugin entry point %s (%s): %s", entry.name, entry.value, exc
            )
            continue
        _register_hooks(hooks, seen_hooks, plugin_obj, entry.value)


    # Remove empty hook lists
    return {k: v for k, v in hooks.items() if v}
