from __future__ import annotations
from typing import List

def gql_variants() -> List[str]:
    # Base set that is useful even when introspection is disabled
    base = [
        "query{__typename}",
        "query q{a:__typename,b:__typename}",
        "query q{__typename}",
        "query q{__typename @include(if:true)}",
        "query q{nonexistentField}",  # expect error revealing root type
        "mutation M{__typename}",     # sometimes allowed even w/o user mutations
    ]
    # Alias fan-out
    alias = [f"query q{{" + ",".join([f"a{i}:__typename" for i in range(n)]) + "}}" for n in (3,4)]
    # Variable shapes that often trigger type errors to reveal info
    vars_based = [
        "query q($x:String!){__typename}",
        "query q($id:ID){__typename}",
        "query q($n:Int){__typename}",
    ]
    # Fragment guesses on common root types
    frags = [
        "query q{__typename}",
        "query q{__typename}",
        "query q{__typename}",
    ]
    out = list(dict.fromkeys(base + alias + vars_based + frags))
    return out
