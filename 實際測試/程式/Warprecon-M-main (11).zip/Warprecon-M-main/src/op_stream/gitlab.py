from __future__ import annotations
"""
op_stream.gitlab — produce Issue payloads (template)
"""
import json, argparse
from pathlib import Path
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
    out = [{"title": f"{x.get('severity','info').upper()} {x.get('type','finding')}", "description": json.dumps(x, ensure_ascii=False, indent=2)} for x in items[:50]]
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"out": args.out, "count": len(out)}, ensure_ascii=False))
if __name__=="__main__":
    main()
