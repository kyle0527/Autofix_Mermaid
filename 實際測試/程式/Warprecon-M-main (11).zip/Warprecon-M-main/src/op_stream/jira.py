from __future__ import annotations
"""
op_stream.jira — emit issues as JSON lines (template)
Real API integration intentionally omitted. Generates payloads for ingestion.
"""
import json, argparse, os, sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser(description="Jira payload generator (template)")
    ap.add_argument("--in", dest="infile", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--project", default="SEC")
    args = ap.parse_args()
    items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
    with Path(args.out).open("w", encoding="utf-8") as w:
        for it in items[:50]:
            payload = {
                "project": args.project,
                "summary": f"[{it.get('severity','info').upper()}] {it.get('type','finding')}",
                "description": json.dumps(it, ensure_ascii=False, indent=2),
                "labels": (it.get("tags") or []) + ["warprecon-m"],
                "severity": it.get("severity","info")
            }
            w.write(json.dumps(payload, ensure_ascii=False)+"\n")
    print(json.dumps({"out": args.out, "count": min(50, len(items))}, ensure_ascii=False))

if __name__=="__main__":
    main()
