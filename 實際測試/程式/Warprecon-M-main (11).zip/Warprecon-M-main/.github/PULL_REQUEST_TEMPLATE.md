### 變更摘要
- 這個 PR 做了什麼？（<50字）

### 影響面
- [ ] CLI/輸出格式有變 → 已更新 `docs/OPERATION.md`
- [ ] 模組介面/資料欄位有變 → 已更新 `docs/ARCH.md`
- [ ] 需要 Release Note → 已更新 `CHANGELOG.md`

### 驗收
- [ ] CI 全綠（含 E2E 乾跑 artifacts）
- [ ] Scorecard 達標（≥ 70/100）
