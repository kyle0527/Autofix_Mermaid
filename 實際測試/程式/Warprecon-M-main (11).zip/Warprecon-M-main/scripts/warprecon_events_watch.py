#!/usr/bin/env python3
import sys, json
for ln in sys.stdin:
    try:
        j=json.loads(ln)
    except Exception:
        continue
    t=j.get("type","")
    if t.startswith("run."):
        print(f"[{t}] code={j.get('code','-')} info={j}")
