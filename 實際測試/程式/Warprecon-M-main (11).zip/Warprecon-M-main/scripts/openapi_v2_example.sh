#!/usr/bin/env bash
python -m op_proto.openapi.sequence_v2 --spec docs/openapi.yaml --base https://api.example.com --workdir work/m5
