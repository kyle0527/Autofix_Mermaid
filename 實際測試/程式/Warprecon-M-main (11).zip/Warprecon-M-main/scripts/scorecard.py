#!/usr/bin/env python3
import json, argparse

WEIGHTS = {
  "discovery": 0.20,
  "protocol": 0.25,
  "verification": 0.15,
  "ranking": 0.10,
  "delivery": 0.10,
  "ecosystem": 0.10,
  "compliance": 0.05,
  "performance": 0.05
}

def score(m):
    def clamp(x): return max(0.0, min(5.0, float(x)))
    # naive mapping: normalize to 0..5 from simple heuristics
    s = 0.0
    s += WEIGHTS["discovery"]   * clamp(1 if m.get("discovery.urls",0) == 0 else 4)
    s += WEIGHTS["protocol"]    * clamp(3 + (1 if m.get("protocol.grpc_schema",0)>0 else 0))
    s += WEIGHTS["verification"]* clamp(3 + (1 if m.get("verification.transforms",1)>=1 else 0))
    s += WEIGHTS["ranking"]     * clamp(3 + (1 if m.get("ranking.bandit",1)>=1 else 0))
    s += WEIGHTS["delivery"]    * clamp(4)
    s += WEIGHTS["ecosystem"]   * clamp(min(5, 2 + 0.5*m.get("ecosystem.plugins",0)))
    s += WEIGHTS["compliance"]  * clamp(2 + (2 if m.get("compliance.oob_self_host",0) else 0))
    s += WEIGHTS["performance"] * clamp(2 + m.get("performance.rate_controls",1))
    return round(s*20, 1)  # to 100

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metrics", required=True, help="JSON file with metrics")
    args = ap.parse_args()
    m = json.loads(open(args.metrics, "r", encoding="utf-8").read())
    print(score(m))

if __name__ == "__main__":
    main()
