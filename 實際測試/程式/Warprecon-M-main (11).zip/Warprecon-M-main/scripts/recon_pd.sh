#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <domain> <workdir>"
  exit 1
fi
domain="$1"; workdir="$2"
python -m op_adapters.pd_wrappers --domain "$domain" --workdir "$workdir"
warprecon-m pipeline --domain "$domain" --cfg config/campaign.yaml --workdir "$workdir" --capture || true
warprecon-m deliver --workdir "$workdir" --out "$workdir/deliverable.zip"
