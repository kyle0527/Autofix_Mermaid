#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEFAULT_VENV="$ROOT_DIR/.venv"

print_usage() {
  cat <<'USAGE'
Usage: scripts/install.sh [options]

Bootstrap a local Warprecon-M environment (non-container).

Options:
  --dev                Install developer extras in addition to runtime extras.
  --extras <list>      Comma separated extras to install (default: dom,grpc).
  --venv <path>        Create/Reuse a virtualenv at <path> (default: .venv).
  --no-venv            Install into the current interpreter without creating a venv.
  --skip-playwright    Skip Playwright browser installation (useful for CI).
  -h, --help           Show this help message.
USAGE
}

log() {
  echo "[install] $*"
}

warn() {
  echo "[install] WARNING: $*" >&2
}

abort() {
  echo "[install] ERROR: $*" >&2
  exit 1
}

EXTRAS_DEFAULT=(dom grpc)
CUSTOM_EXTRAS=()
INCLUDE_DEV=0
CREATE_VENV=1
VENV_PATH="$DEFAULT_VENV"
SKIP_PLAYWRIGHT=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dev)
      INCLUDE_DEV=1
      shift
      ;;
    --extras)
      shift
      [[ $# -gt 0 ]] || abort "--extras requires an argument"
      IFS=',' read -r -a CUSTOM_EXTRAS <<< "$1"
      shift
      ;;
    --extras=*)
      IFS=',' read -r -a CUSTOM_EXTRAS <<< "${1#*=}"
      shift
      ;;
    --venv)
      shift
      [[ $# -gt 0 ]] || abort "--venv requires a path"
      VENV_PATH="$1"
      shift
      ;;
    --venv=*)
      VENV_PATH="${1#*=}"
      shift
      ;;
    --no-venv)
      CREATE_VENV=0
      shift
      ;;
    --skip-playwright)
      SKIP_PLAYWRIGHT=1
      shift
      ;;
    -h|--help)
      print_usage
      exit 0
      ;;
    --)
      shift
      break
      ;;
    *)
      abort "Unknown option: $1"
      ;;
  esac
done

if ! command -v python3 >/dev/null 2>&1; then
  abort "python3 is required"
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')
if ! python3 - <<'PY' >/dev/null; then
import sys
if sys.version_info < (3, 10):
    raise SystemExit(1)
PY
then
  abort "Python 3.10 or newer is required (detected $PYTHON_VERSION)"
fi

log "Using python3 $PYTHON_VERSION"

if (( CREATE_VENV )); then
  if [[ "$VENV_PATH" == ~* ]]; then
    VENV_PATH="$HOME${VENV_PATH:1}"
  fi
  log "Creating virtualenv at $VENV_PATH"
  python3 -m venv "$VENV_PATH"
  # shellcheck disable=SC1090
  source "$VENV_PATH/bin/activate"
else
  log "Installing into current Python interpreter"
fi

cd "$ROOT_DIR"

log "Upgrading pip"
pip install --upgrade pip setuptools wheel >/dev/null

EXTRAS=()
if ((${#CUSTOM_EXTRAS[@]} > 0)); then
  EXTRAS=("${CUSTOM_EXTRAS[@]}")
else
  EXTRAS=("${EXTRAS_DEFAULT[@]}")
fi
if (( INCLUDE_DEV )); then
  EXTRAS+=("dev")
fi

if ((${#EXTRAS[@]} > 0)); then
  declare -A seen=()
  dedup=()
  for extra in "${EXTRAS[@]}"; do
    extra=${extra// /}
    extra=${extra,,}
    [[ -n "$extra" ]] || continue
    if [[ -z ${seen[$extra]+x} ]]; then
      seen[$extra]=1
      dedup+=("$extra")
    fi
  done
  EXTRAS=("${dedup[@]}")
fi

EXTRAS_SPEC=""
if ((${#EXTRAS[@]} > 0)); then
  extras_joined=$(IFS=','; printf '%s' "${EXTRAS[*]}")
  EXTRAS_SPEC="[$extras_joined]"
fi

if [[ -n "$EXTRAS_SPEC" ]]; then
  log "Installing warprecon-m extras $EXTRAS_SPEC"
  pip install -e ".${EXTRAS_SPEC}" >/dev/null
else
  log "Installing warprecon-m"
  pip install -e . >/dev/null
fi

PLAYWRIGHT_STATUS="skipped"
if (( SKIP_PLAYWRIGHT == 0 )); then
  if python -m playwright install chromium >/dev/null 2>&1; then
    PLAYWRIGHT_STATUS="installed"
  else
    warn "Playwright browser install failed; re-run with sudo or --skip-playwright"
    PLAYWRIGHT_STATUS="failed"
  fi
fi

missing_tools=()
for tool in docker grpcurl nuclei sqlmap; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    missing_tools+=("$tool")
  fi
done

if ! warprecon-m --help >/dev/null 2>&1; then
  warn "warprecon-m CLI not found on PATH; ensure the virtualenv is activated"
fi

log "Installation complete"
if (( CREATE_VENV )); then
  log "Activate the environment with: source $VENV_PATH/bin/activate"
fi
log "Playwright browsers: $PLAYWRIGHT_STATUS"
if ((${#missing_tools[@]} > 0)); then
  warn "Missing external tools: ${missing_tools[*]}"
fi
