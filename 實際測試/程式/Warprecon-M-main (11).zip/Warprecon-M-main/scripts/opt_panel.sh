#!/usr/bin/env bash
# Sanitize & Panel quickstart
set -euo pipefail
work="${1:-work/m_full}"
python -m op_output.sanitize --in "$work/ranked.final.json" --out "$work/ranked.sanitized.json" --html "$work/report_v3.html"
python -m op_ui.panel --workdir "$work" --port 8080
