#!/usr/bin/env python3
"""Ensure Python sources do not contain ellipsis placeholders."""

from __future__ import annotations

import sys
import tokenize
from pathlib import Path

IGNORED_TOKEN_TYPES = {
    tokenize.NL,
    tokenize.NEWLINE,
    tokenize.INDENT,
    tokenize.DEDENT,
    tokenize.COMMENT,
    tokenize.ENCODING,
}

ALLOWED_PREV_TOKENS = {"[", "(", "{", ","}


def find_ellipsis_tokens(path: Path) -> list[tuple[int, str]]:
    """Return offending ellipsis entries within *path*."""

    issues: list[tuple[int, str]] = []
    try:
        source_lines = path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError:
        # Fall back to binary reading if decoding fails to avoid crashes.
        source_lines = path.read_text(errors="ignore").splitlines()

    with path.open("rb") as handle:
        try:
            tokens = list(tokenize.tokenize(handle.readline))
        except tokenize.TokenError as exc:  # pragma: no cover - syntax errors should fail
            raise RuntimeError(f"Tokenizing {path} failed: {exc}") from exc

    prev = None
    for token in tokens:
        if token.type == tokenize.ELLIPSIS:
            allowed = prev is not None and prev.string in ALLOWED_PREV_TOKENS
            if not allowed:
                line = source_lines[token.start[0] - 1].rstrip()
                issues.append((token.start[0], line))
        if token.type not in IGNORED_TOKEN_TYPES:
            prev = token
    return issues


def main() -> int:
    failures: list[tuple[Path, int, str]] = []
    for file_path in sorted(Path("src").rglob("*.py")):
        for line_no, snippet in find_ellipsis_tokens(file_path):
            failures.append((file_path, line_no, snippet))

    if failures:
        print("Ellipsis placeholders are not allowed in Python sources.", file=sys.stderr)
        for file_path, line_no, snippet in failures:
            print(f"{file_path}:{line_no}: {snippet}", file=sys.stderr)
        return 1

    print("No ellipsis placeholders detected.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
