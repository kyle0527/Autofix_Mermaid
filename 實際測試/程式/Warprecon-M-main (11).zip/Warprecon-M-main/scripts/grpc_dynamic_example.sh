#!/usr/bin/env bash
python -m op_proto.grpc.dynamic --target api.example.com:443 --workdir work/m4
