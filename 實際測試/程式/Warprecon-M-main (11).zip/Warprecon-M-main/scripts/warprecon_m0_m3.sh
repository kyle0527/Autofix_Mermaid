#!/usr/bin/env bash
# scripts/warprecon_m0_m3.sh — one-shot orchestrator
set -euo pipefail
if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <domain> <base_url> [workdir]"
  exit 1
fi
domain="$1"; base="$2"; workdir="${3:-work/run_$(date +%Y%m%d_%H%M%S)}"
mkdir -p "$workdir"

echo "[M0] PD recon → targets.txt"
python -m op_adapters.pd_wrappers --domain "$domain" --workdir "$workdir"

echo "[Core] pipeline & deliver"
warprecon-m pipeline --domain "$domain" --cfg config/campaign.yaml --workdir "$workdir" --capture || true
warprecon-m deliver --workdir "$workdir" --out "$workdir/deliverable.zip" || true

echo "[M1] gRPC enumerate + HTTP misconfig"
python -m op_proto.grpc.enumerate --target "${domain}:443" --workdir "$workdir" || true
python -m op_checks.misconfig --targets "$workdir/targets.txt" --workdir "$workdir" || true

echo "[Merge] ranked + m1 findngs → ranked.merged.json"
inputs=("$workdir/ranked.json")
[[ -f "$workdir/findings.grpc.json" ]] && inputs+=("$workdir/findings.grpc.json")
[[ -f "$workdir/findings.misconfig.json" ]] && inputs+=("$workdir/findings.misconfig.json")
python -m op_core.merge_findings --inputs "${inputs[@]}" --out "$workdir/ranked.merged.json"

echo "[M2] Precision Gate → ranked.final.json"
python -m op_core.precision_gate --in "$workdir/ranked.merged.json" --out "$workdir/ranked.final.json" --min-score 0.35 --confirm-top-n 20 || true

echo "[M3] OpenAPI sequence + HTML v2"
python -m op_proto.openapi.sequence --spec docs/openapi.yaml --base "$base" --workdir "$workdir" --emit-requests || true
python -m op_output.html_v2 --in "$workdir/ranked.final.json" --out "$workdir/report_v2.html" || true

echo "[Done] Artifacts at $workdir"
