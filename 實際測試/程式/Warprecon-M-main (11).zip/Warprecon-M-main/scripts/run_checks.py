import argparse, json, sys, os
from typing import List

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from op_checks.base import REGISTRY

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", required=False, help="path to apis.json")
    ap.add_argument("--checks", default="idor,oauth")
    ap.add_argument("--out", dest="outfile", default="out/findings.jsonl")
    args = ap.parse_args()

    checks = [c.strip() for c in args.checks.split(",") if c.strip()]
    classes = [REGISTRY[c] for c in checks if c in REGISTRY]

    # read input if provided (optional for safe defaults)
    apis = None
    if args.infile:
        try:
            with open(args.infile, "r", encoding="utf-8") as f:
                apis = json.load(f)
        except Exception:
            apis = None

    out_lines: List[str] = []
    for Cls in classes:
        inst = Cls()
        for finding in inst.run(apis=apis):
            out_lines.append(finding.to_json())

    # ensure out dir
    import os
    os.makedirs(os.path.dirname(args.outfile), exist_ok=True)
    with open(args.outfile, "w", encoding="utf-8") as f:
        for line in out_lines:
            f.write(line + "\n")
    print(f"wrote {len(out_lines)} findings to {args.outfile}")

if __name__ == "__main__":
    main()
