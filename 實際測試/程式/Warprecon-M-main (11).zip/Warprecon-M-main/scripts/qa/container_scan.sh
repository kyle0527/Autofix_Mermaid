#!/usr/bin/env bash
set -euo pipefail

IMAGE_REF=${1:-warprecon-m:latest}
TOOLS=(trivy grype docker scout)

run_trivy() {
  trivy image --severity HIGH,CRITICAL --scanners vuln "$IMAGE_REF"
}

run_grype() {
  grype "$IMAGE_REF" --fail-on high
}

run_docker_scout() {
  docker scout cves "$IMAGE_REF" --only-severity high,critical
}

for tool in "${TOOLS[@]}"; do
  if command -v "$tool" >/dev/null 2>&1; then
    case "$tool" in
      trivy)
        exec run_trivy
        ;;
      grype)
        exec run_grype
        ;;
      docker)
        if docker scout --help >/dev/null 2>&1; then
          exec run_docker_scout
        fi
        ;;
    esac
  fi
done

echo "No supported container scanning tool found (looked for: trivy, grype, docker scout)." >&2
exit 127
