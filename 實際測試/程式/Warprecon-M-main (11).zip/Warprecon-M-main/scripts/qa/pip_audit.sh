#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
ARGS=("--progress-spinner" "off" "--desc")

if [[ -f "${ROOT_DIR}/requirements-dev.txt" ]]; then
  ARGS+=("-r" "${ROOT_DIR}/requirements-dev.txt")
fi
if [[ -f "${ROOT_DIR}/requirements.txt" ]]; then
  ARGS+=("-r" "${ROOT_DIR}/requirements.txt")
fi
if [[ -f "${ROOT_DIR}/pyproject.toml" ]]; then
  ARGS+=("-P" "${ROOT_DIR}")
fi

if command -v pip-audit >/dev/null 2>&1; then
  exec pip-audit "${ARGS[@]}"
fi

if python -m pip_audit --help >/dev/null 2>&1; then
  exec python -m pip_audit "${ARGS[@]}"
fi

echo "pip-audit is not installed. Install it via 'pip install pip-audit'." >&2
exit 127
