# Warprecon-M

可擴充的多協定漏洞掃描器，設計用於 CI 快速掃描與研究情境。
採模組化流程與外掛系統，10 分鐘內即可部署並產出報告。
支援 HTTP/gRPC/OpenAPI 等協定，並以 Scorecard 度量結果。

## 快速開始
1. 安裝相依並載入套件：
   ```bash
   pip install -r requirements-dev.txt
   pip install -e .
   ```
2. 一鍵執行 M0→M3：
   ```bash
   make m0 m1 m2 m3 WORKDIR=work/run1 DOMAIN=https://target.example
   ```
3. 檢視輸出：`work/run1/report_v2.html`、`work/run1/out.sarif`、`work/run1/deliverable.zip`

## 常用指令
| 指令 | 說明 |
| --- | --- |
| `make m0 WORKDIR=... DOMAIN=...` | 基礎掃描並產出初步報告 |
| `pytest -q` | 單元與整合測試 |
| `python scripts/scorecard.py work/run1` | 計算 Scorecard 分數 |

## 成果物一覽
- `report_v2.html`：圖表化報告
- `out.sarif`：SARIF 格式輸出
- `deliverable.zip`：所有 artifacts 打包

## 專案結構與模組角色
```text
src/
├─ op_core/     # 掌管 M0→M3 流程與排名
├─ op_proto/    # 協定探測器（HTTP/gRPC/OpenAPI）
├─ op_output/   # 報告與 artifacts 產生器
└─ op_plugins/  # 外掛檢查器與擴充點
```
> 詳細架構與 I/O 契約請見 [docs/ARCH.md](docs/ARCH.md)

## 常見問題
1. **找不到 command `warprecon-m`？**
   - 確認已安裝並在虛擬環境中執行。
2. **沒有產生 `out.sarif`？**
   - 檢查 `make m0` 是否成功執行，並確認 `work/run1` 目錄存在。
3. **Scorecard 低於門檻？**
   - 重新檢查 `ranked.final.json` 是否完整，或調整掃描設定。
4. **gRPC 枚舉失敗？**
   - 目標可能未開啟 reflection，請提供 proto 檔或略過 M1。
5. **如何追蹤度量？**
   - 參閱 `work/run1/metrics.json` 中的 `ttfp` 與 `hits`。

## 連結
- [操作流程 Runbook](docs/OPERATION.md)
- [架構與介面](docs/ARCH.md)
- [版本變更](CHANGELOG.md)
