# OPERATION — M0→M3 Runbook & 驗收標準

## 環境前置
- Python 3.11+
- 可選：Docker `python:3.11` 映像
- 安裝依賴：`pip install -r requirements-dev.txt`

## M0：基礎掃描
```bash
make m0 WORKDIR=work/run1 DOMAIN=https://target.example
```
輸出：`work/run1/ranked.json`、`work/run1/out.sarif`、`work/run1/report.html`、`work/run1/poc/`
驗收：`ls work/run1/report.html`

## M1：服務枚舉
```bash
make m1 WORKDIR=work/run1 DOMAIN=https://target.example
```
輸出：`work/run1/schema/grpc_*.json`、`work/run1/findings.misconfig.json`
驗收：`ls work/run1/schema/grpc_*.json`

## M2：排序與 Gate
```bash
make m2 WORKDIR=work/run1
```
輸出：`work/run1/ranked.merged.json`、`work/run1/ranked.final.json`
驗收：`jq '.|length' work/run1/ranked.final.json`

## M3：OpenAPI 與新版報表
```bash
make m3 WORKDIR=work/run1 BASE=https://api.example
```
輸出：`work/run1/sequence/seq_*.sh`、`work/run1/requests.py`（可選）、`work/run1/report_v2.html`
驗收：`ls work/run1/report_v2.html work/run1/out.sarif`

## 驗收門檻
- `pytest -q` 全綠
- 乾跑 E2E 產出 HTML/SARIF/ZIP artifacts
- `python scripts/scorecard.py work/run1` ≥ 70/100（Discovery 45 / Verification 15 / Delivery 20 / Ecosystem 10 / Compliance 10）

## 疑難排解
1. 缺少模組 `requests` → `pip install requests`
2. `grpc.enumerate` 超時 → 確認目標支援 reflection
3. `precision_gate` 無輸出 → 確認 `ranked.merged.json` 路徑
4. Scorecard 未達標 → 檢查 `ranked.final.json` 是否存在
5. 命令找不到 → 先執行 `pip install -e .`

## 度量與追蹤
`work/run1/metrics.json` 包含 `ttfp`（Time to First Finding）與 `hits` 等度量，可用於比對不同設定的效果。

## 版本相容性
重大變更請參閱 [CHANGELOG.md](../CHANGELOG.md)。
