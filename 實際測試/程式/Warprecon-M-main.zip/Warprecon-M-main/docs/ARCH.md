# ARCH — 架構與介面索引

## 系統概覽
```mermaid
flowchart TD
    subgraph op_core
        pipeline[op_core.pipeline]
        rank[op_core.rank]
    end
    subgraph op_proto
        http[op_proto.http/ws]
        grpc[op_proto.grpc]
        openapi[op_proto.openapi]
    end
    subgraph op_output
        html[op_output.html_v2]
        sarif[op_output.sarif]
        deliver[op_output.deliver]
    end

    Targets --> pipeline
    pipeline --> http
    pipeline --> grpc
    pipeline --> openapi
    http --> rank
    grpc --> rank
    openapi --> rank
    rank --> html
    rank --> sarif
    rank --> deliver
```

## 核心模組介面索引
| 模組 | 角色 | 主要介面 |
| --- | --- | --- |
| `op_core.pipeline` | 串接 M0→M3 任務與排程 | `run_pipeline(targets)` |
| `op_proto.*` | 協定探測器（HTTP/gRPC/OpenAPI） | `http_probe`, `grpc.enumerate`, `openapi.sequence` |
| `op_core.rank` | 統整並排序 findings | `rank_findings(list[dict])`, CLI `precision_gate` |
| `op_output.*` | 報告產生與 artifacts 封裝 | `html_v2`, `sarif`, `deliver` |
| `op_plugins.*` | 擴充 hook 與自訂檢查器 | `registry.json`, hooks：`vector_probe`, `post_rank`, `artifact_exporter` |

## 擴充點
- **Plugins registry**：`ext/plugins/registry.json`
  ```json
  [
    {"name": "path_dedupe", "module": "op_plugins.builtin.path_dedupe"}
  ]
  ```
- **自訂檢查器**：新增 `.py` 並實作任一 hook：
  ```python
  def vector_probe(workdir, camp, targets): ...
  def post_rank(ranked): ...
  def artifact_exporter(workdir, ranked): ...
  ```

## 資料契約
### ranked.json / ranked.final.json
| 欄位 | 說明 |
| --- | --- |
| `check` | 檢查器名稱 |
| `target` | 探測目標 |
| `severity` | 嚴重度 |
| `evidence` | 佐證資料 |
| `_score` | 排名分數 |
| `_rank` | 排名順序 |

### metrics.json
| 欄位 | 說明 |
| `ttfp` | Time to First Finding（秒） |
| `hits` | findings 數 |

### deliverable.zip
包含 `report_v2.html`、`out.sarif`、`ranked.final.json` 等 artifacts。

> API 細節請見各模組的 docstring，此處僅維護最小 I/O 契約。
