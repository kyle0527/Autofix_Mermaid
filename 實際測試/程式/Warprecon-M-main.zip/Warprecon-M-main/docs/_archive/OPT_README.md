已合併到 README.md，僅供歷史參考

# OPT — 流程優化與面板（M7+，2025-08-30）

## 摘要
- **報告脫敏**：`op_output.sanitize` 將 `Authorization`/`Cookie`/token/JWT 等敏感資訊遮罩，輸出 `ranked.sanitized.json` 與 `report_v3.html`。
- **輕量面板**：`op_ui.panel` 基於 Flask，讀取 `workdir` 內 `ranked.final.json`（或 merged/ranked），提供查詢/篩選/下載與事件流預覽。
- **錯誤分類**：`op_core.error_classify` 將 `events.ndjson` 分類為 dns/timeout/tls/conn/http/other。
- **原則**：失敗即降級；不依賴外部服務；UI 為單檔，便於離線部署。

## 安裝
```bash
python -m pip install flask
```

## 使用
```bash
# 1) 產生脫敏結果 + 報表
python -m op_output.sanitize --in work/m_full/ranked.final.json --out work/m_full/ranked.sanitized.json --html work/m_full/report_v3.html

# 2) 啟動面板
python -m op_ui.panel --workdir work/m_full --port 8080

# 3) 錯誤分類
python -m op_core.error_classify --events work/m_full/events.ndjson --out work/m_full/errors.summary.json
```

## 成功條件 / 風險
- **成功**：所有報表/面板輸出不含明文敏感資訊；Top‑N triage 時間下降 ≥ 30%；錯誤分類能覆蓋 ≥ 80% 的常見錯誤。
- **風險**：正則遮罩可能遮過/遮不全 → 支援自訂遮罩清單（後續可在 `sanitize.py` 中擴充）。
