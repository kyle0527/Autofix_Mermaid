from __future__ import annotations
from pathlib import Path
import subprocess, time, json, sys

USAGE = "python tools/bench_run.py scenarios.json"

def run_cmd(cmd: str) -> tuple[int,float]:
    t0 = time.time()
    p = subprocess.run(cmd, shell=True)
    dt = time.time() - t0
    return p.returncode, dt

def p_at_k(ranked, k=10):
    top = ranked[:k]; good=0
    for f in top:
        ev=f.get("evidence",{}) or {}
        if f.get("_confirmed") or ev.get("variant_hits") or ev.get("sequence_hit"):
            good += 1
    return good/float(k)

def load_ranked(workdir: Path):
    p = workdir/"ranked.json"
    if not p.exists(): return []
    return json.loads(p.read_text(encoding="utf-8"))

def bench_scenarios(conf_path: Path) -> dict:
    conf = json.loads(conf_path.read_text(encoding="utf-8"))
    results = []
    for sc in conf.get("scenarios", []):
        name = sc.get("name","scenario")
        cmd = sc.get("cmd")
        work = Path(sc.get("workdir","work/bench_"+name.replace(" ","_")))
        if not cmd:
            continue
        work.mkdir(parents=True, exist_ok=True)
        rc, dt = run_cmd(cmd)
        ranked = load_ranked(work)
        res = {
            "name": name,
            "cmd": cmd,
            "returncode": rc,
            "duration_sec": dt,
            "p10": round(p_at_k(ranked,10),3) if ranked else 0.0,
            "p20": round(p_at_k(ranked,20),3) if ranked else 0.0,
            "poc_files": len(list((work/"poc").glob("poc_*.*"))) if (work/"poc").exists() else 0
        }
        results.append(res)
    return {"results": results}

def write_html(out: Path, data: dict):
    rows = []
    for r in data.get("results", []):
        rows.append(f"<tr><td>{r['name']}</td><td><code>{r['cmd']}</code></td><td>{r['duration_sec']:.2f}</td><td>{r['p10']:.3f}</td><td>{r['p20']:.3f}</td><td>{r['poc_files']}</td></tr>")
    html = "<!doctype html><meta charset=\"utf-8\"><title>Bench Report</title>" \
           + "<style>body{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:6px} th{background:#f6f6f6}</style>" \
           + "<h1>Bench Report</h1><table><thead><tr><th>Name</th><th>Command</th><th>Duration(s)</th><th>P@10</th><th>P@20</th><th>PoC</th></tr></thead><tbody>" \
           + "".join(rows) + "</tbody></table>"
    out.write_text(html, encoding="utf-8")

def main():
    if len(sys.argv) < 2:
        print(USAGE); return 2
    conf_path = Path(sys.argv[1])
    data = bench_scenarios(conf_path)
    out_dir = conf_path.parent
    (out_dir/"bench_results.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    write_html(out_dir/"bench_report.html", data)
    print("Wrote:", out_dir/"bench_report.html")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
