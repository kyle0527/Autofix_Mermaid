from __future__ import annotations

import pytest

graphql_runner = pytest.importorskip("op_proto.graphql.runner")
generate_candidates = graphql_runner.generate_candidates
probe_set = graphql_runner.probe_set


def test_graphql_generate_and_probe():
    qs = generate_candidates({}, budget=2)
    assert qs and any("__typename" in q for q in qs)
    out = probe_set("http://127.0.0.1:9/graphql", qs, timeout=0.5)  # should error fast but not crash
    assert isinstance(out, list)
