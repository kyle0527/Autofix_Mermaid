from __future__ import annotations
import json
from pathlib import Path

from op_core.session import load_cookies
import httpx

def test_load_cookies_host_only(tmp_path: Path):
    session_dir = tmp_path / "session"
    session_dir.mkdir()
    data = {"cookies": [{"name": "a", "value": "1", "domain": ".example.com", "hostOnly": True, "path": "/"}]}
    (session_dir / "cookies.json").write_text(json.dumps(data), encoding="utf-8")
    jar = load_cookies(tmp_path)
    cookie_domains = [c.domain for c in getattr(jar, "jar", [])]
    assert jar.get("a") == "1"
    assert "example.com" in cookie_domains and all(not d.startswith(".") for d in cookie_domains)
