
#!/usr/bin/env python3
"""
Test suite for IDOR Detection MVP

Tests the IDOR detection functionality with mock service scenarios.
"""

import pytest
import asyncio
import time
import requests
from pathlib import Path
import tempfile
import threading
from typing import Dict, Any, List

# Import our modules
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
sys.path.insert(0, os.path.dirname(__file__))

from op_checks.idor import IdorCheck, IdorDetector, SessionManager, IdVariantGenerator, RequestReplay
from mock_idor_app import start_mock_server, stop_mock_server


class TestIdVariantGenerator:
    """Test ID variant generation logic."""
    
    def test_extract_numeric_ids_from_path(self):
        """Test extraction of numeric IDs from URL path."""
        generator = IdVariantGenerator()
        
        # Test numeric ID in path
        url = "https://example.com/api/users/123/documents/456"
        ids = generator.extract_ids_from_url(url)
        
        assert len(ids) >= 2
        # Check for numeric IDs
        numeric_ids = [(loc, param, val) for loc, param, val in ids if isinstance(val, int)]
        assert len(numeric_ids) >= 2
        
    def test_extract_query_parameter_ids(self):
        """Test extraction of IDs from query parameters."""
        generator = IdVariantGenerator()
        
        url = "https://example.com/api/resource?id=123&user_id=456&token=abc123def"
        ids = generator.extract_ids_from_url(url)
        
        query_ids = [(loc, param, val) for loc, param, val in ids if loc == 'query']
        assert len(query_ids) >= 2
        
    def test_generate_numeric_variants(self):
        """Test generation of variants for numeric IDs."""
        generator = IdVariantGenerator()
        
        url = "https://example.com/api/users/123"
        original_ids = generator.extract_ids_from_url(url)
        variants = generator.generate_variants(url, original_ids)
        
        assert len(variants) > 0
        assert "https://example.com/api/users/124" in variants  # +1 variant
        assert "https://example.com/api/users/122" in variants  # -1 variant
        
    def test_generate_query_variants(self):
        """Test generation of variants for query parameter IDs."""
        generator = IdVariantGenerator()
        
        url = "https://example.com/api/resource?id=123"
        original_ids = generator.extract_ids_from_url(url)
        variants = generator.generate_variants(url, original_ids)
        
        assert len(variants) > 0
        # Check that some variants modify the id parameter
        variant_with_124 = any("id=124" in variant for variant in variants)
        variant_with_1 = any("id=1" in variant for variant in variants)
        assert variant_with_124 or variant_with_1


class TestSessionManager:
    """Test session management functionality."""
    
    def test_add_and_get_session(self):
        """Test adding and retrieving sessions."""
        manager = SessionManager()
        
        auth_data = {
            "token": "test-token-123",
            "headers": {"X-User-Role": "admin"},
            "cookies": {"session_id": "abc123"}
        }
        
        manager.add_session("admin", auth_data)
        session = manager.get_session("admin")
        
        assert session is not None
        assert session["auth_data"]["token"] == "test-token-123"
        assert session["headers"]["X-User-Role"] == "admin"
        
    def test_get_auth_headers(self):
        """Test getting authentication headers."""
        manager = SessionManager()
        
        auth_data = {
            "token": "test-token-123",
            "headers": {"X-User-Role": "admin"}
        }
        
        manager.add_session("admin", auth_data)
        headers = manager.get_auth_headers("admin")
        
        assert "Authorization" in headers
        assert headers["Authorization"] == "Bearer test-token-123"
        assert headers["X-User-Role"] == "admin"
        
    def test_get_nonexistent_session(self):
        """Test retrieving non-existent session."""
        manager = SessionManager()
        
        session = manager.get_session("nonexistent")
        assert session is None
        
        headers = manager.get_auth_headers("nonexistent")
        assert headers == {}


class TestRequestReplay:
    """Test request replay functionality."""
    
    @pytest.fixture
    def mock_server_url(self):
        """Start mock server for testing."""
        base_url = start_mock_server(port=5556)
        yield base_url
        stop_mock_server()
        
    def test_replay_without_auth(self, mock_server_url):
        """Test replaying request without authentication."""
        manager = SessionManager()
        replay = RequestReplay(manager)
        
        async def run_test():
            response = await replay.replay_request(f"{mock_server_url}/", role=None)
            assert response is not None
            assert response["status_code"] == 200
            assert response["role"] is None
            
        asyncio.run(run_test())
        
    def test_replay_with_auth(self, mock_server_url):
        """Test replaying request with authentication."""
        manager = SessionManager()
        manager.add_session("test", {
            "token": "test-token",
            "headers": {"X-Test-Header": "test-value"}
        })
        
        replay = RequestReplay(manager)
        
        async def run_test():
            response = await replay.replay_request(f"{mock_server_url}/", role="test")
            assert response is not None
            assert response["role"] == "test"
            
        asyncio.run(run_test())


class TestIdorDetector:
    """Test the main IDOR detector functionality."""
    
    @pytest.fixture
    def mock_server_url(self):
        """Start mock server for testing."""
        base_url = start_mock_server(port=5557)
        # Give server time to start
        time.sleep(1)
        yield base_url
        stop_mock_server()
        
    def test_setup_test_sessions(self, mock_server_url):
        """Test setting up test sessions."""
        detector = IdorDetector()
        detector.setup_test_sessions(mock_server_url)
        
        admin_session = detector.session_manager.get_session("admin")
        user_session = detector.session_manager.get_session("user")
        anon_session = detector.session_manager.get_session("anonymous")
        
        assert admin_session is not None
        assert user_session is not None
        assert anon_session is not None
        
    def test_detect_idor_no_ids(self, mock_server_url):
        """Test IDOR detection on URL with no IDs."""
        detector = IdorDetector()
        detector.setup_test_sessions(mock_server_url)
        
        async def run_test():
            findings = await detector.detect_idor_single_url(f"{mock_server_url}/")
            assert len(findings) == 0  # No IDs to test
            
        asyncio.run(run_test())
        
    def test_detect_idor_with_path_id(self, mock_server_url):
        """Test IDOR detection on URL with path ID."""
        detector = IdorDetector()
        detector.setup_test_sessions(mock_server_url)
        
        async def run_test():
            # Test the vulnerable endpoint
            findings = await detector.detect_idor_single_url(f"{mock_server_url}/documents/1")
            
            # The mock service's /documents/<id> endpoint is vulnerable
            # Different roles might get different responses, indicating potential IDOR
            assert isinstance(findings, list)
            
        asyncio.run(run_test())


class TestIdorCheckIntegration:
    """Integration tests for the IdorCheck class."""
    
    @pytest.fixture
    def mock_server_url(self):
        """Start mock server for testing."""
        base_url = start_mock_server(port=5558)
        time.sleep(1)  # Give server time to start
        yield base_url
        stop_mock_server()
        
    def test_idor_check_with_string_apis(self, mock_server_url):
        """Test IDOR check with string API list."""
        check = IdorCheck()
        
        apis = [
            f"{mock_server_url}/documents/1",
            f"{mock_server_url}/users/1",
            f"{mock_server_url}/api/v1/resource?id=1"
        ]
        
        findings = list(check.run(apis=apis))
        
        # Should return some findings (even if just processing confirmations)
        assert isinstance(findings, list)
        
    def test_idor_check_with_dict_apis(self, mock_server_url):
        """Test IDOR check with dictionary API list."""
        check = IdorCheck()
        
        apis = [
            {"url": f"{mock_server_url}/documents/1", "method": "GET"},
            {"url": f"{mock_server_url}/users/2", "method": "GET"}
        ]
        
        findings = list(check.run(apis=apis))
        
        assert isinstance(findings, list)
        
    def test_idor_check_empty_apis(self):
        """Test IDOR check with empty API list."""
        check = IdorCheck()
        
        findings = list(check.run(apis=[]))
        assert len(findings) == 0
        
        findings = list(check.run(apis=None))
        assert len(findings) == 0


class TestMockIdorService:
    """Test the mock IDOR service endpoints."""
    
    @pytest.fixture
    def mock_server_url(self):
        """Start mock server for testing."""
        base_url = start_mock_server(port=5559)
        time.sleep(1)
        yield base_url
        stop_mock_server()
        
    def test_login_endpoint(self, mock_server_url):
        """Test login functionality."""
        response = requests.post(f"{mock_server_url}/login", json={
            "username": "admin",
            "password": "admin123"
        })
        
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "token" in data
        assert data["user"]["role"] == "admin"
        
    def test_vulnerable_document_endpoint(self, mock_server_url):
        """Test the vulnerable document endpoint."""
        # Test without authentication - should still return data (vulnerability)
        response = requests.get(f"{mock_server_url}/documents/2")
        
        # This endpoint is vulnerable - it should return data without checking auth
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert data["id"] == 2
        
    def test_secure_document_endpoint(self, mock_server_url):
        """Test the secure document endpoint."""
        # Test without authentication - should deny access
        response = requests.get(f"{mock_server_url}/secure/documents/2")
        
        # This endpoint is secure - should require authentication
        assert response.status_code == 403
        
    def test_vulnerable_user_endpoint(self, mock_server_url):
        """Test the vulnerable user endpoint."""
        # Test accessing user data without authentication
        response = requests.get(f"{mock_server_url}/users/2")
        
        # This endpoint is vulnerable - should return user data
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert data["id"] == 2
        
    def test_api_resource_query_parameter(self, mock_server_url):
        """Test the API resource endpoint with query parameter."""
        response = requests.get(f"{mock_server_url}/api/v1/resource?id=1")
        
        # This endpoint is vulnerable to query parameter manipulation
        assert response.status_code == 200
        data = response.json()
        assert "resource" in data


def test_end_to_end_idor_detection():
    """End-to-end test of IDOR detection with mock service."""
    # Start mock server
    base_url = start_mock_server(port=5560)
    time.sleep(1)
    
    try:
        # Initialize IDOR check
        check = IdorCheck()
        
        # Define test APIs that include vulnerable endpoints
        apis = [
            f"{base_url}/documents/2",  # Vulnerable endpoint
            f"{base_url}/users/1",      # Vulnerable endpoint
            f"{base_url}/api/v1/resource?id=3",  # Vulnerable query param
            f"{base_url}/secure/documents/2",    # Secure endpoint (should not be vulnerable)
        ]
        
        # Run IDOR detection
        findings = list(check.run(apis=apis))
        
        # Validate results
        assert isinstance(findings, list)
        
        # Print findings for debugging
        print(f"\nFound {len(findings)} IDOR findings:")
        for finding in findings:
            print(f"- {finding.title}: {finding.detail}")
            print(f"  Target: {finding.target}")
            print(f"  Severity: {finding.severity}")
            if finding.meta:
                print(f"  Meta: {finding.meta}")
            print()
            
    finally:
        stop_mock_server()


if __name__ == "__main__":
    # Run the end-to-end test when script is executed directly
    print("Running end-to-end IDOR detection test...")
    test_end_to_end_idor_detection()
    print("Test completed!")

