# Autoload project `src/` into sys.path so tests can import top-level packages
import sys
from pathlib import Path
import importlib.util
import pytest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# If optional external dependencies are missing, skip the related tests to keep CI stable
_HAS_FLASK = importlib.util.find_spec("flask") is not None

def pytest_ignore_collect(path, config):
    """Skip collecting tests that require Flask when Flask is not available.

    This runs before importing test modules so it prevents ImportError during
    collection for tests that import the mock Flask app at module scope.
    """
    if _HAS_FLASK:
        return False
    p = str(path)
    # heuristics: tests that reference mock_idor_app or have "idor" in filename
    if "mock_idor_app" in p or Path(p).stem.startswith("test_idor"):
        return True
    return False

def pytest_collection_modifyitems(config, items):
    if not _HAS_FLASK:
        skip_reason = "Flask not installed in environment; skipping IDOR integration tests"
        for item in list(items):
            p = str(item.fspath)
            # skip tests that reference mock_idor_app or are named idor_*
            if "mock_idor_app" in p or "idor" in Path(p).stem:
                item.add_marker(pytest.mark.skip(reason=skip_reason))
