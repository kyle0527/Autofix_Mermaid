from __future__ import annotations

import subprocess

from op_adapters.sqlmap import run_sqlmap
from op_adapters.xsstrike import run_xsstrike


def test_sqlmap_timeout(monkeypatch):
    def fake_run(cmd, capture_output, text, timeout):
        raise subprocess.TimeoutExpired(cmd, timeout)
    monkeypatch.setattr(subprocess, "run", fake_run)
    out = run_sqlmap("http://a")
    assert out and out[0]["evidence"]["error"] == "timeout"


def test_xsstrike_timeout(monkeypatch):
    def fake_run(cmd, capture_output, text, timeout):
        raise subprocess.TimeoutExpired(cmd, timeout)
    monkeypatch.setattr(subprocess, "run", fake_run)
    out = run_xsstrike("http://a")
    assert out and out[0]["evidence"]["error"] == "timeout"
