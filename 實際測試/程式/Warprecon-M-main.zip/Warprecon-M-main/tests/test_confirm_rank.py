from __future__ import annotations

import pytest

confirm = pytest.importorskip("op_core.confirm")
_variants = confirm._variants
from op_core import rank as rank_mod
from op_core.rank import rank_findings


def test_variants_contains_new():
    v = dict(_variants("Xx'"))
    assert "case_flip" in v
    assert "space_pad" in v


def test_rank_adds_rank_and_sorts(monkeypatch):
    items = [
        {"severity": "low", "vector": {"protocol": "http"}, "evidence": {}},
        {"severity": "high", "vector": {"protocol": "http"}, "evidence": {}},
    ]

    calls = {"n": 0}
    orig_strength = rank_mod.strength

    def wrapped(f):
        calls["n"] += 1
        return orig_strength(f)

    monkeypatch.setattr(rank_mod, "strength", wrapped)

    ranked = rank_findings(items)
    assert ranked[0]["severity"].lower() == "high"
    assert all("_rank" in f and "_score" in f for f in ranked)
    assert calls["n"] == len(items)
