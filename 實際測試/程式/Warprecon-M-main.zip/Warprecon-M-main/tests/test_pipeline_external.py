from __future__ import annotations

import logging
from pathlib import Path

from op_core import pipeline


def test_pipeline_logs_and_scans(monkeypatch, tmp_path, caplog):
    calls = {"sqlmap": 0, "xsstrike": 0}

    def fake_sqlmap(url):
        calls["sqlmap"] += 1
        return []

    def fake_xsstrike(url):
        calls["xsstrike"] += 1
        return []

    monkeypatch.setattr(pipeline, "run_sqlmap", fake_sqlmap)
    monkeypatch.setattr(pipeline, "run_xsstrike", fake_xsstrike)

    def fake_recon(domain):
        return ["http://a/graphql", "http://b", "http://c"], {}

    monkeypatch.setattr(pipeline, "_run_recon", fake_recon)

    class DummyCamp:
        def __init__(self):
            self.limits = type("L", (), {"max_concurrency": 0, "per_target_payloads": 0, "max_external_targets": 2})()
            self.output = type("O", (), {"poc_top": 0, "capture": False, "history_ttl_days": 0})()
            self.oob = type("Oob", (), {"base_url": "", "api_key": ""})()

    monkeypatch.setattr(pipeline, "load_campaign", lambda p: DummyCamp())
    monkeypatch.setattr(pipeline, "run_hunt", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "run_nuclei", lambda *a, **k: [])
    monkeypatch.setattr(pipeline, "rank_findings", lambda m, n: m)
    monkeypatch.setattr(pipeline, "write_poc_files", lambda *a, **k: None)
    monkeypatch.setattr(pipeline, "export_html", lambda w, r: str(w/"out.html"))
    monkeypatch.setattr(pipeline, "to_sarif", lambda r: "")
    monkeypatch.setattr(pipeline, "try_capture", lambda *a, **k: None)

    class DummyInteract:
        def poll(self):
            raise RuntimeError("oob fail")
        def export_events(self):
            return {}
        def correlate_findings(self, f):
            return f

    monkeypatch.setattr(pipeline, "InteractClient", lambda b, k: DummyInteract())
    monkeypatch.setattr(pipeline, "crawl_and_capture", lambda d: (_ for _ in ()).throw(RuntimeError("dom fail")))
    monkeypatch.setattr(pipeline, "try_introspect", lambda u: (_ for _ in ()).throw(RuntimeError("gql fail")))

    caplog.set_level(logging.ERROR)
    pipeline.run_pipeline("example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True)

    assert calls["sqlmap"] == 2
    assert calls["xsstrike"] == 2
    text = caplog.text
    assert "dom fail" in text
    assert "gql fail" in text
    assert "oob fail" in text
