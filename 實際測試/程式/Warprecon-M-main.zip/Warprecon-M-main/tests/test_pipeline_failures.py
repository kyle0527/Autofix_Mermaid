import json
import logging
from pathlib import Path

import pytest

from op_core import pipeline

# Helper to patch heavy deps

def patch_basics(monkeypatch, targets=None):
    if targets is None:
        targets = ["https://example.com"]
    monkeypatch.setattr(pipeline, "_run_recon", lambda domain: (targets, {}))
    monkeypatch.setattr(pipeline, "run_hunt", lambda targets, camp, hist, oob_client, workdir: [])
    monkeypatch.setattr(pipeline, "rank_findings", lambda findings, _: findings)
    monkeypatch.setattr(pipeline, "run_nuclei", lambda path, profile: [])
    monkeypatch.setattr(pipeline, "run_sqlmap", lambda target: [])
    monkeypatch.setattr(pipeline, "run_xsstrike", lambda target: [])
    monkeypatch.setattr(pipeline, "export_html", lambda workdir, ranked: str(workdir/"out.html"))
    monkeypatch.setattr(pipeline, "to_sarif", lambda ranked: "")
    monkeypatch.setattr(pipeline, "write_poc_files", lambda workdir, f, i: None)


def test_dom_crawl_failure(monkeypatch, caplog, tmp_path):
    patch_basics(monkeypatch)
    def fail_crawl(domain):
        raise RuntimeError("boom")
    monkeypatch.setattr(pipeline, "crawl_and_capture", fail_crawl)
    caplog.set_level(logging.ERROR)
    pipeline.run_pipeline("example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True)
    disc = tmp_path/"discovery"
    assert json.loads((disc/"dom-requests.json").read_text()) == []
    assert json.loads((disc/"dom-endpoints.json").read_text()) == []
    assert "DOM capture failed" in caplog.text


def test_graphql_introspection_failure(monkeypatch, caplog, tmp_path):
    patch_basics(monkeypatch, targets=["https://example.com/graphql"])
    def fail_introspect(url):
        raise RuntimeError("nope")
    monkeypatch.setattr(pipeline, "try_introspect", fail_introspect)
    caplog.set_level(logging.ERROR)
    pipeline.run_pipeline("example.com", Path("config/campaign.yaml"), tmp_path)
    assert not (tmp_path/"schema").exists()
    assert "GraphQL introspection failed" in caplog.text


def test_oob_poll_failure(monkeypatch, caplog, tmp_path):
    patch_basics(monkeypatch)
    class DummyOOB:
        def __init__(self, base_url, api_key):
            pass
        def poll(self):
            raise RuntimeError("poll fail")
        def export_events(self):
            return {}
        def correlate_findings(self, findings):
            return findings
    monkeypatch.setattr(pipeline, "InteractClient", DummyOOB)
    caplog.set_level(logging.ERROR)
    pipeline.run_pipeline("example.com", Path("config/campaign.yaml"), tmp_path)
    oob_dir = tmp_path/"oob"
    data = json.loads((oob_dir/"events.json").read_text())
    assert data["events"] == []
    assert "OOB poll failed" in caplog.text


def test_dom_screenshot_failure(monkeypatch, caplog, tmp_path):
    patch_basics(monkeypatch)
    async def ok_crawl(d):
        return {"requests": [], "endpoints": []}
    monkeypatch.setattr(pipeline, "crawl_and_capture", ok_crawl)
    def fail_capture(url, outdir):
        raise RuntimeError("snap")
    monkeypatch.setattr(pipeline, "try_capture", fail_capture)
    caplog.set_level(logging.ERROR)
    pipeline.run_pipeline("example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True)
    assert "DOM screenshot capture failed" in caplog.text


def test_dom_snapshot_cleanup_missing(monkeypatch, caplog, tmp_path):
    patch_basics(monkeypatch)
    async def ok_crawl(d):
        return {"requests": [], "endpoints": []}
    monkeypatch.setattr(pipeline, "crawl_and_capture", ok_crawl)
    def missing_file_capture(url, outdir):
        return (None, str(outdir/"missing.png"))
    monkeypatch.setattr(pipeline, "try_capture", missing_file_capture)
    caplog.set_level(logging.WARNING)
    pipeline.run_pipeline("example.com", Path("config/campaign.yaml"), tmp_path, dom_crawl=True)
    assert "DOM snapshot cleanup missing" in caplog.text
