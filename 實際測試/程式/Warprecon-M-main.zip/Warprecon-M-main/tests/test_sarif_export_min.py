import json
from pathlib import Path
from op_output.sarif import export_sarif


def test_sarif_export_min(tmp_path: Path):
    items = [
        {"fingerprint": "a", "severity": "high", "url": "http://a"},
        {"fingerprint": "b", "severity": "low"},
    ]
    path = export_sarif(tmp_path, items)
    data = json.loads(Path(path).read_text())
    assert "runs" in data and data["runs"][0]["results"][0]["ruleId"]
    assert len(data["runs"][0]["results"]) == 2
