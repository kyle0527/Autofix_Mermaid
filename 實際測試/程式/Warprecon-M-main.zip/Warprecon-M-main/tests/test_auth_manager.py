from __future__ import annotations

from op_auth import AuthManager, AuthStrategy


class DummyStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.login_calls = 0

    def login(self, client) -> None:
        self.login_calls += 1
        client["token"] = "ok"

    def ensure_session(self, client) -> None:
        if "token" not in client:
            self.login(client)


def test_multi_role_manager_handles_sessions() -> None:
    admin_strategy = DummyStrategy()
    user_strategy = DummyStrategy()

    mgr = AuthManager(
        {"admin": admin_strategy, "user": user_strategy},
        client_factory=dict,
    )

    admin_client = mgr.client_for("admin")
    assert admin_strategy.login_calls == 1

    # simulate expiry
    del admin_client["token"]
    admin_client = mgr.client_for("admin")
    assert admin_strategy.login_calls == 2

    user_client = mgr.client_for("user")
    assert user_strategy.login_calls == 1
    assert admin_client is not user_client
