import yaml

from op_core.config_builder import build_config



def test_build_config_generates_yaml_with_profile():
    cfg = build_config(
        "https://example.com",
        spa=True,
        budget=30,
        profile="config/profiles/api-only.yaml",
    )
    data = yaml.safe_load(cfg)
    assert data["scopes"]["allow"] == ["https://example.com"]
    assert data["dom"]["crawl"] is True
    assert data["limits"]["max_scan_minutes"] == 30
    assert data["profile"] == "config/profiles/api-only.yaml"

