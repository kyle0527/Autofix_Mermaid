from pathlib import Path

import pytest
from op_chain.assembler import build_graph, suggest_paths
from op_dist.queue import FSQueue

# Skip UI tests if the server module or its dependencies are missing
create_app = pytest.importorskip("op_ui.server").create_app
def test_chain_paths():
    items = [
        {"url":"https://a","vector":{"protocol":"http"}, "payload":"<script>alert(1)</script>", "severity":"medium","_score":50},
        {"url":"https://a","vector":{"protocol":"http"}, "payload":"') UNION SELECT NULL --", "severity":"high","_score":80},
        {"url":"https://b","vector":{"protocol":"http"}, "payload":"http://169.254.169.254/", "severity":"high","_score":85, "evidence":{"oob_token":"t"}},
    ]
    G = build_graph(items); paths = suggest_paths(G, top_k=3)
    assert paths and isinstance(paths[0][0], list)
def test_queue_ops(tmp_path: Path):
    q = FSQueue(tmp_path); tid = q.enqueue("example.com","cfg")
    s1 = q.status(); assert s1["pending"]==1
    d = q.dequeue(); assert d is not None
    q.complete(d[0], {"ok":True})
    s2 = q.status(); assert s2["done"]==1
def test_ui_health(tmp_path: Path):
    app = create_app(tmp_path, Path("config/campaign.yaml"))
    c = app.test_client(); r = c.get("/healthz")
    assert r.status_code == 200 and r.json.get("ok") is True
