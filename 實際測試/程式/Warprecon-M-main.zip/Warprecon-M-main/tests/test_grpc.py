from __future__ import annotations

import pytest

pytest.importorskip("op_proto.grpc.engine")
pytest.importorskip("op_proto.grpc.reflector")
pytest.importorskip("op_proto.grpc.enumerate")

from op_proto.grpc.engine import probe_unary_unary, reflect_services, grpc_probe
from op_proto.grpc.reflector import call_reflect_json
from op_proto.grpc.enumerate import enumerate_methods


def test_grpc_modules_import_and_fail_gracefully():
    # Should not crash even if grpc libs or network not available
    ev = probe_unary_unary("localhost:50051", "/pkg.Svc/Method", b"", tls=False, timeout=0.5)
    assert isinstance(ev, dict)
    r = reflect_services("localhost:50051", tls=False, timeout=0.5)
    assert isinstance(r, dict)
    j = call_reflect_json("localhost:50051", "/pkg.Svc/Method", {"a": 1}, tls=False, timeout=0.5)
    assert isinstance(j, dict)
    ms = enumerate_methods("localhost:50051", tls=False, timeout=0.5)
    assert isinstance(ms, list)
    gp = grpc_probe("localhost:50051")
    assert isinstance(gp, list)


def test_grpc_probe_returns_list():
    res = grpc_probe("localhost:50051")
    assert isinstance(res, list)
