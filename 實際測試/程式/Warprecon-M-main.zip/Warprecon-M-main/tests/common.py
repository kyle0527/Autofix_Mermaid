from __future__ import annotations
from pathlib import Path
import json, tempfile

def make_workdir(prefix: str = "warprecon-m_test_") -> Path:
    p = Path(tempfile.mkdtemp(prefix=prefix))
    return p

def sample_ranked() -> list[dict]:
    return [
        {"severity":"high","vector":{"protocol":"http","location":"query"},"payload":"<script>alert(1)</script>","evidence":{"variant_hits":["urlenc"]},"_score":95,"_rank":1,"url":"https://example.com/"},
        {"severity":"medium","vector":{"protocol":"graphql","location":"query"},"payload":"query{__typename}","evidence":{},"_score":50,"_rank":2,"url":"https://api.example.com/graphql"}
    ]
