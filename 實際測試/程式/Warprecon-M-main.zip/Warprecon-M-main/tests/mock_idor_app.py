
#!/usr/bin/env python3
"""
Mock IDOR service for testing unauthorized access detection.
Simulates various endpoint behaviors including secure and insecure access patterns.
"""

from flask import Flask, jsonify, request, session
from typing import Dict, Any, Optional
import secrets
import threading
import time

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Mock user database
USERS = {
    "admin": {"id": 1, "role": "admin", "password": "admin123", "email": "admin@example.com"},
    "user1": {"id": 2, "role": "user", "password": "user123", "email": "user1@example.com"},
    "user2": {"id": 3, "role": "user", "password": "user456", "email": "user2@example.com"},
}

# Mock data - documents that users should/shouldn't access
DOCUMENTS = {
    1: {"id": 1, "title": "Public Document", "content": "This is public", "owner_id": None, "public": True},
    2: {"id": 2, "title": "User1 Private Doc", "content": "User1's private document", "owner_id": 2, "public": False},
    3: {"id": 3, "title": "User2 Private Doc", "content": "User2's private document", "owner_id": 3, "public": False},
    4: {"id": 4, "title": "Admin Only Doc", "content": "Admin only document", "owner_id": 1, "public": False},
}

# Mock sessions storage
SESSIONS = {}

def get_current_user() -> Optional[Dict[str, Any]]:
    """Get current authenticated user from session."""
    user_id = session.get("user_id")
    if user_id:
        for username, user_data in USERS.items():
            if user_data["id"] == user_id:
                return {"username": username, **user_data}
    return None

def is_admin(user: Optional[Dict[str, Any]]) -> bool:
    """Check if user has admin role."""
    return user and user.get("role") == "admin"

def can_access_document(user: Optional[Dict[str, Any]], doc_id: int) -> bool:
    """Check if user can access the document."""
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        return False
    
    # Public documents are accessible to all
    if doc.get("public"):
        return True
    
    # No user logged in
    if not user:
        return False
    
    # Admin can access everything
    if is_admin(user):
        return True
    
    # User can access their own documents
    return doc.get("owner_id") == user.get("id")

@app.route("/")
def index():
    """Root endpoint."""
    return jsonify({"message": "IDOR Test Service", "version": "1.0"})

@app.route("/login", methods=["POST"])
def login():
    """Login endpoint."""
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    
    user = USERS.get(username)
    if user and user["password"] == password:
        session["user_id"] = user["id"]
        session["username"] = username
        token = secrets.token_hex(16)
        SESSIONS[token] = {
            "user_id": user["id"],
            "username": username,
            "created_at": time.time()
        }
        return jsonify({
            "success": True,
            "message": "Login successful",
            "token": token,
            "user": {"id": user["id"], "username": username, "role": user["role"]}
        })
    
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route("/logout", methods=["POST"])
def logout():
    """Logout endpoint."""
    session.clear()
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if token in SESSIONS:
        del SESSIONS[token]
    return jsonify({"success": True, "message": "Logged out"})

@app.route("/profile")
def profile():
    """User profile endpoint - requires authentication."""
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    
    return jsonify({
        "id": user["id"],
        "username": user["username"],
        "email": user["email"],
        "role": user["role"]
    })

@app.route("/documents")
def list_documents():
    """List documents endpoint."""
    user = get_current_user()
    accessible_docs = []
    
    for doc_id, doc in DOCUMENTS.items():
        if can_access_document(user, doc_id):
            accessible_docs.append({
                "id": doc["id"],
                "title": doc["title"],
                "public": doc.get("public", False)
            })
    
    return jsonify({"documents": accessible_docs})

@app.route("/documents/<int:doc_id>")
def get_document(doc_id: int):
    """Get specific document - VULNERABLE to IDOR."""
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    
    # VULNERABILITY: No access control check!
    return jsonify(doc)

@app.route("/secure/documents/<int:doc_id>")
def get_document_secure(doc_id: int):
    """Get specific document - SECURE version with proper access control."""
    user = get_current_user()
    
    if not can_access_document(user, doc_id):
        return jsonify({"error": "Access denied"}), 403
    
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    
    return jsonify(doc)

@app.route("/users/<int:user_id>")
def get_user(user_id: int):
    """Get user info - VULNERABLE to IDOR."""
    for username, user_data in USERS.items():
        if user_data["id"] == user_id:
            # VULNERABILITY: Returns sensitive data without access control
            return jsonify({
                "id": user_data["id"],
                "username": username,
                "email": user_data["email"],
                "role": user_data["role"]
            })
    
    return jsonify({"error": "User not found"}), 404

@app.route("/secure/users/<int:user_id>")
def get_user_secure(user_id: int):
    """Get user info - SECURE version."""
    current_user = get_current_user()
    
    # Only admin or the user themselves can access user data
    if not current_user or (current_user["id"] != user_id and not is_admin(current_user)):
        return jsonify({"error": "Access denied"}), 403
    
    for username, user_data in USERS.items():
        if user_data["id"] == user_id:
            return jsonify({
                "id": user_data["id"],
                "username": username,
                "email": user_data["email"],
                "role": user_data["role"]
            })
    
    return jsonify({"error": "User not found"}), 404

@app.route("/api/v1/resource")
def api_resource():
    """API endpoint that checks query parameter access."""
    resource_id = request.args.get("id")
    if not resource_id:
        return jsonify({"error": "Missing id parameter"}), 400
    
    try:
        resource_id = int(resource_id)
    except ValueError:
        return jsonify({"error": "Invalid id parameter"}), 400
    
    # VULNERABILITY: No access control on query parameter
    if resource_id in DOCUMENTS:
        return jsonify({"resource": DOCUMENTS[resource_id]})
    
    return jsonify({"error": "Resource not found"}), 404

@app.route("/auth/token", methods=["GET"])
def check_token():
    """Check if token-based auth is valid."""
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    
    if token in SESSIONS:
        session_data = SESSIONS[token]
        return jsonify({
            "valid": True,
            "user_id": session_data["user_id"],
            "username": session_data["username"]
        })
    
    return jsonify({"valid": False}), 401

# Global variable to store the server
_server = None
_thread = None

def start_mock_server(port: int = 5555) -> str:
    """Start the mock server in a background thread."""
    global _server, _thread
    
    if _thread and _thread.is_alive():
        return f"http://localhost:{port}"
    
    def run_server():
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
    
    _thread = threading.Thread(target=run_server, daemon=True)
    _thread.start()
    
    # Give the server a moment to start
    time.sleep(0.5)
    
    return f"http://localhost:{port}"

def stop_mock_server():
    """Stop the mock server."""
    global _server, _thread
    # Flask doesn't provide an easy way to stop from code, 
    # but since it's running in daemon thread, it will stop when main process ends
    pass

def create_mock_app():
    """Create and return the mock Flask app for testing."""
    return app

if __name__ == "__main__":
    print("Starting IDOR mock service...")
    print("Available endpoints:")
    print("  POST /login - Login with username/password")
    print("  GET /profile - Get user profile (requires auth)")
    print("  GET /documents - List accessible documents")
    print("  GET /documents/<id> - Get document (VULNERABLE)")
    print("  GET /secure/documents/<id> - Get document (SECURE)")
    print("  GET /users/<id> - Get user info (VULNERABLE)")
    print("  GET /secure/users/<id> - Get user info (SECURE)")
    print("  GET /api/v1/resource?id=<id> - API resource access (VULNERABLE)")
    print("\nTest users:")
    for username, user_data in USERS.items():
        print(f"  {username}: password={user_data['password']}, role={user_data['role']}")
    
    app.run(host="127.0.0.1", port=5555, debug=True)

