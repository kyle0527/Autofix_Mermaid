from __future__ import annotations

from pathlib import Path

import pytest

load_plugins = pytest.importorskip("op_plugins.loader").load_plugins

PLUGIN = """
def post_rank(ranked):
    for f in ranked:
        f['_score'] = f.get('_score',0) + 1
    return ranked
"""


def test_plugin_loader(tmp_path: Path):
    w = tmp_path
    (w / "plugins").mkdir()
    (w / "plugins" / "p_custom.py").write_text(PLUGIN, encoding="utf-8")
    hooks = load_plugins(w)
    assert "post_rank" in hooks and hooks["post_rank"]
    # ensure custom plugin loaded
    custom_path = w / "plugins" / "p_custom.py"
    assert any(f.__code__.co_filename == str(custom_path) for f in hooks["post_rank"])
    # ensure builtin plugins loaded
    builtin_dir = Path(__file__).resolve().parents[1] / "src" / "op_plugins" / "builtin"
    assert any(Path(f.__code__.co_filename).parent == builtin_dir for f in hooks["post_rank"])


def test_dom_browser_returns_dict():
    browser_mod = pytest.importorskip("op_dom.browser")
    extract_hints_with_playwright = browser_mod.extract_hints_with_playwright
    out = extract_hints_with_playwright("http://localhost:9")
    assert isinstance(out, dict)


def test_wordlist_writer(tmp_path: Path):
    wordlist_mod = pytest.importorskip("op_synth.wordlist")
    p = wordlist_mod.save_wordlist(tmp_path, ["alpha", "beta", "alpha"], name="unit")
    assert Path(p).exists()
