from __future__ import annotations

from pathlib import Path

import pytest
import sys
import types
import builtins

from tests.common import make_workdir, sample_ranked
import builtins, sys, types, logging
from op_output.artifacts import try_capture

sarif_mod = pytest.importorskip("op_output.sarif")
if not hasattr(sarif_mod, "export_sarif"):
    pytest.skip("SARIF export not available", allow_module_level=True)

from op_output.sarif import export_sarif
from op_output.html import export_html
from op_output.html_cards import export_html_cards
from op_output.artifacts import try_capture

def test_exporters_create_files(tmp_path: Path):
    wd = make_workdir('warprecon-m_out_')
    ranked = sample_ranked()
    sp = export_sarif(wd, ranked)
    hp = export_html(wd, ranked)
    cp = export_html_cards(wd, ranked)
    assert Path(sp).exists() and Path(hp).exists() and Path(cp).exists()


def test_try_capture_import_warning(monkeypatch, caplog, tmp_path: Path):
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "playwright.sync_api":
            raise ImportError("no playwright")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    caplog.set_level("WARNING")
    har, png, err = try_capture("http://example.com", tmp_path)
    assert har is None and png is None
    assert "no playwright" in (err or "")
    assert "Playwright import failed" in caplog.text


def test_try_capture_goto_warning(monkeypatch, caplog, tmp_path: Path):
    class DummyPage:
        def goto(self, url, timeout):
            raise RuntimeError("boom")


def test_try_capture_import_failure(monkeypatch, tmp_path, caplog):
    caplog.set_level(logging.WARNING)
    original_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "playwright.sync_api":
            raise RuntimeError("missing")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    har, png, err = try_capture("http://example.com", tmp_path)
    assert har is None and png is None and err
    assert "Playwright import failed" in caplog.text


def test_try_capture_goto_failure(monkeypatch, tmp_path, caplog):
    caplog.set_level(logging.WARNING)

    class DummyPage:
        def goto(self, url, timeout):
            raise RuntimeError("boom")

        def screenshot(self, path, full_page):
            pass

    class DummyContext:
        def new_page(self):
            return DummyPage()

        def close(self):
            pass

    class DummyBrowser:
        def new_context(self, record_har_path):
            return DummyContext()


        def close(self):
            pass

    class DummyPW:
        def __enter__(self):
            class DummyBrowserType:
                def launch(self, headless):
                    return DummyBrowser()

            return types.SimpleNamespace(chromium=DummyBrowserType())

        def __exit__(self, exc_type, exc, tb):
            pass

    def fake_sync_playwright():
        return DummyPW()

    sync_api_module = types.ModuleType("playwright.sync_api")
    sync_api_module.sync_playwright = fake_sync_playwright
    playwright_module = types.ModuleType("playwright")
    playwright_module.sync_api = sync_api_module
    monkeypatch.setitem(sys.modules, "playwright", playwright_module)
    monkeypatch.setitem(sys.modules, "playwright.sync_api", sync_api_module)

    caplog.set_level("WARNING")
    har, png, err = try_capture("http://example.com", tmp_path)
    assert har is None and png is None
    assert err == "boom"

        def close(self):
            pass

    class DummyPlaywright:
        chromium = types.SimpleNamespace(launch=lambda headless=True: DummyBrowser())
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc, tb):
            pass

    monkeypatch.setitem(sys.modules, "playwright", types.SimpleNamespace(sync_api=types.SimpleNamespace(sync_playwright=lambda: DummyPlaywright())))
    har, png, err = try_capture("http://example.com", tmp_path)
    assert har is None and png is None and err
    assert "Capture failed" in caplog.text

