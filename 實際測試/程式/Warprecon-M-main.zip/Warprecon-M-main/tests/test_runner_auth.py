from op_auth import AuthManager, AuthStrategy
from op_core import plugins
import sys, types


class DummyStrategy(AuthStrategy):
    def __init__(self) -> None:
        self.login_called = 0
        self.ensure_called = 0

    def login(self, client):
        self.login_called += 1

    def ensure_session(self, client):
        self.ensure_called += 1


class DummyResponse:
    headers = {"content-type": "text/html"}
    text = ""
    url = "http://example.com"


class DummyClient:
    async def get(self, *a, **kw):  # pragma: no cover - simple stub
        return DummyResponse()

    async def aclose(self):
        pass


class DummyCamp:
    class Limits:
        global_rps = 30
        per_host_rps = 6
        jitter_ms = 120
        max_concurrency = 8
        per_target_payloads = 8
        retries = 1

    class Bandit:
        arms: list = []

    class OOBCfg:
        base_url = None
        api_key = None

    class SynthCfg:
        transforms: list = []

    limits = Limits()
    bandit = Bandit()
    oob = OOBCfg()
    synth = SynthCfg()


def test_run_hunt_invokes_auth_manager(tmp_path, monkeypatch):
    # Inject stub campaign module before importing runner
    sys.modules['op_control.campaign'] = types.SimpleNamespace(Campaign=DummyCamp)

    class _DummyDeDup:
        def seen_before(self, item):
            return False

    sys.modules['op_core.dedupe'] = types.SimpleNamespace(DeDup=_DummyDeDup, fp=lambda item: "0")

    from op_core.runner import run_hunt

    strat = DummyStrategy()
    mgr = AuthManager({"default": strat}, lambda: DummyClient())
    camp = DummyCamp()

    monkeypatch.setattr(
        "op_core.runner.generate_candidates", lambda *a, **k: []
    )  # noqa: E501
    monkeypatch.setattr(
        "op_core.runner.probe_positions", lambda *a, **k: []
    )  # noqa: E501

    async def _noop_probe(*a, **k):
        return None

    monkeypatch.setattr(plugins, "_probe_registry", {})
    for proto in ["http", "graphql", "ws", "grpc"]:
        plugins.register_protocol(proto, _noop_probe)

    findings = run_hunt(  # noqa: E501
        ["http://example.com"], camp, workdir=tmp_path, auth=mgr
    )
    assert findings == []
    assert strat.login_called == 1
