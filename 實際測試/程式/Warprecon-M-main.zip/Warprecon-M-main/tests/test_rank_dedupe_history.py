from op_core.rank import rank_findings
from op_core.dedupe import DeDup, fp
from op_core.history import HistoryDB
from pathlib import Path


def test_rank_sidechannels(tmp_path):
    a = {
        "severity": "medium",
        "vector": {"protocol": "http"},
        "evidence": {"len_delta": 60, "time_delta": 0.3},
    }
    b = {"severity": "medium", "vector": {"protocol": "http"}, "evidence": {}}
    ranked = rank_findings([b, a])
    assert ranked[0] is a



    it = {"target":"https://x",
          "mode":"xss",
          "vector":{"location":"query","param":"q","protocol":"http"},
          "payload":"abc"}
    d = DeDup()
    assert d.seen_before(it) is False
    assert d.seen_before(it) is True
    h = HistoryDB(tmp_path / "history.jsonl", ttl_days=1)
    key = fp(it)
    assert h.seen(key) is False
    h.remember(key, {"ok": True})
    assert h.seen(key) is True

def test_fp_changes_with_protocol_and_mode():
    base = {"target":"https://x","vector":{"location":"query","param":"q"},"payload":"abc"}
    a = {**base, "mode":"xss","vector":{**base["vector"],"protocol":"http"}}
    b = {**base, "mode":"sqli","vector":{**base["vector"],"protocol":"http"}}
    c = {**base, "mode":"xss","vector":{**base["vector"],"protocol":"ws"}}
    assert fp(a) != fp(b)
    assert fp(a) != fp(c)


def test_fp_includes_protocol_and_mode():
    base = {"target": "x", "vector": {"location": "q", "param": "p", "protocol": "http"}, "payload": "abc", "mode": "xss"}
    proto_diff = {"target": "x", "vector": {"location": "q", "param": "p", "protocol": "ws"}, "payload": "abc", "mode": "xss"}
    mode_diff = {"target": "x", "vector": {"location": "q", "param": "p", "protocol": "http"}, "payload": "abc", "mode": "sqli"}
    no_mode = {"target": "x", "vector": {"location": "q", "param": "p", "protocol": "http"}, "payload": "abc"}
    assert fp(base) != fp(proto_diff)
    assert fp(base) != fp(mode_diff)
    assert fp(no_mode) != fp(base)


