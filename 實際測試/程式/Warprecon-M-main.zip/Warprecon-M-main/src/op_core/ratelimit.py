from __future__ import annotations

import asyncio
import threading
import time


class TokenBucket:
    def __init__(self, rate: float, burst: int):
        self.rate = rate
        self.capacity = burst
        self.tokens = burst
        self.lock = threading.Lock()
        self.updated = time.monotonic()

    def take(self, n: int = 1) -> bool:
        with self.lock:
            now = time.monotonic()
            delta = now - self.updated
            self.updated = now
            self.tokens = min(self.capacity, self.tokens + delta * self.rate)
            if self.tokens >= n:
                self.tokens -= n
                return True
            return False


class RateLimiter:
    """Simple async rate limiter with global and per-host buckets."""

    def __init__(
        self,
        global_rps: float,
        per_host_rps: float,
        jitter_ms: int = 0,
        state_file: str | None = None,
    ) -> None:
        burst_g = max(1, int(global_rps))
        burst_h = max(1, int(per_host_rps))
        self.global_bucket = TokenBucket(global_rps, burst_g)
        self.per_host_rps = per_host_rps
        self.burst_host = burst_h
        self.host_buckets: dict[str, TokenBucket] = {}
        self.jitter = jitter_ms / 1000.0

    def _bucket_for(self, host: str) -> TokenBucket:
        b = self.host_buckets.get(host)
        if b is None:
            b = TokenBucket(self.per_host_rps, self.burst_host)
            self.host_buckets[host] = b
        return b

    async def acquire(self, host: str) -> None:
        while True:
            took_global = self.global_bucket.take()
            took_host = self._bucket_for(host).take()
            if took_global and took_host:
                return
            await asyncio.sleep(0.01 + self.jitter)

    def penalize(self, host: str, penalty: float) -> None:
        b = self._bucket_for(host)
        with b.lock:
            b.tokens = max(0.0, b.tokens - penalty)
