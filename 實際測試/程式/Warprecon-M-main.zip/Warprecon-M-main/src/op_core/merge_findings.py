"""Utilities to merge and normalize finding lists.

- Each input may be a ``list[dict]`` or object with a ``"findings"`` list.
- Dedupe key: ``fingerprint`` | ``id`` | ``sha1(type+target+path)``
- Score is filled based on severity if ``_score`` is missing.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

_SEV_BASE = {"critical":0.90, "high":0.75, "medium":0.55, "low":0.35, "info":0.20}

def _norm_items(obj, source_tag: str) -> List[Dict[str, Any]]:
    if isinstance(obj, dict) and "findings" in obj:
        items = obj["findings"]
    elif isinstance(obj, list):
        items = obj
    else:
        items = []
    out: List[Dict[str, Any]] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        it = dict(it)  # copy
        it.setdefault("source", source_tag)
        # severity normalize
        sev = str(it.get("severity", "info")).lower()
        if sev not in _SEV_BASE:
            sev = "info"
        it["severity"] = sev
        # default score
        if "_score" not in it:
            it["_score"] = _SEV_BASE[sev]
        # fingerprint
        fp = it.get("fingerprint") or it.get("fp") or it.get("id")
        if not fp:
            h = hashlib.sha1()
            payload = (
                str(it.get("type", ""))
                + "|"
                + str(it.get("target", ""))
                + "|"
                + str(it.get("path", ""))
            )
            h.update(payload.encode("utf-8"))
            fp = h.hexdigest()[:16]
        it["fingerprint"] = fp
        out.append(it)
    return out

def _load_one(path: Path, source_tag: str) -> List[Dict[str, Any]]:
    try:
        j = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    return _norm_items(j, source_tag)

def merge(paths: List[Path]) -> List[Dict[str, Any]]:
    bag: Dict[str, Dict[str, Any]] = {}
    for p in paths:
        items = _load_one(p, source_tag=p.stem)
        for it in items:
            fp = it["fingerprint"]
            if fp not in bag or float(it.get("_score",0.0)) > float(bag[fp].get("_score",0.0)):
                bag[fp] = it
    out = list(bag.values())
    out.sort(key=lambda x: float(x.get("_score",0.0)), reverse=True)
    for i, it in enumerate(out, start=1):
        it["_rank"] = i
    return out

def _cli() -> None:
    ap = argparse.ArgumentParser(description="Merge multiple findings JSON into ranked list")
    ap.add_argument("--inputs", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    paths = [Path(x) for x in args.inputs]
    out = merge(paths)
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"merged": len(out), "out": args.out}, ensure_ascii=False))

if __name__ == "__main__":
    _cli()
