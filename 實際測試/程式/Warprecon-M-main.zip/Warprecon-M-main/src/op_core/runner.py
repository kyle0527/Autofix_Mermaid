from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Any

from op_auth import AuthManager, NoAuthStrategy
from op_control.campaign import Campaign
from op_core.history import HistoryDB
from op_core.httpclient import make_async_client

from op_core.runtime_gate import wait_if_paused
from op_oob.interactsh import InteractClient
from op_synth.synth import generate_candidates, probe_positions


async def run_hunt_async(
    targets: List[str],
    camp: Campaign,

    history: Optional[HistoryDB] = None,
    oob_client: Optional[InteractClient] = None,
    workdir: Optional[Path] = None,
    auth: Optional[AuthManager] = None,
) -> List[Dict]:

    """Simple asynchronous hunting loop.

    This minimal implementation only exercises the authentication manager and
    candidate generation hooks. Probe functions are provided as patchable
    placeholders so tests can simulate protocol handling.
    """

    # Import linucb implementation lazily so importing this module doesn't
    # fail in lightweight test envs that don't exercise bandit behavior.
    from op_bandit.contextual import LinUCB


    arms = camp.bandit.arms or [
        {"mode": "xss", "protocol": "http", "location": "query"},
        {"mode": "sqli", "protocol": "http", "location": "query"},
        {"mode": "ssrf", "protocol": "http", "location": "header"},
        {"mode": "gql", "protocol": "graphql", "location": "body"},
        {"mode": "ws", "protocol": "ws", "location": "message"},
        {"mode": "grpc", "protocol": "grpc", "location": "body"},
    ]
    bandit = LinUCB(arms)
    oob = oob_client or InteractClient(
        getattr(camp.oob, "base_url", None),
        getattr(camp.oob, "api_key", None),
    )
    state_file = (workdir / "limiter_state.json") if workdir else None

    # Import RateLimiter locally so test modules can stub op_core.runner without
    # requiring the ratelimit module at import time.
    from op_core.ratelimit import RateLimiter

    RateLimiter(
        camp.limits.global_rps,
        camp.limits.per_host_rps,
        camp.limits.jitter_ms,
        state_file=state_file,
    )

    findings: List[Dict] = []
    # Import dedupe helpers locally so tests can stub op_core.dedupe
    from op_core.dedupe import DeDup

    dd = DeDup()
    sem = asyncio.Semaphore(camp.limits.max_concurrency)


    if auth is None:
        auth = AuthManager({"default": NoAuthStrategy()}, lambda: make_async_client(workdir or Path(".")))

    for t in targets:
        client = auth.client_for("default")
        await wait_if_paused(workdir)
        try:
            await probe_positions(t)
        except Exception:
            pass
        generate_candidates(
            t,
            {"protocol": "http", "mode": "xss", "location": "query"},
            per_target=camp.limits.per_target_payloads,
            transforms=camp.synth.transforms,
        )
        # Probe functions are patched in tests; we simply keep references for monkeypatching
        _ = (client,)

    async def handle_target(t: str) -> None:
        async with sem:
            client = auth.client_for("default")
            try:
                pos = await probe_positions(t)
            except Exception:
                pos = []
            ordered = bandit.order({})

            async with make_async_client(workdir or Path(".")) as client:
                form_picks: List[Dict] = []
                try:
                    r0 = await client.get(t, timeout=8.0)
                    if "html" in (r0.headers.get("content-type", "").lower()):
                        forms = extract_forms(str(r0.url), r0.text or "")
                        form_picks = choose_form_fields(forms)
                except Exception:
                    pass
                for idx, arm in enumerate(ordered):
                    cands = generate_candidates(
                        t,
                        arm,
                        per_target=camp.limits.per_target_payloads,
                        transforms=camp.synth.transforms,
                    )
                    for p in pos[:3]:
                        if arm.get("protocol") == "http":
                            cands.append(
                                {
                                    "mode": arm.get("mode"),
                                    "location": p["location"],
                                    "param": p.get("param"),
                                    "payload": "test",
                                    "transform": "identity",
                                }
                            )
                    if arm.get("protocol") == "http" and form_picks:
                        base_payload = "OMEGA_" + (arm.get("mode") or "x")
                        for fpick in form_picks[:3]:
                            cands.append(
                                {
                                    "mode": arm.get("mode"),
                                    "location": "form",
                                    "param": fpick["target_param"],
                                    "payload": base_payload,
                                    "transform": "form_ctx",
                                    "form_ctx": fpick["ctx"],
                                }
                            )
                    for cand in cands:
                        item: Dict[str, Any] = {
                            "target": t,
                            "vector": {
                                "protocol": cand.get("protocol", arm["protocol"]),
                                "location": cand.get("location"),
                                "param": cand.get("param"),
                            },
                            "payload": cand.get("payload", ""),
                        }
                        mode = cand.get("mode") or arm.get("mode")
                        if mode:
                            item["mode"] = mode

                        key = fp(item)
                        if history and history.seen(key):
                            continue

                        f: Optional[Any] = None
                        probe = get_protocol(arm["protocol"])
                        if probe:
                            if arm["protocol"] == "http":
                                await wait_if_paused(workdir)
                            try:

                                f = await ws_probe(t, cand, oob, retries=camp.limits.retries)
                            except NameError:
                                f = None
                        elif arm["protocol"] == "grpc":
                            f = grpc_probe(t)

                        if f:
                            if isinstance(f, dict) and "_penalize" in f:
                                limiter.penalize(host, float(f.get("_penalize", 0.5)))
                                continue
                            if not dd.seen_before(f):
                                findings.append(f); bandit.update(idx, 1.0)
                                if history: history.remember(key, {"ok":True})
                                return
                            else:
                                if history: history.remember(key, {"ok":False})
                    bandit.update(idx, 0.0)



                        if f and not dd.seen_before(f):
                            findings.append(f)  # type: ignore[arg-type]
                            bandit.update(idx, 1.0)
                            if history:
                                history.remember(key, {"ok": True})
                            return
                        else:
                            if history:
                                history.remember(key, {"ok": False})
                bandit.update(idx, 0.0)


    await auth.close_all()
    return []


def run_hunt(
    targets: List[str],
    camp: Campaign,
    history: Optional[HistoryDB] = None,
    oob_client: Optional[InteractClient] = None,
    workdir: Optional[Path] = None,
    auth: Optional[AuthManager] = None,
) -> List[Dict]:
    """Run the asynchronous hunt synchronously."""

    return asyncio.run(
        run_hunt_async(
            targets,
            camp,
            history,
            oob_client=oob_client,
            workdir=workdir,
            auth=auth,
        )
    )


# Placeholder probe functions for monkeypatching in tests
async def http_probe(*a, **k):
    return None


async def graphql_probe(*a, **k):
    return None


async def ws_probe(*a, **k):
    return None


async def grpc_probe(*a, **k):
    return None

