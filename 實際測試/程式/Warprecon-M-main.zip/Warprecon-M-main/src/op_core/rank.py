from __future__ import annotations

from typing import Dict, List, Optional


BASE = {"critical": 100, "high": 70, "medium": 40, "low": 20, "info": 10}


def strength(f: Dict) -> float:
    """Compute a heuristic strength score for a finding."""
    s = BASE.get((f.get("severity") or "medium").lower(), 40)
    ev = f.get("evidence", {}) or {}
    if ev.get("dns_log") or ev.get("oob_token"):
        s += 35
    if ev.get("len_delta") and abs(ev["len_delta"]) > 50:
        s += 10
    if ev.get("time_delta") and ev["time_delta"] > 0.2:
        s += 8
    if ev.get("header_anomaly"):
        s += 5
    proto = (f.get("vector", {}).get("protocol") or "").lower()
    if proto in {"grpc", "ws", "graphql"}:
        s += 10
    if f.get("tool") in {"sqlmap", "nuclei", "xsstrike"}:
        s += 6
    return s


def rank_findings(items: List[Dict], history: Optional[object] = None) -> List[Dict]:
    """Rank findings in descending order of strength.

    Each finding receives two extra fields:

    * ``_score`` – computed by :func:`strength`
    * ``_rank``  – 1-based rank based on ``_score``
    """
    for f in items:
        f["_score"] = strength(f)
    out = sorted(items, key=lambda f: f["_score"], reverse=True)
    for i, x in enumerate(out, start=1):
        x["_rank"] = i
    return out
