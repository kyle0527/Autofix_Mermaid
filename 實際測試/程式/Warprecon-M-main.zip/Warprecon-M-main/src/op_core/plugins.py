from __future__ import annotations

from typing import Any, Callable, Dict, Optional, Protocol


class ProtocolProbe(Protocol):
    async def __call__(
        self,
        target: str,
        cand: Dict[str, Any],
        mint: Any,
        client: Any | None = None,
        retries: int = 0,
    ) -> Optional[Any]:
        """Inspect ``target`` using ``cand`` and return a finding."""


# Global registry mapping protocol name -> probe function
_probe_registry: Dict[str, ProtocolProbe] = {}


def register_protocol(name: str, probe: ProtocolProbe) -> None:
    """Register ``probe`` under ``name`` in the global registry."""
    _probe_registry[name] = probe


def get_protocol(name: str) -> Optional[ProtocolProbe]:
    return _probe_registry.get(name)


def unregister_protocol(name: str) -> None:
    _probe_registry.pop(name, None)


# Register built-in protocol probes -----------------------------------------------------------
try:  # HTTP
    from op_proto.http.engine import http_probe as _http_probe

    async def _http_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        return await _http_probe(target, cand, mint, client, retries=retries)

    register_protocol("http", _http_wrapper)
except Exception:  # pragma: no cover - optional dependency
    pass

try:  # GraphQL
    from op_proto.graphql.engine import graphql_probe as _graphql_probe

    async def _gql_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        return await _graphql_probe(target, cand, mint, retries=retries)

    register_protocol("graphql", _gql_wrapper)
except Exception:  # pragma: no cover
    pass

try:  # WebSocket
    from op_proto.ws.engine import ws_probe as _ws_probe

    async def _ws_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        return await _ws_probe(target, cand, mint, retries=retries)

    register_protocol("ws", _ws_wrapper)
except Exception:  # pragma: no cover
    pass

try:  # gRPC
    from op_proto.grpc.engine import grpc_probe as _grpc_probe

    async def _grpc_wrapper(target: str, cand: Dict[str, Any], mint: Any, client: Any | None = None, retries: int = 0):
        res = await _grpc_probe(target, cand, mint)
        if isinstance(res, list):
            return res[0] if res else None
        return res

    register_protocol("grpc", _grpc_wrapper)
except Exception:  # pragma: no cover
    pass
