from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional
import json, time

@dataclass
class Finding:
    check: str
    target: str
    severity: str = "info"
    title: str = ""
    detail: str = ""
    meta: Optional[Dict[str, Any]] = None
    ts: float = 0.0

    def to_json(self) -> str:
        d = asdict(self)
        d["ts"] = self.ts or time.time()
        return json.dumps(d, ensure_ascii=False)

    @staticmethod
    def from_json(s: str) -> "Finding":
        j = json.loads(s)
        return Finding(**j)
