"""Interactive wizard to generate a minimal scan configuration."""

from __future__ import annotations

from pathlib import Path

from typing import Any, Dict, Optional


import yaml



def build_config(
    target: str,
    spa: bool = False,
    budget: int = 60,
    profile: Optional[str] = None,
) -> str:

    """Return a YAML configuration string for the given parameters.

    Parameters
    ----------
    target: str
        Base URL to include in the allow list.
    spa: bool, optional
        Whether to enable DOM crawling for single-page apps.
    budget: int, optional
        Maximum scan time in minutes.

    profile: str, optional
        Path to an overlay profile YAML. Defaults to ``None``.

    """
    data: Dict[str, Any] = {
        "scopes": {"allow": [target], "deny": []},
        "dom": {"crawl": spa},
        "limits": {"max_scan_minutes": budget},
    }

    if profile:
        data["profile"] = profile

    return yaml.safe_dump(data, sort_keys=False)


def main() -> None:
    """Prompt for values and write a YAML file to disk."""
    target = input("Target URL: ").strip()
    spa_answer = input("Is this a SPA? [y/N]: ").strip().lower()
    spa = spa_answer.startswith("y")
    budget_text = input("Scan budget minutes [60]: ").strip()
    budget = int(budget_text) if budget_text else 60


    profile = None
    profiles_dir = Path("config/profiles")
    available = sorted(profiles_dir.glob("*.yaml"))
    if available:
        print("Available profiles:")
        for idx, p in enumerate(available, 1):
            print(f"  {idx}. {p.name}")
        choice = input("Select profile number [none]: ").strip()
        if choice:
            try:
                profile = str(available[int(choice) - 1])
            except (ValueError, IndexError):
                print("Invalid selection; no profile will be set.")

    config_yaml = build_config(target, spa=spa, budget=budget, profile=profile)

    out_file = input("Output file [scan-config.yaml]: ").strip()
    if not out_file:
        out_file = "scan-config.yaml"
    Path(out_file).write_text(config_yaml)
    print(f"Configuration written to {out_file}")


if __name__ == "__main__":
    main()
