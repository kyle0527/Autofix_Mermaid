from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from op_auth import AuthManager, load_strategy
from op_control.campaign import Campaign, load_campaign
from op_control.config import merge_to_file
from op_core.history import HistoryDB
from op_core.httpclient import make_async_client
from op_core.rank import rank_findings
from op_core.runner import run_hunt

try:
    from op_adapters.pd_tools import recon_plus as _recon
except ImportError as e:  # pragma: no cover - optional dependency
    logging.getLogger(__name__).warning("recon_plus import failed: %s", e)
    _recon = None  # type: ignore
try:
    from op_adapters.pd_tools import recon_plus as _recon_basic
except ImportError as e:  # pragma: no cover - optional dependency
    logging.getLogger(__name__).warning("recon_pipeline import failed: %s", e)
    _recon_basic = None  # type: ignore
from op_adapters.nuclei import run_nuclei
from op_adapters.sqlmap import run_sqlmap
from op_adapters.xsstrike import run_xsstrike
from op_oob.interactsh import InteractClient

from op_output.sarif import to_sarif
from op_checks.idor import IdorCheck
from op_output.html import export_html
from op_output.poc import write_poc_files

from op_output.artifacts import try_capture

from op_proto.graphql.schema import try_introspect

logger = logging.getLogger(__name__)

try:
    from op_dom.capture import crawl_and_capture
except ImportError as e:  # pragma: no cover - optional dependency
    logger.warning("DOM capture import failed: %s", e)
    crawl_and_capture = None  # type: ignore


def _run_recon(domain: str) -> Tuple[List[str], Dict]:
    if _recon is not None:
        try:
            return _recon(domain)
        except (RuntimeError, ValueError) as e:
            logger.warning("recon_plus failed for %s: %s", domain, e)
    if _recon_basic is not None:
        try:
            targets = _recon_basic(domain)
            return targets, {"targets_only": targets}
        except (RuntimeError, ValueError) as e:
            logger.warning("recon_pipeline failed for %s: %s", domain, e)
    roots = [f"https://{domain}", f"http://{domain}"]
    return roots, {"roots_only": roots}


def prepare_campaign(
    campaign_path: Path,
    workdir: Path,
    profile: Optional[Path],
    max_concurrency: Optional[int],
    poc_top: Optional[int],
    capture: Optional[bool],
    history_ttl: Optional[int],
    ultra: bool,
    dom_crawl: bool,
) -> Tuple[Campaign, bool]:
    """Load and configure the campaign settings.

    Profile overrides are merged into the campaign file and runtime
    parameters such as concurrency or output limits are applied. When
    ``ultra`` is enabled additional synthetic transforms and payload
    budget tweaks are applied and DOM crawling is implicitly enabled.

    Returns the prepared :class:`~op_control.campaign.Campaign` instance
    together with the (possibly updated) ``dom_crawl`` flag.
    """
    workdir.mkdir(parents=True, exist_ok=True)

    effective_cfg = campaign_path
    if profile and Path(profile).exists():
        tmp_cfg = workdir / "tmp" / f"merged-{Path(profile).stem}.yaml"
        merge_to_file(campaign_path, Path(profile), tmp_cfg)
        effective_cfg = tmp_cfg

    camp = load_campaign(effective_cfg)
    if max_concurrency:
        camp.limits.max_concurrency = max_concurrency
    if poc_top is not None:
        camp.output.poc_top = poc_top
    if capture is not None:
        camp.output.capture = capture
    if history_ttl is not None:
        camp.output.history_ttl_days = history_ttl

    if ultra:

        ex = [
            "double_encode",
            "unicode_confuse",
            "quote_flip",
            "split_keywords",
            "case_flip",
            "param_spread",
            "urlenc",
            "urlenc_all",
            "comment_break",
            "param_pollution",
            "html_entity",
        ]
        try:
            tlist = list(camp.synth.transforms or [])
        except AttributeError as e:
            logger.warning("camp.synth.transforms missing: %s", e)
            tlist = []
        tlist = list(dict.fromkeys(tlist + ex))
        try:
            camp.synth.transforms = tlist
        except AttributeError as e:
            logger.warning("unable to set synth transforms: %s", e)
        try:
            if getattr(camp.limits, "per_target_payloads", 0) < 18:
                camp.limits.per_target_payloads = 18
        except AttributeError as e:
            logger.warning("unable to set payload budget: %s", e)
        dom_crawl = True

    return camp, dom_crawl


def collect_targets(domain: str, workdir: Path, dom_crawl: bool) -> List[str]:
    """Run reconnaissance and optional DOM crawling for ``domain``.

    Discovery metadata is stored under ``workdir`` and the list of
    discovered targets is returned.
    """

    targets, details = _run_recon(domain)
    disc_dir = workdir / "discovery"
    disc_dir.mkdir(parents=True, exist_ok=True)
    (workdir / "targets.txt").write_text("\n".join(targets), encoding="utf-8")
    (disc_dir / "targets.json").write_text(

        json.dumps({"domain": domain, "targets": targets}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (disc_dir / "details.json").write_text(
        json.dumps(details, ensure_ascii=False, indent=2), 
        encoding="utf-8"
    )
    js_eps = details.get("js_endpoints")
    if isinstance(js_eps, list):
        (disc_dir / "js-endpoints.json").write_text(
            json.dumps(js_eps, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    if dom_crawl and crawl_and_capture is not None:
        try:
            dom = asyncio.run(crawl_and_capture(domain))
        except (OSError, RuntimeError):
            logger.exception("DOM capture failed for %s", domain)
            dom = {"requests": [], "endpoints": []}

        (disc_dir / "dom-requests.json").write_text(
            json.dumps(dom.get("requests", []), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (disc_dir / "dom-endpoints.json").write_text(
            json.dumps(dom.get("endpoints", []), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        try:
            _, png = try_capture(f"https://{domain}", disc_dir / "dom-shot")

            if png is None:
                logger.error("DOM screenshot missing for %s", domain)
            else:
                try:
                    Path(png).unlink()
                except FileNotFoundError:
                    logger.warning("DOM snapshot cleanup missing for %s", domain)
                except OSError:
                    logger.exception("DOM snapshot cleanup failed for %s", domain)
        except Exception:
            logger.exception("DOM screenshot capture failed for %s", domain)
        if dom.get("endpoints"):
            all_targets = list(dict.fromkeys(targets + dom["endpoints"]))
            (workdir / "targets.txt").write_text(
                "\n".join(all_targets), encoding="utf-8"
            )
            targets = all_targets

    gql_urls = [t for t in targets if "/graphql" in t.lower()]
    if gql_urls:
        schema_out: Dict[str, Any] = {}
        try:
            j = asyncio.run(try_introspect(gql_urls[0]))
            if j:
                schema_out[gql_urls[0]] = j
        except (OSError, RuntimeError):
            logger.exception("GraphQL introspection failed for %s", gql_urls[0])

        if schema_out:
            sdir = workdir / "schema"
            sdir.mkdir(parents=True, exist_ok=True)
            (sdir / "graphql-introspection.json").write_text(
                json.dumps(schema_out, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    return targets


def run_scans(
    targets: List[str], camp: Campaign, workdir: Path
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Any]:
    """Execute the scanning suite against ``targets``.


    Returns the ranked findings, any collected out-of-band events and the
    exported OOB state required for report generation.
    """

    hist = HistoryDB(workdir / "history.jsonl", ttl_days=camp.output.history_ttl_days)
    oob = InteractClient(getattr(camp.oob, "base_url", None), getattr(camp.oob, "api_key", None))
    
    auth = AuthManager(
        {"default": load_strategy("none")},
        lambda: make_async_client(workdir),
    )
    findings = run_hunt(
        targets,
        camp,
        hist,
        oob_client=oob,
        workdir=workdir,
        auth=auth,
    )

    try:
        events = oob.poll()
    except (OSError, RuntimeError) as e:
        logger.warning("oob poll failed: %s", e)
        events = []

    oob_state = oob.export_events()

    oob_dir = workdir / "oob"
    oob_dir.mkdir(parents=True, exist_ok=True)
    (oob_dir / "events.json").write_text(
        json.dumps(
            {"events": events, "state": oob.export_events()},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    findings = oob.correlate_findings(findings)

    nuclei_items = run_nuclei(str(workdir / "targets.txt"), None)
    extra: List[Dict] = []
    max_targets = getattr(camp.limits, "max_external_targets", len(targets))
    for t in targets[:max_targets]:
        extra += run_sqlmap(t)
        extra += run_xsstrike(t)


    # IDOR check (optional via campaign idor.enabled)
    idor_cfg = getattr(camp, "idor", {}) or {}
    idor_findings: List[Dict[str, Any]] = []
    try:
        if idor_cfg.get("enabled"):
            # Build candidate API list: numeric-looking endpoints from discovered targets
            api_candidates = []
            import re
            for t in targets:
                if re.search(r"/(\d+)(?:/|$)", t):
                    api_candidates.append({"url": t})
            if api_candidates:
                roles = idor_cfg.get("roles")
                expand = bool(idor_cfg.get("expand_variants", True))
                check = IdorCheck(roles=roles, expand_variants=expand)
                # Findings are dataclasses -> convert to dict for merge
                for f in check.run(api_candidates):
                    d = f.__dict__.copy()
                    # unify key naming with other findings (target/url)
                    if "target" not in d:
                        d["target"] = d.get("url") or d.get("meta", {}).get("url")
                    idor_findings.append(d)
    except Exception as e:  # non-fatal
        logger.warning("idor check failed: %s", e)

    merged = findings + nuclei_items + extra + idor_findings
    ranked = rank_findings(merged, None)

    return ranked, events, oob_state


def export_results(
    ranked: List[Dict[str, Any]],
    events: List[Dict[str, Any]],
    oob_state: Any,
    camp: Campaign,
    workdir: Path,
) -> Dict[str, str]:
    """Write result artifacts for ``ranked`` findings.

    A dictionary with paths to the JSON, SARIF and HTML report files is
    returned.
    """


    json_path = workdir / "ranked.json"
    sarif_path = workdir / "out.sarif"
    html_path = Path(export_html(workdir, ranked))
    json_path.write_text(
        json.dumps(ranked, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    sarif_path.write_text(to_sarif(ranked), encoding="utf-8")
    for i, f in enumerate(ranked[: camp.output.poc_top]):
        write_poc_files(workdir, f, i + 1)
    if camp.output.capture:
        artdir = workdir / "artifacts"
        for i, f in enumerate(ranked[: camp.output.poc_top]):
            url = f.get("url") or f.get("target", "")

            sub = artdir / f"item_{i + 1:02d}"
            try_capture(url, sub)

    oob_dir = workdir / "oob"
    oob_dir.mkdir(parents=True, exist_ok=True)
    (oob_dir / "events.json").write_text(
        json.dumps({"events": events, "state": oob_state}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return {"json": str(json_path), "sarif": str(sarif_path), "html": str(html_path)}

def run_pipeline(
    domain: str,
    campaign_path: Path,
    workdir: Path,
    max_concurrency: Optional[int] = None,
    poc_top: Optional[int] = None,
    capture: Optional[bool] = None,
    history_ttl: Optional[int] = None,
    profile: Optional[Path] = None,
    dom_crawl: bool = False,
    ultra: bool = False,
) -> Dict[str, str]:
    """Run the Warprecon scanning pipeline for a single domain.

    The pipeline performs four major phases: campaign preparation,
    target collection, active scanning and result export. The returned
    dictionary contains paths to the generated JSON, SARIF and HTML
    reports.
    """

    workdir.mkdir(parents=True, exist_ok=True)
    camp, dom_crawl = prepare_campaign(
        campaign_path,
        workdir,
        profile,
        max_concurrency,
        poc_top,
        capture,
        history_ttl,
        ultra,
        dom_crawl,
    )
    targets = collect_targets(domain, workdir, dom_crawl)
    ranked, events, oob_state = run_scans(targets, camp, workdir)
    return export_results(ranked, events, oob_state, camp, workdir)

