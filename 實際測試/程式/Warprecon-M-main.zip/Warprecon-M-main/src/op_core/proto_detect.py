from __future__ import annotations
from typing import Dict
import httpx

def detect_http_versions(url: str, timeout: float = 5.0) -> Dict[str, bool]:
    hints = {"http2": False, "http3_hint": False}
    try:
        with httpx.Client(http2=True, timeout=timeout, follow_redirects=True) as cli:
            r = cli.get(url)
            ver = getattr(r, "http_version", None)
            if ver and "2" in str(ver):
                hints["http2"] = True
            altsvc = r.headers.get("alt-svc","")
            if "h3" in altsvc.lower():
                hints["http3_hint"] = True
    except Exception:
        pass
    return hints
