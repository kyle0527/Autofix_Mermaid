from __future__ import annotations

import hashlib
import json
from typing import Set, Dict


def fp(item: Dict) -> str:
    """Compute a deterministic fingerprint for a finding candidate.

    Includes protocol and, when present, mode and hashes the full payload to
    reduce collisions from truncation. Uses JSON serialization to avoid
    collisions when delimiter characters appear in fields.
    """
    vector = item.get("vector", {}) or {}
    base_obj = {
        "target": item.get("target", "") or "",
        "protocol": vector.get("protocol", "") or "",
        "location": vector.get("location", "") or "",
        "param": vector.get("param", "") or "",
        "payload": item.get("payload", "") or "",
    }
    mode = item.get("mode")
    if mode:
        base_obj["mode"] = mode
    base = json.dumps(base_obj, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(base.encode("utf-8")).hexdigest()


class DeDup:
    """Track fingerprints of findings to prevent duplicates."""

    def __init__(self):
        self.seen: Set[str] = set()

    def seen_before(self, item: Dict) -> bool:
        """Return True if the item's fingerprint has been seen before."""
        h = fp(item)
        if h in self.seen:
            return True
        self.seen.add(h)
        return False
