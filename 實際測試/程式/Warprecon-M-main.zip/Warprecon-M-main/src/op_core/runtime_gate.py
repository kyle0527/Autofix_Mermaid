from __future__ import annotations
from pathlib import Path
import asyncio, json

async def wait_if_paused(workdir: Path, poll_interval: float = 0.5) -> None:
    """If workdir/control.json has {"pause": true}, wait until it becomes false or file removed."""
    ctrl = workdir / "control.json"
    while True:
        try:
            j = json.loads(ctrl.read_text(encoding="utf-8")) if ctrl.exists() else {}
            if j.get("pause"):
                await asyncio.sleep(poll_interval)
                continue
        except Exception:
            pass
        break
