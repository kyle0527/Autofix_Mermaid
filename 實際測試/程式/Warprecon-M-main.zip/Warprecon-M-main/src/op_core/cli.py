from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from op_control.campaign import load_campaign
from op_core.runner import run_hunt
from op_core.rank import rank_findings
from op_core.pipeline import run_pipeline
from op_output.sarif import to_sarif
from op_dist.queue import FSQueue
from op_dist.agent import run_agent
from op_ui.server import create_app
from op_output.deliver import make_deliverable_zip
from op_checks.base import REGISTRY
def main() -> None:
    p = argparse.ArgumentParser(prog="warprecon-m", description="Warprecon-M CLI")
    sub = p.add_subparsers(dest="cmd", required=True)
    h = sub.add_parser("hunt", help="Adaptive hunt")
    h.add_argument("--targets", required=True)
    h.add_argument("--cfg", required=True)
    h.add_argument("--out", required=True)
    r = sub.add_parser("rank", help="Rank findings")
    r.add_argument("--in", dest="infile", required=True)
    r.add_argument("--out", required=True)
    rep = sub.add_parser("report", help="Emit SARIF from ranked JSON")
    rep.add_argument("--in", dest="infile", required=True)
    rep.add_argument("--out", required=True)
    pipe = sub.add_parser("pipeline", help="Recon → Hunt → Adapters → Rank → Reports")
    pipe.add_argument("--domain", required=True)
    pipe.add_argument("--cfg", required=True)
    pipe.add_argument("--workdir", required=True)
    pipe.add_argument("--max-concurrency", type=int, default=None)
    pipe.add_argument("--poc-top", type=int, default=None)
    pipe.add_argument("--capture", action="store_true")
    pipe.add_argument("--history-ttl", type=int, default=None)
    pipe.add_argument("--profile", type=str, default=None, help="Overlay YAML profile (e.g., config/profiles/p4-high-precision.yaml)")
    pipe.add_argument("--dom-crawl", action="store_true", help="Enable Playwright DOM/SPA discovery (if available)")
    pipe.add_argument("--ultra", action="store_true", help="Enable Ultra mode (max transforms, per-target payloads)")
    qa = sub.add_parser("queue-add", help="Enqueue a domain task")
    qa.add_argument("--workdir", required=True)
    qa.add_argument("--domain", required=True)
    qa.add_argument("--cfg", default="config/campaign.yaml")
    ag = sub.add_parser("agent", help="Run an agent worker")
    ag_sub = ag.add_subparsers(dest="agent_cmd", required=True)
    ag_run = ag_sub.add_parser("run")
    ag_run.add_argument("--workdir", required=True)
    ag_run.add_argument("--cfg", required=True)
    ag_run.add_argument("--max-concurrency", type=int, default=None)
    ag_run.add_argument("--max-loops", type=int, default=None)
    ui = sub.add_parser("ui", help="Launch UI server")
    ui.add_argument("--workdir", required=True)
    ui.add_argument("--cfg", required=True)
    ui.add_argument("--port", type=int, default=8787)
    dv = sub.add_parser("deliver", help="Zip outputs for delivery")
    dv.add_argument("--workdir", required=True)
    dv.add_argument("--out", default=None)
    # IDOR check subcommand (re-added)
    idor = sub.add_parser("idor", help="Run IDOR check over targets file")
    idor.add_argument("--targets", required=True)

    idor.add_argument("--out", required=True)
    idor.add_argument("--expand-variants", action="store_true")
    idor.add_argument("--max-variants", type=int, default=50)
    idor.add_argument("--exclude", action="append", default=[], help="Regex patterns to exclude URLs")

    args = p.parse_args()
    if args.cmd == "hunt":
        camp = load_campaign(Path(args.cfg))
        targets = [x.strip() for x in Path(args.targets).read_text(encoding="utf-8").splitlines() if x.strip()]
        items = run_hunt(targets, camp, None)
        Path(args.out).write_text("\\n".join(json.dumps(x, ensure_ascii=False) for x in items), encoding="utf-8")
    elif args.cmd == "rank":
        items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
        ranked = rank_findings(items)
        Path(args.out).write_text(json.dumps(ranked, ensure_ascii=False, indent=2), encoding="utf-8")
    elif args.cmd == "report":
        items = json.loads(Path(args.infile).read_text(encoding="utf-8"))
        Path(args.out).write_text(to_sarif(items), encoding="utf-8")
    elif args.cmd == "pipeline":
        prof = Path(args.profile) if args.profile else None
        out = run_pipeline(args.domain, Path(args.cfg), Path(args.workdir),
                           max_concurrency=args.max_concurrency,
                           poc_top=args.poc_top,
                           capture=args.capture,
                           history_ttl=args.history_ttl,
                           profile=prof,
                           dom_crawl=args.dom_crawl,
                           ultra=args.ultra)
        print(json.dumps(out, ensure_ascii=False, indent=2))
    elif args.cmd == "queue-add":
        q = FSQueue(Path(args.workdir)/"queue")
        tid = q.enqueue(args.domain, args.cfg)
        print(json.dumps({"queued": tid, "domain": args.domain}, ensure_ascii=False))
    elif args.cmd == "agent":
        if args.agent_cmd == "run":
            run_agent(Path(args.workdir), Path(args.cfg), max_loops=args.max_loops, max_concurrency=args.max_concurrency)
    elif args.cmd == "ui":
        app = create_app(Path(args.workdir), Path(args.cfg))
        app.run(host="127.0.0.1", port=args.port, debug=False)
    elif args.cmd == "deliver":
        z = make_deliverable_zip(Path(args.workdir), Path(args.out) if args.out else None)
        print(json.dumps({"zip": z}, ensure_ascii=False))

    elif args.cmd == "idor":
        from op_checks.idor import IdorCheck
        urls = [ln.strip() for ln in Path(args.targets).read_text(encoding="utf-8").splitlines() if ln.strip()]
        apis = [{"url": u} for u in urls]
        check = IdorCheck(expand_variants=args.expand_variants, max_variants=args.max_variants, exclude_patterns=args.exclude)
        res = [f.__dict__ for f in check.run(apis)]
        Path(args.out).write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"findings": len(res), "out": args.out}, ensure_ascii=False))






    elif args.cmd == "checks":
        # Load APIs from file or treat as single URL
        if Path(args.apis).exists():
            try:
                with open(args.apis, 'r', encoding='utf-8') as f:
                    apis = json.load(f)
            except Exception:
                apis = [args.apis]  # Treat as single URL if JSON parsing fails
        else:
            apis = [args.apis]  # Single URL
        
        # Get the check class and instantiate it
        check_class = REGISTRY.get(args.check)
        if not check_class:
            print(f"Error: Unknown check '{args.check}'. Available: {list(REGISTRY.keys())}", file=sys.stderr)
            return
        
        check_instance = check_class()
        workdir = Path(args.workdir) if args.workdir else None
        
        # Run the check
        findings = list(check_instance.run(apis=apis, workdir=workdir))
        
        # Write findings to output file
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(out_path, 'w', encoding='utf-8') as f:
            for finding in findings:
                f.write(finding.to_json() + '\n')
        
        print(f"Completed {args.check} check on {len(apis)} APIs")
        print(f"Found {len(findings)} findings")
        print(f"Results written to {out_path}")
        
        # Print summary of findings
        if findings:
            print("\nFindings summary:")
            for finding in findings:
                print(f"  {finding.severity.upper()}: {finding.title}")
                print(f"    Target: {finding.target}")
                if finding.meta and finding.meta.get('idor_type'):
                    print(f"    Type: {finding.meta['idor_type']}")
                print()





