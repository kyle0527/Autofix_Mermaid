from __future__ import annotations
from pathlib import Path
import json

def load_cookies(workdir: Path):
    """Load cookies from work/session/cookies.json if present.

    Supports a list or a Chrome-style export with ``cookies`` key. Always
    returns an ``httpx.Cookies`` jar (empty if file missing or parsing fails).
    ``hostOnly`` is honoured by stripping a leading dot from the domain.
    """
    try:  # httpx may be optional in some environments
        from httpx import Cookies  # type: ignore
    except Exception:  # pragma: no cover - fallback for minimal envs
        Cookies = dict  # type: ignore

    jar = Cookies()
    p = workdir / "session" / "cookies.json"
    if not p.exists():
        return jar
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "cookies" in data:
            data = data["cookies"]
        if isinstance(data, list):
            for c in data:
                name = c.get("name")
                value = c.get("value")
                domain = c.get("domain") or ""
                if c.get("hostOnly"):
                    domain = domain.lstrip(".")
                path = c.get("path") or "/"
                if name is not None and value is not None:
                    try:
                        if isinstance(jar, dict):
                            jar[name] = value
                        else:
                            jar.set(name, value, domain=domain or None, path=path or "/")
                    except Exception:
                        continue
    except Exception:
        pass
    return jar
