from __future__ import annotations
from pathlib import Path
import httpx
from op_core.session import load_cookies

def make_async_client(workdir: Path) -> httpx.AsyncClient:
    cookies = load_cookies(workdir)
    return httpx.AsyncClient(follow_redirects=True, cookies=cookies)
