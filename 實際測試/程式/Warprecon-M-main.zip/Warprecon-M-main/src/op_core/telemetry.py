from __future__ import annotations
from pathlib import Path
import json, time, threading, logging

class Telemetry:
    _lock = threading.Lock()
    _state = {
        "workdir": None,
        "start_ts": None,
        "end_ts": None,
        "first_hit_ts": None,
        "first_confirmed_ts": None,
        "hits": 0,
        "confirmed_hits": 0,
    }

    @classmethod
    def start(cls, workdir: Path):
        with cls._lock:
            cls._state.update({
                "workdir": str(workdir),
                "start_ts": time.time(),
                "end_ts": None,
                "first_hit_ts": None,
                "first_confirmed_ts": None,
                "hits": 0,
                "confirmed_hits": 0,
            })
            cls._write()

    @classmethod
    def event(cls, etype: str, data: dict | None = None):
        """Append a single-line JSON event to events.jsonl with timestamp."""
        try:
            wd = cls._state.get("workdir")
            if not wd:
                return
            rec = {"ts": time.time(), "type": str(etype)}
            if data:
                rec.update(data)
            p = Path(wd) / "events.jsonl"
            with p.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception as e:
            logging.getLogger(__name__).exception("telemetry event failure: %s", e)

    @classmethod
    def hit(cls, finding: dict):
        # record first hit and first confirmed timestamps
        with cls._lock:
            if cls._state["start_ts"] is None:
                return
            now = time.time()
            cls._state["hits"] += 1
            if not cls._state["first_hit_ts"]:
                cls._state["first_hit_ts"] = now
            if (finding or {}).get("_confirmed") or ((finding or {}).get("evidence") or {}).get("sequence_hit"):
                cls._state["confirmed_hits"] += 1
                if not cls._state["first_confirmed_ts"]:
                    cls._state["first_confirmed_ts"] = now
            cls._maybe_write()

    @classmethod
    def finish(cls):
        with cls._lock:
            if cls._state["start_ts"] is None:
                return
            cls._state["end_ts"] = time.time()
            cls._write()

    @classmethod
    def _metrics(cls) -> dict:
        st = dict(cls._state)
        if st.get("start_ts") and st.get("first_confirmed_ts"):
            st["ttfp_seconds"] = max(0.0, float(st["first_confirmed_ts"] - st["start_ts"]))
        else:
            st["ttfp_seconds"] = None
        if st.get("start_ts") and st.get("end_ts"):
            st["duration_seconds"] = max(0.0, float(st["end_ts"] - st["start_ts"]))
        else:
            st["duration_seconds"] = None
        return st

    @classmethod
    def _maybe_write(cls):
        # write every ~5 seconds
        try:
            if int(time.time()) % 5 == 0:
                cls._write()
        except Exception as e:
            logging.getLogger(__name__).exception("telemetry periodic write failure: %s", e)

    @classmethod
    def _write(cls):
        try:
            wd = cls._state.get("workdir")
            if not wd:
                return
            p = Path(wd) / "metrics.json"
            p.write_text(json.dumps(cls._metrics(), ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logging.getLogger(__name__).exception("telemetry write failure: %s", e)
