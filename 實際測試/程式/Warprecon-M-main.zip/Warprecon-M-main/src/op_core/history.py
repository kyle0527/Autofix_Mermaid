from __future__ import annotations
from pathlib import Path
import json, time
from typing import Dict

class HistoryDB:
    def __init__(self, path: Path, ttl_days: int = 30):
        self.path = path
        self.ttl = ttl_days * 86400
        self.now = time.time()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def _iter(self):
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                line=line.strip()
                if not line: continue
                try:
                    obj = json.loads(line)
                    yield obj
                except Exception:
                    continue

    def seen(self, key: str) -> bool:
        for obj in self._iter():
            if obj.get("k")==key and self.now - obj.get("t",0) < self.ttl:
                return True
        return False

    def remember(self, key: str, meta: Dict):
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"k": key, "t": self.now, "m": meta}, ensure_ascii=False)+"\n")
