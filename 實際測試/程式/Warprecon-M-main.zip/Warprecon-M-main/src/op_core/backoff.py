from __future__ import annotations
import random, time
def jitter_backoff(base: float=0.5, factor: float=2.0, max_time: float=8.0, attempt: int=0) -> float:
    t = min(max_time, base*(factor**attempt))
    return t * (0.5 + random.random())
