from __future__ import annotations
import base64, secrets, time, logging
from typing import Optional, Dict, List, Tuple

try:
    import httpx
except Exception:  # pragma: no cover
    httpx = None  # type: ignore

# Optional RSA (best-effort). If cryptography missing, falls back to token-only mode.
try:  # pragma: no cover
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    _HAS_CRYPTO = True
except Exception:  # pragma: no cover
    _HAS_CRYPTO = False

class InteractClient:
    """
    Interactsh-like client with optional RSA registration.
    Config (via constructor):
      - base_url: service URL (e.g., https://oast.pro or your self-host)
      - api_key: optional bearer / token header
      - use_rsa: bool to attempt RSA registration (requires 'cryptography')
    Behavior:
      - If base_url missing or httpx unavailable → disabled mode (but mint() still returns local token).
      - register(): POST /register with public key, secret, correlation-id; flexible payload.
      - poll(): GET /poll or POST /poll with id/secret headers or JSON; flexible shape normalization.
      - correlate_findings(): attach OOB events to findings & bump severity.
    """
    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, use_rsa: bool = True):
        self.base_url = (base_url or "").rstrip("/")
        self.api_key = api_key or ""
        self.enabled = bool(self.base_url and httpx is not None)
        self.domain: Optional[str] = None
        self._registered = False
        self._tokens: Dict[str, Dict] = {}  # label -> meta(fqdn, created_at, hits)
        self._events: List[Dict] = []
        self._last_poll = 0.0
        self._corr_id = secrets.token_hex(8)
        self._secret = secrets.token_hex(12)
        self._use_rsa = bool(use_rsa and _HAS_CRYPTO)
        self._priv_pem: Optional[bytes] = None
        self._pub_pem: Optional[bytes] = None

        if self._use_rsa:
            try:
                key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
                self._priv_pem = key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption(),
                )
                self._pub_pem = key.public_key().public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo,
                )
            except Exception:
                self._use_rsa = False  # graceful fallback

    def _headers(self) -> Dict[str, str]:
        h = {"accept": "application/json"}
        if self.api_key:
            h["authorization"] = f"Bearer {self.api_key}"
        # flexible headers some servers accept
        h["x-correlation-id"] = self._corr_id
        h["x-secret"] = self._secret
        return h

    def register(self) -> None:
        if not self.enabled or self._registered:
            return
        try:
            import httpx  # type: ignore
            url = self.base_url + "/register"
            payload: Dict[str, str] = {"secret": self._secret, "correlation-id": self._corr_id}
            if self._use_rsa and self._pub_pem:
                payload["public-key"] = base64.b64encode(self._pub_pem).decode("ascii")
            with httpx.Client(timeout=6.0) as s:
                r = s.post(url, json=payload, headers=self._headers())
                if r.status_code == 200:
                    j = r.json()
                    self.domain = j.get("domain") or j.get("oob_domain") or j.get("subdomain")
                if not self.domain:
                    # Fallback: derive domain from base_url host
                    from urllib.parse import urlparse
                    self.domain = (urlparse(self.base_url).netloc or "oob.local")
            self._registered = True
        except httpx.RequestError as e:  # type: ignore
            logging.getLogger(__name__).warning("Interact register failed: %s", e)
            self.enabled = False
            self._registered = False
            self.domain = None
        except Exception as e:  # pragma: no cover - unexpected
            logging.getLogger(__name__).exception("Unexpected register error: %s", e)
            self.enabled = False
            self._registered = False
            self.domain = None

    def mint(self, prefix: Optional[str] = None) -> str:
        label = (prefix or "t") + secrets.token_hex(6)
        if self.enabled and not self._registered:
            self.register()
        fqdn = (label + "." + self.domain) if (self.enabled and self.domain) else (label + ".disabled")
        self._tokens[label] = {"fqdn": fqdn, "created_at": time.time(), "hits": []}
        return fqdn

    def _flex_poll(self) -> List[Dict]:
        """
        Try GET /poll and POST /poll with common shapes.
        Returns normalized event list.
        """
        if not self.enabled or not self._registered:
            return []
        import httpx  # type: ignore
        def norm_events(obj: Dict) -> List[Dict]:
            if not isinstance(obj, dict): return []
            items = obj.get("events") or obj.get("records") or obj.get("data") or []
            out: List[Dict] = []
            for e in items:
                host = e.get("host") or e.get("full-id") or e.get("domain") or ""
                ip = e.get("remote_addr") or e.get("remote-address") or e.get("ip") or ""
                proto = e.get("protocol") or e.get("type") or "http"
                req = e.get("request") or e.get("raw-request") or ""
                out.append({"host": host, "ip": ip, "protocol": proto, "request": req, "raw": e})
            return out

        hd = self._headers()
        q = {"id": self._corr_id, "secret": self._secret}
        with httpx.Client(timeout=6.0) as s:
            # GET style
            try:
                r = s.get(self.base_url + "/poll", params=q, headers=hd)
                if r.status_code == 200:
                    ev = norm_events(r.json())
                    if ev:
                        return ev
            except httpx.RequestError as e:
                logging.getLogger(__name__).warning("Interact poll GET failed: %s", e)
            # POST style with JSON
            try:
                r = s.post(self.base_url + "/poll", json=q, headers=hd)
                if r.status_code == 200:
                    ev = norm_events(r.json())
                    if ev:
                        return ev
            except httpx.RequestError as e:
                logging.getLogger(__name__).warning("Interact poll POST failed: %s", e)
        return []

    def poll(self) -> List[Dict]:
        now = time.time()
        if now - self._last_poll < 2.0:
            return []
        self._last_poll = now
        try:
            ev = self._flex_poll()
        except Exception as e:  # pragma: no cover
            logging.getLogger(__name__).exception("Interact poll error: %s", e)
            ev = []
        if ev:
            self._events.extend(ev)
            # attach to tokens by label substring
            for label, meta in self._tokens.items():
                for e in ev:
                    if label in (e.get("host") or ""):
                        meta["hits"].append(e)
        return ev

    def correlate_findings(self, findings: List[Dict]) -> List[Dict]:
        updated: List[Dict] = []
        idx: Dict[str, List[Dict]] = {}
        fqdn_to_hits: Dict[str, List[Dict]] = {}
        for label, meta in self._tokens.items():
            if meta["hits"]:
                idx[label] = list(meta["hits"])
                fqdn_to_hits[meta["fqdn"]] = list(meta["hits"])
        for f in findings:
            ev = f.get("evidence") or {}
            tok = ev.get("oob_token") or ""
            label = tok.split(".")[0] if tok else ""
            hits = idx.get(label) or fqdn_to_hits.get(tok) or []
            if hits:
                f = dict(f); ev = dict(ev)
                ev["oob_events"] = hits
                f["evidence"] = ev
                # promote severity
                if f.get("severity") in (None, "", "low", "medium", "high"):
                    f["severity"] = "critical"
                f["_oob_verified"] = True
            updated.append(f)
        return updated

    def export_events(self) -> Dict:
        return {"tokens": self._tokens, "events": self._events, "domain": self.domain, "enabled": self.enabled, "corr_id": self._corr_id}
