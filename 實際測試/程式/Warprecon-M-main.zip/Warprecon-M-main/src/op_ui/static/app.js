const $ = (sel)=>document.querySelector(sel);
const $$ = (sel)=>Array.from(document.querySelectorAll(sel));

// ---- prefs ----
function savePref(k,v){ try{ localStorage.setItem('warprecon-m_'+k, JSON.stringify(v)); }catch(e){} }
function loadPref(k, def){ try{ const v = localStorage.getItem('warprecon-m_'+k); return v? JSON.parse(v): def }catch(e){ return def } }

let ranked=[];

function initPrefs(){
  $('#sortBy').value = loadPref('sortBy','score');
  const sevDef = loadPref('sevFilter',['high','medium','low','info']);
  $$('#sevFilter option').forEach(o=> o.selected = sevDef.includes(o.value));
  const protoDef = loadPref('protoFilter',['http','graphql','ws','grpc']);
  $$('#protoFilter option').forEach(o=> o.selected = protoDef.includes(o.value));
  $('#q').value = loadPref('q','');
  const csvDef = loadPref('csvFields',["_rank","_score","severity","vector.protocol","tool","url","payload","_confirmed","evidence.sequence_hit"]);
  $$('.csvf').forEach(chk=> chk.checked = csvDef.includes(chk.value));
}

function loadMetrics(){
  return fetch('/api/metrics').then(r=>r.json()).then(m=>{
    $('#ttfp').textContent = (m.ttfp_seconds!=null)?Number(m.ttfp_seconds).toFixed(3):'-';
    $('#dur').textContent = (m.duration_seconds!=null)?Number(m.duration_seconds).toFixed(3):'-';
    $('#hits').textContent = m.hits||0; $('#chits').textContent = m.confirmed_hits||0;
  }).catch(()=>{});
}
function fetchRanked(){ return fetch('/api/ranked').then(r=>r.json()).then(j=>{ ranked=j||[] }) }
function sevOrder(s){ const o={critical:0,high:1,medium:2,low:3,info:4}; return o[(s||'').toLowerCase()]??99; }

function applySortFilter(){
  const sevSel = Array.from($('#sevFilter').selectedOptions).map(o=>o.value.toLowerCase());
  const protoSel = Array.from($('#protoFilter').selectedOptions).map(o=>o.value.toLowerCase());
  const q = ($('#q').value||'').toLowerCase();
  const sortBy = $('#sortBy').value;
  savePref('sevFilter', sevSel); savePref('protoFilter', protoSel); savePref('q', q); savePref('sortBy', sortBy);
  let items = ranked.filter(f=>{
    const sev = (f.severity||'').toLowerCase();
    const proto = ((f.vector||{}).protocol||'').toLowerCase();
    if(sevSel.length && !sevSel.includes(sev)) return false;
    if(protoSel.length && !protoSel.includes(proto)) return false;
    if(q){
      const ev = f.evidence||{};
      const hay = ((f.payload||'')+' '+(f.url||f.target||'')+' '+JSON.stringify(ev)).toLowerCase();
      if(!hay.includes(q)) return false;
    }
    return true;
  });
  items.sort((a,b)=>{
    if(sortBy==='rank') return (a._rank||9999)-(b._rank||9999);
    if(sortBy==='severity') return sevOrder(a.severity)-sevOrder(b.severity);
    if(sortBy==='confirmed'){
      const ac = (a._confirmed||((a.evidence||{}).sequence_hit));
      const bc = (b._confirmed||((b.evidence||{}).sequence_hit));
      if(ac!==bc) return ac? -1: 1;
      return (b._score||0)-(a._score||0);
    }
    return (b._score||0)-(a._score||0);
  });
  renderCards(items);
}

function chip(txt){ return `<span class="chip">${txt}</span>` }
function card(i,f){
  const sev = (f.severity||'').toUpperCase();
  const tgt = (f.url||f.target||'');
  const payload = (f.payload||'').toString().slice(0,240);
  const score = (f._score||0).toFixed(2);
  const cf = f._confirmed? '✅' : '';
  const proto = ((f.vector||{}).protocol||'');
  const tool = (f.tool||'');
  const ev = f.evidence||{};
  const snip = (ev.snippet||ev.details||'').toString().slice(0,240);
  return `
  <div class="card">
    <div class="head"><span class="rank">${i}</span><span class="sev ${sev}">${sev}</span><span class="score">Score ${score}</span><span class="cf">${cf}</span></div>
    <div class="tags">${chip(proto)} ${chip(tool)} ${chip(f._confirmed?'confirmed':'')}</div>
    <div class="payload"><code>${payload}</code></div>
    <div class="target"><a href="${tgt}" target="_blank">${tgt}</a></div>
    <div class="snippet">${snip}</div>
    <div class="btns">
      <button class="btn" data-a="ev">Evidence</button>
      <button class="btn" data-a="evdl" title="Download evidence JSON">Ev JSON</button>
      <button class="btn" data-a="poc">PoC</button>
      <button class="btn" data-a="curl">Copy cURL</button>
    </div>
    <pre class="_ev hidden">${JSON.stringify(ev,null,2)}</pre>
  </div>`
}

function renderCards(items){
  const el = $('#cards'); el.innerHTML = items.map((f,idx)=>card(idx+1,f)).join('');
  $$('#cards .btn').forEach((b)=>{
    b.addEventListener('click', ev=>{
      const a = b.getAttribute('data-a');
      const c = b.closest('.card');
      const i = Array.from($('#cards').children).indexOf(c);
      if(a==='ev'){
        const pre = c.querySelector('._ev');
        $('#modalPre').textContent = pre.textContent;
        $('#modal').classList.remove('hidden');
      } else if(a==='evdl'){
        fetch('/api/evidence?i='+i).then(r=>r.json()).then(j=>{
          const blob = new Blob([JSON.stringify(j,null,2)], {type:'application/json'});
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a'); a.href=url; a.download='evidence_'+(i+1)+'.json'; a.click();
          URL.revokeObjectURL(url);
        });
      } else if(a==='poc'){
        window.open('/poc/','_blank');
      } else if(a==='curl'){
        fetch('/api/poc_snippet?i='+i).then(r=>r.text()).then(txt=>{
          navigator.clipboard && navigator.clipboard.writeText(txt);
          alert('cURL snippet copied.');
        });
      }
    });
  });
}

function drawChart(){
  Promise.all([fetch('/api/events').then(r=>r.json()), fetch('/api/metrics').then(r=>r.json())]).then(([ev,m])=>{
    const cv=$('#chart'); const ctx=cv.getContext('2d');
    ctx.clearRect(0,0,cv.width,cv.height);
    if(!ev||!ev.length){ ctx.fillText('No events',10,20); return; }
    const ts = ev.map(e=>Number(e.ts||0)).filter(Boolean);
    const min=Math.min.apply(null,ts), max=Math.max.apply(null,ts); const dur=Math.max(1,max-min);
    // draw bucket bars (total counts)
    const bins=new Array(20).fill(0);
    ev.forEach(e=>{ const x=Math.floor(((Number(e.ts)-min)/dur)*19); if(x>=0&&x<20) bins[x]++; });
    const mw=cv.width-40, mh=cv.height-40; const ox=20, oy=10;
    const maxv=Math.max(1, Math.max.apply(null,bins));
    ctx.strokeStyle='#e5e7eb'; ctx.strokeRect(ox,oy,mw,mh);
    ctx.fillStyle='#4b5563';
    for(let i=0;i<20;i++){ const h=(bins[i]/maxv)*mh; const x=ox + (i*(mw/20))+2; const w=(mw/20)-4; ctx.fillRect(x, oy+mh-h, w, h); }
    // event type colored ticks
    const color = (t)=> t.startsWith('gql') ? '#6366f1' : (t.startsWith('grpc') ? '#f59e0b' : (t.startsWith('http_caps') ? '#10b981' : (t.startsWith('run') ? '#ef4444' : '#9ca3af')));
    ev.forEach(e=>{
      const x = ox + ((Number(e.ts)-min)/dur)*mw;
      ctx.strokeStyle = color(String(e.type||''));
      ctx.beginPath(); ctx.moveTo(x, oy+mh); ctx.lineTo(x, oy+mh-8); ctx.stroke();
    });
    if(m.first_confirmed_ts){ const x = ox + ((m.first_confirmed_ts-min)/dur)*mw; ctx.strokeStyle='#ef4444'; ctx.beginPath(); ctx.moveTo(x, oy); ctx.lineTo(x, oy+mh); ctx.stroke(); }
  }).catch(()=>{});
}

function refresh(){ Promise.all([loadMetrics(), fetchRanked()]).then(()=>{ applySortFilter(); drawChart(); }) }

function loadWorkdirs(){
  fetch('/api/workdirs').then(r=>r.json()).then(j=>{
    const sel=$('#workSel'); sel.innerHTML='';
    (j.items||[]).forEach(d=>{ const opt=document.createElement('option'); opt.value=d; opt.textContent=d; if(d===j.current) opt.selected=true; sel.appendChild(opt); });
  });
}

function showRuns(){
  fetch('/api/runs_all').then(r=>r.json()).then(j=>{
    const tb = $('#runsTable tbody'); tb.innerHTML='';
    (j.items||[]).forEach(node=>{
      const nodeName = node.node || 'node';
      (node.runs||[]).forEach(run=>{
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${nodeName}</td><td>${run.workdir||''}</td><td>${(run.ttf p??'-')}</td><td>${(run.duration??'-')}</td><td>${Number(run.p10||0).toFixed(2)}</td><td>${Number(run.p20||0).toFixed(2)}</td><td>${run.poc||0}</td><td><button class="btn use">Use</button></td>`;
        const btn = tr.querySelector('.use');
        btn.addEventListener('click', ()=>{
          fetch('/api/use?dir='+encodeURIComponent(run.workdir)).then(()=>{ $('#runsModal').classList.add('hidden'); refresh(); loadWorkdirs(); });
        });
        tb.appendChild(tr);
      });
    });
    $('#runsModal').classList.remove('hidden');
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  initPrefs();
  loadWorkdirs(); refresh();
  $('#btnRefresh').addEventListener('click', refresh);
  $('#modalClose').addEventListener('click', ()=>$('#modal').classList.add('hidden'));
  $('#runsClose').addEventListener('click', ()=>$('#runsModal').classList.add('hidden'));
  $('#zipClose').addEventListener('click', ()=>$('#zipModal').classList.add('hidden'));
  ['sortBy','sevFilter','protoFilter'].forEach(id=> $('#'+id).addEventListener('change', applySortFilter));
  $('#q').addEventListener('input', ()=>{ applySortFilter() });
  $('#btnCSV').addEventListener('click', ()=>{ const fields=$$('.csvf:checked').map(x=>x.value); savePref('csvFields', fields); window.open('/api/csv?fields='+encodeURIComponent(fields.join(',')),'_blank'); });
  $('#btnZIP').addEventListener('click', ()=>{ $('#zipModal').classList.remove('hidden'); });
  $('#zipGo').addEventListener('click', ()=>{ const inc=$$('.zipf:checked').map(x=>x.value).join(','); window.open('/api/export_zip?include='+encodeURIComponent(inc),'_blank'); });
  $('#workSel').addEventListener('change', ()=>{ const dir=$('#workSel').value; fetch('/api/use?dir='+encodeURIComponent(dir)).then(()=>{ refresh(); loadWorkdirs(); }); });
  $('#btnPause').addEventListener('click', ()=>{ fetch('/api/control?pause=1').then(()=>{}) });
  $('#btnResume').addEventListener('click', ()=>{ fetch('/api/control?pause=0').then(()=>{}) });
  $('#btnRuns').addEventListener('click', showRuns);
});
