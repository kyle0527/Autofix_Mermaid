from __future__ import annotations
from flask import Flask, jsonify, request, send_file
from pathlib import Path
import json, threading
from op_core.pipeline import run_pipeline
from op_dist.queue import FSQueue
from op_chain.assembler import build_graph, suggest_paths
from op_output.deliver import make_deliverable_zip

def create_app(workdir: Path, cfg_path: Path) -> Flask:
    app = Flask(__name__)
    @app.get("/healthz")
    def healthz():
        return jsonify({"ok": True})
    @app.get("/api/findings")
    def findings():
        p = workdir/"ranked.json"
        if not p.exists():
            return jsonify({"items": []})
        items = json.loads(p.read_text(encoding="utf-8"))
        return jsonify({"items": items, "count": len(items)})
    @app.get("/api/targets")
    def targets():
        p1 = workdir/"targets.txt"
        p2 = workdir/"discovery"/"targets.json"
        t = p1.read_text(encoding="utf-8").splitlines() if p1.exists() else []
        j = json.loads(p2.read_text(encoding="utf-8")) if p2.exists() else {"targets":[]}
        return jsonify({"targets": t, "discovery": j})
    @app.get("/api/discovery")
    def discovery():
        ddir = workdir/"discovery"
        obj = {}
        for name in ["details.json","js-endpoints.json","dom-requests.json","dom-endpoints.json"]:
            p = ddir/name
            if p.exists():
                try: obj[name] = json.loads(p.read_text(encoding="utf-8"))
                except Exception: obj[name] = None
        return jsonify(obj)
    @app.get("/api/oob")
    def oob():
        p = workdir/"oob"/"events.json"
        if not p.exists():
            return jsonify({"count": 0, "events": []})
        j = json.loads(p.read_text(encoding="utf-8"))
        ev = j.get("events") or []
        return jsonify({"count": len(ev)})
    @app.get("/api/chain")
    def chain():
        p = workdir/"ranked.json"
        if not p.exists():
            return jsonify({"paths": []})
        items = json.loads(p.read_text(encoding="utf-8"))
        G = build_graph(items)
        paths = suggest_paths(G)
        return jsonify({"paths": paths})
    @app.post("/api/run")
    def run_now():
        data = request.get_json(force=True, silent=True) or {}
        domain = data.get("domain"); mc = int(data.get("max_concurrency", 6))
        profile = data.get("profile"); capture = bool(data.get("capture", False)); dom_crawl = bool(data.get("dom_crawl", False))
        prof_path = Path(profile) if profile else None
        def _task():
            run_pipeline(domain, cfg_path, workdir, max_concurrency=mc, profile=prof_path, capture=capture, dom_crawl=dom_crawl)
        threading.Thread(target=_task, daemon=True).start()
        return jsonify({"accepted": True, "domain": domain, "profile": profile, "capture": capture, "dom_crawl": dom_crawl})
    @app.post("/api/queue/add")
    def qadd():
        data = request.get_json(force=True, silent=True) or {}
        domain = data.get("domain"); q = FSQueue(workdir/"queue")
        tid = q.enqueue(domain, str(cfg_path))
        return jsonify({"queued": tid, "domain": domain})
    @app.get("/api/deliver")
    def deliver():
        z = make_deliverable_zip(workdir)
        return send_file(z, as_attachment=True)
    @app.get("/")
    def home():
        return """<!doctype html>
<html><head><meta charset='utf-8'><title>Warprecon-M UI</title>
<style>
body{font-family:system-ui;margin:20px}
table{border-collapse:collapse;width:100%}
td,th{border:1px solid #ddd;padding:6px}
.details{display:none;background:#fafafa}
.code{white-space:pre-wrap;font-family:ui-monospace,Consolas,monospace}
button{cursor:pointer}
.wrap{display:grid;grid-template-columns:1fr 1fr;gap:24px}
pre{white-space:pre-wrap}
small.badge{display:inline-block;padding:2px 6px;border:1px solid #888;border-radius:10px;margin-left:8px}
</style>
</head><body>
<h1>Warprecon-M – UI</h1>
<div>
  <form onsubmit="run();return false;">
    Domain: <input id="d" value="example.com"/> MaxConc: <input id="mc" value="6" size="3"/>
    Profile:
    <select id="pf">
      <option value="">(base only)</option>
      <option value="config/profiles/p2-waf-friendly.yaml">WAF friendly</option>
      <option value="config/profiles/p2-fast-gql.yaml">Fast GraphQL</option>
      <option value="config/profiles/p4-high-precision.yaml">High Precision</option>
      <option value="config/profiles/p4-aggressive.yaml">Aggressive</option>
    </select>
    <label style="margin-left:10px"><input type="checkbox" id="cap"/> Capture</label>
    <label style="margin-left:10px"><input type="checkbox" id="dom"/> DOM Crawl</label>
    <button type="submit">Run Now</button>
    <button onclick="queue();return false;">Queue</button>
    <a href='/api/deliver' style='margin-left:12px'>Download Deliverable</a>
    <small class="badge" id="oobcnt">OOB: 0</small>
  </form>
</div>
<div class="wrap">
  <div>
    <h2>Targets</h2>
    <pre id="tg"></pre>
    <h2>Findings</h2>
    <table id="tbl">
    <thead><tr><th>#</th><th>URL</th><th>Protocol</th><th>Severity</th><th>Score</th><th>Details</th></tr></thead>
    <tbody></tbody></table>
  </div>
  <div>
    <h2>Discovery</h2>
    <details open><summary>Details / JS Endpoints</summary><pre id="disc"></pre></details>
    <details><summary>DOM Requests / Endpoints</summary><pre id="domdisc"></pre></details>
    <h2>Suggested Chains</h2>
    <ol id="chains"></ol>
  </div>
</div>
<script>
function row(i,x){
  const tr=document.createElement('tr');
  tr.innerHTML=`<td>${i+1}</td><td>${x.url||x.target||''}</td><td>${(x.vector||{}).protocol||''}</td>
    <td>${x.severity||''}</td><td>${x._score||''}</td><td><button data-i="${i}">Expand</button></td>`;
  const tr2=document.createElement('tr'); tr2.className='details'; tr2.id='det'+i;
  const ev=JSON.stringify(x.evidence||{},null,2);
  tr2.innerHTML=`<td colspan="6"><div class="code"><b>Payload:</b> ${x.payload}<br/><b>Vector:</b> ${JSON.stringify(x.vector)}<br/><b>Evidence:</b> ${ev}</div></td>`;
  tr.querySelector('button').onclick=()=>{
    const d=document.getElementById('det'+i);
    d.style.display = d.style.display==='table-row' ? 'none' : 'table-row';
  };
  return [tr,tr2];
}
async function refresh(){
  const r = await fetch('/api/findings'); const j = await r.json();
  const tb = document.querySelector('#tbl tbody'); tb.innerHTML='';
  (j.items||[]).forEach((x,i)=>{ const rows=row(i,x); rows.forEach(r=>tb.appendChild(r)); });
  const rc = await fetch('/api/chain'); const jc = await rc.json();
  const ol = document.querySelector('#chains'); ol.innerHTML='';
  (jc.paths||[]).forEach(p=>{ const li=document.createElement('li'); li.textContent=p[0].join(' -> '); ol.appendChild(li); });
  const rt = await fetch('/api/targets'); const jt = await rt.json();
  document.getElementById('tg').textContent = (jt.targets||[]).join('\\n');
  const rd = await fetch('/api/discovery'); const jd = await rd.json();
  document.getElementById('disc').textContent = JSON.stringify({details:jd["details.json"], js_endpoints: jd["js-endpoints.json"]}, null, 2);
  document.getElementById('domdisc').textContent = JSON.stringify({dom_requests:jd["dom-requests.json"], dom_endpoints: jd["dom-endpoints.json"]}, null, 2);
  const ro = await fetch('/api/oob'); const jo = await ro.json();
  document.getElementById('oobcnt').textContent = 'OOB: '+(jo.count||0);
}
async function run(){
  const d=document.getElementById('d').value; const mc=document.getElementById('mc').value; const pf=document.getElementById('pf').value; const cap=document.getElementById('cap').checked; const dom=document.getElementById('dom').checked;
  await fetch('/api/run',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({domain:d,max_concurrency:mc,profile:pf,capture:cap, dom_crawl:dom})});
  setTimeout(refresh, 3000);
}
async function queue(){
  const d=document.getElementById('d').value;
  await fetch('/api/queue/add',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({domain:d})});
  alert('Queued '+d);
}
setInterval(refresh, 5000); refresh();
</script>
</body></html>"""
    return app
