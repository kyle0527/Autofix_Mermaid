from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List, Dict, Any, Optional
import time, json as _json, re
import httpx
from op_core.finding_contract import Finding






from __future__ import annotations

"""Minimal IDOR detection logic (MVP).

Usage pattern (tests + future pipeline integration):

    check = IdorCheck(
        roles=[
            {"name":"user1","headers":{"X-User-ID":"1"}},
            {"name":"user2","headers":{"X-User-ID":"2"}},
            {"name":"anon","headers":{}},
        ]
    )
    findings = list(check.run([
        {"url":"http://host/api/v1/notes/2","owner_user_id":2},
        {"url":"http://host/api/v1/orders/11","owner_user_id":2},
    ]))

Input (apis list): each item may include:
  - url (required)
  - owner_user_id (int) : Which user id should be considered the legitimate owner
  - method (default GET)

Detection heuristics:
  1. Perform baseline request with owner headers.
  2. Replay with every other role (different user id or anonymous).
  3. If a non-owner receives 200 where owner also 200 -> potential full IDOR (severity=medium).
  4. If a non-owner receives 206 (Partial Content) while owner 200 -> partial disclosure (severity=low).
  5. Similarity heuristic (content length ratio) logged in meta for later refinement.

Future expansion points (not implemented yet):
  - Automatic discovery of owner_user_id via creating own resources.
  - Numeric ID mutation (id±1, other_user_id) generator.
  - Structured response diffing (JSON semantic comparison).


from dataclasses import dataclass
from typing import Iterable, List, Dict, Any, Optional
import time
import httpx
from op_core.finding_contract import Finding



@dataclass
class Role:
    name: str



    user_id: Optional[int] = None  # convenience cache (parsed from headers)








    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Role":
        headers = d.get("headers", {}) or {}
        uid = None
        if "X-User-ID" in headers:

            try:
                uid = int(headers["X-User-ID"])
            except ValueError:
                uid = None
        return Role(name=d.get("name") or f"role_{len(headers)}", headers=headers, user_id=uid)



                uid = int(headers["X-User-ID"])
            except ValueError:
                uid = None

        return Role(name=d.get("name") or f"role_{len(headers)}", headers=headers, usfMimport re
import json
import time
import httpx
import asyncio
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from pathlib import Path

try:
    from ..op_core.finding_contract import Finding
    from ..op_core.session import load_cookies
except ImportError:
    # Handle standalone execution
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from op_core.finding_contract import Finding
    from op_core.session import load_cookies


class SessionManager:
    """Manages user sessions and authentication for IDOR testing."""
    
    def __init__(self, workdir: Optional[Path] = None):
        self.workdir = workdir or Path(".")
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.cookies = load_cookies(self.workdir) if workdir else {}
    
    def add_session(self, role: str, auth_data: Dict[str, Any]) -> None:
        """Add a session for a specific role."""
        self.sessions[role] = {
            "auth_data": auth_data,
            "cookies": auth_data.get("cookies", {}),
            "headers": auth_data.get("headers", {}),
            "token": auth_data.get("token"),
            "created_at": time.time()
        }
    
    def get_session(self, role: str) -> Optional[Dict[str, Any]]:
        """Get session data for a specific role."""
        return self.sessions.get(role)
    
    def get_auth_headers(self, role: str) -> Dict[str, str]:
        """Get authentication headers for a role."""
        session = self.get_session(role)
        if not session:
            return {}
        
        headers = dict(session.get("headers", {}))
        
        # Add token-based auth if available
        if session.get("token"):
            headers["Authorization"] = f"Bearer {session['token']}"
        
        return headers
    
    def get_auth_cookies(self, role: str) -> Dict[str, str]:
        """Get authentication cookies for a role."""
        session = self.get_session(role)
        if not session:
            return {}
        
        return session.get("cookies", {})


class IdVariantGenerator:
    """Generates ID variants for testing different access patterns."""
    
    @staticmethod
    def extract_ids_from_url(url: str) -> List[Tuple[str, str, Any]]:
        """Extract potential IDs from URL path and query parameters.
        
        Returns list of (location, param_name, value) tuples where:
        - location is 'path' or 'query'
        - param_name is the parameter name or path segment position
        - value is the extracted ID value
        """
        ids = []
        parsed = urlparse(url)
        
        # Extract from path segments
        path_segments = [seg for seg in parsed.path.split('/') if seg]
        for i, segment in enumerate(path_segments):
            # Look for numeric IDs, UUIDs, or alphanumeric identifiers
            if re.match(r'^\d+$', segment):  # Numeric ID
                ids.append(('path', str(i), int(segment)))
            elif re.match(r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$', segment, re.I):  # UUID
                ids.append(('path', str(i), segment))
            elif re.match(r'^[a-zA-Z0-9]{6,}$', segment):  # Alphanumeric ID
                ids.append(('path', str(i), segment))
        
        # Extract from query parameters
        query_params = parse_qs(parsed.query)
        for param_name, values in query_params.items():
            for value in values:
                if re.match(r'^\d+$', value):  # Numeric ID
                    ids.append(('query', param_name, int(value)))
                elif re.match(r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$', value, re.I):  # UUID
                    ids.append(('query', param_name, value))
                elif re.match(r'^[a-zA-Z0-9]{6,}$', value):  # Alphanumeric ID
                    ids.append(('query', param_name, value))
        
        return ids
    
    @staticmethod
    def generate_variants(url: str, original_ids: List[Tuple[str, str, Any]]) -> List[str]:
        """Generate URL variants by modifying IDs."""
        variants = []
        
        for location, param_name, original_value in original_ids:
            # Generate variant values
            variant_values = []
            
            if isinstance(original_value, int):
                # Numeric variants
                variant_values.extend([
                    original_value + 1,
                    original_value - 1,
                    original_value + 10,
                    1, 2, 3, 999, 9999,  # Common test values
                    0, -1  # Edge cases
                ])
            elif isinstance(original_value, str):
                if re.match(r'^[a-f0-9-]{36}$', original_value, re.I):  # UUID
                    # UUID variants - generate some test UUIDs
                    variant_values.extend([
                        "00000000-0000-0000-0000-000000000001",
                        "11111111-1111-1111-1111-111111111111",
                        "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
                    ])
                else:  # Alphanumeric
                    # Alphanumeric variants
                    variant_values.extend([
                        original_value + "1",
                        original_value[:-1] + "0" if len(original_value) > 1 else "0",
                        "admin", "test", "demo", "user1", "user2"
                    ])
            
            # Generate URLs with variants
            for variant_value in variant_values:
                if location == 'path':
                    # Modify path segment
                    parsed = urlparse(url)
                    path_segments = parsed.path.split('/')
                    segment_index = int(param_name)
                    if 0 <= segment_index < len(path_segments) - 1:  # -1 because split includes empty string at start
                        new_segments = path_segments.copy()
                        new_segments[segment_index + 1] = str(variant_value)  # +1 because of empty string at index 0
                        new_path = '/'.join(new_segments)
                        new_url = urlunparse((parsed.scheme, parsed.netloc, new_path, 
                                            parsed.params, parsed.query, parsed.fragment))
                        variants.append(new_url)
                
                elif location == 'query':
                    # Modify query parameter
                    parsed = urlparse(url)
                    query_params = parse_qs(parsed.query, keep_blank_values=True)
                    query_params[param_name] = [str(variant_value)]
                    new_query = urlencode(query_params, doseq=True)
                    new_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path,
                                        parsed.params, new_query, parsed.fragment))
                    variants.append(new_url)
        
        return list(set(variants))  # Remove duplicates


class RequestReplay:
    """Handles request replay with different authentication contexts."""
    
    def __init__(self, session_manager: SessionManager):
        self.session_manager = session_manager
    
    async def replay_request(self, url: str, method: str = "GET", 
                           role: Optional[str] = None, 
                           timeout: float = 10.0) -> Optional[Dict[str, Any]]:
        """Replay a request with specific role authentication."""
        try:
            headers = {}
            cookies = {}
            
            if role:
                headers.update(self.session_manager.get_auth_headers(role))
                cookies.update(self.session_manager.get_auth_cookies(role))
            
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    cookies=cookies
                )
                
                return {
                    "url": url,
                    "method": method,
                    "role": role,
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "content_length": len(response.content),
                    "content": response.text[:1000],  # Limit content for analysis
                    "response_time": response.elapsed.total_seconds()
                }
        
        except Exception as e:
            return {
                "url": url,
                "method": method,
                "role": role,
                "error": str(e),
                "status_code": None
            }


class IdorDetector:
    """maindetection engine."""
    
    def __init__(self, workdir: Optional[Path] = None):
        self.session_manager = SessionManager(workdir)
        self.request_replay = RequestReplay(self.session_manager)
        self.variant_generator = IdVariantGenerator()
    
    def setup_test_sessions(self, base_url: str) -> None:
        """Setup test sessions with different user roles.
        This enhanced version attempts to log in to the target service
        and capture real authentication tokens/cookies.
        """
        import httpx
        
        # Try to set up real authenticated sessions
        try:
            # Attempt to log in as admin
            admin_data = self._attempt_login(base_url, "admin", "admin123")
            if admin_data:
                self.session_manager.add_session("admin", admin_data)
            else:
                # Fallback to default headers
                self.session_manager.add_session("admin", {
                    "headers": {"X-User-Role": "admin"},
                    "token": "admin-token-123"
                })
            
            # Attempt to log in as regular user
            user_data = self._attempt_login(base_url, "user1", "user123")
            if user_data:
                self.session_manager.add_session("user", user_data)
            else:
                # Fallback to default headers
                self.session_manager.add_session("user", {
                    "headers": {"X-User-Role": "user"},
                    "token": "user-token-456"
                })
            
            # Anonymous session (no auth)
            self.session_manager.add_session("anonymous", {})
            
        except Exception as e:
            # Fallback to basic session setup if login fails
            self.session_manager.add_session("admin", {
                "headers": {"X-User-Role": "admin"},
                "token": "admin-token-123"
            })
            
            self.session_manager.add_session("user", {
                "headers": {"X-User-Role": "user"},
                "token": "user-token-456"
            })
            
            self.session_manager.add_session("anonymous", {})
    
    def _attempt_login(self, base_url: str, username: str, password: str) -> Optional[Dict[str, Any]]:
        """Attempt to log in to the target service and return session data."""
        try:
            import httpx
            
            with httpx.Client(timeout=10.0) as client:
                # Try to login
                login_response = client.post(
                    f"{base_url}/login",
                    json={"username": username, "password": password}
                )
                
                if login_response.status_code == 200:
                    login_data = login_response.json()
                    
                    if login_data.get("success"):
                        # Extract session data
                        cookies = dict(login_response.cookies)
                        token = login_data.get("token")
                        
                        return {
                            "cookies": cookies,
                            "token": token,
                            "headers": {},
                            "user_info": login_data.get("user", {})
                        }
        
        except Exception:
            pass
        
        return None
    
    async def detect_idor_single_url(self, url: str, method: str = "GET") -> List[Dict[str, Any]]:
        """Detect IDOR vulnerabilities for a single URL."""
        findings = []
        
        # Extract IDs from the URL
        original_ids = self.variant_generator.extract_ids_from_url(url)
        
        if not original_ids:
            # No IDs found in URL, skip IDOR testing
            return findings
        
        # Test original URL with different roles
        roles = ["admin", "user", "anonymous"]
        original_responses = {}
        
        for role in roles:
            response = await self.request_replay.replay_request(url, method, role)
            if response:
                original_responses[role] = response
        
        # Generate variants and test them
        variant_urls = self.variant_generator.generate_variants(url, original_ids)
        
        for variant_url in variant_urls[:10]:  # Limit to first 10 variants to avoid too many requests
            variant_responses = {}
            
            for role in roles:
                response = await self.request_replay.replay_request(variant_url, method, role)
                if response:
                    variant_responses[role] = response
            
            # Analyze responses for IDOR indicators
            idor_finding = self._analyze_responses(url, variant_url, original_responses, variant_responses)
            if idor_finding:
                findings.append(idor_finding)
        
        return findings
    
    def _analyze_responses(self, original_url: str, variant_url: str,
                          original_responses: Dict[str, Dict[str, Any]],
                          variant_responses: Dict[str, Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Analyze response patterns to detect IDOR vulnerabilities."""
        
        # Check for unauthorized access patterns
        for role in ["user", "anonymous"]:
            orig_resp = original_responses.get(role)
            var_resp = variant_responses.get(role)
            
            if not orig_resp or not var_resp:
                continue
            
            # Pattern 1: Successful access to variant when original failed
            if (orig_resp.get("status_code") in [401, 403, 404] and 
                var_resp.get("status_code") == 200):
                
                return {
                    "type": "idor_unauthorized_access",
                    "original_url": original_url,
                    "variant_url": variant_url,
                    "role": role,
                    "original_status": orig_resp.get("status_code"),
                    "variant_status": var_resp.get("status_code"),
                    "evidence": {
                        "original_response": orig_resp,
                        "variant_response": var_resp
                    }
                }
            
            # Pattern 2: Same successful status but different content (indicating access to different resource)
            if (orig_resp.get("status_code") == 200 and var_resp.get("status_code") == 200 and
                orig_resp.get("content_length", 0) != var_resp.get("content_length", 0)):
                
                # Check if content is significantly different
                content_diff = abs(orig_resp.get("content_length", 0) - var_resp.get("content_length", 0))
                if content_diff > 50:  # Significant difference threshold
                    
                    return {
                        "type": "idor_content_disclosure",
                        "original_url": original_url,
                        "variant_url": variant_url,
                        "role": role,
                        "original_status": orig_resp.get("status_code"),
                        "variant_status": var_resp.get("status_code"),
                        "content_length_diff": content_diff,
                        "evidence": {
                            "original_response": orig_resp,
                            "variant_response": var_resp
                        }
                    }
            
            # Pattern 3: Both succeed but should require authorization (baseline security check)
            if (orig_resp.get("status_code") == 200 and var_resp.get("status_code") == 200 and
                role == "anonymous"):
                
                # Check if this appears to be a protected resource that allows anonymous access
                orig_content = orig_resp.get("content", "").lower()
                var_content = var_resp.get("content", "").lower()
                
                # Look for indicators of sensitive data that shouldn't be accessible anonymously
                sensitive_indicators = ["password", "email", "private", "confidential", "secret", "token"]
                
                if any(indicator in orig_content or indicator in var_content for indicator in sensitive_indicators):
                    # This might be a baseline authorization bypass
                    return {
                        "type": "idor_authorization_bypass",
                        "original_url": original_url,
                        "variant_url": variant_url,
                        "role": role,
                        "original_status": orig_resp.get("status_code"),
                        "variant_status": var_resp.get("status_code"),
                        "evidence": {
                            "original_response": orig_resp,
                            "variant_response": var_resp,
                            "reason": "Sensitive data accessible without authentication"
                        }
                    }
        
        # Pattern 4: Cross-role access - user can access admin resources
        admin_resp = original_responses.get("admin")
        user_resp = original_responses.get("user")
        
        if (admin_resp and user_resp and 
            admin_resp.get("status_code") == 200 and user_resp.get("status_code") == 200):
            
            # If both admin and user can access the same resource with similar content,
            # check if it should be admin-only by looking for admin indicators
            admin_content = admin_resp.get("content", "").lower()
            
            admin_indicators = ["admin", "administrator", "manage", "delete", "control"]
            if any(indicator in admin_content for indicator in admin_indicators):
                return {
                    "type": "idor_privilege_escalation",
                    "original_url": original_url,
                    "variant_url": original_url,  # Same URL, different roles
                    "role": "user",
                    "original_status": admin_resp.get("status_code"),
                    "variant_status": user_resp.get("status_code"),
                    "evidence": {
                        "original_response": admin_resp,
                        "variant_response": user_resp,
                        "reason": "User role can access admin-level content"
                    }
                }
        
        return None











class IdorCheck:
    name = "idor"

    def __init__(self, roles: Optional[List[Dict[str, Any]]] = None, timeout: float = 6.0, expand_variants: bool = False,
                 exclude_patterns: Optional[List[str]] = None, max_variants: int = 50):

        if not roles:
            roles = [
                {"name": "user1", "headers": {"X-User-ID": "1"}},
                {"name": "user2", "headers": {"X-User-ID": "2"}},
                {"name": "anon", "headers": {}},
            ]
        self.roles: List[Role] = [Role.from_dict(r) for r in roles]
        self.timeout = timeout
        self.expand_variants = expand_variants
        self.exclude_patterns = exclude_patterns or []
        self._exclude_re = []

        for pat in self.exclude_patterns:
            try:
                self._exclude_re.append(re.compile(pat))
            except Exception:
                pass
        self.max_variants = max_variants



        """Produce simple numeric +/- variants for last integer in path.

        Returns list of dicts with url + owner_user_id matching the mutated id.
        """
        import re
        # Find ALL numeric path segments (without query) and make per-segment ± variants







        m = re.match(r"^(https?://[^?#]+)", url)
        if not m:
            return []
        base_path = m.group(1)
        parts = base_path.split("/")
        variants: List[Dict[str, Any]] = []
        for idx, seg in enumerate(parts):
            if not re.fullmatch(r"\d+", seg):
                continue
            try:
                val = int(seg)
            except ValueError:
                continue
            for delta in (-1, 1):
                new_val = val + delta
                if new_val < 1:
                    continue
                new_parts = list(parts)
                new_parts[idx] = str(new_val)



                suffix = ""
                suf_match = re.search(r"^(https?://[^?#]+)([?#].*)$", url)
                if suf_match:



 
                # append any suffix (query/fragment)
                suffix = ""
                suf_match = re.search(r"^(https?://[^?#]+)([?#].*)$", url)
                if suf_match:
                    # reuse original suffix for all variants








                    suffix = suf_match.group(2)
                variants.append({"url": new_url + suffix, "owner_user_id": owner_user_id if owner_user_id is not None else val})
        return variants

    @staticmethod
    def generate_query_variants(url: str, window: int = 1) -> List[Dict[str, Any]]:
        from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
        parts = urlparse(url)
        if not parts.query:
            return []
        qs = parse_qsl(parts.query, keep_blank_values=True)
        numeric_params = [(k, v) for (k, v) in qs if re.fullmatch(r"\d+", v)]
        if not numeric_params:
            return []
        out: List[Dict[str, Any]] = []
        for k, v in numeric_params[:2]:
            try:
                base_id = int(v)
            except ValueError:
                continue
            for delta in (-1, 1):
                nid = base_id + delta
                if nid < 1:
                    continue
                new_q = []
                for k2, v2 in qs:
                    if k2 == k and v2 == v:
                        new_q.append((k2, str(nid)))
                    else:
                        new_q.append((k2, v2))
                new_query = urlencode(new_q)
                new_url = urlunparse((parts.scheme, parts.netloc, parts.path, parts.params, new_query, parts.fragment))
                out.append({"url": new_url})
        return out

    def _fetch(self, client: httpx.Client, method: str, url: str, headers: Dict[str, str]) -> Dict[str, Any]:
        t0 = time.time()
        try:
            r = client.request(method.upper(), url, headers=headers, timeout=self.timeout)
            body = r.text or ""
            return {
                "status": r.status_code,
                "content_length": len(body),

                "error": None,
            }
        except Exception as e:
            return {"status": 0, "content_length": 0, "body": "", "elapsed_ms": int((time.time() - t0) * 1000), "error": str(e)}

    def run(self, apis=None, **kwargs) -> Iterable[Finding]:
        if not apis:
            return []
        expanded: List[Dict[str, Any]] = []
        for api in apis:
            if isinstance(api, dict):
                expanded.append(api)
                if self.expand_variants:
                    if "owner_user_id" not in api:
                        nums = re.findall(r"/(\d+)(?:/|$)", api.get("url", ""))
                        if nums:
                            api["owner_user_id"] = int(nums[-1])
                    if len(expanded) < self.max_variants:
                        expanded.extend(self.generate_numeric_variants(api.get("url", ""), api.get("owner_user_id")))
                    if len(expanded) < self.max_variants:
                        expanded.extend(self.generate_query_variants(api.get("url", "")))
            else:
                expanded.append({"url": str(api)})
        if self._exclude_re:
            filt: List[Dict[str, Any]] = []
            for ent in expanded:
                u = ent.get("url") if isinstance(ent, dict) else str(ent)
                if any(r.search(u) for r in self._exclude_re):
                    continue
                filt.append(ent)
            expanded = filt







                    # If owner_user_id missing try parse last numeric segment
                    if "owner_user_id" not in api:
                        import re
                        nums = re.findall(r"/(\d+)(?:/|$)", api.get("url",""))
                        if nums:
                            api["owner_user_id"] = int(nums[-1])
                    if len(expanded) < self.max_variants:
                        expanded.extend(self.generate_numeric_variants(api.get("url",""), api.get("owner_user_id")))
                    if len(expanded) < self.max_variants:
                        expanded.extend(self.generate_query_variants(api.get("url","")))
            else:
                expanded.append({"url": str(api)})
        # Apply exclude filters
        if self._exclude_re:
            filtered: List[Dict[str, Any]] = []


            for ent in expanded:
                u = ent.get("url") if isinstance(ent, dict) else str(ent)
                if any(r.search(u) for r in self._exclude_re):


                filtered.append(ent)
            expanded = filtered







        findings: List[Finding] = []
        cache: Dict[str, Dict[str, Any]] = {}
        with httpx.Client(follow_redirects=True) as client:
            for api in expanded:
                url = api.get("url") if isinstance(api, dict) else str(api)
                if not url:
                    continue
                method = api.get("method", "GET") if isinstance(api, dict) else "GET"
                owner_uid = api.get("owner_user_id") if isinstance(api, dict) else None
                owner_role: Optional[Role] = None
                if owner_uid is not None:
                    for r in self.roles:
                        if r.user_id == owner_uid:
                            owner_role = r; break
                if not owner_role:
                    owner_role = next((r for r in self.roles if r.user_id is not None), self.roles[0])
                ck_base = f"B::{method}::{url}::{owner_role.name}"
                base = cache.get(ck_base)
                if base is None:
                    base = self._fetch(client, method, url, owner_role.headers)
                    cache[ck_base] = base
                for role in self.roles:
                    if role is owner_role:
                        continue
                    ck_alt = f"A::{method}::{url}::{role.name}"
                    alt = cache.get(ck_alt)
                    if alt is None:
                        alt = self._fetch(client, method, url, role.headers)
                        cache[ck_alt] = alt
                    base_status = base["status"]; alt_status = alt["status"]
                    pattern = severity = title = None
                    if base_status in (401,403) and alt_status == 200:
                        severity = "high"; title = "Reverse Authorization Bypass: non-owner allowed while owner denied"; pattern = "reverse_bypass"
                    elif base_status == 200 and alt_status == 200:





                cache_key_owner = f"BASE::{method}::{url}::{owner_role.name}"
                if cache_key_owner in cache:
                    base = cache[cache_key_owner]
                else:
                    base = self._fetch(client, method, url, owner_role.headers)
                    cache[cache_key_owner] = base
                base_status = base["status"]

                for role in self.roles:
                    if role is owner_role:
                        continue
                    cache_key_alt = f"ALT::{method}::{url}::{role.name}"
                    if cache_key_alt in cache:
                        alt = cache[cache_key_alt]
                    else:
                        alt = self._fetch(client, method, url, role.headers)
                        cache[cache_key_alt] = alt
                    alt_status = alt["status"]
                    pattern = None
                    severity = None
                    title = None
                    # Reverse bypass: owner denied, outsider allowed
                    if base_status in (401,403) and alt_status == 200:
                        severity = "high"
                        title = "Reverse Authorization Bypass: non-owner allowed while owner denied"
                        pattern = "reverse_bypass"
                    # Normal success cases
                    elif base_status == 200 and alt_status == 200:
                        # Try JSON structural diff to distinguish full vs partial
                        import json as _json
     keys_owner = keys_alt = None





         try:
                            o_j = _json.loads(base["body"]) if base["body"].strip().startswith("{") else None
                            a_j = _json.loads(alt["body"]) if alt["body"].strip().startswith("{") else None
                            if isinstance(o_j, dict) and isinstance(a_j, dict):





                            pass
                        if keys_owner and keys_alt:
                            if keys_alt == keys_owner:
                                severity = "medium"; title = "Potential IDOR: non-owner gained full access"; pattern = "full_access"
                            elif keys_alt.issubset(keys_owner):
         severity = "medium"; title = "Potential IDOR: non-owner gained full access"; pattern = "full_access"
                    elif base_status == 200 and alt_status == 206:
                        severity = "low"; title = "Potential Partial Disclosure via IDOR"; pattern = "partial_disclosure"
                    elif base_status == 405 and alt_status == 200:
                        severity = "medium"; title = "Potential Method Confusion / Bypass"; pattern = "method_confusion"
                    else:
                        continue
                    clen_base = max(base["content_length"], 1); clen_alt = max(alt["content_length"], 1)
                    ratio = min(clen_base, clen_alt) / max(clen_base, clen_alt)
                    meta = {
                        "url": url,
                        "method": method,
                        "owner_role": owner_role.name,
                        "alt_role": role.name,
                        "owner_status": base_status,
                        "alt_status": alt_status,
                        "owner_clen": clen_base,
                        "alt_clen": clen_alt,
                        "clen_similarity": round(ratio, 3),
                        "owner_user_id": owner_role.user_id,
                        "alt_user_id": role.user_id,
                        "variant_expanded": self.expand_variants,
                        "pattern": pattern,

