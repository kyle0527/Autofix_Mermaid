from typing import Iterable

try:
    from ..op_core.finding_contract import Finding
except ImportError:
    # Handle standalone execution
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from op_core.finding_contract import Finding

# Change this to a domain you control when running real checks
EVIL_HOST = "https://example-evil.invalid"

class OAuthOpenRedirectCheck:
    name = "oauth"

    def run(self, apis=None, **kwargs) -> Iterable[Finding]:
        # placeholder impl: no-op
        return []
