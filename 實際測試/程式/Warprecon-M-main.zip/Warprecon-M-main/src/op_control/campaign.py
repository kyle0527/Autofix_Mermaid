from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
try:
    from pydantic import BaseModel
except Exception:  # pragma: no cover - fallback for test environments without pydantic
    # Minimal fallback so tests that only import this module don't fail.
    class BaseModel:  # type: ignore
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


class Limits(BaseModel):
    global_rps: int = 30
    per_host_rps: int = 6
    jitter_ms: int = 120
    max_concurrency: int = 8
    per_target_payloads: int = 8
    retries: int = 1
    max_depth: int = 2


class BanditCfg(BaseModel):
    algo: str = "linucb"
    arms: List[Dict[str, Any]] = []


class OOBCfg(BaseModel):
    provider: str = "interactsh"
    base_url: Optional[str] = None
    api_key: Optional[str] = None


class SynthCfg(BaseModel):
    transforms: List[str] = [
        "identity",
        "double_encode",
        "quote_flip",
        "split_keywords",
        "gql_variants",
    ]


class OutputCfg(BaseModel):
    poc_top: int = 5
    capture: bool = False
    history_ttl_days: int = 30


class IdorCfg(BaseModel):
    enabled: bool = True
    max_variants_per_id: int = 10
    test_roles: List[str] = ["admin", "user", "anonymous"]
    session_config: Dict[str, Dict[str, Any]] = {}


class Campaign(BaseModel):
    allow: List[str] = []
    deny: List[str] = []
    limits: Limits = Limits()
    bandit: BanditCfg = BanditCfg()
    oob: OOBCfg = OOBCfg()
    synth: SynthCfg = SynthCfg()
    output: OutputCfg = OutputCfg()
    idor: IdorCfg = IdorCfg()


def load_campaign(p: Path) -> Campaign:
    """Load a campaign configuration from *p*.

    The configuration file is optional; when absent or partially populated,
    default :class:`Campaign` values are used.
    """

    data: Dict[str, Any] = {}
    if Path(p).exists():
        data = yaml.safe_load(Path(p).read_text(encoding="utf-8")) or {}

    return Campaign(
        allow=data.get("scopes", {}).get("allow", []),
        deny=data.get("scopes", {}).get("deny", []),
        limits=Limits(**(data.get("limits") or {})),
        bandit=BanditCfg(**(data.get("bandit") or {})),
        oob=OOBCfg(**(data.get("oob") or {})),
        synth=SynthCfg(**(data.get("synth") or {})),
        output=OutputCfg(**(data.get("output") or {})),
        idor=IdorCfg(**(data.get("idor") or {})),
    )

