from __future__ import annotations
from typing import List, Dict, Tuple
import re
from urllib.parse import urlparse, urljoin

def _same_host(u: str, host: str) -> bool:
    try:
        return urlparse(u).netloc.split(':')[0].lower() == host.lower()
    except Exception:
        return False

def _extract_endpoints(html: str, base: str, host: str) -> List[str]:
    out: List[str] = []
    pats = [
        r"fetch\(\s*['\"]([^'\"]+)['\"]",
        r"axios\.(?:get|post|put|delete|patch)\(\s*['\"]([^'\"]+)['\"]",
        r"new\s+WebSocket\(\s*['\"]([^'\"]+)['\"]",
        r"['\"](/(?:api|graphql)/[A-Za-z0-9_\-\/]+)['\"]",
        r"(https?://[A-Za-z0-9\.\-]+(?::\d+)?/[^\s'\"\\)]+)",
    ]
    for pat in pats:
        for m in re.findall(pat, html):
            u = urljoin(base, m)
            if _same_host(u, host):
                out.append(u)
    return list(dict.fromkeys(out))

def render_discover(url: str, max_pages: int = 6, wait_ms: int = 800) -> Tuple[List[str], Dict]:
    """
    Best-effort DOM discovery using Playwright (if available). Returns (endpoints, details).
    details: { 'pages': [], 'errors': [] }
    """
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception:
        return [], {"note": "playwright not installed"}

    from urllib.parse import urlparse
    host = urlparse(url).netloc.split(':')[0]
    pages_seen = 0
    endpoints: List[str] = []
    details = {"pages": [], "errors": []}
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(ignore_https_errors=True)
            page = context.new_page()
            page.goto(url, wait_until="domcontentloaded")
            def _harvest():
                html = page.content()
                eps = _extract_endpoints(html, str(page.url), host)
                for e in eps:
                    if e not in endpoints:
                        endpoints.append(e)
                details["pages"].append({"url": str(page.url), "endpoints": eps[:50]})
            _harvest()
            # Click simple anchors and SPA links (limited to same host, anchor clicks)
            anchors = page.query_selector_all("a[href]")
            for a in anchors[:max_pages-1]:
                try:
                    href = a.get_attribute("href") or ""
                    if not href: continue
                    from urllib.parse import urljoin
                    absu = urljoin(str(page.url), href)
                    if not _same_host(absu, host): continue
                    a.click()
                    page.wait_for_timeout(wait_ms)
                    _harvest()
                    pages_seen += 1
                    if pages_seen >= max_pages: break
                except Exception as ex:
                    details["errors"].append(str(ex))
            browser.close()
    except Exception as ex:
        details["errors"].append(str(ex))
    return endpoints, details
