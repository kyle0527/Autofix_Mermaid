from __future__ import annotations

"""Authentication session manager supporting multiple user roles."""

import inspect
from typing import Any, Callable, Dict

from . import AuthStrategy, NoAuthStrategy


class AuthManager:
    """Manage authenticated clients for multiple user roles.

    Parameters
    ----------
    strategies:
        Mapping of role name to :class:`AuthStrategy` instances.
    client_factory:
        Callable that returns a new HTTP client when a role is first used.
    """

    def __init__(
        self,
        strategies: Dict[str, AuthStrategy],
        client_factory: Callable[[], Any],
    ) -> None:
        self._strategies = strategies
        self._client_factory = client_factory
        self._clients: Dict[str, Any] = {}

    def client_for(self, role: str) -> Any:
        """Return an authenticated client for ``role``.

        Creates the client on first use and ensures the session is still valid
        on subsequent calls.
        """

        client = self._clients.get(role)
        strategy = self._strategies.get(role, NoAuthStrategy())
        if client is None:
            client = self._client_factory()
            self._clients[role] = client
            strategy.login(client)
        else:
            strategy.ensure_session(client)
        return client

    def renew(self, role: str) -> None:
        """Force re-login for the given ``role`` if it exists."""

        client = self._clients.get(role)
        strategy = self._strategies.get(role)
        if client is not None and strategy is not None:
            strategy.login(client)

    def renew_all(self) -> None:
        """Force re-login for all cached clients."""

        for role in list(self._clients.keys()):
            self.renew(role)

    async def close_all(self) -> None:
        """Close all underlying clients and clear cache."""

        for client in self._clients.values():
            close = getattr(client, "aclose", None)
            if callable(close):
                if inspect.iscoroutinefunction(close):
                    await close()
                else:
                    close()
        self._clients.clear()
