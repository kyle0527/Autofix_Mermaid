from __future__ import annotations

from pathlib import Path
from typing import Any

from op_core.session import load_cookies

from . import AuthStrategy


class CookieAuthStrategy(AuthStrategy):
    """Reuse cookies from ``<workdir>/session/cookies.json``."""

    def __init__(self, workdir: Path):
        self.workdir = Path(workdir)

    def login(self, client: Any) -> None:
        jar = load_cookies(self.workdir)
        if hasattr(client, "cookies"):
            try:
                client.cookies.update(jar)  # type: ignore[arg-type]
            except Exception:
                for k, v in getattr(jar, "items", lambda: [])():
                    try:
                        client.cookies[k] = v  # type: ignore[index]
                    except Exception:
                        continue

    def ensure_session(self, client: Any) -> None:
        if (
            hasattr(client, "cookies")
            and not client.cookies  # type: ignore[truthy-function]
        ):
            self.login(client)
