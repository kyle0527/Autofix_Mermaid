from __future__ import annotations

"""Pluggable authentication strategies for Warprecon-M."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Type


class AuthStrategy(ABC):
    """Interface for authentication and session maintenance."""

    @abstractmethod
    def login(self, client: Any) -> None:
        """Perform an initial login using the provided HTTP client."""

    @abstractmethod
    def ensure_session(self, client: Any) -> None:
        """Validate the current session and re-login if necessary."""


class NoAuthStrategy(AuthStrategy):
    """Default strategy that performs no authentication."""

    def login(self, client: Any) -> None:  # pragma: no cover
        return None

    def ensure_session(self, client: Any) -> None:  # pragma: no cover
        return None


from .cookie import CookieAuthStrategy  # noqa: E402
from .jwt import JWTAuthStrategy  # noqa: E402
from .manager import AuthManager  # noqa: E402
from .oauth import OAuthAuthStrategy  # noqa: E402

_STRATEGIES: Dict[str, Type[AuthStrategy]] = {
    "none": NoAuthStrategy,
    "cookie": CookieAuthStrategy,
    "jwt": JWTAuthStrategy,
    "oauth": OAuthAuthStrategy,
}


def load_strategy(name: str, **kwargs: Any) -> AuthStrategy:
    """Factory helper to construct an authentication strategy.

    Unknown names fall back to :class:`NoAuthStrategy` to preserve
    backwards compatibility.
    """

    cls = _STRATEGIES.get(name.lower(), NoAuthStrategy)
    return cls(**kwargs)  # type: ignore[call-arg]


__all__ = [
    "AuthStrategy",
    "NoAuthStrategy",
    "CookieAuthStrategy",
    "JWTAuthStrategy",
    "OAuthAuthStrategy",
    "AuthManager",
    "load_strategy",
]
