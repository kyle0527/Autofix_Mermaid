from __future__ import annotations

import logging
from importlib import util
from pathlib import Path
from types import ModuleType
from typing import Callable, Dict, List

logger = logging.getLogger(__name__)

HOOK_NAMES = ["vector_probe", "post_rank", "artifact_exporter"]


def _load_module(path: Path) -> ModuleType | None:
    """Dynamically load a module from ``path``.

    Returns ``None`` if the module could not be imported.
    """
    try:
        module_name = f"op_plugin_{path.stem}"
        spec = util.spec_from_file_location(module_name, path)
        if spec and spec.loader:
            mod = util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore[assignment]
            return mod
    except Exception as exc:
        logger.warning("Failed to load plugin %s: %s", path, exc)
    return None


def load_plugins(workdir: Path) -> Dict[str, List[Callable]]:
    """Search for plugin modules and collect hook functions.

    The following directories are scanned for ``*.py`` files:

    * ``<workdir>/plugins``
    * ``./plugins``
    * ``./ext/plugins``
    * ``op_plugins/builtin`` (within the package)

    For every discovered module the hooks ``vector_probe``, ``post_rank`` and
    ``artifact_exporter`` are collected if present.
    """

    search_paths = [
        workdir / "plugins",
        Path("plugins"),
        Path("ext/plugins"),
        Path(__file__).resolve().parent / "builtin",
    ]

    hooks: Dict[str, List[Callable]] = {name: [] for name in HOOK_NAMES}

    for d in search_paths:
        if not d.exists():
            continue
        for plugin_path in sorted(d.glob("*.py")):
            mod = _load_module(plugin_path)
            if not mod:
                continue
            for hook_name in HOOK_NAMES:
                func = getattr(mod, hook_name, None)
                if callable(func):
                    hooks[hook_name].append(func)

    # Remove empty hook lists
    return {k: v for k, v in hooks.items() if v}
