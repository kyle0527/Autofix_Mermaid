from __future__ import annotations
import subprocess, json, codecs
from typing import List, Dict

def run_nuclei(targets_file: str, templates_dir: str|None=None) -> List[Dict]:
    cmd = ["nuclei","-l",targets_file,"-jsonl"]
    if templates_dir: cmd += ["-t",templates_dir]
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except FileNotFoundError:
        return []
    out: List[Dict]=[]
    decoder = codecs.getincrementaldecoder("utf-8")("replace")
    for raw in p.stdout or []:
        line = decoder.decode(raw).strip()
        if not line: continue
        try:
            j=json.loads(line)
            out.append({
                "target": j.get("host") or j.get("matched-at"),
                "vector": {"protocol":"http","location":"nuclei","param":None},
                "payload": j.get("info",{}).get("name"),
                "tool": "nuclei",
                "evidence": {"matcher": j.get("matcher-name"), "template": j.get("template-id")},
                "severity": (j.get("info",{}).get("severity") or "medium"),
                "url": j.get("matched-at")
            })
        except Exception:
            continue
    return out
