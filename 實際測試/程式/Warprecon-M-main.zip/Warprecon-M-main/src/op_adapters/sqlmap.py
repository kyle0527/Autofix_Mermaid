from __future__ import annotations
import subprocess, re
from typing import Dict, List

SQLI_PATTERNS = [r"sqlmap identified the following injection", r"parameter .* appears to be injectable", r"the back-end DBMS is"]

def run_sqlmap(url: str, param: str="id", timeout: int = 120) -> List[Dict]:
    cmd = ["sqlmap","-u",f"{url}","-p",param,"--batch","--level","1","--risk","1","--random-agent"]
    timeout = 40
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        output = (res.stdout or "") + (res.stderr or "")
    except FileNotFoundError:
        return []
    except subprocess.TimeoutExpired as e:
        snippet = ((e.stdout or "") + (e.stderr or ""))[-800:]
        if not snippet:
            snippet = f"sqlmap timed out after {timeout}s"

        return [{
            "target": url,
            "vector": {"protocol":"http","location":"query","param":param},
            "payload": "sqlmap-auto",
            "tool": "sqlmap",
            "evidence": {"error":"timeout"},
            "severity": "info",
            "url": url
        }]
    
    hits = any(re.search(pat, output, re.I) for pat in SQLI_PATTERNS)
    
    if hits:
        return [{
            "target": url,
            "vector": {"protocol":"http","location":"query","param":param},
            "payload": "sqlmap-auto",
            "tool": "sqlmap",
            "evidence": {"output": output[-800:]},
            "severity": "high",
            "url": url
        }]
    return []
