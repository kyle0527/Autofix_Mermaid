from __future__ import annotations
from pathlib import Path
import json, time
from typing import Optional
from op_dist.queue import FSQueue
from op_core.pipeline import run_pipeline
def run_agent(workdir: Path, cfg_path: Path, max_loops: int|None=None, sleep_sec: float=1.0, max_concurrency: int|None=None):
    q = FSQueue(workdir/"queue"); runs_dir = workdir/"runs"; runs_dir.mkdir(parents=True, exist_ok=True)
    loops = 0
    while True:
        item = q.dequeue()
        if not item:
            time.sleep(sleep_sec)
        else:
            tid, path = item
            job = json.loads(path.read_text(encoding="utf-8"))
            domain = job.get("domain"); job_cfg = Path(job.get("cfg", str(cfg_path)))
            out = run_pipeline(domain, job_cfg, runs_dir/tid, max_concurrency=max_concurrency)
            q.complete(tid, {"ok": True, "out": out, "domain": domain})
        loops += 1
        if max_loops and loops >= max_loops:
            break
