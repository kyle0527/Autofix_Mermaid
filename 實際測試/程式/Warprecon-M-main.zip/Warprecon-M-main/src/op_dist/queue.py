from __future__ import annotations
from pathlib import Path
import json, time, uuid, shutil, fcntl
from typing import Optional, Dict, List, Tuple
from contextlib import contextmanager
class FSQueue:
    def __init__(self, root: Path):
        self.root = root
        self.pending = self.root/"pending"
        self.processing = self.root/"processing"
        self.done = self.root/"done"
        self._lockfile = self.root / ".lock"
        for d in [self.pending, self.processing, self.done]:
            d.mkdir(parents=True, exist_ok=True)
        self._lockfile.touch(exist_ok=True)

    @contextmanager
    def _locked(self):
        with self._lockfile.open("r+") as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)
    def enqueue(self, domain: str, cfg: str) -> str:
        tid = f"{int(time.time())}-{uuid.uuid4().hex[:8]}"
        with self._locked():
            (self.pending / f"{tid}.json").write_text(
                json.dumps({"domain": domain, "cfg": cfg}, ensure_ascii=False), encoding="utf-8"
            )
        return tid
    def _list(self, d: Path) -> List[Path]:
        return sorted([p for p in d.glob("*.json")])
    def dequeue(self) -> Optional[Tuple[str, Path]]:
        with self._locked():
            for p in self._list(self.pending):
                dest = self.processing / p.name
                try:
                    shutil.move(str(p), str(dest))
                    return (p.stem, dest)
                except Exception:
                    continue
        return None
    def complete(self, tid: str, meta: Dict):
        with self._locked():
            (self.done / f"{tid}.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
            proc = self.processing / f"{tid}.json"
            if proc.exists():
                proc.unlink(missing_ok=True)
    def status(self) -> Dict[str,int]:
        return {"pending": len(self._list(self.pending)), "processing": len(self._list(self.processing)), "done": len(self._list(self.done))}
