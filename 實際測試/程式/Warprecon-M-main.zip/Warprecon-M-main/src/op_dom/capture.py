from __future__ import annotations
import asyncio, json, re, os
from typing import Dict, List, Any
from urllib.parse import urlparse, urljoin

def _same_host(u: str, host: str) -> bool:
    try:
        return urlparse(u).netloc.split(':')[0].lower() == host.lower()
    except Exception:
        return False

async def crawl_and_capture(domain: str, max_pages: int = None, max_requests: int = None) -> Dict[str, Any]:
    out = {"requests": [], "endpoints": []}
    try:
        from playwright.async_api import async_playwright  # type: ignore
    except Exception:
        return out
    # env overrides
    if max_pages is None:
        try: max_pages = int(os.environ.get("OP_DOM_MAX_PAGES","5"))
        except Exception: max_pages = 5
    if max_requests is None:
        try: max_requests = int(os.environ.get("OP_DOM_MAX_REQ","200"))
        except Exception: max_requests = 200

    start = f"https://{domain}"
    host = domain.split(":")[0].lower()
    seen_pages = set()
    reqs: List[Dict[str, Any]] = []
    eps: List[str] = []

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context()
        page = await ctx.new_page()

        def on_request(request):
            try:
                u = request.url
                if len(reqs) >= max_requests: return
                if _same_host(u, host):
                    entry = {
                        "method": request.method,
                        "url": u,
                        "headers": request.headers,
                    }
                    try:
                        post = request.post_data
                        if post: entry["body"] = post
                    except Exception:
                        pass
                    reqs.append(entry)
                    if any(k in u.lower() for k in ["/api/", "/graphql", "/socket", "/ws"]):
                        eps.append(u)
            except Exception:
                pass

        page.on("request", on_request)

        try:
            await page.goto(start, wait_until="domcontentloaded", timeout=20000)
            seen_pages.add(start)
        except Exception:
            await browser.close()
            return out

        try:
            hrefs = await page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
            hrefs = [h for h in hrefs if isinstance(h, str) and _same_host(h, host)]
        except Exception:
            hrefs = []
        for h in hrefs[:max_pages-1]:
            try:
                if h in seen_pages: continue
                await page.goto(h, wait_until="domcontentloaded", timeout=15000)
                seen_pages.add(h)
            except Exception:
                continue

        await browser.close()

    out["requests"] = reqs
    out["endpoints"] = list(dict.fromkeys(eps))
    return out
