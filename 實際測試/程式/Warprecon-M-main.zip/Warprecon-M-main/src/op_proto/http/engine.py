from __future__ import annotations
import httpx, urllib.parse, time, asyncio, random
from typing import Dict
from op_forms.simple import extract_csrf_tokens

RETRY_STATUS = {429, 502, 503, 504}

def _compose_url(base: str, cand: Dict) -> str:
    u = urllib.parse.urlparse(base)
    loc = cand.get("location")
    if loc == "query":
        q = f"{u.query}&{cand.get('param','q')}={urllib.parse.quote_plus(cand['payload'])}" if u.query else f"{cand.get('param','q')}={urllib.parse.quote_plus(cand['payload'])}"
        return urllib.parse.urlunparse((u.scheme,u.netloc,u.path,u.params,q,u.fragment))
    if loc == "path":
        path = u.path.rstrip('/') + '/' + urllib.parse.quote(cand['payload']) + '/'
        return urllib.parse.urlunparse((u.scheme,u.netloc,path,u.params,u.query,u.fragment))
    return base

def _allow_by_ctype(mode: str, ctype: str, txt_hint: str) -> bool:
    ctype = (ctype or '').lower()
    if mode == 'xss':
        return ('text/html' in ctype) or ('xhtml' in ctype) or ('<html' in (txt_hint or '').lower())
    if mode == 'sqli':
        return ('text/html' in ctype) or ('json' in ctype) or (not ctype)
    return True

async def http_probe(target: str, cand: Dict, mint, client: httpx.AsyncClient, retries: int = 1) -> Dict|None:
    headers={}; cookies={}; data=None; json=None
    loc = cand.get("location")
    url = _compose_url(target, cand)

    # form context handling
    form_ctx = cand.get("form_ctx") if isinstance(cand.get("form_ctx"), dict) else None
    if loc == "header" and cand.get("param"): headers[cand["param"]] = cand["payload"]
    elif loc == "cookie" and cand.get("param"): cookies[cand["param"]] = cand["payload"]
    elif loc == "form":
        pname = cand.get("param","q")
        data = {}
        if form_ctx and isinstance(form_ctx.get("inputs"), list):
            # keep original values, override target field with payload, include CSRF tokens
            for inp in form_ctx["inputs"]:
                n = inp.get("name"); v = inp.get("value","")
                if not n: continue
                data[n] = v
            data[pname] = cand["payload"]
            data.update(extract_csrf_tokens(form_ctx["inputs"]))
        else:
            data = {pname: cand["payload"]}
        # if action differs from base, send to action url
        if form_ctx and form_ctx.get("action"):
            url = form_ctx["action"]
    elif loc == "json":
        json = {cand.get("param","q"): cand["payload"]}

    # baseline request for gating
    r0 = None
    try:
        r0 = await client.get(target, timeout=8.0)
        base_len = len(r0.text or "")
        ctype0 = getattr(r0, "headers", {}).get("content-type", "")
    except Exception:
        base_len = 0
        ctype0 = ""
    if not _allow_by_ctype(cand.get("mode",""), ctype0, getattr(r0, "text", "")):
        return None

    delay = 0.4
    penal = None
    for attempt in range(max(1, 1+int(retries))):
        if attempt>0:
            await asyncio.sleep(delay + random.uniform(0, 0.2))
            delay = min(2.5, delay * 1.8)

        try:
            t1 = time.perf_counter()
            if data is not None or json is not None:
                r = await client.post(url, headers=headers, cookies=cookies, data=data, json=json, timeout=12.0)
            else:
                r = await client.get(url, headers=headers, cookies=cookies, timeout=12.0)
            status = getattr(r, "status_code", 200)
            if status in RETRY_STATUS:
                penal = {"_penalize": delay}
                if attempt < retries:
                    continue
            dt = time.perf_counter() - t1
            txt = (r.text or "").lower()
            hit=False; ev={"time_delta": round(dt,3), "transform": cand.get("transform")}
            if cand.get("mode")=="xss" and ("<script>" in txt or "onload=" in txt):
                hit=True; ev["snippet"]=r.text[:200]; ev["len_delta"]=len(r.text)-base_len
            if cand.get("mode")=="sqli" and any(k in txt for k in ["syntax","sql","mysql","postgres","sqlite"]):
                hit=True; ev["snippet"]=r.text[:200]; ev["len_delta"]=len(r.text)-base_len
            if cand.get("mode")=="ssrf":
                tok = mint.mint(); ev["oob_token"]=tok; hit=True
            if hit:
                return {"target":target,"vector":{"protocol":"http","location":loc,"param":cand.get("param")},
                        "payload":cand.get("payload"),"tool":"warprecon-m-http","evidence":ev,
                        "severity":"high" if cand.get("mode")!="xss" else "medium","url":str(getattr(r,'url',url))}
            break
        except Exception:
            penal = {"_penalize": delay}
            if attempt < retries:
                continue
            break
    return penal
