from __future__ import annotations

"""
op_proto.grpc.enumerate
- Enumerate gRPC services/methods using reflection (if available).
- Emit schema/{host}_{port}.json and findings.grpc.json
"""
import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

try:
    import grpc
    from google.protobuf import descriptor_pb2
    from grpc_reflection.v1alpha import reflection as grpc_reflection
except Exception:  # pragma: no cover
    grpc = None  # type: ignore

from .utils import plaintext_on_tls_port, tls_min_version


def _split_target(target: str) -> Tuple[str, int]:
    m = re.match(r"^\[?([A-Za-z0-9\.\-:_]+)\]?:([0-9]{1,5})$", target)
    if m:
        host, port = m.group(1), int(m.group(2))
        return host, port
    if ":" in target:
        host, p = target.rsplit(":", 1)
        return host, int(p)
    return target, 443


def _enumerate_services(
    target: str, use_tls: bool = True, timeout: float = 5.0
) -> Dict[str, Any]:
    if grpc is None:
        return {"error": "grpcio/grpcio-reflection not installed"}
    options = (("grpc.ssl_target_name_override", target.split(":")[0]),)
    channel = None
    try:
        if use_tls:
            channel = grpc.secure_channel(
                target, grpc.ssl_channel_credentials(), options=options
            )
        else:
            channel = grpc.insecure_channel(target)
        grpc.channel_ready_future(channel).result(timeout=timeout)
        stub = grpc_reflection.ReflectionStub(channel)  # type: ignore
        services = stub.ListServices(
            grpc_reflection.ServerReflectionRequest(list_services="")
        )  # type: ignore
        out: Dict[str, Any] = {"services": []}
        names = []
        for resp in services:
            if resp.list_services_response:
                for s in resp.list_services_response.service:
                    if s.name.startswith("grpc.reflection."):  # skip
                        continue
                    names.append(s.name)
        for sname in names:
            # Fetch file descriptor for service
            req = grpc_reflection.ServerReflectionRequest(
                file_containing_symbol=sname
            )  # type: ignore
            for r in stub.ServerReflectionInfo(iter([req])):
                if r.file_descriptor_response:
                    for b in r.file_descriptor_response.file_descriptor_proto:
                        fd = descriptor_pb2.FileDescriptorProto()
                        fd.ParseFromString(b)
                        out["services"].append(
                            {"name": sname, "file": fd.name},
                        )
        return out
    except Exception as e:
        return {"error": str(e)}
    finally:
        try:
            if channel:
                channel.close()
        except Exception:
            pass


def enumerate_methods(
    target: str,
    tls: bool = True,
    timeout: float = 5.0,
) -> List[str]:
    """Return a list of service names exposed by *target*.

    This stub leverages :func:`_enumerate_services` and never raises.  The
    returned list may be empty if reflection is not available or dependencies
    are missing.
    """
    try:
        schema = _enumerate_services(target, use_tls=tls, timeout=timeout)
        return [s.get("name", "") for s in schema.get("services", [])]
    except Exception:
        return []


def main() -> None:
    ap = argparse.ArgumentParser(description="gRPC reflection enumerator")
    ap.add_argument("--target", required=True, help="host:port")
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()
    host, port = _split_target(args.target)
    workdir = Path(args.workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    schema_dir = workdir / "schema"
    schema_dir.mkdir(parents=True, exist_ok=True)

    findings: List[Dict[str, Any]] = []
    schema = _enumerate_services(f"{host}:{port}", use_tls=True)
    schema_path = schema_dir / f"grpc_{host.replace(':', '_')}_{port}.json"
    schema_path.write_text(
        json.dumps(schema, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if plaintext_on_tls_port(host, port):
        findings.append(
            {
                "type": "grpc.plaintext_on_tls_port",
                "host": host,
                "port": port,
                "severity": "medium",
                "evidence": "TCP accept on 443 without TLS handshake",
            }
        )
    # TLSv1 allowed?
    try:
        import ssl

        if tls_min_version(host, port, ssl.TLSVersion.TLSv1):
            findings.append(
                {
                    "type": "tls.v1_enabled",
                    "host": host,
                    "port": port,
                    "severity": "low",
                    "evidence": "TLSv1 handshake succeeded",
                }
            )
    except Exception:
        pass

    (workdir / "findings.grpc.json").write_text(
        json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {"schema": str(schema_path), "findings": len(findings)},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
