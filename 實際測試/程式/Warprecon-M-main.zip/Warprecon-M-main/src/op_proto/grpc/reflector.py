from __future__ import annotations

from typing import Any, Dict


def call_reflect_json(
    target: str,
    method: str,
    message: Dict[str, Any],
    tls: bool = False,
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """Return a placeholder reflection response.

    The real implementation would issue a gRPC reflection request.  This stub
    simply returns an empty dictionary so tests can run without the heavy gRPC
    dependencies.
    """
    return {}
