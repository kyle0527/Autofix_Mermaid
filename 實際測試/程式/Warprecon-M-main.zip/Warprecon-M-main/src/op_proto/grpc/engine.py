"""Minimal gRPC probing utilities used by Warprecon-M."""

from __future__ import annotations

import argparse
import json

from pathlib import Path
from typing import Any, Dict, List, Optional

from .enumerate import _enumerate_services, _split_target
from .utils import plaintext_on_tls_port, tls_min_version



async def grpc_probe(target: str, cand: Dict, mint) -> Optional[List[Dict]]:
    """Async wrapper around :func:`grpc_probe_sync` for pipeline compatibility."""
    return grpc_probe_sync(target)


def grpc_probe_sync(target: str) -> List[Dict]:
    """Minimal synchronous gRPC probe used by :func:`grpc_probe`.

    Returns a list of ``informational`` findings when plaintext transport or
    obsolete TLS versions are detected.  The function never raises and
    otherwise returns an empty list.
    """
    try:
        host, port = _split_target(
            target if ":" in target else f"{target}:443",
        )
        outs: List[Dict] = []
        if plaintext_on_tls_port(host, port):
            outs.append(
                {
                    "protocol": "grpc",
                    "type": "grpc.plaintext_on_tls_port",
                    "target": f"{host}:{port}",
                    "severity": "medium",
                    "evidence": "TCP accept on 443/plaintext",
                }
            )
        try:
            import ssl

            if tls_min_version(host, port, ssl.TLSVersion.TLSv1):
                outs.append(
                    {
                        "protocol": "grpc",
                        "type": "tls.v1_enabled",
                        "target": f"{host}:{port}",
                        "severity": "low",
                        "evidence": "TLSv1 handshake succeeded",
                    }
                )
        except Exception:
            pass
        return outs
    except Exception:
        return []


def probe_unary_unary(
    target: str,
    method: str,
    payload: bytes,
    *,
    tls: bool = False,
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """Best-effort unary-unary gRPC probe returning a placeholder result."""
    return {
        "target": target,
        "method": method,
        "sent": len(payload),
        "tls": tls,
        "timeout": timeout,
    }


def reflect_services(
    target: str, tls: bool = True, timeout: float = 5.0
) -> Dict[str, Any]:
    """Return gRPC reflection information for *target*.

    The real engine would perform a network call using gRPC reflection.  This
    lightweight stub reuses :func:`_enumerate_services` and never raises,
    allowing unit tests to exercise the API without depending on gRPC
    libraries or network availability.
    """
    try:
        return _enumerate_services(target, use_tls=tls, timeout=timeout)
    except Exception:
        return {}


def _cli() -> None:
    ap = argparse.ArgumentParser(description="gRPC minimal engine CLI")
    ap.add_argument("--target", required=True)
    ap.add_argument("--workdir", required=True)
    args = ap.parse_args()
    host, port = _split_target(args.target)
    workdir = Path(args.workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    out = {
        "schema": _enumerate_services(f"{host}:{port}", use_tls=True),
        "plaintext_on_tls": plaintext_on_tls_port(host, port),
    }
    (workdir / "findings.grpc.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {"ok": True, "findings": str(workdir / "findings.grpc.json")},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    _cli()
