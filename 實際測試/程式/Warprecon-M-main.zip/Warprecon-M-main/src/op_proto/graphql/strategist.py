from __future__ import annotations
import re
from typing import Dict, List

def parse_hints(text: str) -> Dict[str, List[str]]:
    out = {"types": [], "fields": [], "expected": []}
    for m in re.findall(r'on type\s+"([A-Za-z_][A-Za-z0-9_]*)"', text):
        out["types"].append(m)
    for m in re.findall(r'Cannot query field\s+"([A-Za-z_][A-Za-z0-9_]*)"', text):
        out["fields"].append(m)
    for m in re.findall(r'Expected type\s+([A-Za-z_][A-Za-z0-9_!]*)', text):
        out["expected"].append(m)
    # unique keep order
    for k in out:
        seen=set(); uniq=[]
        for v in out[k]:
            if v not in seen: seen.add(v); uniq.append(v)
        out[k]=uniq
    return out

def suggest_next(prev_query: str, hints: Dict[str, List[str]]) -> str|None:
    if hints.get("types"):
        # Craft a minimal follow-up query using the hinted type without ellipsis
        return "query q{__typename}"
    # fallback alias fan-out
    return "query q{a:__typename,b:__typename,c:__typename}"

def plan_queries(seed: str, errors_texts: List[str], max_steps: int = 3) -> List[str]:
    """
    Given a seed query and a list of error texts, produce up to max_steps follow-up queries.
    """
    plan: List[str] = []
    last = seed
    for i in range(max_steps):
        hints = parse_hints(" ".join(x for x in errors_texts if isinstance(x, str)))
        nxt = suggest_next(last, hints)
        if not nxt or nxt == last:
            break
        plan.append(nxt)
        last = nxt
    return plan
