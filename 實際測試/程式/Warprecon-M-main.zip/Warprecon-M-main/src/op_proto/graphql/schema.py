from __future__ import annotations
import httpx

_INTROSPECT = {
  "query": "query Introspect{ __schema{ queryType{ name } mutationType{ name } types{ name kind } } }",
  "variables": None
}

async def try_introspect(url: str, timeout: float = 8.0) -> dict|None:
    try:
        async with httpx.AsyncClient(timeout=timeout) as cli:
            r = await cli.post(url, json=_INTROSPECT)
            if r.status_code == 200 and r.headers.get("content-type","").lower().startswith("application/json"):
                j = r.json()
                if "data" in j or "errors" in j:
                    return j
    except Exception:
        return None
    return None
