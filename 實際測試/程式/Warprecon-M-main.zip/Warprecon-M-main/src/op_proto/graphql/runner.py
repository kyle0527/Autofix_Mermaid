from __future__ import annotations

from typing import Any, Dict, Iterable, List

try:  # pragma: no cover - optional dependency
    import httpx
except Exception:  # pragma: no cover
    httpx = None  # type: ignore


def generate_candidates(schema: Dict[str, Any], budget: int = 1) -> List[str]:
    """Generate basic GraphQL queries from an introspection *schema*.

    The helper understands a tiny subset of the GraphQL introspection schema:
    if ``schema`` contains a top-level ``fields`` list, queries will be
    generated for each field up to ``budget``.  Otherwise a trivial ``__typename``
    probe is returned.
    """
    fields = []
    for f in schema.get("fields", []) or []:
        name = f.get("name")
        if name:
            fields.append(name)
    queries: List[str] = []
    if fields:
        for name in fields[: budget]:
            queries.append(f"query {{ {name} {{ __typename }} }}")
    while len(queries) < max(1, budget):
        queries.append("query { __typename }")
    return queries


def probe_set(
    url: str, queries: Iterable[str], timeout: float = 1.0
) -> List[Dict[str, Any]]:
    """Send *queries* to *url* and collect results.

    The function attempts to POST the GraphQL queries using :mod:`httpx` if it
    is available; failures or missing dependencies are captured in the returned
    list so callers can proceed without raising exceptions.
    """
    outs: List[Dict[str, Any]] = []
    for q in queries:
        if httpx is None:
            outs.append({"query": q, "error": "httpx not installed"})
            continue
        try:
            r = httpx.post(url, json={"query": q}, timeout=timeout)
            try:
                outs.append(r.json())
            except Exception:
                outs.append({"query": q, "status": r.status_code})
        except Exception as e:  # pragma: no cover - network dependent
            outs.append({"query": q, "error": str(e)})
    return outs
