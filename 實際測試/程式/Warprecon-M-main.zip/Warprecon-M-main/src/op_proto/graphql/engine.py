from __future__ import annotations
import httpx, asyncio, random
from typing import Dict, List
from .strategist import parse_hints, plan_queries

RETRY_STATUS = {429, 502, 503, 504}

async def _post_json(url: str, payload: Dict) -> httpx.Response:
    async with httpx.AsyncClient(timeout=12.0) as client:
        return await client.post(url, json=payload)

async def graphql_probe(target: str, cand: Dict, mint, retries: int = 1, strategist_steps: int = 3) -> Dict|None:
    seed = cand.get("payload","query{__typename}")
    variables = cand.get("variables")
    delay = 0.4
    penal = None
    for attempt in range(max(1, 1+int(retries))):
        if attempt>0:
            await asyncio.sleep(delay + random.uniform(0, 0.2))
            delay = min(2.5, delay * 1.8)
        try:
            r = await _post_json(target, {"query": seed, "variables": variables})
            status = getattr(r, "status_code", 200)
            if status in RETRY_STATUS:
                penal = {"_penalize": delay}
                if attempt < retries:
                    continue
            txt = r.text or ""
            ctype = r.headers.get("content-type","") or ""
            j = {}
            if ctype.lower().startswith("application/json"):
                try: j = r.json()
                except Exception: j = {}
            # Success path
            if status==200 and "__typename" in txt:
                return {"target":target,"vector":{"protocol":"graphql","location":"body","param":None},
                        "payload":seed,"tool":"warprecon-m-graphql",
                        "evidence":{"snippet":txt[:240]},
                        "severity":"medium","url":target}
            # Strategist multi-step
            errors_texts: List[str] = []
            if isinstance(j, dict) and "errors" in j:
                for e in j.get("errors") or []:
                    m = e.get("message") or ""
                    if m: errors_texts.append(m)
            if errors_texts and strategist_steps>0:
                plan = plan_queries(seed, errors_texts, max_steps=max(1, int(strategist_steps)))
                seen = {seed}
                for q in plan:
                    if q in seen: continue
                    seen.add(q)
                    r2 = await _post_json(target, {"query": q})
                    t2 = r2.text or ""
                    if "__typename" in t2 or r2.status_code==200:
                        return {"target":target,"vector":{"protocol":"graphql","location":"body","param":None},
                                "payload":q,"tool":"warprecon-m-graphql",
                                "evidence":{"snippet":t2[:240], "hints": parse_hints(" ".join(errors_texts))},
                                "severity":"medium","url":target}
            break
        except Exception:
            penal = {"_penalize": delay}
            if attempt < retries: continue
            break
    return penal
