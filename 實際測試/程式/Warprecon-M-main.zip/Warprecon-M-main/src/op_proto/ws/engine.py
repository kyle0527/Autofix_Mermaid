from __future__ import annotations
import asyncio, websockets, random
from typing import Dict

async def ws_probe(target: str, cand: Dict, mint, retries: int = 1) -> Dict|None:
    delay = 0.4
    penal = None
    for attempt in range(max(1, 1+int(retries))):
        if attempt>0:
            await asyncio.sleep(delay + random.uniform(0, 0.2))
            delay = min(2.5, delay * 1.8)
        try:
            async with websockets.connect(target, ping_interval=20) as ws:
                await ws.send("hello")
                try: _ = await asyncio.wait_for(ws.recv(), timeout=3.0)
                except Exception: pass
                await ws.send(cand.get("payload",'["ping"]'))
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=5.0)
                    return {"target":target,"vector":{"protocol":"ws","location":"message","param":None},
                            "payload":cand.get("payload"),"tool":"warprecon-m-ws",
                            "evidence":{"snippet":str(msg)[:200]},
                            "severity":"medium","url":target}
                except asyncio.TimeoutError:
                    penal = {"_penalize": delay}
                    if attempt < retries: continue
                    break
        except Exception:
            penal = {"_penalize": delay}
            if attempt < retries: continue
            break
    return penal
