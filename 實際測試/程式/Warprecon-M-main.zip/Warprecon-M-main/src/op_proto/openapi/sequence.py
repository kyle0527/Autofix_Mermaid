from __future__ import annotations
"""
op_proto.openapi.sequence
Generate minimal POST→GET sequence PoCs from OpenAPI v3 spec.
- Writes under {workdir}/sequence/: curl scripts and requests.py
"""
import argparse, json, os
from pathlib import Path
from typing import Dict, Any, List, Tuple
import re

try:
    import httpx  # only used when --run is provided
except Exception:
    httpx = None  # type: ignore

from .loader import load_spec, list_operations

def _find_sequences(spec: Dict[str, Any]) -> List[Tuple[str, str]]:
    # naive: pair POST /resource with GET /resource/{id}
    ops = list_operations(spec)
    posts = [p for p, v in ops.items() if "post" in v]
    gets = [p for p, v in ops.items() if "get" in v]
    pairs: List[Tuple[str,str]] = []
    for p in posts:
        base = p.rstrip("/")
        for g in gets:
            if g.startswith(base) and re.search(r"\{[^}]*id[^}]*\}", g):
                pairs.append((p, g))
    return pairs

def _emit_curl(base: str, post: str, get: str) -> str:
    post_url = base.rstrip("/") + post
    get_url = base.rstrip("/") + get
    body = '{"name":"warprecon-m","id":"{{id}}"}'
    curl_post = f'curl -sS -X POST "{post_url}" -H "Content-Type: application/json" -d \'{body}\''
    curl_get = f'curl -sS "{get_url}"'
    sh = f"""#!/usr/bin/env bash
set -euo pipefail
command -v jq >/dev/null 2>&1 || { echo 'jq is required for this PoC'; exit 1; }
ID="$({curl_post} | jq -r '.id // .data.id // .result.id // empty')"
if [[ -z "$ID" ]]; then echo "No id in POST response"; exit 2; fi
URL="{get_url.replace('{id}', '$ID')}"
echo "[+] GET $URL"
{curl_get.replace('{id}', '$ID')}
"""
    return sh

def main() -> None:
    ap = argparse.ArgumentParser(description="Generate minimal POST→GET sequence from OpenAPI spec")
    ap.add_argument("--spec", required=True)
    ap.add_argument("--base", required=True, help="Base URL, e.g., https://api.example.com")
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--emit-requests", action="store_true", help="Also emit a Python requests.py PoC")
    args = ap.parse_args()

    spec = load_spec(Path(args.spec))
    pairs = _find_sequences(spec)

    outdir = Path(args.workdir) / "sequence"
    outdir.mkdir(parents=True, exist_ok=True)

    artifacts = []
    for i, (post, get) in enumerate(pairs[:10], start=1):
        sh = _emit_curl(args.base, post, get)
        p = outdir / f"seq_{i:02d}.sh"
        p.write_text(sh, encoding="utf-8"); os.chmod(p, 0o755)
        artifacts.append(str(p))

    if args.emit_requests:
        py = outdir / "requests.py"
        py.write_text(
            'import os, requests\n'
            'base = os.environ.get("BASE", "%s")\n'
            'post_path = "%s"\nget_path = "%s"\n'
            'r = requests.post(base.rstrip("/") + post_path, json={"name":"warprecon-m"})\n'
            'rid = (r.json().get("id") or r.json().get("data",{}).get("id"))\n'
            'assert rid, "No id in POST response"\n'
            'u = (base.rstrip("/") + get_path).replace("{id}", str(rid))\n'
            'print("[+] GET", u)\n'
            'print(requests.get(u).text)\n' % (args.base, pairs[0][0] if pairs else "", pairs[0][1] if pairs else ""),
            encoding="utf-8"
        )

    (outdir / "manifest.json").write_text(json.dumps({"pairs": pairs, "artifacts": artifacts}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"pairs": len(pairs), "outdir": str(outdir)}, ensure_ascii=False))

if __name__ == "__main__":
    main()
