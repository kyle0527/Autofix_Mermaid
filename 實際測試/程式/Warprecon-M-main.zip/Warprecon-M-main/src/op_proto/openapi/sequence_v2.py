from __future__ import annotations
"""
op_proto.openapi.sequence_v2 — POST→GET using binder-derived payloads
"""
import argparse, json, os, re
from pathlib import Path
from typing import Dict, Any, List, Tuple
try:
    import httpx
except Exception:
    httpx = None  # type: ignore
from .loader import load_spec, list_operations
from .binder import _stub_for_schema

def _pairs(spec: Dict[str, Any]) -> List[Tuple[str,str,Dict[str,Any]]]:
    paths = list_operations(spec)
    pairs = []
    for p, conf in paths.items():
        if "post" in conf:
            req = conf["post"].get("requestBody",{}).get("content",{}).get("application/json",{}).get("schema",{})
            body = _stub_for_schema(req or {"type":"object"})
            for g, gconf in paths.items():
                if "get" in gconf and g.startswith(p.rstrip("/")) and re.search(r"\{[^}]*id[^}]*\}", g):
                    pairs.append((p,g,body))
    return pairs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--base", required=True)
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--run", action="store_true")
    args = ap.parse_args()

    spec = load_spec(Path(args.spec))
    pairs = _pairs(spec)
    outdir = Path(args.workdir)/"sequence_v2"; outdir.mkdir(parents=True, exist_ok=True)
    manifest = []
    for i,(post,get,body) in enumerate(pairs[:10], start=1):
        manifest.append({"post":post,"get":get,"body":body})
        if args.run and httpx:
            with httpx.Client(timeout=10, verify=False) as cx:
                r = cx.post(args.base.rstrip("/")+post, json=body)
                jd = {}
                try: jd = r.json()
                except Exception: pass
                rid = jd.get("id") or jd.get("data",{}).get("id")
                if rid:
                    rg = cx.get((args.base.rstrip("/")+get).replace("{id}", str(rid)))
        # emit artifacts
        Path(outdir/f"pair_{i:02d}.json").write_text(json.dumps({"post":post,"get":get,"body":body}, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(outdir/"manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"pairs":len(manifest), "outdir": str(outdir)}, ensure_ascii=False))

if __name__=="__main__":
    main()
