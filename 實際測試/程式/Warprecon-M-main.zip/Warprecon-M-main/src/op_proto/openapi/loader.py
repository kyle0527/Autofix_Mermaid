from __future__ import annotations
import json, yaml
from pathlib import Path
from typing import Dict, Any

def load_spec(path: Path) -> Dict[str, Any]:
    s = path.read_text(encoding="utf-8")
    try:
        return json.loads(s)
    except Exception:
        return yaml.safe_load(s)

def list_operations(spec: Dict[str, Any]) -> Dict[str, Any]:
    return spec.get("paths", {})
