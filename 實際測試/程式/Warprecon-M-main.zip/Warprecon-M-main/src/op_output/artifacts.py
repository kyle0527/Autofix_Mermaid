from __future__ import annotations
from pathlib import Path
from typing import Optional, Tuple


import logging


logger = logging.getLogger(__name__)



def try_capture(url: str, outdir: Path) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception as e:
        logger.warning("Playwright import failed: %s", e)
        return (None, None, str(e))
    outdir.mkdir(parents=True, exist_ok=True)
    har = outdir / "capture.har"
    png = outdir / "screenshot.png"
    error: Optional[str] = None
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(record_har_path=str(har))
        page = context.new_page()
        try:
            page.goto(url, timeout=15000)
            page.screenshot(path=str(png), full_page=False)
        except Exception as e:

            logger.warning("page.goto failed: %s", e)
            error = str(e)
        context.close()
        browser.close()
    if error:
        return (None, None, error)
    return (
        str(har) if har.exists() else None,
        str(png) if png.exists() else None,
        None,
    )

            logger.warning("Capture failed for %s: %s", url, e)
            context.close(); browser.close()
            return (None, None, str(e))
        context.close(); browser.close()
    return (str(har) if har.exists() else None, str(png) if png.exists() else None, None)

