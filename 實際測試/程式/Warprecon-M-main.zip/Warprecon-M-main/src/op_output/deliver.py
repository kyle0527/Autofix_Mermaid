from __future__ import annotations
from pathlib import Path
import zipfile
INCLUDE_PATTERNS = [
  "ranked.json", "out.sarif", "report.html",
  "poc/poc_*.ps1", "poc/poc_*.py",
  "artifacts/**/screenshot.png", "artifacts/**/capture.har",
  "targets.txt", "history.jsonl",
  "discovery/**", "schema/**", "oob/**"
]
def _glob_all(root: Path):
    for pat in INCLUDE_PATTERNS:
        for p in root.glob(pat):
            if p.is_file():
                yield p
def make_deliverable_zip(workdir: Path, out_zip: Path|None=None) -> str:
    out_zip = out_zip or (workdir / "deliverable.zip")
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in _glob_all(workdir):
            z.write(p, p.relative_to(workdir).as_posix())
    return str(out_zip)
