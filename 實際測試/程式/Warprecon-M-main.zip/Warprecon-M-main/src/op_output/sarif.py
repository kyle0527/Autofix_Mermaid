from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable


def to_sarif(items: Iterable[Dict]) -> str:
    results = [
        {
            "ruleId": x.get("rule_id", "OPR"),
            "level": "error"
            if (x.get("severity") or "medium") in {"high", "critical"}
            else "warning",
            "message": {"text": (x.get("evidence", {}) or {}).get("snippet", "finding")},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": x.get("url", "")}
                    }
                }
            ],
            "properties": {
                "payload": x.get("payload"),
                "protocol": (x.get("vector", {}).get("protocol")),
            },
        }
        for x in items
    ]
    return json.dumps(
        {
            "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": "warprecon-m"}}, "results": results}],
        },
        ensure_ascii=False,
        indent=2,
    )


def export_sarif(workdir: Path, items: Iterable[Dict]) -> str:
    """Write ranked findings to a SARIF file and return its path."""
    out = Path(workdir) / "out.sarif"
    out.write_text(to_sarif(list(items)), encoding="utf-8")
    return str(out)

