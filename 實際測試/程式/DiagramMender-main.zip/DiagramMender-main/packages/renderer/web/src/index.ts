// Web renderer wrapper placeholder in TypeScript
export async function render(code: string, outEl: HTMLElement, mermaid: any): Promise<void> {
  const id = 'm_' + Date.now().toString(36);
  const { svg } = await mermaid.render(id, code);
  outEl.innerHTML = svg;
}
