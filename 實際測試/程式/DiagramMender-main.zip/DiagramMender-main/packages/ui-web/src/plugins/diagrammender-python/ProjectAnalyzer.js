// ProjectAnalyzer.js — lightweight, client-side Python project analyzer (ESM)
/**
 * Given a list of File objects (from <input type="file" webkitdirectory multiple>),
 * build two Mermaid diagrams:
 * 1) 系統架構圖：module import dependency graph (flowchart LR)
 * 2) 運作流程圖：heuristic flow from entrypoints (if __name__ == "__main__")
 *
 * Note: This is a best-effort static scan using regex and relative paths; it is
 * not a full Python parser, but adequate for overview diagrams.
 */

/** @typedef {{ arch: string, flow: string, stats: {modules: number, edges: number, entrypoints: number} }} ProjectDiagrams */

export async function analyzePythonProject(files) {
  /** @type {Map<string, string>} */
  const texts = new Map();
  /** @type {Set<string>} */
  const modules = new Set();

  // Read .py files only
  const pyFiles = Array.from(files).filter(f => f.name.endsWith('.py'));
  for (const f of pyFiles) {
    const rel = (f.webkitRelativePath || f.name).replaceAll('\\', '/');
    const mod = rel.replace(/\.py$/i, '').replace(/\//g, '.');
    const txt = await f.text();
    texts.set(mod, txt);
    modules.add(mod);
  }

  // Build import edges
  /** @type {Array<[string, string]>} */
  const edges = [];
  for (const [mod, txt] of texts) {
    const lines = txt.split(/\r?\n/);
    for (const line of lines) {
      const m1 = line.match(/^\s*import\s+([a-zA-Z0-9_.,\s]+)/);
      if (m1) {
        const parts = m1[1].split(',').map(s => s.trim()).filter(Boolean);
        for (let p of parts) {
          p = p.split(/\s+as\s+/)[0];
          const target = p.replace(/\s+/g, '');
          // Add edge to internal module if exists by prefix match
          const internal = pickInternalModule(target, modules);
          if (internal) edges.push([mod, internal]);
        }
      }
      const m2 = line.match(/^\s*from\s+([a-zA-Z0-9_.]+)\s+import\s+/);
      if (m2) {
        const target = m2[1];
        const internal = pickInternalModule(target, modules);
        if (internal) edges.push([mod, internal]);
      }
    }
  }

  // Architecture graph (flowchart LR)
  const nodeDecl = Array.from(modules).map(m => `${safe(m)}("${m.split('.').slice(-1)[0]}")`).join('\n  ');
  const edgeDecl = edges.map(([a, b]) => `${safe(a)} --> ${safe(b)}`).join('\n  ');
  const arch = [
    'flowchart LR',
    '  %% Modules',
    `  ${nodeDecl}`,
    '',
    '  %% Imports',
    `  ${edgeDecl}`
  ].join('\n');

  // Entry flow (heuristic)
  /** @type {Array<string>} */
  const flows = [];
  let entryCount = 0;
  for (const [mod, txt] of texts) {
    const mainIdx = txt.indexOf(`if __name__ == "__main__"`);
    if (mainIdx >= 0) {
      entryCount++;
      const calls = Array.from(txt.slice(mainIdx).matchAll(/([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/g))
        .map(m => m[1])
        .filter((fn, i, arr) => arr.indexOf(fn) === i && fn !== 'print');
      const lines = [`subgraph ${mod}`, `  Start([Start])`];
      for (const c of calls) {
        const nid = `fn_${c}`;
        lines.push(`  ${nid}["${c}()"]`);
        lines.push(`  Start --> ${nid}`);
      }
      lines.push('end');
      flows.push(lines.join('\n'));
    }
  }
  const flow = [
    'flowchart TD',
    flows.length ? flows.join('\n\n') : '  Start([Start]) --> Nil[未偵測到 entrypoint（__main__）]'
  ].join('\n');

  return { arch, flow, stats: { modules: modules.size, edges: edges.length, entrypoints: entryCount } };
}

/** Normalize an id for Mermaid nodes */
function safe(name) {
  return name.replace(/[^a-zA-Z0-9_]/g, '_');
}

function pickInternalModule(target, modules) {
  // Prefer exact match, else longest prefix that exists
  if (modules.has(target)) return target;
  let best = null;
  for (const m of modules) {
    if (target === m || target.startsWith(m + '.')) {
      if (!best || m.length > best.length) best = m;
    }
  }
  return best;
}
