// AutoFix.js — minimal, safe normalizations for Mermaid source (ESM)
/**
 * Normalize Mermaid code for v10/v11:
 * - Trim BOM/leading spaces
 * - Ensure first line is a diagram keyword
 * - Upgrade legacy `graph` -> `flowchart` when applicable
 * - Remove trailing semicolons that break some blocks
 * - Normalize CRLF to LF
 */
export class AutoFix {
  /**
   * @param {string} input
   * @returns {{ code: string, notes: string[] }}
   */
  static run(input) {
    const notes = [];
    let code = input.replace(/^\uFEFF/, ''); // strip BOM
    code = code.replace(/\r\n?/g, '\n');

    // Remove trailing semicolons at end of lines that are safe to drop
    code = code.replace(/;\s*$/gm, '');

    // If the first non-empty token is "graph", treat it as flowchart (Mermaid still accepts graph)
    const first = code.trimStart().slice(0, 40);
    if (/^graph\b/.test(first)) {
      code = code.replace(/^graph\b/i, 'flowchart');
      notes.push('已將 legacy "graph" 轉為 "flowchart"');
    }

    // If not starting with a known diagram keyword, wrap as flowchart TD
    if (!/^(flowchart|sequenceDiagram|gantt|classDiagram|stateDiagram|erDiagram|journey|gitGraph|pie|timeline|mindmap)\b/m.test(code.trimStart())) {
      code = 'flowchart TD\n' + code;
      notes.push('未偵測到圖表宣告，已自動加入 `flowchart TD`');
    }

    return { code, notes };
  }
}
