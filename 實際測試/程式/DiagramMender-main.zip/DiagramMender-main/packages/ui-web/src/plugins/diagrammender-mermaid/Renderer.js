// Renderer.js — render helper (ESM)
/**
 * Render Mermaid to target element.
 * @param {string} code
 * @param {HTMLElement} outEl
 * @param {import('mermaid').Mermaid} mermaid
 * @returns {Promise<void>}
 */
export async function renderMermaid(code, outEl, mermaid) {
  outEl.classList.add('mermaid');
  outEl.setHTMLUnsafe?.(code); // for future APIs; ok if undefined
  try {
    const id = 'm_' + Date.now().toString(36) + Math.random().toString(36).slice(2);
    const { svg } = await mermaid.render(id, code);
    outEl.innerHTML = svg;
  } catch (err) {
    outEl.innerHTML = '';
    throw err;
  }
}
