/* app.js — orchestrates UI */
import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs';
import { AutoFix } from './plugins/diagrammender-mermaid/AutoFix.js';
import { renderMermaid } from './plugins/diagrammender-mermaid/Renderer.js';
import { setupUI } from './plugins/ui/UI.js';

/** Initialize Mermaid & UI */
export function initApp() {
  mermaid.initialize({
    startOnLoad: false,
    securityLevel: 'loose',
    theme: document.documentElement.classList.contains('dark') ? 'dark' : 'default',
    logLevel: 'fatal',
  });

  const els = {
    src: /** @type {HTMLTextAreaElement} */ (document.getElementById('src')),
    out: /** @type {HTMLDivElement} */ (document.getElementById('out')),
    log: /** @type {HTMLPreElement} */ (document.getElementById('log')),
    btn: /** @type {HTMLButtonElement} */ (document.getElementById('btn-render')),
    chkDark: /** @type {HTMLInputElement} */ (document.getElementById('chk-dark')),
  };

  setupUI({ els, mermaid, AutoFix, renderMermaid });
}
