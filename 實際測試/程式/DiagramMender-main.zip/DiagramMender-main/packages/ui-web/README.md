# DiagramMender • UI (Web)

A static ESM demo that:
- parses a Python project (best-effort, client-side) to produce Mermaid diagrams,
- auto-refines Mermaid syntax,
- renders the output for preview.

This is a transitional package while we refactor into the `core/parsers/fix-rules/renderer` architecture.
