// ES6 module entry
import { initApp } from './src/app.js';

// Ensure DOM is ready (ESM executes after parsing but be explicit)
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});
