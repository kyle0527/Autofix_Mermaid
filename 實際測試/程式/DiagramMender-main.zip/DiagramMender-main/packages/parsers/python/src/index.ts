// Python parser plugin placeholder in TypeScript
export interface IRNode {
  kind: string;
  [key: string]: unknown;
}

export interface ParseResult {
  kind: 'ir';
  nodes: IRNode[];
}

export function parsePython(files: File[] | string[]): ParseResult {
  // TODO: move logic from ui-web/plugins/diagrammender-python/ProjectAnalyzer.js
  return { kind: 'ir', nodes: [] };
}
