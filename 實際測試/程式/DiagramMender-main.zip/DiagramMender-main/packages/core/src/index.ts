// Core pipeline placeholder in TypeScript
export interface Emission {
  code: string;
  diagnostics: string[];
}

export type IR = unknown;

export function toIR(parsed: unknown): IR {
  return parsed as IR;
}

export function emitMermaid(ir: IR): Emission {
  return { code: String(ir ?? ''), diagnostics: [] };
}
