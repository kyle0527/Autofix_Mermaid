// Fix-rules placeholder in TypeScript
export interface FixResult {
  code: string;
  notes: string[];
}

export function applyFixes(code: string): FixResult {
  return { code, notes: [] };
}
