#!/usr/bin/env node
// Minimal CLI placeholder
import fs from 'node:fs/promises';

async function main(): Promise<void> {
  const input: string | undefined = process.argv[2];
  if (!input) {
    console.error('Usage: diagrammender <input.mmd>');
    process.exit(1);
  }
  const code = await fs.readFile(input, 'utf-8');
  console.log(code);
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});

